---
title: "Fonte — Urdidura do Vazio"
node_type: "document"
summary: "Índice de proveniência para Urdidura do Vazio ~ TdV(1).docx."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["Urdidura do Vazio"]
tags: ["cânone","fonte-primária","índice"]
properties: {"canon_layer":"primary_source_index","source_document":"Urdidura do Vazio ~ TdV(1).docx","section_count":14}
---
# Fonte — Urdidura do Vazio

Documento-fonte importado de `Urdidura do Vazio ~ TdV(1).docx`. Esta página funciona como índice de proveniência. As páginas abaixo preservam o texto da obra; sínteses transversais aparecem separadamente e permanecem em revisão.

## Seções importadas

- [[../02-urdidura/urdidura-i-antes-da-diferenca|I ~ ANTES DA DIFERENÇA]]
- [[../02-urdidura/urdidura-ii-as-tres-naturezas|II ~ AS TRÊS NATUREZAS]]
- [[../02-urdidura/urdidura-iii-o-reflexo|III ~ O REFLEXO]]
- [[../02-urdidura/urdidura-iv-o-alem-veu|IV ~ O ALÉM-VÉU]]
- [[../02-urdidura/urdidura-v-o-veu-e-a-tessitura|V ~ O VÉU E A TESSITURA]]
- [[../02-urdidura/urdidura-vi-os-dominios-do-medo|VI ~ OS DOMÍNIOS DO MEDO]]
- [[../02-urdidura/urdidura-vii-os-dominios-do-conhecimento|VII ~ OS DOMÍNIOS DO CONHECIMENTO]]
- [[../02-urdidura/urdidura-viii-o-fluxo|VIII ~ O FLUXO]]
- [[../02-urdidura/urdidura-ix-a-anatomia-das-dobras|IX ~ A ANATOMIA DAS DOBRAS]]
- [[../02-urdidura/urdidura-x-a-composicao-humana|X ~ A COMPOSIÇÃO HUMANA]]
- [[../02-urdidura/urdidura-xi-canalizacao|XI ~ CANALIZAÇÃO]]
- [[../02-urdidura/urdidura-xii-as-formas-de-aproximacao|XII ~ AS FORMAS DE APROXIMAÇÃO]]
- [[../02-urdidura/urdidura-xiii-aquilo-que-ainda-nao-possui-nome|XIII ~ AQUILO QUE AINDA NÃO POSSUI NOME]]
- [[../02-urdidura/urdidura-apendice-glossario-da-urdidura|APÊNDICE ~ GLOSSÁRIO DA URDIDURA]]
