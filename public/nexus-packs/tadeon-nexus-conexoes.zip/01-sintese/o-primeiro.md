---
title: "O Primeiro"
node_type: "concept"
summary: "Manifestação antiga do Medo associada à saudade da indistinção e ao impulso de desfazer limites."
status: "review"
visibility: "workspace"
icon: "circle-dot-dashed"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# O Primeiro

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Manifestação antiga do Medo associada à saudade da indistinção e ao impulso de desfazer limites.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
