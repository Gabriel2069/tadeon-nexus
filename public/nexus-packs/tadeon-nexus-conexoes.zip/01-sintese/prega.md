---
title: "Prega"
node_type: "concept"
summary: "Estágio inicial de uma Dobra, quando o Véu começa a ceder e a continuidade inclina-se sem ruptura completa."
status: "review"
visibility: "workspace"
icon: "chevrons-down"
aliases: ["Pregas"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Prega

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Estágio inicial de uma Dobra, quando o Véu começa a ceder e a continuidade inclina-se sem ruptura completa.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
