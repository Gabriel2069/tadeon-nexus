---
title: "Selo"
node_type: "concept"
summary: "Estrutura de contenção e reorganização usada para estabilizar relações alteradas sem apagar automaticamente sua história."
status: "review"
visibility: "workspace"
icon: "badge-check"
aliases: ["Selos","Selagem"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx","Livro de Regras ~ TdV(3).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Selo

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Estrutura de contenção e reorganização usada para estabilizar relações alteradas sem apagar automaticamente sua história.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/regras|Fonte — Livro de Regras]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
