---
title: "A Chama Fria"
node_type: "concept"
summary: "Manifestação axial do Conhecimento, ligada à revelação, conservação e organização sem promessa necessária de consolo."
status: "review"
visibility: "workspace"
icon: "flame"
aliases: ["Chama Fria"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# A Chama Fria

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Manifestação axial do Conhecimento, ligada à revelação, conservação e organização sem promessa necessária de consolo.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
