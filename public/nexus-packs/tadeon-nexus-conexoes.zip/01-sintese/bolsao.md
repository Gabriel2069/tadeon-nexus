---
title: "Bolsão"
node_type: "concept"
summary: "Estágio anatômico da Dobra em que a alteração adquire interioridade e organização local."
status: "review"
visibility: "workspace"
icon: "circle-dashed"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Bolsão

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Estágio anatômico da Dobra em que a alteração adquire interioridade e organização local.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
