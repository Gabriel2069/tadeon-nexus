---
title: "Eclis"
node_type: "concept"
summary: "Domínio do Medo ligado à carne, incorporação, deformação e ameaça ao contorno corporal."
status: "review"
visibility: "workspace"
icon: "bone"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Eclis

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Domínio do Medo ligado à carne, incorporação, deformação e ameaça ao contorno corporal.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
