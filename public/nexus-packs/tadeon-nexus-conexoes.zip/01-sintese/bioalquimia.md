---
title: "Bioalquimia"
node_type: "concept"
summary: "Campo científico da vida, linhagem, materiais cultivados, medicina e contenção biológica."
status: "review"
visibility: "workspace"
icon: "dna"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["O.A. III ~ Ciências de Veth.docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Bioalquimia

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Campo científico da vida, linhagem, materiais cultivados, medicina e contenção biológica.

## Fontes principais

- [[../00-fontes/ciencias|Fonte — Ciências de Veth]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
