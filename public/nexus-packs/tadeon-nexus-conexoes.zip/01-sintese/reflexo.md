---
title: "O Reflexo"
node_type: "concept"
summary: "Realidade estável em que relações repetem-se com fidelidade suficiente para sustentar matéria, vida, memória e escolha."
status: "review"
visibility: "workspace"
icon: "circle-dot"
aliases: ["Reflexo"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx","Urdidura do Vazio ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# O Reflexo

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Realidade estável em que relações repetem-se com fidelidade suficiente para sustentar matéria, vida, memória e escolha.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
