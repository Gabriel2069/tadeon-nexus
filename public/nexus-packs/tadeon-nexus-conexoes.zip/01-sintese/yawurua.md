---
title: "Yawurua"
node_type: "region"
summary: "Território associado ao Lobo Alvor e ao sistema tectônico que também envolve Kitomena e Aotearoa."
status: "review"
visibility: "workspace"
icon: "waves"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx","O.A. IV ~ Geografia de Veth(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Yawurua

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Território associado ao Lobo Alvor e ao sistema tectônico que também envolve Kitomena e Aotearoa.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/geografia|Fonte — Geografia de Veth]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
