---
title: "Furo"
node_type: "concept"
summary: "Forma de ruptura descrita no cenário quando a continuidade deixa de apenas inclinar-se e abre passagem instável."
status: "review"
visibility: "workspace"
icon: "circle-slash-2"
aliases: ["Furos"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Furo

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Forma de ruptura descrita no cenário quando a continuidade deixa de apenas inclinar-se e abre passagem instável.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
