---
title: "Arden"
node_type: "location"
summary: "O planeta e a experiência compartilhada em que se passa Tessitura do Vazio; um mundo cotidiano sustentado por relações profundas."
status: "review"
visibility: "workspace"
icon: "globe-2"
aliases: ["Arden"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Arden

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

O planeta e a experiência compartilhada em que se passa Tessitura do Vazio; um mundo cotidiano sustentado por relações profundas.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
