---
title: "Fio"
node_type: "concept"
summary: "Menor relação ainda percebida como relação; dependência entre partes do mundo, não uma linha material oculta."
status: "review"
visibility: "workspace"
icon: "git-branch"
aliases: ["Fios"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Fio

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Menor relação ainda percebida como relação; dependência entre partes do mundo, não uma linha material oculta.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
