---
title: "Pneumática"
node_type: "concept"
summary: "Campo técnico de pressão, hidráulica, materiais e controle que sustenta máquinas e infraestrutura de precisão."
status: "review"
visibility: "workspace"
icon: "gauge"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["O.A. III ~ Ciências de Veth.docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Pneumática

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Campo técnico de pressão, hidráulica, materiais e controle que sustenta máquinas e infraestrutura de precisão.

## Fontes principais

- [[../00-fontes/ciencias|Fonte — Ciências de Veth]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
