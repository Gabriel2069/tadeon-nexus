---
title: "A Ordem"
node_type: "organization"
summary: "Instituição comparativa dedicada a investigar, classificar e conter relações do Além-Véu sem reivindicar compreensão total."
status: "review"
visibility: "workspace"
icon: "shield"
aliases: ["Ordem"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx","Urdidura do Vazio ~ TdV(1).docx","O.A. III ~ Ciências de Veth.docx"],"editorial_rule":"direct_sources_prevail"}
---
# A Ordem

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Instituição comparativa dedicada a investigar, classificar e conter relações do Além-Véu sem reivindicar compreensão total.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/ciencias|Fonte — Ciências de Veth]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
