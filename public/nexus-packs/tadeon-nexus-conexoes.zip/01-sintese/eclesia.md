---
title: "A Eclésia"
node_type: "organization"
summary: "Estrutura religiosa da Cristandade de Veth, participante histórica das disputas e aproximações entre fé, ciência e Ordem."
status: "review"
visibility: "workspace"
icon: "landmark"
aliases: ["Eclésia"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# A Eclésia

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Estrutura religiosa da Cristandade de Veth, participante histórica das disputas e aproximações entre fé, ciência e Ordem.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
