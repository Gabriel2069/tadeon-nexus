---
title: "Lobo Tramontana"
node_type: "region"
summary: "Grande domínio regional de Veth, com geologia, climas, rios, recursos e tradições técnicas próprias."
status: "review"
visibility: "workspace"
icon: "mountain"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx","O.A. IV ~ Geografia de Veth(1).docx","O.A. III ~ Ciências de Veth.docx"],"editorial_rule":"direct_sources_prevail"}
---
# Lobo Tramontana

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Grande domínio regional de Veth, com geologia, climas, rios, recursos e tradições técnicas próprias.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/geografia|Fonte — Geografia de Veth]]
- [[../00-fontes/ciencias|Fonte — Ciências de Veth]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
