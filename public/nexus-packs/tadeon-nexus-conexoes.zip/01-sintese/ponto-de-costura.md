---
title: "Ponto de Costura"
node_type: "concept"
summary: "Relação crítica pela qual uma alteração pode ser compreendida, tensionada ou selada."
status: "review"
visibility: "workspace"
icon: "crosshair"
aliases: ["Pontos de Costura"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx","Livro de Regras ~ TdV(3).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Ponto de Costura

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Relação crítica pela qual uma alteração pode ser compreendida, tensionada ou selada.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/regras|Fonte — Livro de Regras]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
