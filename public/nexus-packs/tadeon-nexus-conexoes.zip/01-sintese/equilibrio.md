---
title: "Equilíbrio"
node_type: "rule"
summary: "Medida dinâmica de inteireza entre corpo, consciência e história diante das pressões de Medo e Conhecimento ao longo do Tempo."
status: "review"
visibility: "workspace"
icon: "scale"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Livro de Regras ~ TdV(3).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Equilíbrio

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Medida dinâmica de inteireza entre corpo, consciência e história diante das pressões de Medo e Conhecimento ao longo do Tempo.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/regras|Fonte — Livro de Regras]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
