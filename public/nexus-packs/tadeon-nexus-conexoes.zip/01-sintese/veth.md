---
title: "Veth"
node_type: "region"
summary: "Conjunto de massas, mares internos, arquipélagos e rotas que concentra a maior parte da humanidade conhecida de Arden."
status: "review"
visibility: "workspace"
icon: "map"
aliases: ["Veth e o mundo conhecido"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx","O.A. IV ~ Geografia de Veth(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Veth

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Conjunto de massas, mares internos, arquipélagos e rotas que concentra a maior parte da humanidade conhecida de Arden.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/geografia|Fonte — Geografia de Veth]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
