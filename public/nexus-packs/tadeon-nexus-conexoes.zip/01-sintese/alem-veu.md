---
title: "Além-Véu"
node_type: "concept"
summary: "Nome humano para aquilo que excede a organização estável do Reflexo sem constituir um país ou espaço separado."
status: "review"
visibility: "workspace"
icon: "cloud"
aliases: ["O Além-Véu"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Além-Véu

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Nome humano para aquilo que excede a organização estável do Reflexo sem constituir um país ou espaço separado.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
