---
title: "O Véu"
node_type: "concept"
summary: "Conjunto vivo de relações que mantém pessoas, lugares e coisas pertencendo ao mundo humano; organiza e traduz, em vez de simplesmente bloquear."
status: "review"
visibility: "workspace"
icon: "layers-3"
aliases: ["Véu"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# O Véu

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Conjunto vivo de relações que mantém pessoas, lugares e coisas pertencendo ao mundo humano; organiza e traduz, em vez de simplesmente bloquear.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
