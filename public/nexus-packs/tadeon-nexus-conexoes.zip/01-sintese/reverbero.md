---
title: "Revérbero"
node_type: "location"
summary: "Dobra estabilizada: não necessariamente segura, mas quieta o bastante para integrar-se à história do lugar."
status: "review"
visibility: "workspace"
icon: "radio"
aliases: ["Revérberos"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Revérbero

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Dobra estabilizada: não necessariamente segura, mas quieta o bastante para integrar-se à história do lugar.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
