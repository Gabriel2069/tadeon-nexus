---
title: "Ancoragem"
node_type: "concept"
summary: "Fixação pela qual uma alteração encontra relações suficientes para permanecer e aprofundar-se."
status: "review"
visibility: "workspace"
icon: "anchor"
aliases: ["Âncora","Âncoras"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx","Arden ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Ancoragem

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Fixação pela qual uma alteração encontra relações suficientes para permanecer e aprofundar-se.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]
- [[../00-fontes/arden|Fonte — Arden]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
