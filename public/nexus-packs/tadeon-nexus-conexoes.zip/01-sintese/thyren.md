---
title: "Thyren"
node_type: "concept"
summary: "Domínio do Medo ligado ao oculto, à distância e ao que não pode ser confirmado."
status: "review"
visibility: "workspace"
icon: "eye-off"
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Urdidura do Vazio ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail"}
---
# Thyren

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Domínio do Medo ligado ao oculto, à distância e ao que não pode ser confirmado.

## Fontes principais

- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
