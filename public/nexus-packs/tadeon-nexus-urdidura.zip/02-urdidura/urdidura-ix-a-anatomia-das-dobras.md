---
title: "Urdidura do Vazio — IX ~ A ANATOMIA DAS DOBRAS"
node_type: "concept"
summary: "Seção “IX ~ A ANATOMIA DAS DOBRAS” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["IX ~ A ANATOMIA DAS DOBRAS"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"IX ~ A ANATOMIA DAS DOBRAS","source_order":9,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# IX ~ A ANATOMIA DAS DOBRAS

## Dobra

Uma Dobra ocorre quando os Fios de uma malha deixam de acompanhar a disposição habitual do Reflexo. Eles cedem à direção de outra organização, aproximam relações que normalmente permaneceriam distribuídas e criam tensão entre a forma atual do lugar e a forma que começa a tornar-se possível.

Nem toda Dobra é ruptura. Tramas são Dobras artificiais temporárias. Uma obra, um juramento ou uma mudança coletiva também podem dobrar relações em sentido amplo, embora não alcancem necessariamente a profundidade metafísica que produz passagem. A palavra descreve desvio de continuidade; o estado da malha determina o fenômeno que surgirá.

Dobras naturais podem nascer de pressão primordial, trauma, repetição, perda de continuidade, presença de Fragmentos, Canalização, conflito entre Selos, convergência de Assinaturas ou processos que nenhuma investigação consegue reduzir a uma causa isolada. O motivo humano e a anatomia cosmológica nem sempre coincidem.

Prega é pressão. Bolsão é passagem. Ancoragem é fixação.

## Prega

Prega é o movimento em que o Véu começa a ceder sem ter sido atravessado. A malha local inclina-se, distribui tensão de forma irregular e produz pequenas incompatibilidades. O Reflexo ainda possui continuidade suficiente para recompor-se.

O Pré-Furo é a expressão reconhecível dessa fase. Sonhos convergem, animais evitam um ponto, objetos parecem deslocados, sons chegam sem origem clara e memórias apresentam pequenas falhas. Nenhum sinal prova sozinho uma Prega. O padrão está na maneira pela qual alterações distintas apontam para a mesma tensão.

Intervenções precoces podem impedir o aprofundamento sem requerer Selagem formal. Reparar uma estrutura, restaurar uma prática, reconhecer uma perda, afastar um Fragmento ou simplesmente interromper a repetição que sustenta a pressão pode oferecer ao Véu relações suficientes para recuperar sua forma.

## Bolsão

Bolsão é o movimento em que a Dobra atravessa o Véu e começa a ocupar o Reflexo de maneira instável. Forma-se uma passagem, não necessariamente espacial. Relações de outra malha adquirem expressão local e pressionam o ambiente para conservar coerência.

O Furo é a forma territorial do Bolsão. Pode ser fraco, ativo ou crítico segundo a profundidade alcançada. Enquanto não se fixa, depende da tensão que o alimenta. Pode pulsar, crescer, recuar e fechar-se. Uma manifestação atravessada por Furo continua ligada à malha de origem de modo diferente de um Fragmento desprendido.

Fechar um Furo é impedir que a passagem complete Ancoragem. O Selo oferece a borda, reorganiza a Significância, Linguagem, Memória e outras relações locais, devolvendo ao Reflexo capacidade para afirmar sua própria continuidade.

## Ancoragem

Ancoragem ocorre quando a Dobra encontra no Reflexo relações capazes de sustentá-la sem depender inteiramente da pressão que a produziu. A malha local deixa de apenas sofrer presença e passa a participar de sua organização.

A Âncora é a Dobra fixada. Não é o objeto, a pessoa, a árvore, o altar ou a ruína que serve como foco visível. Esses elementos podem concentrar expressão ou funcionar como Ponto de Costura. A Âncora pertence ao território de relações que aprendeu a manter a malha invasora.

Por isso não pode ser carregada como Fragmento e não retorna simplesmente para além do Véu. Destruir o foco pode espalhar, ocultar ou intensificar a fixação. Selar uma Âncora significa contê-la ou pacificá-la, separando relações que ainda podem retornar daquelas que já se tornaram parte da história do lugar.

## Zona de Aspecto

Quando uma Âncora aprofunda-se até reorganizar território, surge uma Zona de Aspecto. O Domínio não apenas manifesta efeitos dentro da região. Passa a definir parte das condições pelas quais espaço, corpo, memória, linguagem ou sequência funcionam ali.

Uma Zona de Eclis pode desenvolver ecossistemas que tratam visitantes como matéria incompleta. Morae pode distribuir identidades entre habitantes. Thyren pode retirar regiões inteiras de todo sistema de percepção. Zha’el pode converter valor social em consequência física. Domínios do Conhecimento podem conservar versões únicas da história, impedir tradução ou preservar pessoas numa forma sem mudança.

Reconquistar uma Zona não é apagar tudo que ocorreu. Habitantes, ruínas, práticas e novas formas de vida podem depender de relações produzidas pela territorialização. A operação precisa devolver escolha e pluralidade sem fingir que o lugar pode regressar a um passado intacto.

## Revérbero

Revérbero é uma Dobra estabilizada. Pode surgir quando uma Âncora é pacificada ou quando uma alteração encontra equilíbrio natural antes de tornar-se ameaça ativa. A ligação com a malha primordial permanece, mas já não há Tensão conduzindo ao aprofundamento.

Estável não significa seguro. Um Revérbero conserva Assinatura, facilita Tramas compatíveis e pode produzir pulsos quando perturbado. Extração, destruição de relações mantenedoras, perda de Significância ou contato com outra Dobra podem devolver movimento ao que parecia inerte.

Revérberos de Conhecimento são especialmente comuns porque Memória, Linguagem e Significância encontram formas sociais de permanência. Podem existir como bibliotecas, santuários, cidades, arquivos ou tradições. Revérberos de Medo costumam parecer mais viscerais, mas também podem estabilizar-se em ecossistemas, tabus, respostas corporais e territórios.

Um Revérbero é uma cicatriz. A palavra não diminui o acontecimento. Indica que o Reflexo encontrou a maneira de continuar sem retornar à forma anterior.

Furos se fecham. Âncoras se cercam. Zonas se reconquistam. Revérberos permanecem.

## Fragmentos

Fragmento é o retalho deixado quando uma Dobra se desfaz de maneira incompleta. A maior parte dos Fios retorna ou perde expressão, mas um padrão permanece separado da malha original, conservando Assinatura e tensão próprias.

Ele não é um pedaço pronto de uma entidade que caiu no mundo. É memória estrutural de uma relação que o Reflexo aprendeu e não conseguiu esquecer por inteiro. Pode assumir forma mineral, orgânica, mecânica, sonora, textual ou difícil de classificar. A forma visível é a expressão que encontrou, não sua totalidade.

Fragmentos facilitam a Canalização porque oferecem um padrão já percorrido. O canalizador não precisa alcançar a mesma profundidade para aproximar determinados Fios. Essa facilidade possui limite: o Fragmento conduz a Trama segundo sua Assinatura e restringe possibilidades que não reconhece.

## Selos

Selo é estrutura de continuidade. Símbolos podem participar, mas nenhuma figura geométrica possui eficácia isolada. Um Selo reconhece a Natureza e a Assinatura da Dobra, estabelece borda e fixa essa borda a relações que o Reflexo consegue sustentar.

Há Selos mantidos por arquitetura, palavras, calendários, mecanismos, cultivos, canções, peregrinações, arquivos, cuidados e hábitos. Muitos funcionam sem que a comunidade conheça sua cosmologia. Isso não os torna fé cega. Significa que compreensão pode existir distribuída em prática, mesmo quando ninguém consegue formulá-la por inteiro.

Selagem não é expulsão automática. Pregas podem ser aliviadas; Furos, fechados; Âncoras, contidas ou pacificadas; Zonas, reduzidas e reconquistadas. Revérberos podem precisar apenas de manutenção. O resultado depende do estado da malha, não da força com que um símbolo é imposto.

## Pontos de Costura

Toda manifestação persistente depende de relações específicas. Ponto de Costura é o nome dado à dependência cuja alteração modifica a estabilidade do fenômeno. Pode ser nome, ausência, posição, memória, sequência, vínculo, contradição, corpo, promessa ou qualquer relação que a Assinatura não consegue perder sem tornar-se outra coisa.

O Ponto de Costura não é necessariamente fraqueza. Uma manifestação pode protegê-lo, ignorá-lo ou sequer reconhecê-lo como separado. Descobri-lo significa compreender por que a Dobra encontrou continuidade naquele lugar e qual relação ainda lhe permite permanecer.

Duas ameaças do mesmo Domínio não compartilham a mesma Costura. Linguagem pode enfraquecer uma presença de Thyren e alimentar outra. Certeza pode resistir a Morae ou tornar-se o instrumento que ela utiliza. A cosmologia oferece gramática; a história local decide a frase.
