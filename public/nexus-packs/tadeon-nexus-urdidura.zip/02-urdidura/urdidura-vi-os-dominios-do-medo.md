---
title: "Urdidura do Vazio — VI ~ OS DOMÍNIOS DO MEDO"
node_type: "concept"
summary: "Seção “VI ~ OS DOMÍNIOS DO MEDO” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["VI ~ OS DOMÍNIOS DO MEDO"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"VI ~ OS DOMÍNIOS DO MEDO","source_order":6,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# VI ~ OS DOMÍNIOS DO MEDO

## O que significa um Domínio

Domínio é um modo recorrente pelo qual uma Natureza organiza relações. Não é uma subdivisão administrativa do Além-Véu, nem uma entidade individual. Eclis, Morae, Thyren e Zha’el são profundidades reconhecíveis do Medo, gramáticas pelas quais limite, perda e incorporação adquirem expressão.

Um Primevo pode surgir dentro de um Domínio quando uma Assinatura alcança coerência suficiente para preservar comportamento próprio. Uma Zona de Aspecto aparece quando a lógica de um Domínio territorializa-se no Reflexo. O Aspecto é a forma regional dessa presença, não o Domínio inteiro.

Nenhuma manifestação esgota sua origem. Derrotar uma criatura de Eclis não diminui Eclis. Pacificar uma Âncora de Morae não remove a dúvida do universo. Os Domínios não são inimigos finais. São possibilidades constitutivas que se tornam ameaças quando deixam de reconhecer proporção, limite ou escolha.

## Eclis ~ o que devora a carne

Eclis é o Domínio pelo qual o Medo encontra corpo, sensação, metabolismo, dor, crescimento e incorporação. Sua raiz não está no horror de carne deformada. Está no primeiro limite vivo que precisou distinguir o que deveria entrar, o que deveria ser expulso e o que precisava ser destruído para que a forma continuasse.

Toda cicatrização participa de Eclis. Também participam a fome, a imunidade, o prazer, a repulsa, a reprodução e o reflexo que afasta um membro do fogo antes que a consciência formule perigo. O corpo não é recipiente passivo. É uma malha que decide incessantemente o que pode tornar-se parte dela.

O horror começa quando a incorporação perde reconhecimento de exterior. Uma ferida continua reparando-se depois de fechada. Um organismo trata o próprio corpo como invasor. Uma casa distribui funções como órgãos. Uma comunidade transforma cuidado em assimilação e chama de cura tudo que remove a diferença.

Manifestações de Eclis costumam produzir uma gramática sensorial intensa: calor, pressão, umidade, pulso, odor, fome, coceira, dor ou prazer deslocado. Essa gramática não é uma lista obrigatória. Uma Assinatura pode expressar Eclis por ausência completa de sensação, fazendo do corpo algo incapaz de reconhecer que já está sendo incorporado.

Resistências a Eclis frequentemente envolvem limite consciente, suspensão de sensação, reconhecimento de autonomia ou recusa da assimilação. Nenhuma delas é fraqueza universal. O Ponto de Costura depende da relação específica que permitiu à manifestação confundir permanecer com absorver.

Eclis não deseja carne. Deseja que nada permaneça estrangeiro ao corpo que escolheu como mundo.

## Morae ~ a que dilui a mente

Morae é o Domínio pelo qual o Medo encontra mente, autoria, interpretação e identidade. Surge da possibilidade de que a consciência deixe de confiar na relação entre aquilo que percebe e aquilo que chama de si.

Mudar não é dissolver-se. Toda pessoa abandona convicções, esquece, aprende e descobre que partes de sua história foram compreendidas de maneira incompleta. Morae cresce quando a malha já não consegue distinguir transformação de substituição. O pensamento pode ser verdadeiro e ainda parecer estrangeiro; a lembrança pode ser falsa e sustentar toda uma vida.

Seu horror raramente começa com delírio completo. Começa na hesitação que não encontra onde repousar. Em uma palavra que parece ter sido usada de outro modo. Em um afeto que chega sem origem reconhecível. Quando duas pessoas recordam uma intimidade que nunca compartilharam. A mente procura um ponto externo de confirmação e encontra apenas outras versões de si.

Morae pode manifestar-se em indivíduos, grupos e instituições. Um arquivo pode alterar documentos para conservar a versão que acredita ter sempre possuído. Uma cidade pode atribuir a mesma infância a habitantes diferentes. Uma família pode produzir identidade coletiva tão densa que nenhuma lembrança particular consegue contradizê-la.

Certeza de identidade, testemunho recíproco e presença encarnada costumam oferecer resistência. Ainda assim, uma manifestação pode justamente alimentar-se de certezas rígidas. O Ponto de Costura não é declarar “quem sou” como fórmula. É recuperar a relação pela qual uma consciência pode mudar sem perder autoria sobre a própria mudança.

## Thyren ~ a que sussurra no escuro

Thyren é o Domínio pelo qual o Medo encontra ausência, distância, percepção incompleta e aquilo que não pode ser confirmado. A escuridão pertence a Thyren apenas porque torna visível a insuficiência dos sentidos. O Domínio continua presente sob plena luz, em tudo que permanece fora do campo de atenção.

Nenhuma consciência percebe o mundo inteiro. Viver exige selecionar. Sons tornam-se fundo, rostos passam sem registro, estruturas que sustentam uma cidade desaparecem da experiência de quem apenas usufrui seus efeitos. Essa limitação protege a mente. Também oferece lugares onde algo pode existir sem ser reconhecido.

Uma manifestação de Thyren não precisa esconder criaturas. Pode remover a capacidade de notar uma porta, uma pessoa ou uma consequência. Pode separar origem e som, presença e sombra, registro e objeto. Pode fazer com que uma comunidade veja um sofrimento diariamente e ainda não consiga incluí-lo na descrição de sua própria realidade.

Linguagem deliberada frequentemente oferece resistência porque nomear recoloca algo numa malha compartilhada. Medir, iluminar, testemunhar e repetir também podem fazê-lo. Porém, uma Assinatura de Thyren pode ocupar precisamente os nomes, transformando a descrição em forma de ocultação. Perceber não é apenas olhar. É permitir que o percebido altere a organização do que se considera real.

Thyren não é a ameaça escondida no escuro. É a parte do mundo que cresce e permanece fora de tudo que poderia confirmá-la.

## Zha’el ~ o que julga do alto

Zha’el é o Domínio pelo qual o Medo encontra valor, merecimento, comparação, culpa, hierarquia e julgamento. Ele nasce onde uma forma consciente depende de outras para reconhecer posição, pertencimento e direito de continuar.

Julgar não é sempre violência. Comunidades precisam distinguir cuidado e dano; pessoas precisam responder por escolhas; medidas permitem construir, trocar e reparar. Zha’el aproxima-se quando a medida deixa de servir à vida e passa a exigir que toda vida justifique a própria existência diante dela.

Religião pode tornar-se linguagem de Zha’el, mas não possui exclusividade. Direito, ciência, beleza, produtividade, honra, linhagem, pureza, eficiência e amor familiar podem receber a mesma deformação. O Domínio ocupa qualquer sistema de Significância capaz de transformar diferença em falta inevitável.

Suas manifestações constroem escalas que nunca permitem suficiência. O sacrifício prova culpa em vez de encerrá-la. A perfeição alcançada muda a medida. A absolvição torna-se novo teste. Uma pessoa é reduzida ao pior ato, à origem, ao corpo, à utilidade ou à profecia que outros lhe atribuíram.

Recusar julgamento não significa negar consequência. Muitas Costuras de Zha’el exigem admitir responsabilidade sem aceitar que responsabilidade esgote a identidade. Outras exigem destruir a própria escala, revelar quem lucra com ela ou devolver à medida a função limitada que possuía antes de tornar-se mundo.

## O Primeiro ~ a saudade da indistinção

O Primeiro é a manifestação mais antiga reconhecível do Medo. Não porque tenha surgido antes do Tempo, algo que nenhuma origem poderia fazer, mas porque se aproxima do medo anterior a todo objeto: a possibilidade de que existir como diferença tenha sido a primeira perda.

Textos humanos dizem que o Primeiro é saudoso. A palavra concede-lhe emoção, mas alcança uma verdade. Todas as suas manifestações tendem ao retorno da inteireza anterior. Não a uma união em que formas permanecem relacionadas, mas ao estado em que nenhuma separação exige cuidado, escolha ou consequência.

Ele não comanda os Domínios como soberano. É reconhecido através deles quando sua direção se aproxima da dissolução total. Eclis o revela quando tudo se torna um único corpo. Morae, quando nenhuma identidade conserva autoria. Thyren, quando presença e ausência já não podem ser distinguidas. Zha’el, quando toda existência recebe o mesmo julgamento: ter-se separado foi a falta original.

O Primeiro pode manifestar-se sem que os quatro Domínios apareçam em igual proporção. A convergência amplia sua proximidade porque reúne caminhos diferentes para a mesma indistinção, mas não funciona como ritual inevitável. O Reflexo possui incontáveis maneiras de perder diferença.

Talvez o Primeiro não queira destruir. Talvez “querer” seja apenas o modo humano de nomear uma pressão anterior à malícia. Isso não reduz o perigo. Uma maré não precisa odiar uma cidade para apagá-la da costa.

O Primeiro não é cruel. É saudoso. E sua saudade não consegue compreender que tudo o que ama no Vazio desapareceria se o Vazio voltasse a ser inteiro.

## Primevos

Primevos são manifestações de alta ordem que adquiriram coerência própria dentro de um ou mais Domínios. Não são filhos do Primeiro nem fragmentos menores de uma pessoa primordial. São padrões que se repetiram, alimentaram e reconheceram até preservar comportamento através de diferentes expressões.

Alguns Primevos parecem conscientes. Planejam, respondem, lembram e utilizam linguagem. Outros possuem inteligência semelhante à de um ecossistema, uma doença ou uma corrente. A distinção entre vontade real e Assinatura complexa nem sempre pode ser feita do interior de uma manifestação.

Um Primevo não precisa possuir corpo constante. Pode aparecer em criaturas, sonhos, arquiteturas, cultos, sintomas ou sequências de acontecimentos. O que permanece é a organização relacional que torna essas expressões parte da mesma presença.
