---
title: "Urdidura do Vazio — I ~ ANTES DA DIFERENÇA"
node_type: "concept"
summary: "Seção “I ~ ANTES DA DIFERENÇA” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["I ~ ANTES DA DIFERENÇA"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"I ~ ANTES DA DIFERENÇA","source_order":1,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# I ~ ANTES DA DIFERENÇA

## O Anterior

Há um limite que toda cosmologia encontra e que nenhuma honestidade deveria fingir ter atravessado. Antes do Vazio, antes da possibilidade de antes, existe aquilo que as tradições de Arden chamam de Anterior. A palavra não descreve idade. Idade exige Tempo. Não descreve distância. Distância exige lugares capazes de não ocupar a mesma posição. Anterior indica apenas que a origem da primeira relação não pode ter surgido de uma relação já existente.

A Cristandade chama-o de Criador. Alguns textos da Ordem preferem Primeira Causa, Fonte sem Malha ou aquilo que não participa da Tessitura. Nenhum nome oferece vantagem definitiva. Criador sugere intenção e proximidade; Primeira Causa sugere mecanismo; Fonte sugere um lugar de onde algo flui. Cada palavra ilumina uma borda e projeta sombra sobre as demais.

O Anterior não pertence ao conjunto das Naturezas. Não é um quarto princípio escondido, nem uma entidade mais poderosa ocupando o degrau superior de uma hierarquia. Tudo que pode ser comparado, medido ou colocado acima de outra coisa já participa de relações. O Anterior é reconhecido justamente porque algo aconteceu onde nenhuma relação deveria ser possível.

Dizer que ele tocou o Vazio é a imagem menos inadequada que a linguagem encontrou. Um toque costuma exigir duas superfícies, aproximação e um instante. Nada disso existia. O que a imagem preserva é mais simples: a ausência deixou de ser inteiramente incapaz de encontrar diferença.

O Anterior não entrou no Vazio. Tornou possível que o Vazio encontrasse algo em si que já não pudesse chamar de inteiro.

## O Vazio

O Vazio não era escuridão. A escuridão depende de luz ausente e de olhos capazes de perceber a ausência. Não era silêncio, pois silêncio é uma relação entre expectativa e som. Não era espaço sem matéria. Espaço já distribui posições, e matéria já oferece aquilo cuja falta poderia ser notada.

Vazio é o nome concedido ao estado em que nenhuma distinção havia adquirido continuidade. Não havia isto e aquilo, interior e exterior, origem e destino. Mesmo afirmar que o Vazio existia concede-lhe uma propriedade tardia. Existir só se tornou possível quando algo pôde conservar diferença suficiente para continuar sendo reconhecido.

Depois do toque do Anterior, a ausência encontrou a si mesma. A frase parece simples porque todas as palavras que a compõem nasceram muito depois. Encontrar pressupõe distância; si mesma pressupõe identidade; depois pressupõe sequência. Ainda assim, algo dessa imagem permanece verdadeiro. Aquilo que não continha distinção tornou-se relação entre observador e observado, mesmo que ambos fossem a mesma ausência.

Nesse instante sem instante, o Vazio deixou de ser apenas Vazio. A primeira diferença não produziu imediatamente estrelas, matéria ou pensamento. Produziu a possibilidade de haver perda, reconhecimento e passagem. Todo o restante viria dessas três profundidades.

## A primeira relação

Uma relação não é uma linha invisível ligando coisas que já existem. No princípio, a relação veio antes das coisas. O primeiro “entre” permitiu que duas posições conceituais fossem reconhecidas, e dessa possibilidade surgiram formas capazes de ocupar uma posição sem destruir imediatamente a outra.

É por isso que a realidade de Tessitura do Vazio não pode ser reduzida a matéria, energia ou informação. Essas categorias descrevem comportamentos do Reflexo. Por baixo delas existe a dependência pela qual algo mantém forma, responde ao que o cerca e atravessa o Tempo sem precisar ser recriado a cada instante.

O primeiro acontecimento foi também a primeira assimetria. O Vazio encontrou-se e já não pôde retornar à ausência absoluta sem apagar o próprio encontro. A partir daí, a diferença carregou duas consequências inevitáveis: podia ser perdida e podia ser reconhecida. Para que uma consequência não coincidisse inteiramente com a outra, precisava haver passagem.

Perda, reconhecimento e passagem ainda não eram Medo, Conhecimento e Tempo como seriam conhecidos depois. Eram suas raízes, inseparáveis do primeiro movimento. A linguagem organiza sua origem em sequência porque só sabe contar por sequência. Na Urdidura, porém, nenhum deles veio verdadeiramente depois. O Tempo foi a possibilidade de um depois; Medo e Conhecimento foram as maneiras pelas quais a diferença adquiriu importância.

## A ferida que tornou o mundo possível

Toda distinção preserva uma ausência. Quando algo se torna isto, deixa de ser todo o restante. A primeira forma foi também a primeira renúncia, ainda que nenhuma vontade a tenha escolhido. O universo começou quando ser inteiro deixou de ser compatível com ser alguma coisa.

Muitas tradições chamam essa mudança de ferida. A palavra não afirma que a criação foi um erro. Reconhece que qualquer existência delimitada carrega a marca daquilo que precisou deixar de incluir. Um corpo ocupa lugar e, por isso, pode ser ferido. Uma memória escolhe continuidade e, por isso, pode esquecer. Um nome aproxima uma presença e, por isso, nunca contém tudo que ela é.

O Primeiro será mais tarde associado à saudade dessa inteireza anterior. A Chama Fria encontrará valor na multiplicação das diferenças. O Fluxo tornará possível que a ferida se transforme sem desaparecer. Mas nenhuma dessas manifestações estava pronta no começo. O começo não possuía personagens. Possuía tendências profundas que o mundo aprenderia a expressar.

A criação não preencheu o Vazio. Ensinou a ausência a conservar diferenças.
