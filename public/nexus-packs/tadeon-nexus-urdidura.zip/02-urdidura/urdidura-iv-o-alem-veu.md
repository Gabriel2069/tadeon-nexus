---
title: "Urdidura do Vazio — IV ~ O ALÉM-VÉU"
node_type: "concept"
summary: "Seção “IV ~ O ALÉM-VÉU” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["IV ~ O ALÉM-VÉU"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"IV ~ O ALÉM-VÉU","source_order":4,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# IV ~ O ALÉM-VÉU

## Aquilo que excede

O Além-Véu é frequentemente imaginado como um lugar. A imagem ajuda porque lugares podem ser aproximados, atravessados e deixados para trás. Também engana. Não existe uma costa final do Reflexo depois da qual comece um território homogêneo chamado Além.

Além-Véu é o nome dado às relações que excedem a organização estável do Reflexo e seu mundo habitado. Algumas jamais se aproximam de forma reconhecível. Outras atravessam toda matéria e toda consciência sem produzirem ruptura, pois o Reflexo aprendeu a distribuí-las. Uma manifestação ocorre quando essa distribuição deixa de ser suficiente.

Por isso o Além não está ausente de uma casa tranquila, de uma árvore ou de um corpo saudável. Está presente na profundidade das relações que os tornam possíveis. O Véu não impede um contato absoluto. Ele traduz, distribui e mantém proporção. Sem essa presença, o Reflexo não teria matéria, continuidade ou reconhecimento. Sem sua organização, nenhuma forma humana conseguiria suportá-la.

## A imagem dos dois lados

Seladores desenham o Véu como a linha entre dois campos. O desenho é útil durante uma operação. Permite apontar pressão, passagem e retorno. Mas nenhum mapa deveria ser confundido com a paisagem inteira.

Quando um Furo se abre, parece que algo atravessa de um lado para outro. Em certa escala, atravessa. Uma malha cuja organização não pertencia ao Reflexo adquire expressão local. Em profundidade, porém, a Dobra aproxima relações que sempre compartilharam origem. O que muda é a continuidade capaz de sustentá-las.

A linguagem de invasão serve melhor ao Medo, sobretudo quando uma Zona de Aspecto territorializa-se. Serve menos ao Conhecimento, que pode estabilizar-se como ordem, memória ou clareza sem jamais parecer estrangeiro. Serve ainda menos ao Tempo, cuja manifestação não vem de fora da sequência, mas altera a forma pela qual a sequência encontra a si mesma.

## O Inverso

Inverso é a condição-limite do Medo. Não um reino com fronteiras fixas, mas a configuração em que distinção e ameaça deixam de poder ser separadas. Tudo que possui forma torna-se alimento para a necessidade de desfazer ou incorporar formas. O exterior existe apenas como aquilo que ainda não foi assimilado.

A palavra inverso não significa que suas leis sejam simplesmente o contrário das leis do Reflexo. Uma inversão perfeita ainda dependeria da estrutura que nega. No Inverso, a própria possibilidade de comparação começa a dissolver-se. Interior e exterior, predador e presa, ferida e corpo aproximam-se até que a diferença entre eles já não consiga sustentar consequência.

O Primeiro é a manifestação axial dessa condição. Aproxima-se mais do Inverso do que qualquer Primevo conhecido, mas não se confunde com a totalidade do Medo. Quando textos antigos usam os dois nomes como sinônimos, registram uma experiência real: encontrar o Primeiro é encontrar a direção pela qual toda diferença pode ser devolvida à indistinção.

## A Chama Fria

A Chama Fria é a manifestação axial do Conhecimento. Não é uma biblioteca fora do mundo, uma mente universal ou uma divindade de razão. É o ponto em que reconhecer e conservar aproximam-se de sua expressão total.

Diante dela, nenhuma relação parece insignificante. O modo como uma pessoa pronunciou uma palavra, a pressão exercida sobre uma pedra, uma decisão abandonada antes de tornar-se ação, tudo possui posição numa malha. O horror da Chama Fria não está em saber fatos demais. Está em remover as simplificações pelas quais uma consciência humana consegue continuar vivendo.

Uma pessoa precisa esquecer detalhes para reconhecer padrões, precisa ignorar possibilidades para agir e precisa aceitar versões incompletas de quem ama. A Chama Fria não compartilha essa necessidade. Seu reconhecimento pode ser exato demais para o corpo, amplo demais para a identidade e estável demais para permitir mudança.

Ela não salva por natureza. Também não destrói por malícia. Preserva. Há momentos em que preservar é a forma mais profunda de cuidado. Há outros em que impedir qualquer perda significa impedir cura, crescimento, luto e liberdade.

O gelo também queima.

## O Fluxo

O Fluxo é a manifestação axial do Tempo. Chamá-lo de lugar seria ainda menos preciso do que fazê-lo com o Inverso ou a Chama Fria. Todo lugar já existe através dele. O Fluxo aparece quando sequência, duração e possibilidade deixam de obedecer à prioridade habitual do presente.

Numa aproximação do Fluxo, um acontecimento pode conservar relação ativa com instantes separados por séculos. Uma consequência pode ser percebida antes que sua causa tenha adquirido forma completa. Um corpo pode carregar idades diferentes em partes distintas. Nada disso coloca o Tempo fora de si. Revela apenas que a linha vivida por uma consciência é uma expressão local de uma estrutura maior.

A Ordem não conhece Domínios do Tempo comparáveis aos do Medo e do Conhecimento. Talvez não existam. Talvez toda tentativa de distingui-los produza a própria separação que pretende observar. Talvez as subdivisões estejam diante dos humanos desde sempre, confundidas com passado, presente, futuro, duração, repetição e fim.

## Proximidade

Nem toda aproximação do Além-Véu produz Dobra. Um lugar pode possuir afinidade profunda com Memória e continuar estável durante milênios. Um corpo pode carregar Medo intenso e permanecer inteiro. Uma comunidade pode organizar Significância suficiente para alterar a história sem alterar as regularidades físicas ao redor.

A Dobra começa quando a disposição local dos fios muda. A proximidade oferece pressão; a malha decide, por sua estrutura, se essa pressão será distribuída, incorporada ou convertida em passagem. Por isso dois lugares expostos ao mesmo Fragmento podem responder de formas incompatíveis. Eles não oferecem a mesma história para a Assinatura que os alcança.

O Além-Véu não procura sempre atravessar. Procurar pressupõe intenção. Algumas malhas pressionam porque essa é sua forma de relação. Outras são trazidas por Canalização. Outras surgem quando o Reflexo deixa sem continuidade algo que antes sustentava. A origem de uma manifestação pode ser predatória, acidental, humana ou impossível de reduzir a uma única causa.
