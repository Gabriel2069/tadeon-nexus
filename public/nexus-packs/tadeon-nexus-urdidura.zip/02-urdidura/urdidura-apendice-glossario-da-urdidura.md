---
title: "Urdidura do Vazio — APÊNDICE ~ GLOSSÁRIO DA URDIDURA"
node_type: "concept"
summary: "Seção “APÊNDICE ~ GLOSSÁRIO DA URDIDURA” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["APÊNDICE ~ GLOSSÁRIO DA URDIDURA"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"APÊNDICE ~ GLOSSÁRIO DA URDIDURA","source_order":14,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# APÊNDICE ~ GLOSSÁRIO DA URDIDURA

Anterior / Criador

Origem reconhecida antes da primeira relação. Não pertence à Tessitura nem constitui uma quarta Natureza.

Vazio

Estado anterior à continuidade de qualquer distinção. Não é espaço, escuridão ou ausência de matéria.

Natureza

Origem primordial de um conjunto de relações. As Naturezas conhecidas são Medo, Conhecimento e Tempo.

Tempo

Natureza da sequência, duração, transformação e consequência.

Fluxo

Manifestação axial do Tempo.

Medo

Natureza do limite, incorporação, resistência, perda e dissolução.

Primeiro

Manifestação axial mais antiga reconhecível do Medo, orientada à indistinção.

Inverso

Condição-limite do Medo em que distinção e ameaça deixam de ser separáveis.

Conhecimento

Natureza da distinção, do reconhecimento, da continuidade e da relação significativa.

Chama Fria

Manifestação axial do Conhecimento.

Reflexo

Realidade relacional estável em que as três Naturezas se expressam de forma compatível com continuidade.

Além-Véu

Conjunto de relações que excedem a organização estável do Reflexo. Não é apenas um lugar exterior.

Véu

Malha viva de relações que traduz, distribui e mantém as Naturezas em formas vivíveis no Reflexo.

Fio

Dependência mínima ainda perceptível como relação.

Malha

Conjunto de Fios que sustenta uma forma comum.

Tessitura

Estrutura relacional completa formada por Fios e Malhas; também seu campo de estudo.

Urdidura

Organização profunda da Tessitura que oferece direção e continuidade para padrões.

Assinatura

Padrão particular pelo qual uma malha, manifestação, Fragmento ou Trama organiza Fios.

Domínio

Modo recorrente pelo qual uma Natureza organiza relações.

Primevo

Manifestação de alta ordem que adquiriu coerência própria dentro de um ou mais Domínios.

Aspecto

Forma territorial assumida por um Domínio numa região reorganizada por Dobra.

Eclis

Domínio do Medo ligado a corpo, sensação, metabolismo, crescimento e incorporação.

Morae

Domínio do Medo ligado à mente, autoria, interpretação e identidade.

Thyren

Domínio do Medo ligado a ausência, distância e percepção incompleta.

Zha’el

Domínio do Medo ligado a valor, merecimento, culpa, medida e julgamento.

Memória

Domínio do Conhecimento pelo qual relações deixam continuidade.

Significância

Domínio do Conhecimento pelo qual relações adquirem peso capaz de reorganizar outras.

Linguagem

Domínio do Conhecimento pelo qual padrões tornam-se compartilháveis entre malhas.

Alma

Domínio do Conhecimento ligado à continuidade singular e ao pertencimento de alguém a si.

Dobra

Desvio na disposição habitual dos Fios de uma malha.

Prega

Movimento inicial de uma Dobra, no qual o Véu cede sem ser atravessado.

Pré-Furo

Expressão reconhecível de uma Prega ativa.

Bolsão

Movimento em que uma Dobra atravessa o Véu e ocupa o Reflexo de forma instável.

Furo

Forma territorial de um Bolsão; passagem ativa ainda não fixada.

Ancoragem

Movimento em que uma Dobra se conecta ao Reflexo e passa a sustentar-se localmente.

Âncora

Dobra fixada ao Reflexo.

Zona de Aspecto

Território parcialmente reorganizado segundo a lógica de um Domínio.

Revérbero

Dobra estabilizada naturalmente ou pacificada por Selagem.

Fragmento

Retalho de uma Dobra desfeita de maneira incompleta, conservando Assinatura e tensão.

Selo

Estrutura de continuidade que oferece borda e reorganização a uma Dobra.

Ponto de Costura

Relação específica da qual depende a estabilidade de uma manifestação.

Canalização

Aproximação e manipulação consciente de Fios profundos da Tessitura.

Trama

Padrão temporário tecido por Canalização.

Expressão

Resultado observável produzido quando o Reflexo tenta incorporar uma Trama ou manifestação.

Relaxamento

Retorno dos Fios após o fim de uma costura tensionada.

Refluxo

Desorganização residual produzida durante o Relaxamento.

Equilíbrio

Direção de organização da malha humana entre os polos do Medo e do Conhecimento.

Sensibilidade

Capacidade de perceber tensão, direção e Assinatura em Fios profundos.

O mundo persiste porque suas relações ainda sabem onde se encontrar.

FIM
