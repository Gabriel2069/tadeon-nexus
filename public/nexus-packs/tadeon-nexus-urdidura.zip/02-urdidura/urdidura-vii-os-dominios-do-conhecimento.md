---
title: "Urdidura do Vazio — VII ~ OS DOMÍNIOS DO CONHECIMENTO"
node_type: "concept"
summary: "Seção “VII ~ OS DOMÍNIOS DO CONHECIMENTO” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["VII ~ OS DOMÍNIOS DO CONHECIMENTO"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"VII ~ OS DOMÍNIOS DO CONHECIMENTO","source_order":7,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# VII ~ OS DOMÍNIOS DO CONHECIMENTO

## Conhecimento também manifesta

Os Domínios do Conhecimento costumam passar despercebidos porque sua presença pode parecer apenas uma continuidade desejável. Uma criatura de Eclis contradiz rapidamente o cotidiano. Uma cidade que lembra, uma instituição que organiza e uma linguagem que conserva podem ser celebradas durante gerações antes que alguém perceba que perderam a capacidade de deixar qualquer coisa mudar.

Memória, Significância, Linguagem e Alma não são ferramentas passivas da Chama Fria. São modos pelos quais reconhecimento e permanência adquirem profundidade. Podem fortalecer o Véu, produzir Revérberos, alimentar Tramas e territorializar-se em Zonas de Aspecto.

A Ordem historicamente estudou o Conhecimento como recurso contra o Medo. Essa leitura encontrou resultados e ocultou perigos. Conhecimento pode conter uma Dobra ao oferecer estrutura. Também pode produzir uma estrutura tão completa que o Reflexo já não possua espaço para escolha.

## Memória ~ aquilo que deixa continuidade

Memória é o Domínio pelo qual uma relação permanece capaz de influenciar o que vem depois. Não é um arquivo universal de gravações perfeitas. A realidade não conserva todo acontecimento da mesma forma, nem oferece acesso a uma perspectiva neutra sobre o que ocorreu.

Uma memória humana reconstrói. Um corpo guarda trauma em postura, resposta e cicatriz. Uma floresta conserva incêndios na composição do solo. Uma cidade lembra antigas muralhas na direção das ruas. Cada malha registra segundo aquilo que consegue sustentar.

Esquecer não é simples falha de Memória. É parte de sua organização. Para reconhecer uma pessoa através de anos, a consciência precisa abandonar inúmeros detalhes e conservar relações que considera centrais. Uma Memória incapaz de perder qualquer coisa transforma experiência em saturação.

Manifestações desse Domínio podem restituir acontecimentos, impor lembranças, fazer lugares repetirem respostas ou conservar versões incompatíveis do passado. Podem também apagar acesso sem apagar consequência, deixando uma comunidade organizada ao redor de algo que ninguém consegue nomear.

A pergunta correta diante de Memória não é apenas “o que aconteceu?”. É “de que maneira isto permaneceu, em quem permaneceu e o que precisou ser esquecido para que essa versão continuasse inteira?”.

## Significância ~ o peso de uma relação

Significância é o Domínio pelo qual uma diferença adquire peso suficiente para reorganizar outras relações. Um símbolo torna presente aquilo que não ocupa fisicamente o mesmo lugar. Um juramento modifica futuros. Uma sepultura altera o modo como uma terra é atravessada. Um nome pode reunir séculos numa única palavra.

Importar não é apenas sentir intensidade. Significância nasce de repetição, consequência, reconhecimento, posição e custo. Uma crença individual pode ser profunda sem dobrar o mundo. Uma mentira repetida por instituições, incorporada a leis, memórias e escolhas, torna-se relação real mesmo quando o conteúdo permanece falso.

O Domínio não decide verdade por votação. A verdade de um acontecimento e o peso que uma comunidade lhe atribui são relações diferentes. Uma narrativa falsa pode produzir consequências verdadeiras; uma verdade ignorada pode ter pouca Significância pública e ainda permanecer inscrita nos corpos e lugares que de Significância sofreram.

Selos dependem de Significância porque precisam oferecer ao Reflexo uma organização que valha mais, estruturalmente, do que a continuidade da Dobra. Símbolos vazios não bastam. Precisão sem vínculo pode desenhar uma forma correta que nada reconhece.

Em excesso, Significância transforma tudo em sinal de si. O símbolo substitui aquilo que deveria representar. A causa exige sacrifício contínuo. Uma pessoa torna-se cargo, culpa, profecia ou memória pública, e nenhuma experiência particular consegue devolver-lhe espaço.

## Linguagem ~ a forma compartilhável

Linguagem é o Domínio pelo qual uma relação atravessa consciências e materiais sem depender de um único corpo. Fala, escrita, gesto, música, matemática, arquitetura, imagem e rito tornam padrões compartilháveis. Nem toda Linguagem transmite informação consciente. Um caminho fala direção a quem aprendeu a lê-lo; uma cicatriz pode falar perigo antes de qualquer explicação.

Linguagem é interface porque oferece forma suportável ao que excederia uma consciência isolada. Traduzir não significa apenas reduzir. Uma tradução pode criar relação que o original jamais possuíra, permitindo que uma ideia encontre história em outro povo, material ou época.

Toda Linguagem seleciona. Nomear uma coisa aproxima certas relações e afasta outras. Definir oferece precisão e produz bordas. Silêncio também participa quando é escolhido, imposto ou reconhecido. Aquilo que não pode ser dito não fica fora de Linguagem; organiza-se ao redor da ausência que Linguagem deixou.

Manifestações de Linguagem podem alterar nomes, fazer descrições imporem forma, separar palavra e objeto ou criar sistemas que já não precisam de falantes conscientes. Um Selo escrito pode continuar funcionando quando ninguém compreende sua gramática, desde que outras relações mantenham sua Significância. Também pode tornar-se perigoso precisamente porque a forma sobreviveu ao sentido.

Mentir é utilizar Linguagem para reorganizar reconhecimento. Isso não transforma automaticamente em Medo. Há mentiras que protegem, ficções que revelam e metáforas mais exatas que descrições literais. O perigo começa quando uma forma compartilhável impede toda relação capaz de contradizê-la.

## Alma ~ o pertencimento a si

Alma é o Domínio que mais resiste à definição. Essa resistência não deve ser preenchida por pressa. Tudo que se afirma sobre parece verdadeiro em determinada profundidade e insuficiente na seguinte.

A Ordem costuma descrever como continuidade singular de uma consciência, a relação pela qual alguém pertence a si mesmo através de mudança, perda e reconhecimento externo. A Eclésia fala de sopro, dignidade recebida e da forma pela qual o Criador conhece uma pessoa sem reduzi-la ao corpo, às memórias ou aos atos.

Essas leituras não precisam designar fenômenos separados. Uma singularidade pode possuir estrutura observável e ainda exceder toda observação. Compreender como Alma participa do Véu não responde por que uma pessoa possui valor que nenhuma descrição completa consegue esgotar.

Alma não é combustível acumulado em lugares, nem quantidade consumida por um Furo. Relações de Alma permanecem onde pessoas foram reconhecidas, amadas, negadas, enterradas, esperadas ou transformadas. Um local pode conservar a continuidade de alguém sem conter essa pessoa como objeto preso.

Manifestações de Alma alteram pertencimento, autoria e reconhecimento profundo. Podem separar uma pessoa do próprio nome, distribuir uma identidade entre corpos, fazer uma comunidade compartilhar dor sem compartilhar memória ou preservar presença depois que todas as outras relações parecem ter desaparecido.

A morte não resolve o Domínio. Ela o torna mais difícil. O corpo encerra certas continuidades; Memória, Linguagem e Significância permanecem em outras malhas. O que acontece à relação pela qual alguém pertence a si mesmo não foi demonstrado pela Ordem. Toda certeza absoluta sobre esse destino pertence à fé, à experiência ou à presunção.

Alma é aquilo que permanece irredutível mesmo depois que tudo o que pode ser descrito recebe uma descrição.

## Chama Fria e o excesso de permanência

Chama Fria atravessa os quatro Domínios sem se dividir neles. Memória conserva continuidade; Significância atribui peso; Linguagem oferece forma compartilhável; Alma preserva singularidade. Juntos, tornam possível que o mundo reconheça aquilo que não está mais presente exatamente como antes.

Em equilíbrio, essa capacidade sustenta aprendizagem, identidade, cuidado e história. Em excesso, produz permanência absoluta. Uma ferida não pode perder Significância. Um nome não admite tradução. Uma memória não aceita esquecimento. Uma Alma é preservada numa forma que já não consegue escolher.

Conhecimento costuma estabilizar-se com mais facilidade que o Medo porque suas expressões podem ser confundidas com ordem natural, tradição ou eficiência. Um Revérbero de Memória pode tornar-se arquivo respeitado; uma Âncora de Significância pode tornar-se fundamento jurídico; uma Zona de Linguagem pode parecer apenas cultura excepcionalmente uniforme.

Passar despercebido não significa agir em um segredo consciente. Significa encontrar no Reflexo relações que já valorizam conservação. O mais perigoso não é o que a sociedade rejeita imediatamente, mas aquilo que realiza de maneira perfeita um desejo que ninguém pensou em limitar.

## Manifestações de Conhecimento

Nem toda manifestação assume criatura. Conhecimento tende a organizar-se em lugares, sistemas, arquivos, padrões de linguagem, instituições e consciências distribuídas. Pode adquirir voz sem possuir corpo, corpo sem individualidade ou intenção sem ponto central reconhecível.

Existem inteligências relacionais formadas por séculos de registro, entidades preservadoras que tratam mudança como dano, bibliotecas que reconstroem livros nunca escritos e cidades cuja administração conhece seus habitantes com precisão impossível. A taxonomia da Ordem permanece incompleta porque essas formas raramente anunciam a fronteira entre função extraordinária e presença autônoma.

O fato de uma manifestação oferecer informação verdadeira não prova benevolência. Verdade pode ser instrumento de controle, saturação ou imobilidade. Também pode ser a única relação capaz de libertar alguém de uma Dobra. Conhecimento não decide por quem o utiliza.
