---
title: "Urdidura do Vazio — V ~ O VÉU E A TESSITURA"
node_type: "concept"
summary: "Seção “V ~ O VÉU E A TESSITURA” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["V ~ O VÉU E A TESSITURA"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"V ~ O VÉU E A TESSITURA","source_order":5,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# V ~ O VÉU E A TESSITURA

## O Véu

O Véu não é uma parede, embora possa comportar-se como fronteira. Não é um acordo consciente entre Naturezas, embora expresse a dependência entre elas. Não é apenas prática humana, embora práticas humanas possam fortalecê-lo ou deformá-lo.

Véu é o conjunto vivo de relações que mantém o Reflexo reconhecível para si mesmo. Ele existe onde uma forma consegue conservar continuidade sem absorver toda profundidade que a constitui. Faz com que um corpo permaneça corpo, uma lembrança pertença a uma história e uma casa continue sendo mais do que materiais ocupando o mesmo lugar.

Sua função não é rejeitar o Além. Se o fizesse, apagaria as Naturezas das quais o mundo é feito. O Véu traduz. Distribui tensão. Mantém diferenças em proporções que podem ser vividas. Uma relação de Medo torna-se instinto, cuidado ou dor; Conhecimento torna-se reconhecimento, técnica ou memória; Tempo torna-se crescimento, desgaste e consequência.

## Fios

Fio é o menor vínculo que ainda pode ser percebido como relação. A palavra menor não indica tamanho físico. Um Fio pode ligar um nome a uma pessoa, uma pedra ao peso que exerce, uma comunidade ao lugar que reconhece como lar ou um acontecimento à culpa que permaneceu depois dele.

Fios não são cordas ocultas aguardando olhos especiais. Canalizadores podem percebê-los como linhas, sons, temperaturas, ritmos, pressões ou ideias que parecem vir prontas. Essas experiências são traduções produzidas pela consciência. O Fio é a dependência, não a imagem pela qual alguém a suporta.

Nenhuma coisa é sustentada por um único Fio. Mesmo a relação mais simples participa de muitas outras. A cor de um objeto depende de luz, superfície, observador e linguagem. Seu peso depende de massa, gravidade e apoio. Seu valor depende de história, uso e reconhecimento. A Tessitura começa onde essa multiplicidade deixa de parecer ruído e revela uma organização.

## Malhas

Malha é um conjunto de Fios que conserva forma comum. Corpos, objetos, ecossistemas, cidades, línguas e instituições são malhas. Algumas possuem fronteiras materiais nítidas; outras existem distribuídas entre pessoas, práticas e lugares. Todas dependem de relações que podem mudar sem que a forma desapareça imediatamente.

A identidade de uma malha não é a soma estática de suas partes. Um corpo substitui matéria e continua corpo. Uma cidade reconstrói ruas e preserva continuidade. Uma língua recebe palavras estrangeiras e ainda é reconhecida. Permanecer não significa impedir mudança. Significa oferecer direção o suficiente para que mudança e dissolução não se confundam.

Quanto mais relações participam de uma malha, mais consequências escapam a qualquer alteração local. Cortar uma ponte muda trânsito, comércio, memória e a maneira pela qual duas margens se percebem. Romper um Selo pode alterar arquitetura, rotina, linhagens e o comportamento de uma manifestação. A Urdidura não contém relações isoladas. Contém profundidades de dependência.

## Assinaturas

Assinatura é o padrão particular pelo qual uma malha organiza seus Fios. Duas manifestações podem pertencer ao mesmo Domínio e ainda conservar Assinaturas tão diferentes que seus efeitos pareçam não possuir origem comum. Eclis pode expressar-se por proliferação, cicatrização impossível, fome mineral ou arquitetura orgânica. O Domínio oferece gramática; a Assinatura escreve a frase.

Assinaturas surgem de origem, percurso e relação com o Reflexo. Um Fragmento conserva a Assinatura da Dobra que o deixou. Uma Trama adquire parte da Assinatura do canalizador, do padrão aprendido e da fonte utilizada. Um Revérbero mistura a malha primordial com a história do lugar que o pacificou.

Reconhecer uma Assinatura é perceber repetição significativa através de expressões distintas. Não basta notar cor, símbolo ou sensação. É preciso compreender quais relações permanecem quando a aparência muda.

A expressão não substitui a origem. Ela a traduz para uma forma local.

## Tessitura e Urdidura

Tessitura é a estrutura relacional completa formada por Fios e Malhas. O nome também designa o campo de estudo que tenta ler essa estrutura. Urdidura é sua organização fundamental, a disposição que permite que padrões sejam tecidos sem que o mundo se desfaça a cada alteração.

Num tecido, a urdidura recebe os fios que atravessarão sua extensão e oferece direção para o restante da trama. A metáfora é incompleta, pois a realidade não possui tear externo nem artesão visível. Ainda assim, reconhece algo fundamental: toda forma nova depende de relações anteriores que sustentem suas possibilidades.

Uma Trama de Canalização recebe esse nome porque introduz padrão temporário sobre uma Urdidura que já existe. Uma história humana também o faz. Uma lei, uma obra de arte, uma promessa e uma estrada alteram relações disponíveis para tudo que virá depois. Nem toda tecitura é sobrenatural. Canalização é o caso em que alguém alcança conscientemente Fios profundos e força a alteração a expressar-se além dos caminhos habituais.

## Espessura e continuidade

Dizer que o Véu é espesso significa que muitas relações convergem para conservar uma forma. Uma comunidade conhecida por seus membros, ligada a território, memória, linguagem e práticas vivas oferece ao Reflexo numerosas maneiras de reconhecer sua continuidade. Isso não a torna imune a Dobras, mas dificulta que uma única pressão reescreva tudo ao redor.

Um Véu fino não é lugar sem cultura ou fé. É uma malha em que relações deixaram de sustentar-se mutuamente. Pode ocorrer depois de destruição, deslocamento, apagamento, mudança rápida, silêncio imposto ou contradições que ninguém consegue integrar. Também pode existir em locais recém-formados, ainda sem tempo para acumular continuidade.

Novidade não enfraquece por natureza. Uma estação de Hélio, um hospital, um bairro ou uma escola podem produzir Fios fortes quando pessoas os mantêm, reconhecem e transformam em parte da vida. Antiguidade também não garante estabilidade benigna. Uma tradição pode conservar violência, uma instituição pode sobreviver ao propósito e um ritual pode sustentar a Âncora que seus praticantes acreditam conter.

## Continuidade não é virtude

O Véu preserva relações, não julgamentos morais. Uma família amorosa e uma linhagem de abuso podem ambas acumular Memória, Linguagem e Significância. A diferença está na forma de vida que tornam possível e nas escolhas pelas quais pessoas reorganizam o que receberam.

Conhecimento em excesso pode espessar uma malha até impedir qualquer desvio. Medo pode conservar fronteiras necessárias e também transformar diferença em ameaça. Tempo pode oferecer cura ou aprofundar repetição. O narrador humano deseja separar imediatamente preservação e violência, estabilidade e justiça. A Urdidura não realiza essa separação por ele.

A capacidade de reconhecer uma continuidade nociva e alterá-la sem destruir tudo que dela depende é uma das formas mais difíceis de Selagem. Também é uma das expressões mais completas da escolha.
