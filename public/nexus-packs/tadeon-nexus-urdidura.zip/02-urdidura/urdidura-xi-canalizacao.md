---
title: "Urdidura do Vazio — XI ~ CANALIZAÇÃO"
node_type: "concept"
summary: "Seção “XI ~ CANALIZAÇÃO” de Urdidura do Vazio, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "orbit"
aliases: ["XI ~ CANALIZAÇÃO"]
tags: ["cânone","fonte-primária","urdidura"]
properties: {"canon_layer":"primary_source","source_document":"Urdidura do Vazio ~ TdV(1).docx","source_section":"XI ~ CANALIZAÇÃO","source_order":11,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]. O conteúdo abaixo preserva a redação da seção de origem.

# XI ~ CANALIZAÇÃO

## Tecer

Canalizar não é produzir uma energia oculta, ordenar a uma entidade que realize efeito ou pronunciar fórmula capaz de suspender regras. É aproximar-se de uma malha primordial, puxar Fios, organizá-los e pedir ao Reflexo que incorpore por algum tempo uma relação que não teria surgido daquele modo.

A Trama é o padrão costurado. O efeito visível é Expressão, a resposta pela qual o Reflexo tenta acomodar a deformação. Duas Tramas podem produzir fogo e não compartilhar Natureza, Assinatura, custo ou comportamento. A chama é consequência. A verdade da Canalização está na relação que a tornou necessária.

Toda Canalização atravessa cinco movimentos: Aproximação, Tração, Tecitura, Expressão e Relaxamento. A rapidez de uma Trama não remove nenhum deles. Apenas faz com que a consciência treinada os percorra numa duração pequena demais para observadores comuns distinguirem.

## Aproximação

Antes de tocar Fios, o canalizador provoca uma Dobra temporária entre sua própria malha e a Natureza escolhida. Não abre necessariamente um Furo. Cria acesso, uma inclinação controlada na qual relações profundas tornam-se perceptíveis.

Sanidade mede, nesse momento, a capacidade de permanecer indivíduo diante de uma escala que não reconhece pessoas da mesma forma que pessoas se reconhecem. O risco mais silencioso não é ver horror. É aceitar por um instante a organização da malha aproximada como mais verdadeira que a própria continuidade.

Instrumentos, Fragmentos, gestos e ritos ajudam a oferecer forma à aproximação. Nenhum substitui compreensão. Um padrão repetido sem relação pode funcionar por algum tempo graças à Significância herdada, mas torna o canalizador dependente de uma costura que já não sabe reparar.

## Tração

Tração é o movimento de deslocar Fios da disposição que ocupavam. O canalizador não os cria. Também não os possui. Mantém tensão suficiente para que permaneçam acessíveis enquanto a malha de origem responde tentando recuperar continuidade.

Puxar mais não significa apenas produzir efeito maior. Significa deslocar relações mais espessas, conectadas a maior número de consequências. Um Fio profundo carrega a resistência de tudo que depende de sua posição.

O esforço energético e mental surge dessa reciprocidade. O canalizador puxa e é puxado. A Natureza não precisa possuir vontade para responder. Uma ponte tensionada devolve força a quem a curva; uma malha primordial faz o mesmo em escala capaz de alterar corpo, percepção e identidade.

## Tecitura

Tecitura é o momento em que Fios deslocados recebem padrão. Aqui nasce a Trama. Canalização mede capacidade de organizar relações coerentes, não força bruta. Um padrão simples pode usar Fios intensos; um padrão delicado pode exigir complexidade extraordinária.

Tramas são aprendidas como compreensões. Gestos, palavras e diagramas ajudam a conduzir memória corporal e atenção, mas não são a Trama em si. Quem copia movimentos sem compreender pode reproduzir uma Assinatura apenas enquanto todas as condições permanecem idênticas.

O canalizador participa do padrão. Sua história, Equilíbrio, linguagem e intenção alteram pequenos aspectos da costura. Maestria reduz variação sem eliminá-la. Nenhuma Trama atravessa uma consciência e sai completamente indiferente à forma que a sustentou.

## Expressão

Quando a costura se completa, o Reflexo tenta incorporá-la. A Expressão é a maneira pela qual regularidades locais respondem à nova relação. Combustão, movimento, ocultação, cura, percepção ou sobreposição temporal são resultados possíveis, não categorias fundamentais.

Uma Trama de Medo que aquece pode fazer matéria responder como metabolismo, atrito ou fome. Uma Trama de Conhecimento pode produzir calor reorganizando informação molecular ou impondo um padrão de reação. O observador vê temperatura; a Urdidura reconhece caminhos diferentes.

Quanto mais profunda a Dobra, mais o ambiente participa. Tramas pequenas parecem efeitos localizados. Estiramentos deixam memória, alteram Assinaturas próximas e podem criar instabilidades secundárias mesmo quando executados com sucesso.

## Relaxamento e Refluxo

Nenhuma costura tensionada permanece sem manutenção. Quando a Trama termina, Fios procuram retornar à disposição anterior ou encontrar nova configuração estável. Relaxamento é esse movimento inevitável.

Refluxo é a desorganização produzida quando o retorno não consegue recompor relações com precisão. Não é punição moral nem reação irada de uma entidade. É consequência física e ontológica de ter deslocado uma malha que sustenta outras coisas além do efeito desejado.

Falhas aumentam Refluxo porque Fios retornam antes de receber padrão coerente. Interrupções fazem etapas incompletas colidirem. Mesmo o sucesso pode deixar marcas quando a Dobra foi profunda demais para que o Reflexo esqueça imediatamente a relação experimentada.

O canalizador experiente não procura ausência absoluta de Refluxo. Aprende a prever direção, oferecer caminhos de retorno e decidir quando uma cicatriz é custo aceitável. Essa decisão nunca pertence apenas à técnica. Alguém mais pode ter de viver no lugar que a Trama ensinou a mudar.

## Fragmentos como caminhos já percorridos

Um Fragmento facilita a Canalização porque contém padrão que o Reflexo já expressou. Seguir um caminho existente exige menos profundidade que construir um novo. Isso não torna o Fragmento ferramenta neutra.

Sua Assinatura favorece relações compatíveis, distorce outras e oferece limite de amplitude. O canalizador pode utilizar uma cicatriz para evitar contato direto mais profundo, mas passa a repetir parte da história que produziu aquela cicatriz.

Uso prolongado aproxima a malha pessoal da organização do Fragmento. Às vezes isso aparece como hábito, sonho, sensação ou mudança de Equilíbrio. Em outros casos, a pessoa torna-se Ponto de Costura de uma relação que acreditava apenas carregar.

## Canalização e humanidade

Tramas bem-sucedidas não deslocam automaticamente o Equilíbrio. Contato controlado pode integrar-se à malha humana. Falha, Refluxo, repetição extrema e Dobras profundas deixam direção mais forte porque obrigam a pessoa a organizar-se segundo a Natureza tocada.

O risco não está em usar poder e tornar-se impuro. Está em permitir que uma única relação resolva todos os problemas. Medo oferece respostas rápidas ao perigo; Conhecimento oferece controle e clareza; Fluxo oferece a sedução de escapar da consequência. A humanidade preserva-se enquanto ainda consegue escolher caminhos que a força disponível não tornou inevitáveis.

Toda Trama altera o mundo. As mais perigosas são aquelas que também convencem o canalizador de que nenhuma outra relação teria sido possível.
