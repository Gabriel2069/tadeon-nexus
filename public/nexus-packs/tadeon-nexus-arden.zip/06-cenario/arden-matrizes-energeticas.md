---
title: "Arden — Matrizes energéticas"
node_type: "concept"
summary: "Seção “Matrizes energéticas” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Matrizes energéticas"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Matrizes energéticas","source_order":38,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Matrizes energéticas

A hidropneumática usa rios e reservatórios para comprimir ar, elevar água e manter redes urbanas. A mareopneumática aproveita a variação de nível em baías, canais e estuários. Moinhos eólicos alimentam oficinas, bombas e acumuladores. Matrizes termossolares concentram calor; sistemas óptico-solares conduzem luz, carregam materiais fotossensíveis e alimentam redes de comunicação.

Geotermia sustenta regiões como Yamashiro, Axum e Aotearoa. Armazenamento gravítico eleva pesos e água para devolver energia mais tarde. Sistemas osmóticos trabalham em estuários. Bioalquimia explora fermentação, gradientes de concentração, tecidos contráteis e organismos capazes de produzir calor, pressão, adesão ou substâncias específicas.

Nenhuma matriz é igualmente eficiente em toda parte. A Geografia precede a tecnologia. Um vale montanhoso favorece queda e pressão; uma costa recortada, maré; um deserto, concentração solar; uma floresta úmida, cultivo biológico. Isso impede que o mundo pareça construído a partir de um único catálogo de máquinas.
