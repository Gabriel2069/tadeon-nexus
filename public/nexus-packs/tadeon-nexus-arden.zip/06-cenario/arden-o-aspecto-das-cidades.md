---
title: "Arden — O aspecto das cidades"
node_type: "concept"
summary: "Seção “O aspecto das cidades” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O aspecto das cidades"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O aspecto das cidades","source_order":43,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O aspecto das cidades

Cidades de Arden combinam pedra, madeira, vidro, metal e matéria cultivada. Tubos aparecem onde precisam ser acessados, não como ornamento universal. Torres de Hélio ocupam elevações. Reservatórios, aquedutos e câmaras de pressão determinam bairros. Veículos pneumáticos percorrem linhas principais; animais, barcos e caminhada continuam essenciais.

O medievo-futurismo de Arden não é uma fantasia de engrenagens aplicadas a qualquer superfície. É a continuidade visível de técnicas antigas que cresceram sem abandonar a arquitetura, ofício, fé e paisagem. Uma catedral pode conter sistemas térmicos, arquivo óptico e Selo secular sem deixar de ser catedral.
