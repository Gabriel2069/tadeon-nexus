---
title: "Arden — Âncoras"
node_type: "concept"
summary: "Seção “Âncoras” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Âncoras"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Âncoras","source_order":16,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Âncoras

Uma Âncora não é um Furo maior. É uma Dobra que mudou de condição.

O Furo atravessa. A Âncora permanece.

Ela surge quando o Bolsão encontra no Reflexo relações capazes de manter sua organização sem depender integralmente da pressão original. A malha local deixa de apenas sofrer a presença e começa a participar dela. O lugar passa a recordar a Dobra, alimentar seus ritmos e devolver seus efeitos mesmo quando a manifestação que a produziu já não está próxima.

Uma árvore, um túmulo, uma máquina, um corpo ou uma promessa podem funcionar como foco visível dessa fixação. Não são, por si mesmos, a Âncora. São pontos pelos quais a Ancoragem se exprime ou relações cuja ruptura pode enfraquecê-la. A Âncora é territorial: pertence ao conjunto de fios que o lugar passou a sustentar. Não pode ser carregada como um Fragmento nem removida pela destruição simples de seu foco.

Nas Âncoras iniciais, os efeitos ainda retornam a um centro reconhecível. O local parece lembrar o fenômeno e reconduzir acontecimentos para ele. À medida que a Ancoragem se fortalece, distâncias perdem importância, comportamentos são incorporados à rotina e a própria arquitetura, vegetação ou população começam a reorganizar-se ao redor da Dobra. Em seu grau mais profundo, o lugar já não apenas abriga uma presença. Ele preserva parte de sua malha.

Por isso, Âncoras não podem simplesmente ser empurradas para trás do Véu. A ligação já utiliza matéria, história, linguagem e continuidade pertencentes ao Reflexo. Selá-las exige separar aquilo que pode ser devolvido daquilo que passou a integrar o mundo.

Uma Âncora pode ser contida, permanecendo no local sem expressar ativamente sua Natureza. Também pode ser pacificada, quando seus fios são reorganizados até deixarem de puxar por conta própria. Nesse segundo resultado, ela se torna um Revérbero.

Âncoras se cercam.
