---
title: "Arden — O Véu"
node_type: "concept"
summary: "Seção “O Véu” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O Véu"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O Véu","source_order":12,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O Véu

O Véu é frequentemente desenhado como uma fronteira entre o Reflexo e o Além-Véu. O desenho é útil para aprendizes e perigoso quando levado ao pé da letra. Não há uma superfície contínua escondida atrás do céu ou sob a pele. O Véu é o conjunto vivo de relações que faz uma coisa continuar pertencendo ao mundo humano.

Uma casa possui Véu porque foi construída, habitada, reparada, nomeada e lembrada. Um caminho possui Véu porque pés o repetem e lugares reconhecem sua direção. Uma pessoa possui Véu porque corpo, memória, linguagem, vínculos e passagem do tempo mantêm entre si uma concordância suficiente. Uma instituição pode fortalecer o Véu ao conservar práticas através de gerações. Também pode afiná-lo quando preserva apenas a forma de um propósito que já esqueceu.

O Véu não rejeita tudo que vem do Além. Se o fizesse, o próprio Reflexo deixaria de existir. Ele organiza, distribui e traduz. Mantém fios em relações que podem ser vividas sem que cada presença primordial reivindique a totalidade do que toca.
