---
title: "Arden — Dobras"
node_type: "concept"
summary: "Seção “Dobras” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Dobras"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Dobras","source_order":14,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Dobras

Uma Dobra começa quando uma malha deixa de acompanhar a disposição habitual do Reflexo. Seus fios cedem, aproximam-se de outra organização e passam a carregar uma tensão que o lugar, o corpo ou a consciência ainda não sabem acomodar. Nem toda Dobra é uma abertura. Nem toda abertura permanece. A palavra descreve o movimento anterior às formas que esse movimento poderá assumir.

Algumas Dobras são produzidas deliberadamente. Toda Trama nasce de uma Dobra pequena e temporária, aberta por um canalizador para alcançar fios que normalmente permaneceriam além de seu alcance. Outras surgem sem intenção humana, quando malhas primordiais se aproximam do Reflexo, quando um acontecimento imprime peso demais sobre um lugar ou quando relações incompatíveis permanecem sobrepostas por tempo suficiente para deformar o Véu.

Uma Dobra natural aprofunda-se através de três movimentos. Eles não são fenômenos independentes, mas momentos de uma mesma alteração.

A Prega ocorre quando o Véu começa a ceder. Há pressão, inclinação e pequenos deslocamentos, mas a malha externa ainda não atravessou por completo. O lugar parece responder a algo que ainda não chegou.

O Bolsão forma-se quando a Dobra atravessa o Véu e ocupa o Reflexo de maneira instável. O que antes pressionava passa a ter passagem. Surgem os Furos.

A Ancoragem acontece quando a Dobra deixa de depender apenas da pressão que a produziu e encontra no próprio Reflexo relações capazes de sustentá-la. A malha local aprende a carregar parte da organização estrangeira. Surgem as Âncoras.

Prega é pressão. Bolsão é passagem. Ancoragem é fixação. A partir desses três movimentos, uma alteração pode desaparecer, ser fechada, estabilizar-se ou crescer até que uma região inteira já não reconheça completamente a lógica que possuía.
