---
title: "Arden — Escolhas prontas de cenário"
node_type: "concept"
summary: "Seção “Escolhas prontas de cenário” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Escolhas prontas de cenário"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Escolhas prontas de cenário","source_order":71,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Escolhas prontas de cenário

Mar de Veth

Uma cidade portuária depende de uma estação pneumática construída sobre ruínas oceânicas elevadas. A rede começa a distribuir pressão em ritmos que correspondem a nomes apagados dos registros.

Yamashiro

Fontes termais mudam de composição antes de uma festa ancestral. A evacuação impediria um desastre vulcânico, mas interromperia o costume que mantém um Selo insular.

Verdania

O Viridário recebe pacientes cuja regeneração elimina cicatrizes e, com elas, lembranças ligadas aos ferimentos.

Lago Texcoco Central

O nível do lago recua e revela uma estrada ritual para uma ilha ausente dos mapas e presente em todas as canções locais.

Istmo de Veth

Dois reinos disputam uma passagem enquanto deslizamentos expõem uma antiga estrutura de contenção que depende de circulação humana contínua.

Grande Deserto de Veth

Uma matriz termossolar encontra sob a areia uma cidade preservada por Significância, na qual nenhum habitante admite que o tempo passou.

Kitomena

Cristais de uma nova jazida registram conversas antes que aconteçam e atraem academias, guildas, Ordem e contrabandistas.

Aotearoa

Um lago de caldeira devolve objetos lançados nele em gerações diferentes, sempre na mesma noite.

Veth Cinério

Uma expedição encontra o acampamento da equipe anterior perfeitamente conservado, embora seus integrantes tenham retornado anos antes.

Osva

Uma falha na Rede de Hélio faz dezoito governos receberem a mesma mensagem com assinaturas diferentes.
