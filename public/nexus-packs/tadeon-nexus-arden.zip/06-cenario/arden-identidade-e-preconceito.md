---
title: "Arden — Identidade e preconceito"
node_type: "concept"
summary: "Seção “Identidade e preconceito” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Identidade e preconceito"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Identidade e preconceito","source_order":35,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Identidade e preconceito

Veth não desenvolveu uma hierarquia continental duradoura organizada pela cor da pele. Migrações antigas, impérios multiétnicos, cidadania urbana, doutrina eclesial de dignidade humana e ausência de um sistema colonial planetário que transformasse fenótipo em estatuto impediram que essa classificação se tornasse base jurídica ampla.

Isso não torna Arden livre de exclusão. Há desprezo por sotaque, religião local, condição social, origem rural, linhagem, profissão, cidadania, exposição ao Além-Véu e pertencimento a povos específicos. Reinos constroem estereótipos uns dos outros; guildas protegem acesso; elites naturalizam privilégios; comunidades traumatizadas confundem diferença com perigo. O mundo é mais pacífico em algumas dimensões porque instituições aprenderam a não transformar certas diferenças em guerra total. Continua humano nas demais.
