---
title: "Arden — Como as eras são contadas"
node_type: "concept"
summary: "Seção “Como as eras são contadas” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Como as eras são contadas"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Como as eras são contadas","source_order":51,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Como as eras são contadas

O calendário da Concordância começa no tratado que unificou medidas, regras de trânsito e arbitragem entre reinos dos grandes mares internos. Tudo que veio antes recebe datas negativas apenas por conveniência. Povos diferentes conservam calendários próprios, e muitos acontecimentos antigos só podem ser posicionados em intervalos amplos.

As seis eras seguintes não cobrem todos os povos de maneira igual. Uma região pode ter vivido expansão enquanto outra se recuperava de guerra. Os nomes descrevem tendências de Veth, não leis universais. Servem ao narrador como grandes camadas sobre as quais histórias locais podem ser escolhidas.
