---
title: "Arden — Conhecimento"
node_type: "concept"
summary: "Seção “Conhecimento” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Conhecimento"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Conhecimento","source_order":8,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Conhecimento

O Conhecimento é aquilo que permite a uma diferença permanecer reconhecível. Ele não se reduz a informação, inteligência ou estudo. Uma árvore que responde à luz conserva um modo de distinguir direção. Uma cicatriz guarda a história de um ferimento sem precisar lembrá-lo. Uma comunidade repete um nome e impede que uma pessoa desapareça inteiramente quando o corpo já não está.

Sua manifestação central é chamada Chama Fria. A imagem parece contraditória porque tenta aproximar duas experiências que a linguagem comum separa: iluminação e ausência de calor, clareza e indiferença, presença e distância. A Chama Fria não consola por natureza. Ela revela, conserva e organiza. É possível ser salvo por uma verdade e destruído pela mesma verdade quando ela remove todas as formas humanas de suportá-la.

Memória, Significância, Linguagem e Alma são os quatro grandes Domínios pelos quais o Conhecimento se fixa no humano. Memória conserva relações através do tempo. Significância decide que algo importa e, por importar, modifica o que se torna possível ao redor. Linguagem permite que uma forma atravesse pessoas sem depender de um único corpo. Alma mantém a continuidade interior pela qual alguém ainda pode dizer “eu” depois de mudar.
