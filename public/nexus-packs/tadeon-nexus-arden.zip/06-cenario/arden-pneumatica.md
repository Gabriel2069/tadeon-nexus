---
title: "Arden — Pneumática"
node_type: "concept"
summary: "Seção “Pneumática” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Pneumática"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Pneumática","source_order":39,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Pneumática

Redes pneumáticas movem êmbolos, ferramentas, elevadores, veículos sobre trilhos, aparelhos médicos e sistemas industriais. Em centros urbanos, tubulações subterrâneas distribuem pressão a oficinas e edifícios. Reservatórios, válvulas, manômetros e câmaras de compensação fazem parte da paisagem.

A pressão é poderosa e vulnerável. Vazamentos reduzem bairros inteiros ao silêncio. Contaminação pode atravessar uma rede. Sabotagem de uma estação de compressão interrompe transporte, água e produção ao mesmo tempo. Técnicos conhecem a cidade por sons que a maioria não percebe: um assobio fora de ritmo, um golpe atrasado, a ausência de vibração numa parede.
