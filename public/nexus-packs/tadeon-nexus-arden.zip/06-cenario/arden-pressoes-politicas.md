---
title: "Arden — Pressões políticas"
node_type: "concept"
summary: "Seção “Pressões políticas” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Pressões políticas"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Pressões políticas","source_order":59,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Pressões políticas

A Liga de Osva concentra poder militar, informacional e técnico. Estados menores procuram garantias ou formam contrapesos. Movimentos separatistas, crises sucessórias e disputas por rios continuam locais, mas qualquer conflito pode afetar redes suprarregionais.

Casas de crédito influenciam governos sem ocupar tronos. Guildas controlam materiais e formação. Academias contestam fronteiras entre segredo e pesquisa. Portos servem ao comércio legal, à diplomacia, ao contrabando e ao Mercado das Costuras.
