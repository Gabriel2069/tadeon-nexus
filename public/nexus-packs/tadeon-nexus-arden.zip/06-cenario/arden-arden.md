---
title: "Arden — Arden"
node_type: "concept"
summary: "Seção “Arden” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Arden"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Arden","source_order":1,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Arden

O mundo se chama Arden. O nome vem de uma língua que ninguém fala e que nenhum arquivo conseguiu reconstruir por inteiro. Os poucos fragmentos preservados sugerem dois sentidos inseparáveis: aquilo que persiste e aquilo que ainda não foi completamente compreendido. A palavra sobreviveu ao idioma que a criou, atravessou migrações, calendários, reformas ortográficas e impérios, até tornar-se tão comum que a maioria das pessoas já não percebe o que carrega ao pronunciá-la.

Arden designa o planeta, mas também uma experiência compartilhada. Um marinheiro vê Arden no horizonte que retorna depois de meses de viagem. Uma camponesa o encontra no ritmo das águas e na memória de uma terra cultivada por nomes que já não conhece. Um matemático reconhece Arden na regularidade que permite prever um eclipse; um Selador, na pequena falha que faz essa regularidade esquecer a si mesma por alguns minutos. Nenhuma dessas visões é mais verdadeira sozinha.

Seus habitantes não sabem que vivem num cenário. Não imaginam outra história da ciência, outra disposição de continentes ou um mundo em que a energia tenha seguido matrizes diferentes. Para eles, válvulas, cristais, tecidos cultivados, torres de Hélio e câmaras de pressão pertencem ao mesmo universo das colheitas, das tempestades e do desgaste das pedras. Quando o impossível se manifesta, raramente é chamado de impossível. Recebe nomes mais próximos: acidente, febre, assombração, fraude, castigo, coincidência, lembrança ruim. Muitas vezes, essa redução permite que uma comunidade continue vivendo. Às vezes, é o que deixa uma Âncora crescer sob suas casas.

O perigo de Arden não está em esconder um segundo mundo atrás do primeiro. Está em fazer do cotidiano a forma mais estável de algo muito maior. O extraordinário não invade uma realidade pura. Ele encontra nela fios conhecidos, pressiona hábitos antigos e usa a mesma matéria de que os corpos, cidades, promessas e memórias são feitos.
