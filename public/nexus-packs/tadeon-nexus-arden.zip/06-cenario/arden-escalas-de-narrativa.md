---
title: "Arden — Escalas de narrativa"
node_type: "concept"
summary: "Seção “Escalas de narrativa” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Escalas de narrativa"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Escalas de narrativa","source_order":70,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Escalas de narrativa

Uma história pode permanecer numa casa, acompanhar um rio, atravessar um reino ou envolver a rede institucional de Veth. A escala não determina importância. Uma família que tenta conservar a memória de um morto pode tocar Alma de maneira mais profunda do que uma crise diplomática continental.

Para campanhas longas, permita que cada arco revele uma camada maior: primeiro a ferida local, depois a instituição que a administra, a história que a produziu e a pressão sistêmica que a mantém. O mundo cresce por conexão, não por uma escalada obrigatória de poder.
