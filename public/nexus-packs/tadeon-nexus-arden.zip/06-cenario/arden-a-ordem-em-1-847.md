---
title: "Arden — A Ordem em 1.847"
node_type: "organization"
summary: "Seção “A Ordem em 1.847” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["A Ordem em 1.847"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"A Ordem em 1.847","source_order":49,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# A Ordem em 1.847

A Ordem organiza-se em funções de Selagem, arquivo, interpretação, cura e vigilância. Seus nomes variam entre regiões, mas Seladores, Arquivistas, Intérpretes, Curadores e Vigias formam a espinha comum. Conclaves e mestres regionais tentam manter unidade sem conhecer por completo tudo que ocorre nas bases locais.

A instituição possui acordos secretos com governos, acesso protegido por vínculos eclesiais e autoridade suficiente para agir em crises. Essa autoridade nunca foi irrestrita. Soberanos recusam entrada, oficiais exigem explicações, mosteiros discordam, academias contestam sigilo e membros da própria Ordem decidem que o Conclave sabe menos do que afirma.

Sua contradição central permanece: proteger a liberdade humana por meio de uma instituição que oculta conhecimento, limita escolhas e intervém sem consentimento público. O segredo nasceu em épocas de perseguição, recrutamento forçado e culto. Em 1.847, governos, academias e redes técnicas já reconhecem padrões por conta própria. Ocultar tudo deixou de impedir descoberta; frequentemente apenas garante que ela ocorra sem orientação.
