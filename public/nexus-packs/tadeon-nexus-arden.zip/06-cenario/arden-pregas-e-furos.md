---
title: "Arden — Pregas e Furos"
node_type: "concept"
summary: "Seção “Pregas e Furos” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Pregas e Furos"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Pregas e Furos","source_order":15,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Pregas e Furos

Uma Prega é o primeiro movimento reconhecível de uma Dobra. O Véu perdeu tensão num ponto, mas nenhuma passagem estável se formou. O Reflexo ainda conserva sua organização e tenta absorver a pressão por conta própria.

Nesse estágio, as alterações costumam ser pequenas demais para adquirir um significado comum. Um objeto parece deslocado sem que ninguém recorde tê-lo movido. Um som termina antes da própria reverberação. Pessoas diferentes sonham com o mesmo lugar e o esquecem ao despertar. Animais evitam uma sala, uma árvore ou uma rua sem reagir a qualquer presença visível. O erro existe, mas ainda não encontrou forma suficiente para insistir.

A Ordem chama esse estado de Pré-Furo. É o momento em que intervenção, compreensão ou simples restauração da continuidade local ainda podem impedir que a Dobra se aprofunde. Uma prática retomada, um conflito encerrado, um nome devolvido ao arquivo ou uma estrutura reparada podem oferecer ao Véu material suficiente para recompor-se.

O Furo surge quando a Prega se torna Bolsão. A Dobra atravessa o Véu e começa a ocupar o Reflexo. Não existe ainda fixação verdadeira; a passagem depende da tensão que a alimenta e permanece instável. Por isso um Furo pode crescer, recuar, pulsar ou fechar-se.

Quanto mais profundo se torna, mais o ambiente deixa de apresentar incidentes isolados e passa a responder segundo um padrão. Os primeiros Furos alteram pontos pequenos. Outros reorganizam salas, lembranças, corpos ou sequências. Nos mais críticos, aquilo que atravessa já procura no mundo uma relação capaz de sustentá-lo.

Fechar um Furo significa impedir que o Bolsão complete sua Ancoragem. O Selo recompõe ou cobre a abertura e devolve a Dobra para além do limite que havia atravessado. A cicatriz pode permanecer sensível por anos, mas a malha estrangeira já não possui continuidade própria no Reflexo.

Um Furo ainda pode ser fechado porque continua sendo passagem. Mas quando encontra sustentação local, já não é mais Furo.

Furos se fecham.
