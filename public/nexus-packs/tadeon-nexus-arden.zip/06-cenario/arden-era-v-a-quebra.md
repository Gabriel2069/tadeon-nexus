---
title: "Arden — Era V ~ A Quebra"
node_type: "historical_event"
summary: "Seção “Era V ~ A Quebra” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Era V ~ A Quebra"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Era V ~ A Quebra","source_order":56,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Era V ~ A Quebra

Anos 900 a 1.400

A Quebra não foi uma noite. Foi um longo período em que crises diferentes encontraram vias para reforçar umas às outras. A Grande Pestilência, entre meados do século X e o início do XI, matou até três em cada dez pessoas em certas regiões. Portos fecharam, aldeias desapareceram, hospitais improvisaram métodos e comunidades abandonaram mortos sem os ritos que sustentavam sua memória.

A doença era natural em sua transmissão e devastadora em suas consequências sociais. A mortalidade coletiva, o deslocamento e a ruptura de práticas abriram condições para Furos em lugares antes estáveis. A Ordem cometeu um de seus erros mais duradouros ao procurar uma única causa primordial para ocorrências que exigiam medicina, logística, cuidado e Selagem ao mesmo tempo.

Guerras de sucessão redesenharam fronteiras. Casas bancárias ruíram depois de cadeias de dívida e perda de arquivos. Estradas deixaram de ser mantidas. Regiões que haviam dependido de importação reaprenderam técnicas locais. Outras nunca se recuperaram por completo.

A Eclésia tornou-se essencial em hospitais, abrigos e preservação de registros. O Instituto Viridário nasceu nesse contexto. A Ordem reformou protocolos, criou redundâncias de arquivo e ampliou funções de cura e interpretação. Também aprofundou o segredo, convencida de que populações exaustas não suportariam conhecer a extensão do Além-Véu.

Ao final da era, Veth era menos populoso, mais institucional e mais desconfiado. Muitas estruturas do presente surgiram como respostas emergenciais que nunca foram desfeitas.
