---
title: "Arden — O primeiro mundo"
node_type: "concept"
summary: "Seção “O primeiro mundo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O primeiro mundo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O primeiro mundo","source_order":9,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O primeiro mundo

Quando Tempo, Medo e Conhecimento se atravessaram de maneira estável, o Reflexo começou. Não como algum projeto completo, mas como uma continuidade. A matéria encontrou duração; as estrelas, ciclos; os mares, limites temporários. Regularidades físicas surgiram porque o mundo aprendeu a repetir relações sem precisar recordá-las conscientemente.

A Ordem descreve esse processo por modelos, e as academias o estudam por física, astronomia, química e geologia. A Cristandade contempla nele a intenção do Criador. As duas leituras não precisam competir. Uma trata das relações que podem ser observadas dentro do mundo; a outra pergunta por que existe um mundo capaz de sustentá-las. Em Arden, houve períodos em que pessoas transformaram essa diferença em rivalidade. Nunca conseguiram impedir que seus próprios métodos continuassem aproximando-as da mesma borda.
