---
title: "Arden — Uma estabilidade dependente"
node_type: "concept"
summary: "Seção “Uma estabilidade dependente” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Uma estabilidade dependente"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Uma estabilidade dependente","source_order":58,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Uma estabilidade dependente

Em 1.847, a maioria das pessoas encontra um mundo funcional. Mercados abrem, colheitas são previstas, mensagens chegam, hospitais tratam doenças e tribunais resolvem parte suficiente dos conflitos. Guerras existem, mas tratados limitam seus piores excessos. A Cristandade oferece uma linguagem comum de dignidade. A Concordância oferece procedimentos. A ciência continua avançando.

Essa estabilidade depende de redes acumuladas. Uma cidade pode parecer autônoma e ainda receber grãos de três reinos, pressão de uma estação fora de seus muros, crédito de Vélia, reagentes de Verdania e sinais de uma torre mantida por outra jurisdição. Histórias contemporâneas de Arden ganham força quando revelam uma dependência invisível sem transformar toda instituição em conspiração.
