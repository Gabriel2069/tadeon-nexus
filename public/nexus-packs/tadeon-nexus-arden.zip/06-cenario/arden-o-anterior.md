---
title: "Arden — O Anterior"
node_type: "concept"
summary: "Seção “O Anterior” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O Anterior"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O Anterior","source_order":4,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O Anterior

Existe, além de tudo que pode ser medido ou colocado em sequência, aquilo que os teólogos mais cautelosos chamam de o Anterior. Não lhe atribuem corpo, gênero ou lugar. Até mesmo intenção é uma palavra insegura, pois pressupõe a passagem entre desejar e agir, e essa passagem pertence ao Tempo. O Anterior precede o próprio sentido de preceder.

A Cristandade de Veth chama-o de Criador. Não porque possua uma descrição completa, mas porque reconhece no mundo a consequência de um ato que não precisava ter acontecido. A Ordem raramente emprega o mesmo nome em relatórios, embora estude desde sua fundação os rastros desse ato. Alguns membros veem nisso uma diferença de método. Outros, depois de anos diante das mesmas perguntas, concluem que oração e investigação se aproximam de uma margem comum por lados distintos.

O que houve antes do toque do Anterior não pode ser dito. O próprio verbo haver já concede existência, duração e distinção demais. Há somente uma imagem repetida em tradições separadas por oceanos: algo tocou aquilo que ainda não era coisa alguma, e a ausência percebeu que podia deixar de ser inteira.
