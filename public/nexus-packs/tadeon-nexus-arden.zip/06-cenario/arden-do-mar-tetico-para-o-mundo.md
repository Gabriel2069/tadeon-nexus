---
title: "Arden — Do Mar Tético para o mundo"
node_type: "sea"
summary: "Seção “Do Mar Tético para o mundo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Do Mar Tético para o mundo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Do Mar Tético para o mundo","source_order":31,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Do Mar Tético para o mundo

As evidências mais antigas de humanidade consciente concentram-se nas margens do antigo Mar Tético. O lugar recebeu muitos nomes, entre eles Mar do Éden, antes que a forma atual se estabilizasse. Costas férteis, estuários, ilhas e mudanças climáticas repetidas favoreceram populações capazes de mover-se, trocar e conservar técnicas.

A dispersão não ocorreu como uma marcha única. Grupos seguiram rios para o interior, contornaram montanhas, atravessaram estreitos e retornaram a regiões já ocupadas por parentes distantes. Populações separaram-se e reencontraram-se inúmeras vezes. Por isso, nenhuma cultura de Arden representa um estágio intacto do passado. Todas são resultado de continuidade, contato, perda e escolha.
