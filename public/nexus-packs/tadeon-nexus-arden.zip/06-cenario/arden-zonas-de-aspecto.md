---
title: "Arden — Zonas de Aspecto"
node_type: "concept"
summary: "Seção “Zonas de Aspecto” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Zonas de Aspecto"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Zonas de Aspecto","source_order":17,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Zonas de Aspecto

Quando uma Âncora se aprofunda além da fixação local, a Dobra começa a territorializar-se. Ela deixa de depender de um foco, de uma construção ou de uma única comunidade e passa a reorganizar uma região segundo a lógica da malha que sustenta.

A Ordem chama esse estado, que até então se mantém em de Zona de Aspecto, expressão conservada por seus protocolos mesmo depois de sucessivas reformas cosmológicas. Numa Zona, o Além-Véu não está apenas presente. O território começa a aceitar suas relações como parte das condições locais.

Uma Zona ligada a Eclis pode reorganizar ecossistemas e corpos até que deformação e adaptação se tornem difíceis de separar. Morae pode fazer pensamentos, identidades e percepções circularem entre habitantes. Thyren transforma ausência, distância e ocultação em propriedades do espaço. Zha’el permite que culpa, julgamento ou valor determinem consequências materiais. Zonas de Conhecimento podem conservar versões únicas da história, ordenar comunidades em padrões rígidos ou impedir que uma região esqueça. O Fluxo pode fazer épocas diferentes disputarem o mesmo lugar.

Não se resolve uma Zona com um único Selo. Parte dela pode ser isolada, reduzida ou pacificada. Seus Pontos de Costura precisam ser recuperados ao longo de uma operação extensa, pois aquilo que antes era uma anomalia já possui habitantes, hábitos, caminhos e interesses.

Reconquistar uma Zona não significa retornar o território a um passado intacto. Significa devolver ao Reflexo relações suficientes para que pessoas e lugares voltem a escolher o que podem tornar-se.

Zonas se reconquistam.
