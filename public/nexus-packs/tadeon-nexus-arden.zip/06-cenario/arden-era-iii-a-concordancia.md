---
title: "Arden — Era III ~ A Concordância"
node_type: "historical_event"
summary: "Seção “Era III ~ A Concordância” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Era III ~ A Concordância"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Era III ~ A Concordância","source_order":54,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Era III ~ A Concordância

Anos 0 a 400

O Ano Zero não unificou Veth politicamente. Criou a linguagem para que diferenças fossem negociadas sem precisar dar origem a guerras. O primeiro tratado estabeleceu padrões de medida, garantias de trânsito, reconhecimento de contratos e formas de arbitragem entre signatários dos mares internos.

O Vethi Comum, já falado nos portos, ganhou gramáticas, escolas e uso administrativo. Calendários foram correlacionados. Casas de crédito passaram a compensar dívidas entre reinos. A circulação de técnicas acelerou, e a noção de que uma descoberta poderia pertencer a uma comunidade científica mais ampla começou a disputar espaço com segredos de guilda.

A Proto-Ordem encontrou no novo sistema condições para sua primeira reforma. Um concílio de praticantes passou décadas comparando Selos, taxonomias e relatos. O nome Ordem do Véu tornou-se comum, assim como o princípio de que conter não significa destruir e compreender não significa obedecer.

O período também produziu resistência. Reinos temiam perda de autonomia, guildas recusavam padrões, comunidades viam o Vethi como ameaça às línguas locais. A Concordância sobreviveu porque não exigiu uma identidade única. Tornou-se uma infraestrutura de convivência: imperfeita e difícil de abandonar.
