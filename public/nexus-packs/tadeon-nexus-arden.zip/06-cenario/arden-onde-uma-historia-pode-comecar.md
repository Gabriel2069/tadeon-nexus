---
title: "Arden — Onde uma história pode começar"
node_type: "concept"
summary: "Seção “Onde uma história pode começar” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Onde uma história pode começar"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Onde uma história pode começar","source_order":63,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Onde uma história pode começar

Uma história em Arden começa onde uma continuidade concreta deixa de funcionar. Pode ser um bairro cuja rede pneumática transmite vozes; uma comunidade que perdeu o ritual funerário durante uma epidemia; um arquivo óptico que conserva versões divergentes do mesmo tratado; uma mina de Kitomena em que cristais reagem a nomes; um mosteiro construído sobre Revérbero; um navio preso nas correntes de Veth Cinério; uma cidade de Yamashiro evacuada depois de tremores que obedecem ao calendário.

O mundo já oferece o bastante. Escolha uma região, uma instituição, uma prática cotidiana, uma ferida e as pessoas que dependem dela. A escala pode crescer, mas não precisa começar grande.
