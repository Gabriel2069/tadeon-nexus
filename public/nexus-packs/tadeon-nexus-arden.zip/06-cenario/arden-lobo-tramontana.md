---
title: "Arden — Lobo Tramontana"
node_type: "region"
summary: "Seção “Lobo Tramontana” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Lobo Tramontana"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Lobo Tramontana","source_order":25,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Lobo Tramontana

Tramontana estende-se de oeste a leste sob a Franja Norte. Seu bloco ocidental reúne costas frias, planícies temperadas, o Mar de Veth e algumas das regiões urbanas mais antigas. A leste desse mar, Valdmere e Rethmark aproximam-se do Arco Montanhoso Central, a grande sutura que registra a separação e a reunião de duas porções do continente.

Além das cristas encontra-se a Bacia Yamashirense, remanescente do mar antigo que existiu entre os blocos. O arquipélago de Yamashiro ergue-se dentro dela, ainda vulcânico, cercado por cidades que aprenderam a construir junto de tremores, fontes termais e caldeiras. Daesung e Qin ocupam o bloco oriental, onde o Rio Han Ji atravessa planícies de monção antes de alcançar o Oceano Forâneo.

Tramontana oferece histórias de passagem: do frio polar às cidades téticas, das planícies às montanhas, de uma civilização ocidental integrada ao Oriente por corredores que já foram fundo oceânico. Toda travessia carrega a lembrança de que o continente foi inteiro, deixou de ser e voltou a parecer inteiro sem apagar a divisão.
