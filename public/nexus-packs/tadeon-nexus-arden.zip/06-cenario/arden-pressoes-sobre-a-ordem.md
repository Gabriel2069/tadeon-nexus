---
title: "Arden — Pressões sobre a Ordem"
node_type: "organization"
summary: "Seção “Pressões sobre a Ordem” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Pressões sobre a Ordem"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Pressões sobre a Ordem","source_order":60,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Pressões sobre a Ordem

A Ordem perdeu pessoas, arquivos e confiança com a Base Sul. Seus membros discordam sobre transparência, relação com a Eclésia e cooperação com academias. A Segunda Luz preserva cópias de documentos que o Conclave perdeu, embora a forma como as obteve seja suspeita. O Mercado das Costuras movimenta Fragmentos mais rápido do que apreensões conseguem acompanhá-los.

A frequência crescente de Furos força decisões ruins. Bases escolhem quais ocorrências merecem resposta. Governos percebem padrões. Comunidades mantêm Selos sem apoio. Algumas manifestações são contidas por pessoas que nunca ouviram o nome da Ordem.
