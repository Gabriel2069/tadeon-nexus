---
title: "Arden — A longa gestação da Ordem"
node_type: "organization"
summary: "Seção “A longa gestação da Ordem” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["A longa gestação da Ordem"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"A longa gestação da Ordem","source_order":48,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# A longa gestação da Ordem

A Ordem do Véu não começou com um fundador. Durante as Guerras de Formação, pessoas de regiões distantes descobriram práticas capazes de conter manifestações, reconhecer Fragmentos e reforçar continuidades locais. Eram curadores, artesãos, sacerdotes, estudiosos, militares, parteiras e pessoas que sobreviveram a algo que suas comunidades não conseguiam nomear.

A rede surgiu quando esses praticantes passaram a reconhecer resultados uns nos outros. Comércio, exílio, peregrinação e hospitalidade permitiram comparação. Métodos incompatíveis revelaram princípios comuns. O silêncio, inicialmente simples prudência, tornou-se parte da organização.

A Cristandade não foi criada para servir à Ordem. Suas comunidades já existiam, e muitas de suas práticas sustentavam relações que a Proto-Ordem aprenderia mais tarde a descrever. Mosteiros ocupavam lugares remotos, conservavam registros e recebiam pessoas feridas por experiências que governos preferiam negar. A aproximação aconteceu porque ambos trabalhavam sobre continuidade: um por fé, cuidado e memória; outro por observação, Selagem e contenção.

Com os séculos, a Ordem passou a habitar partes da Eclésia. Alguns abades e prioras pertenciam a ela; alguns rituais religiosos coincidiam com manutenção de Selos; alguns scriptorios guardavam dois catálogos. A maioria dos fiéis, ministros e instituições nunca conheceu essa estrutura secreta. Sua fé continuou autêntica. A Ordem sobreviveu dentro da Eclésia porque não precisava fingir que cuidado, significado e repetição eram úteis. Precisava apenas compreender que já eram.
