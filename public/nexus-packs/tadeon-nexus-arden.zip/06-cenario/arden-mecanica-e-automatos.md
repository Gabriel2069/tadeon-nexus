---
title: "Arden — Mecânica e autômatos"
node_type: "concept"
summary: "Seção “Mecânica e autômatos” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Mecânica e autômatos"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Mecânica e autômatos","source_order":42,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Mecânica e autômatos

Engrenagens, cames, molas, contrapesos e mecanismos diferenciais realizam tarefas repetitivas, controlam fluxos e traduzem sinais em movimentos. Autômatos agrícolas, industriais, domésticos e cerimoniais podem atingir complexidade impressionante. Sua inteligência aparente nasce do desenho cuidadoso de respostas, não de consciência.

A mecânica de precisão é também arte. Um instrumento revela escola, região e linhagem de oficina na escolha de metal, ritmo e acabamento. Máquinas são reparadas por gerações e acumulam modificações que nenhum projeto original previa. Algumas tornam-se instituições materiais: uma cidade não saberia mais operar sem um mecanismo construído por pessoas cujos nomes perdeu.
