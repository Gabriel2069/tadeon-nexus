---
title: "Arden — Veth Cinério"
node_type: "region"
summary: "Seção “Veth Cinério” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Veth Cinério"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Veth Cinério","source_order":30,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Veth Cinério

Veth Cinério ergue-se muito a leste, sobre a Placa Forânea. Não é polar. Possui chuvas, rios, florestas e terras que poderiam sustentar ocupação mais ampla. Ainda assim, nenhuma colonização duradoura produziu continuidade comparável à das outras massas.

Correntes irregulares e distância explicam parte do isolamento. O restante pertence ao que a Ordem chama de Confluência: uma concentração de Âncoras e sobreposições cuja origem pode estar ligada à Grande Contenção. O Véu ali não se apresenta simplesmente fino. Em alguns lugares, relações incompatíveis permanecem visíveis ao mesmo tempo.

No interior fica O Cerne, um planalto onde vegetação, oxidação, memória e passagem do tempo respondem de maneiras que não se repetem com segurança. A Ordem mantém presença limitada e rotativa. Nenhum mapa interno deve ser tratado como definitivo. Em Arden, Veth Cinério é uma região; para uma campanha, pode tornar-se um mundo inteiro.

| GEOGRAFIA COMO ESCOLHA Escolher uma região já define parte do tom. Tramontana favorece travessias entre tradição e integração técnica; Ocíduo, distâncias ecológicas e rios; Alvor, escassez, planaltos e civilizações antigas; Yawurua, permanência geológica; ilhas, isolamento e especialização; Veth Cinério, incerteza ontológica. |
| --- |
