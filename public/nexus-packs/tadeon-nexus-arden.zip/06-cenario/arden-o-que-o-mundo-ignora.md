---
title: "Arden — O que o mundo ignora"
node_type: "concept"
summary: "Seção “O que o mundo ignora” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O que o mundo ignora"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O que o mundo ignora","source_order":62,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O que o mundo ignora

Pouquíssimas pessoas conhecem a cosmologia da Ordem. Menos ainda conhecem a extensão de suas dúvidas. A população não vive em negação constante; vive com categorias adequadas à experiência comum. A maioria dos ruídos é só ruído. A maioria dos sonhos pertence a quem sonha. A maioria das doenças exige médico, não Selador.

O narrador preserva o tom quando permite que explicações naturais sejam verdadeiras e que o Além-Véu participe delas sem torná-las falsas. Um surto pode ser doença e ainda encontrar Significância suficiente para produzir manifestação. Uma guerra pode ser política e abrir Âncoras. Um culto pode explorar pessoas antes de servir a qualquer Primevo.
