---
title: "Arden — Era II ~ A Formação"
node_type: "historical_event"
summary: "Seção “Era II ~ A Formação” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Era II ~ A Formação"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Era II ~ A Formação","source_order":53,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Era II ~ A Formação

Dos primeiros Estados ao século anterior à Concordância

A agricultura de escala, o domínio de rios e o crescimento de portos transformaram assentamentos em Estados. Kemet organizou-se ao redor do Netjer. Cidades vêlianas ocuparam margens do Mar Tético. Comunidades de Verdania, Huexotl, Tramontana e Yawurua desenvolveram sistemas próprios de escrita, medida e autoridade.

As Guerras de Formação não foram um conflito único. Foram séculos em que cidades, dinastias, ligas e povos móveis disputaram água, passagens, tributos e legitimidade. Cordilheiras definiram fronteiras; mares permitiram contorná-las. Reinos nasceram, desapareceram e deixaram instituições que sucessores conservaram sem conservar seus nomes.

As grandes tradições técnicas adquiriram forma nesse período. Sistemas pneumáticos surgiram em vales e oficinas que precisavam mover força sem depender de animais em todos os pontos. Óptica cresceu em observatórios, portos e desertos. Bioalquimia desenvolveu-se em regiões de alta diversidade e em centros médicos. Nenhuma tradição permaneceu regional por muito tempo.

A Cristandade espalhou-se por tradução, hospitalidade, cuidado e adaptação litúrgica. Sua descentralização permitiu que comunidades distantes se reconhecessem sem abandonar práticas locais. A Proto-Ordem cresceu nos mesmos corredores, ainda sem nome único, reunindo Seladores que trocavam métodos e aprendiam a distinguir a eficácia de repetição vazia.

O final da era foi marcado pelo cansaço. Reinos comercialmente dependentes uns dos outros continuavam submetidos a dezenas de medidas, moedas, direitos de passagem e ciclos de retaliação. A Concordância nasceu menos de idealismo do que da percepção de que a continuidade do comércio já era maior do que qualquer Estado conseguia controlar sozinho.
