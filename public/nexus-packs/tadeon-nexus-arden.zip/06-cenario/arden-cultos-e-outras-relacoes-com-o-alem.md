---
title: "Arden — Cultos e outras relações com o Além"
node_type: "concept"
summary: "Seção “Cultos e outras relações com o Além” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Cultos e outras relações com o Além"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Cultos e outras relações com o Além","source_order":50,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Cultos e outras relações com o Além

A Eclésia rejeita cultos que transformam manifestações em autoridade espiritual. A rejeição nasce tanto de doutrina quanto de experiência: exposição pode ser confundida com revelação, coerção com transcendência, dissolução da identidade com união.

Nem toda prática popular relacionada ao Além-Véu é culto. Amuletos, histórias, tabus, festas e gestos protetivos podem conservar memória real, superstição, comércio ou tudo isso ao mesmo tempo. A Ordem erra quando trata uma cultura inteira como risco. Comunidades erram quando preservam uma prática depois que o significado original foi substituído por outra presença.

Redes como o Mercado das Costuras, dissidências científicas e grupos de arquivo mostram que o sobrenatural também circula por ambição, curiosidade, necessidade e convicção. Nem todo antagonista deseja o fim do mundo. Muitos acreditam que o segredo da Ordem já causa mais dano do que o conhecimento que ela esconde.

| INSTITUIÇÕES EM CENA Nenhuma instituição deve aparecer como uma mente única. Dê rosto às divergências: um mosteiro que protege a comunidade e recusa a Ordem; um Vigia que teme a transparência; uma pesquisadora que rompe protocolos para salvar pacientes; um governo que precisa da contenção e desconfia de quem a oferece. |
| --- |
