---
title: "Arden — Pontos de Costura"
node_type: "concept"
summary: "Seção “Pontos de Costura” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Pontos de Costura"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Pontos de Costura","source_order":22,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Pontos de Costura

Toda manifestação que permanece no Reflexo depende de uma relação específica. O Ponto de Costura é a forma narrativa dessa dependência: aquilo que precisa ser descoberto para que a ameaça deixe de ser apenas uma quantidade de força.

Pode ser uma contradição, um nome verdadeiro, uma ausência, uma promessa, uma sequência temporal, uma posição física ou o vínculo entre duas pessoas. Encontrá-lo exige investigação porque o mundo raramente apresenta suas causas na superfície. Agir sobre ele transforma o confronto. Uma criatura pode ser ferida muitas vezes; somente a Costura explica por que ela continua existindo.

| A REGRA E A VERDADE As regras de Furos, Âncoras, Selos, Tramas, Magnitude e Pontos de Costura não acrescentam uma camada mecânica sobre o cenário. Elas medem consequências que já existem na ficção. Quando uma regra parecer abstrata, retorne à relação que ela representa. |
| --- |
