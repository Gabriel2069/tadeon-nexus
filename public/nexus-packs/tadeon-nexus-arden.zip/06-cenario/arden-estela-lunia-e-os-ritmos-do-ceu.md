---
title: "Arden — Estela, Lúnia e os ritmos do céu"
node_type: "concept"
summary: "Seção “Estela, Lúnia e os ritmos do céu” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Estela, Lúnia e os ritmos do céu"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Estela, Lúnia e os ritmos do céu","source_order":23,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Estela, Lúnia e os ritmos do céu

Arden orbita Estela, cuja luz organiza dias, estações, colheitas e grande parte das matrizes energéticas de Veth. Lúnia acompanha o planeta e governa marés, calendários regionais, festividades e antigas práticas de observação. Nenhum povo precisou conhecer a mecânica celeste completa para perceber que os corpos acima participavam do movimento das águas e da vida.

Astrônomos de Kemet, Qalat, Colhara e muitas outras regiões transformaram a observação em medida. Teólogos viram nos ciclos uma forma de fidelidade. Navegadores construíram rotas sobre posições de estrelas. A Ordem descobriu que certos Selos respondem a configurações celestes, embora nunca tenha provado se os astros alteram a Tessitura ou apenas oferecem relógios tão antigos que o mundo inteiro aprendeu a obedecê-los.
