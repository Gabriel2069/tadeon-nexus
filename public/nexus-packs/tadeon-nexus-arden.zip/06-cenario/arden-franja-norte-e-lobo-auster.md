---
title: "Arden — Franja Norte e Lobo Auster"
node_type: "region"
summary: "Seção “Franja Norte e Lobo Auster” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Franja Norte e Lobo Auster"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Franja Norte e Lobo Auster","source_order":29,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Franja Norte e Lobo Auster

A Franja Norte não é uma linha de terra, mas uma faixa de plataformas de gelo, ilhas, montanhas e mares que se abrem e fecham conforme as estações. Expedições partem de Myrova e Nordhavn, seguindo janelas de navegação que podem não existir no retorno.

O Lobo Auster ocupa o extremo sul. Sua costa norte foi visitada, medida e abandonada por equipes que retornaram com dados, amostras e pouca vontade de repetir a viagem. Sob o gelo existem montanhas, bacias e lagos. Registros antigos da Ordem sugerem relações entre Auster e a primeira estabilização ampla do Véu, mas a afirmação permanece cercada por lacunas demais para tornar-se consenso.
