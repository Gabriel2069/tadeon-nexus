---
title: "Arden — Confronto"
node_type: "concept"
summary: "Seção “Confronto” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Confronto"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Confronto","source_order":68,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Confronto

Combate existe em Arden, mas força raramente resolve sozinha uma manifestação estabilizada. O confronto deve expressar investigação acumulada. Conhecer território, reduzir capacidades, proteger relações e atingir a Costura torna as regras parte da narrativa.

Contra pessoas, o combate continua humano: rápido, perigoso e cheio de consequências políticas. A presença do Além-Véu não transforma todos os conflitos em batalhas contra monstros. Muitas histórias terminam com decisões sobre segredo, autoridade, culpa e reparação.
