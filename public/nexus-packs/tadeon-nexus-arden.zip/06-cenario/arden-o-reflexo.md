---
title: "Arden — O Reflexo"
node_type: "concept"
summary: "Seção “O Reflexo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O Reflexo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O Reflexo","source_order":3,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O Reflexo

A realidade em que a humanidade vive recebe, entre os estudiosos da Ordem, o nome de Reflexo. A palavra não significa cópia. Não existe um original completo aguardando do outro lado, do qual este mundo seria versão empobrecida. Reflexo é o lugar em que relações adquirem forma suficiente para serem vividas: onde uma causa encontra consequência, onde um corpo mantém contorno, onde uma lembrança pertence a alguém e onde uma palavra pode ser repetida sem tornar-se outra coisa a cada som.

O Reflexo parece sólido porque repete a si mesmo com admirável fidelidade. A pedra cai; a água encontra o ponto mais baixo; o sangue coagula; uma estrela retorna ao meridiano previsto. A ciência nasce dessa confiança. A vida também. Nada poderia amadurecer, aprender ou prometer se o mundo precisasse decidir novamente suas regras a cada instante.

Ainda assim, estabilidade não é isolamento. O Reflexo é tecido pelas mesmas forças que excedem seus limites. O Além-Véu não é um país distante, tampouco um depósito de monstros aguardando passagem. Ele está na origem e na continuidade de tudo que existe. A diferença humana não é estar livre dele, mas possuir uma organização capaz de transformar seus fios em identidade, vínculo e escolhas.

| PARA NARRAR ARDEN Comece pelo que funciona. Uma aldeia precisa ter colheitas, hábitos, parentescos, instrumentos e uma memória local antes que qualquer Furo tenha importância. O horror surge quando algo conhecido deixa de conservar a relação que o tornava reconhecível. |
| --- |
