---
title: "Arden — Ciência e fé"
node_type: "concept"
summary: "Seção “Ciência e fé” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Ciência e fé"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Ciência e fé","source_order":46,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Ciência e fé

Alguns estudiosos e ministros tratam ciência e fé como rivais. A rivalidade costuma crescer quando uma delas pretende ocupar a pergunta da outra. A ciência descreve relações, mede, testa e aprende a produzir efeitos. A fé pergunta por intenção, dignidade, responsabilidade e por aquilo que permanece quando uma explicação não oferece consolo.

Nos limites, ambas encontram o mesmo objeto. A Ordem estuda as consequências do toque do Anterior. A Eclésia adora o Criador. Um método não prova a totalidade do outro, mas muitos dos membros mais experientes de ambas reconhecem que a distância entre eles é menor do que suas instituições gostam de admitir.

Essa convergência não torna a religião um manual secreto de cosmologia, nem a ciência uma liturgia disfarçada. Mantém a dualidade viva. Uma campanha pode apresentar personagens sinceramente religiosos e cientistas igualmente sinceros sem decidir que um grupo vive numa ilusão menor.
