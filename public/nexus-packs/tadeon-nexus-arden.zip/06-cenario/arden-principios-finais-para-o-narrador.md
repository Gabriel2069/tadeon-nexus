---
title: "Arden — Princípios finais para o narrador"
node_type: "concept"
summary: "Seção “Princípios finais para o narrador” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Princípios finais para o narrador"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Princípios finais para o narrador","source_order":72,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Princípios finais para o narrador

◆ O mundo comum deve funcionar antes de falhar.

◆ O Além-Véu está presente na constituição do mundo; manifestação não significa invasão de um exterior puro.

◆ Ciência, fé e tradição podem observar a mesma verdade sem usar o mesmo vocabulário.

◆ Instituições possuem memória, interesses, pessoas e contradições.

◆ Tecnologia deve resolver problemas concretos e criar dependências concretas.

◆ Toda ameaça persistente possui uma relação que a sustenta.

◆ Consequências devem permanecer: corpos, cidades e vínculos não retornam automaticamente ao estado anterior.

◆ O mistério amplia a imaginação quando possui contorno suficiente para orientar ações.

◆ Arden não costuma precisar ser expandido para servir à campanha. Pede ser escolhido.

Arden não espera passivamente. Cidades continuam crescendo, rios mudam curso, instituições esquecem seus propósitos e o Véu responde a cada continuidade que se fortalece ou se perde. O mundo não se prepara para uma única história. Prepara condições para milhares delas.

A tarefa do narrador é decidir qual delas os personagens encontrarão primeiro.

Anterior / Criador

Aquilo que precede Vazio, Tempo, Medo e Conhecimento. A Cristandade o adora como Criador; a Ordem estuda indiretamente as consequências de seu toque.

Vazio

A falta que se percebeu e, ao fazê-lo, tornou possível distinção. Origem conceitual de Tempo, Medo e Conhecimento.

Tempo

Condição de sequência, transformação e consequência. Sua manifestação é chamada Fluxo.

Fluxo

Manifestação ou direção reconhecível do Tempo, percebida em alterações de sequência, repetição e duração.

Medo

Natureza primordial ligada a limite, incorporação, resistência, perda e dissolução.

Primeiro

Manifestação mais antiga reconhecível do Medo e aproximação do Inverso. Não equivale à totalidade do Medo.

Inverso

Condição-limite do Medo em que distinção e ameaça deixam de ser separáveis

Conhecimento

Natureza primordial que permite distinção, reconhecimento, conservação e relação significativa.

Chama Fria

Manifestação central do Conhecimento, ligada a clareza, organização e permanência.

Reflexo

Realidade relacional habitada, onde matéria, consciência e sequência conservam regularidade suficiente para a vida.

Além-Véu

Conjunto de relações e formas que excedem a organização estável do Reflexo. Não é somente um lugar exterior.

Véu

Malha viva de relações que mantém coisas, pessoas, lugares e histórias pertencendo ao Reflexo.

Tessitura

Estrutura relacional completa formada por fios e malhas; também o campo de estudo que busca compreender suas alterações.

Urdidura

Organização profunda da Tessitura e conjunto cosmológico que explica como o cenário, as ameaças e a Canalização se relacionam.

Fio

Relação mínima ainda perceptível como dependência entre partes do mundo.

Malha

Conjunto de fios que sustentam uma forma comum, como corpo, lugar, língua, instituição ou memória coletiva.

Natureza

Origem primordial dos fios empregados ou manifestados: Medo, Conhecimento ou Tempo.

Domínio

Modo recorrente de organização de uma Natureza. Eclis, Morae, Thyren e Zha’el são Domínios do Medo; Memória, Significância, Linguagem e Alma são Domínios do Conhecimento.

Dobra

Deformação local da Tessitura produzida pela aproximação, sobreposição ou manipulação de malhas. É a estrutura fundamental da qual surgem Pregas, Furos, Âncoras, Zonas e Revérberos.

Prega

Primeiro movimento de uma Dobra. O Véu cede e sofre pressão, mas ainda não foi atravessado. Origina o Pré-Furo.

Pré-Furo

Prega ativa na qual o Véu já perdeu tensão, mas nenhuma passagem estável foi formada.

Bolsão

Movimento em que a Dobra atravessa o Véu e ocupa o Reflexo de forma instável. Origina os Furos.

Furo

Falha local do Véu em que relações deixam de sustentar a forma esperada do Reflexo.

Ancoragem

Movimento em que uma Dobra se fixa ao Reflexo e passa a sustentar-se por relações locais. Origina as Âncoras.

Âncora

Dobra fixada ao Reflexo, sustentada pela malha do lugar e incapaz de simplesmente retornar para além do Véu.

Zona de Aspecto

Estado territorial de uma Dobra em que uma região passa a reorganizar-se segundo a lógica da malha que a ocupa.

Revérbero

Dobra estabilizada naturalmente ou pela pacificação de uma Âncora. Seus fios permanecem no Reflexo sem Tensão ativa.

Fragmento

Retalho desprendido de uma Dobra que se desfez de forma incompleta, preservando parte de seu padrão e de sua assinatura, e podendo mediar Canalização.

Canalização

Aproximação e manipulação consciente de fios profundos da Tessitura.

Trama

Padrão temporário produzido por Canalização para reorganizar uma relação do Reflexo.

Refluxo

Retorno desordenado dos fios durante ou após o relaxamento de uma Trama.

Selo

Estrutura que estabelece e fixa uma borda de continuidade, permitindo ao Reflexo recompor ou conter uma ruptura.

Ponto de Costura

Relação específica que sustenta a permanência de uma ameaça e que pode ser descoberta e alterada narrativamente.

Marca

Momento ou relação em que um personagem passou a reconhecer os rasgos do mundo.

Primevo

Classificação histórica e operacional para manifestações complexas do Medo que adquiriram padrão próprio.

Veth

Conjunto continental, marítimo e civilizacional onde se concentra a humanidade conhecida de Arden.

Concordância

Sistema de tratados, medidas, tribunais e redes iniciado no Ano Zero para organizar a convivência e circulação entre reinos.

Vethi Comum

Língua franca de comércio, administração e circulação inter-regional.

Cristandade de Veth

Fé ampla que reconhece o Criador, a dignidade humana e uma relação ética entre divino e criação.

Eclésia de Veth

Rede institucional de comunidades, mosteiros, escolas, hospitais, scriptoria e concílios da Cristandade.

Ordem do Véu

Instituição velada dedicada a estudo, contenção, cura, arquivo e vigilância de fenômenos ligados à Tessitura.

Grande Contenção

Evento pré-histórico associado à Confluência e ao Cerne, cuja natureza completa permanece desconhecida.

Confluência

Nome da Ordem para a concentração de Âncoras e sobreposições em Veth Cinério.

O Cerne

Planalto interior de Veth Cinério onde as consequências da Grande Contenção permanecem visíveis.

Grande Pestilência

Conjunto epidêmico dos séculos X e XI que devastou regiões de Veth e alterou instituições, demografia e estabilidade do Véu.

Liga de Osva

Coalizão de dezoito reinos fundada em 1.800 para compartilhar inteligência, padrões e assistência defensiva.

Colapso da Base Sul

Destruição da principal base meridional da Ordem em 1.845, ainda não explicada de forma conclusiva.
