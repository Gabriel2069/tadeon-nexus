---
title: "Arden — Era VI ~ O Presente"
node_type: "historical_event"
summary: "Seção “Era VI ~ O Presente” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Era VI ~ O Presente"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Era VI ~ O Presente","source_order":57,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Era VI ~ O Presente

Anos 1.400 a 1.847

A Era Presente começou com reconstrução. Reinos estabilizaram fronteiras, cidades voltaram a crescer e tecnologias da Expansão foram refinadas. Pneumática, óptica, bioalquimia e mecânica alcançaram integração que seus criadores iniciais não teriam imaginado. A Concordância passou por reformas e ampliou tribunais, arquivos e padrões.

A estabilidade, porém, tornou-se dependente de redes que poucas pessoas compreendem por inteiro. Bancos, torres de Hélio, matrizes energéticas, hospitais e rotas de abastecimento atravessam soberanias. A política do presente é menos marcada por conquista direta do que por acesso, crédito, informação e capacidade técnica.

A partir de 1.700, registros da Ordem indicam aumento lento e consistente na frequência de Furos. Nenhuma região parece concentrar a causa. Lugares historicamente estáveis apresentam falhas. Selos antigos exigem manutenção mais frequente. Revérberos produzem efeitos que não constam em arquivos anteriores.

Em 1.800, dezoito reinos firmaram o Tratado de Osva e criaram a Liga de Osva, compartilhando inteligência, padrões e assistência defensiva. A Liga não é um governo, mas concentra capacidade suficiente para alterar o equilíbrio de todo Veth. Outros reinos veem nela proteção, ameaça ou modelo inevitável.

Em 1.845, a Base Sul da Ordem foi destruída. O colapso foi rápido, coordenado e deixou registros incompatíveis. Sobreviventes descrevem uma manifestação que parecia combinar Domínios sem obedecer às separações tradicionais. Arquivos foram retirados antes do evento por pessoas ainda não identificadas. Dois anos depois, a Ordem continua operando com lacunas, suspeitas internas e regiões meridionais sem coordenação plena.

O Primeiro aparece em hipóteses que o Conclave evita registrar como conclusão. Pode haver intenção por trás da aceleração. Pode haver um processo mais antigo que a Ordem interpretou através de uma figura conhecida. Em 1.847, a diferença entre essas possibilidades já não é acadêmica.

A reconstrução também abriu rotas que as eras anteriores não podiam manter. Expedições cruzam o Oceano Forâneo, sondam fundos profundos e aproximam-se de Veth Cinério com instrumentos capazes de registrar muito mais do que seus intérpretes conseguem compreender. Cada viagem amplia o mapa e enfraquece a antiga certeza de que as regiões conhecidas eram suficientes.

Ao mesmo tempo, a população de Veth passou a viver cercada por permanências herdadas da Quebra. Hospitais, protocolos de quarentena, reservas de grãos, redundâncias de arquivo e limites de guerra nasceram de catástrofes que muitos já recordam apenas como datas. A estabilidade moderna não apagou o trauma; transformou-o em infraestrutura.

É por isso que o presente parece tão preparado e tão vulnerável. Quase toda crise encontra uma instituição capaz de responder. Quase toda instituição depende de redes que uma crise ampla pode interromper. Arden entrou em 1.847 com mais conhecimento, recursos e coordenação do que em qualquer era anterior, justamente quando as categorias usadas para organizar o Além-Véu começam a falhar.
