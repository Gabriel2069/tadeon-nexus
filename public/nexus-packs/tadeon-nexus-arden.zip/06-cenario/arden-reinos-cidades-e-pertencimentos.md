---
title: "Arden — Reinos, cidades e pertencimentos"
node_type: "concept"
summary: "Seção “Reinos, cidades e pertencimentos” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Reinos, cidades e pertencimentos"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Reinos, cidades e pertencimentos","source_order":33,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Reinos, cidades e pertencimentos

A Concordância reconhece trinta Estados soberanos plenos. Quase o dobro de entidades possui relevância própria quando se incluem principados federados, cidades pactuadas, territórios associados, confederações insulares e dependências com representação separada. A palavra reino permaneceu como categoria diplomática mesmo onde não existe coroa.

Monarquias parlamentares convivem com repúblicas consulares, federações feudais, governos colegiados, confederações clânicas e sistemas cuja autoridade acompanha água, templo ou ofício. Nenhuma forma é tratada pelo mundo como destino final da política. Cada uma possui uma história que explica por que pessoas continuam aceitando-a ou por que já não aceitam.

As cidades variam de portos com poucos milhares de habitantes a metrópoles excepcionais que se aproximam ou ultrapassam um milhão quando somadas suas áreas contínuas. Maravezia, Osva e outros grandes centros dependem de saneamento, aquedutos, transporte pneumático, conservação de alimentos, redes de crédito e comunicação luminográfica. O interior de Veth continua majoritariamente rural, mas não isolado de mercados, calendários e decisões tomadas a semanas de distância.
