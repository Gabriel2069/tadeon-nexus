---
title: "Arden — Óptica"
node_type: "concept"
summary: "Seção “Óptica” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Óptica"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Óptica","source_order":40,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Óptica

Lentes, espelhos, prismas e fibras cristalinas transmitem e processam luz. A Rede de Hélio envia mensagens por torres que codificam posição, cor, frequência e sequência. Arquivos ópticos conservam grandes volumes de informação em placas, cristais e filmes. Calculadores de interferência resolvem operações específicas com precisão extraordinária.

Esses sistemas não pensam. Autômatos e calculadores executam relações preparadas por pessoas. Podem ordenar, comparar, projetar e repetir, mas não produzem Alma por acumulação de complexidade. A crença de que um mecanismo muito sofisticado despertará sozinho existe em romances, cultos e pesquisas marginais; nenhum caso foi reconhecido de forma confiável.
