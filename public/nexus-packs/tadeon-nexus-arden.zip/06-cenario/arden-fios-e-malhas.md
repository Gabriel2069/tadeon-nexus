---
title: "Arden — Fios e Malhas"
node_type: "concept"
summary: "Seção “Fios e Malhas” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Fios e Malhas"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Fios e Malhas","source_order":13,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Fios e Malhas

Fio é o nome dado à menor relação que ainda pode ser percebida como relação. Um medo entre pessoa e lembrança; a tensão entre pedra e peso; o significado que um símbolo adquire depois de repetido; a continuidade de um nome através de gerações. Fios não são linhas luminosas escondidas dentro das coisas, embora canalizadores possam percebê-los dessa maneira. São modos pelos quais uma parte do mundo depende de outra.

Malhas surgem quando muitos fios passam a sustentar uma forma comum. Um corpo é malha. Uma floresta, uma língua, uma cidade, uma linhagem de ofício e uma dívida antiga também. Quanto mais relações participam de uma malha, mais difícil é alterá-la sem consequências que escapem ao ponto inicial.

A Urdidura é o estudo dessas relações em sua escala maior: a tentativa de compreender como o Reflexo continua inteiro, como o Além-Véu encontra passagem e como ações humanas podem reforçar, deslocar ou romper o que parecia permanente.
