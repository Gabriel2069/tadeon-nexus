---
title: "Arden — Línguas"
node_type: "concept"
summary: "Seção “Línguas” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Línguas"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Línguas","source_order":32,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Línguas

Veth fala dezenas de línguas vivas e muitas variedades cuja classificação depende de quem está ouvindo. O Vethi Comum nasceu nos portos antes da Concordância, simplificado por pessoas que precisavam negociar sem partilhar infância, religião ou sotaque. Tornou-se língua de trânsito, contrato e informação, mas nunca apagou os idiomas locais.

As semelhanças entre famílias linguísticas guardam migrações antigas, conquistas, traduções religiosas e séculos de comércio. Palavras técnicas viajam com facilidade especial. Um instrumento pode receber nome albrático, uma medida veliana, uma raiz kemetina e uma terminação adaptada ao Vethi. O Livro das Línguas aprofunda essas histórias; para o narrador, basta lembrar que cada palavra revela quem teve autoridade para nomear primeiro.
