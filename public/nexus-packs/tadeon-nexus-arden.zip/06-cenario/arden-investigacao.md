---
title: "Arden — Investigação"
node_type: "concept"
summary: "Seção “Investigação” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Investigação"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Investigação","source_order":66,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Investigação

Investigar em Tessitura do Vazio não significa apenas encontrar pistas até uma resposta pronta. Significa reconstruir relações. Quem nomeou o lugar? O que mudou? Quem depende de que a situação continue sendo interpretada de determinada forma? Que memória foi removida? Que instituição tem acesso e por que escolheu não agir?

Pistas devem alterar entendimento e possibilidade. Uma boa descoberta revela risco, oferece escolha ou aproxima o Ponto de Costura. Informação que apenas confirma o que o grupo já sabe pode construir atmosfera, mas não deve substituir o movimento.
