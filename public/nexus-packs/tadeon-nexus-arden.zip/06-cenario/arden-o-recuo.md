---
title: "Arden — O Recuo"
node_type: "concept"
summary: "Seção “O Recuo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O Recuo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O Recuo","source_order":11,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O Recuo

O Recuo é o nome posterior dado a uma mudança cuja duração ninguém conhece. As manifestações do Conhecimento deixaram de conservar a mesma presença externa, enquanto Memória, Significância, Linguagem e Alma se aprofundaram na experiência humana. Aquilo que antes aparecia diante das pessoas passou a agir através da capacidade de recordar, compreender, nomear e manter-se inteiro.

Há escolas da Ordem que descrevem o Recuo como a escolha da Chama Fria diante do risco de extinção humana. Teólogos o aproximam de uma graça inscrita na própria criação. Outros estudiosos defendem que não houve decisão alguma, apenas a consequência inevitável de uma espécie que se tornou capaz de abrigar Conhecimento sem ser imediatamente consumida por ele. Nenhuma interpretação explica por completo por que o Medo também mudou.

O Medo não permaneceu fora. Entrou no corpo, no instinto, no desejo de proteger, na violência e no apego. O Conhecimento não ficou restrito ao pensamento. Tornou-se técnica, memória coletiva, linguagem, fé e identidade. O Tempo não continuou como cenário. Fez de cada pessoa uma continuidade provisória entre aquilo que recebeu e aquilo que deixará.

A humanidade é feita dos três. Seu diferencial não é pureza, mas composição. Um ser humano pode carregar fios do Além-Véu sem deixar de ser humano porque sempre os carregou. O sobrenatural começa quando essa composição perde a proporção capaz de sustentar uma vida, um lugar ou uma história reconhecível.

| PARA NARRAR A COSMOLOGIA Não transforme Tempo, Medo e Conhecimento em deuses elementais que explicam cada fenômeno de maneira simples. Eles devem ampliar o sentido de um acontecimento, nunca reduzi-lo. Um incêndio continua exigindo combustível, calor e oxigênio; também pode tornar-se o lugar onde uma comunidade perde sua Memória e onde essa perda encontra forma. |
| --- |
