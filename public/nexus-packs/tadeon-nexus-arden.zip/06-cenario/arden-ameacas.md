---
title: "Arden — Ameaças"
node_type: "concept"
summary: "Seção “Ameaças” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Ameaças"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Ameaças","source_order":67,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Ameaças

Uma ameaça não é definida pelo dano que causa. É definida pela profundidade com que sua presença reorganiza o mundo ao redor. Magnitude mede essa permanência. Arquétipo descreve seu comportamento em confronto. Vetores de Tensão mostram como ela alcança corpos, espaço, mente e território. O Ponto de Costura preserva a solução narrativa.

Manifestações devem possuir lógica, mesmo quando essa lógica excede uma compreensão imediata. Eclis reorganiza corpo e matéria viva; Morae altera confiança mental e interioridade; Thyren trabalha ausência, ocultação e aquilo que não pode ser confirmado; Zha’el transforma valor e julgamento em força; Fluxo altera sequência; Conhecimento em excesso conserva e ordena até retirar escolhas.
