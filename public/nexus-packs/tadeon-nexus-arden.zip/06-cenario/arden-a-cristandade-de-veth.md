---
title: "Arden — A Cristandade de Veth"
node_type: "religion"
summary: "Seção “A Cristandade de Veth” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["A Cristandade de Veth"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"A Cristandade de Veth","source_order":45,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# A Cristandade de Veth

A Cristandade de Veth reconhece um Criador anterior ao mundo, uma criação intencional e uma dignidade humana que não depende de reino, ofício ou nascimento. Suas tradições discordam sobre imagens, liturgias, calendários, linguagem e sobre quase toda tentativa de explicar como o divino se relaciona com a história. Ainda assim, reconhecem-se como partes de uma fé comum.

Não existe autoridade universal comparável a um trono religioso. Concílios regionais estabelecem consensos; mosteiros e escolas acumulam prestígio; comunidades conservam práticas que nenhuma instituição central controla. A unidade é mantida por reconhecimento, peregrinação, textos compartilhados, hospitalidade e pela convicção de que nenhuma forma humana esgota o Criador.

A história religiosa de Arden não é isenta de conflito. Houve excomunhões locais, disputas por patrimônio, perseguições breves, apropriações políticas e movimentos que feriram pessoas em nome de certezas estreitas. Esses episódios não se transformaram em guerras continentais de conversão nem produziram uma máquina central de perseguição. A estrutura descentralizada, a memória de abusos e a teologia da insuficiência humana impediram que violência religiosa se tornasse fundamento duradouro da ordem política.
