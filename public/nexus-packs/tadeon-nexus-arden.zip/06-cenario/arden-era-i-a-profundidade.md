---
title: "Arden — Era I ~ A Profundidade"
node_type: "historical_event"
summary: "Seção “Era I ~ A Profundidade” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Era I ~ A Profundidade"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Era I ~ A Profundidade","source_order":52,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Era I ~ A Profundidade

Milênios anteriores aos primeiros Estados

A Profundidade é conhecida por ruínas sem autores, mudanças de costa, camadas de cinza, objetos fora de contexto e Memórias que não conseguem decidir se pertencem a uma pessoa ou a um povo inteiro. Os primeiros humanos viviam num mundo em que a distinção entre fenômeno natural, presença primordial e prática religiosa ainda não havia adquirido as categorias atuais.

Comunidades surgiram nas margens do Mar Tético, em vales de rios e costas ricas em alimento. Aprenderam fogo, cultivo, navegação rasa, conservação e cuidado. Também aprenderam que certos lugares respondiam a nomes, que algumas mortes deixavam continuidades perigosas e que repetir um gesto em grupo podia impedir uma presença de atravessar.

Os primeiros Seladores não conheciam Naturezas, Domínios ou Tessitura. Conheciam um poço que precisava permanecer coberto, uma canção que não podia ser interrompida e uma pedra que deveria mudar de casa a cada geração. Muitos métodos eram inseparáveis de mitos porque o mito preservava sequências e intenções quando nenhuma escrita existia.

A Grande Contenção pertence ao fim incerto dessa era. Múltiplas manifestações convergiram em Veth Cinério, e povos cujos nomes se perderam participaram de uma resposta cujo alcance ainda excede os métodos modernos. O Cerne é a cicatriz visível. A Ordem não sabe se a Contenção criou a Confluência, impediu que ela alcançasse o restante do mundo ou ambas as coisas.

Registros fragmentários também associam o Lobo Auster à primeira estabilização extensa do Véu. Nenhuma expedição confirmou a afirmação. Ela sobrevive porque aparece em Memórias de povos que não mantiveram contato conhecido.
