---
title: "Arden — Bioalquimia"
node_type: "concept"
summary: "Seção “Bioalquimia” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Bioalquimia"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Bioalquimia","source_order":41,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Bioalquimia

Bioalquimia cultiva processos vivos em vez de apenas extrair substâncias prontas. Fungos preservam alimentos, culturas produzem medicamentos, tecidos são estimulados a regenerar, fibras recebem propriedades específicas e organismos marinhos oferecem compostos impossíveis de obter em escala por síntese mineral.

A área possui sua própria sombra. Linhagens podem escapar, reagir ao Véu, cruzar limites éticos ou transformar tratamento em dependência. O Instituto Viridário e outras casas de pesquisa trabalham justamente na fronteira entre alteração biológica, exposição primordial e cura. Uma campanha pode tratar a bioalquimia como maravilha médica, indústria, ecologia ou horror corporal sem mudar de cenário.
