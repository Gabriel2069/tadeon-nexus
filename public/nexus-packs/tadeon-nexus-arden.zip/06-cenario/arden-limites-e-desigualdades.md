---
title: "Arden — Limites e desigualdades"
node_type: "concept"
summary: "Seção “Limites e desigualdades” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Limites e desigualdades"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Limites e desigualdades","source_order":44,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Limites e desigualdades

Tecnologia avançada não significa acesso igual. Materiais raros concentram produção. Guildas guardam métodos. Redes exigem manutenção. Reinos pobres importam peças que não sabem fabricar. Vilas afastadas vivem com soluções locais enquanto metrópoles acumulam infraestrutura interdependente.

Quanto mais integrada uma cidade, maior a quantidade de continuidades capazes de falhar juntas. A mesma rede que distribui água pode sustentar hospitais, oficinas e Selos. A mesma torre que leva notícias pode espalhar um código alterado. Progresso amplia possibilidades e também a área atingida por um erro.

| TECNOLOGIA EM JOGO Apresente primeiro a função. Um aparelho deve resolver um problema concreto de transporte, cura, cálculo, comunicação ou produção. Depois mostre material, manutenção, ruído e dependências. A tecnologia de Arden torna o cenário particular quando faz parte da vida, não quando serve apenas de decoração. |
| --- |
