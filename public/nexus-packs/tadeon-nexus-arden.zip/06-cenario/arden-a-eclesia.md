---
title: "Arden — A Eclésia"
node_type: "organization"
summary: "Seção “A Eclésia” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["A Eclésia"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"A Eclésia","source_order":47,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# A Eclésia

Eclésia de Veth é o nome dado à rede de mosteiros, comunidades, escolas, casas de cura, scriptorios, centros de caridade e concílios que oferecem continuidade institucional à Cristandade. A fé é mais antiga e mais ampla do que essa rede. A Eclésia organiza parte dela sem possuí-la por inteiro.

Em muitas regiões, a Eclésia é a instituição presente quando governos não chegam. Mantém arquivos, acolhe viajantes, ensina leitura, arbitra disputas e cuida de doentes. Essa função fez de seus edifícios pontos de continuidade social. Sem saber, muitas comunidades fortaleceram o Véu por séculos através de práticas de cuidado, memória e nomeação.
