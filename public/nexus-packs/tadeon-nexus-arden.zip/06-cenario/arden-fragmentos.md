---
title: "Arden — Fragmentos"
node_type: "concept"
summary: "Seção “Fragmentos” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Fragmentos"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Fragmentos","source_order":19,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Fragmentos

Fragmentos são retalhos deixados quando uma Dobra se desfaz de maneira incompleta. O Reflexo recupera grande parte de sua forma, mas uma porção do padrão que havia sido tecido permanece separada da malha original. Aquilo que sobra consegue conservar organização, tensão e assinatura suficientes para continuar existindo como uma pequena margem própria.

Um Fragmento não veio pronto do Além-Véu. Ele é uma cicatriz materializada, uma memória estrutural de uma relação que o mundo aprendeu e depois não conseguiu esquecer por inteiro. Pode nascer da retração de um Furo, da ruptura de uma Âncora, da perturbação de um Revérbero, de uma Trama extrema ou da presença prolongada de uma manifestação. Pode assumir forma mineral, orgânica, mecânica, sonora, textual ou impossível de classificar com segurança. Não são baterias de energia. São relações incompletas que continuam tentando terminar-se.

Um Fragmento limita e possibilita. Ele oferece ao canalizador fios cuja Natureza já está marcada, reduzindo a necessidade de alcançar diretamente o Além-Véu. Ao mesmo tempo, conduz toda costura para os padrões que carrega. Quanto mais poderoso o Fragmento, menos indiferente ele é à forma de uso.
