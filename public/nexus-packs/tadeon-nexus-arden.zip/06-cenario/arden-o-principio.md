---
title: "Arden — O princípio"
node_type: "concept"
summary: "Seção “O princípio” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O princípio"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O princípio","source_order":37,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O princípio

As ciências de Veth não organizaram a civilização ao redor de uma única matriz. Rios, marés, vento, luz, calor, pressão, altura, concentração química e atividade biológica tornaram-se fontes complementares. O resultado é uma civilização da condução: menos interessada em produzir força a partir da destruição contínua de matéria do que em capturar diferenças, armazená-las e entregá-las ao lugar onde podem realizar trabalho.

Combustão existe. Eletricidade, magnetismo e carga são fenômenos conhecidos. Nenhum deles se tornou o centro universal da infraestrutura. Uma cidade pode receber ar comprimido de quedas-d’água, luz armazenada por matrizes ópticas, calor de sais aquecidos, alimentos conservados por bioalquimia e decisões calculadas em câmaras de interferência. A mesma cidade ainda utiliza fogo em cozinhas, forjas e emergências.
