---
title: "Arden — Selos"
node_type: "concept"
summary: "Seção “Selos” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Selos"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Selos","source_order":21,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Selos

Um Selo é uma estrutura de continuidade. Símbolos podem participar dele, mas nenhum desenho possui poder isolado da verdade que afirma. Um Selo eficaz reconhece a Natureza da ruptura, estabelece uma borda e fixa essa borda ao mundo por relações humanas capazes de sustentá-la.

Há Selos mantidos por palavras repetidas, calendários, peregrinações, peças mecânicas, arranjos arquitetônicos, cultivos, arquivos e práticas de cuidado. Muitas comunidades preservam Selos sem conhecer o termo. A Ordem aprendeu cedo que a manutenção mais duradoura raramente é a mais secreta. É aquela que consegue tornar-se costume sem perder o sentido.

O resultado de uma Selagem depende do estado da Dobra. Pregas podem ser aliviadas antes que atravessem. Furos são fechados e devolvidos para além do Véu. Âncoras são contidas ou transformadas em Revérberos. Zonas exigem redução, isolamento e reconquista. Revérberos não precisam ser apagados, mas compreendidos e mantidos.

A frase tradicional dos Seladores resume uma teoria inteira:

“Furos se fecham. Âncoras se cercam. Zonas se reconquistam. Revérberos permanecem”
