---
title: "Arden — Canalização e custo"
node_type: "concept"
summary: "Seção “Canalização e custo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Canalização e custo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Canalização e custo","source_order":69,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Canalização e custo

Tramas não são uma lista de feitiços separada da identidade. Cada Canalização aproxima o personagem de uma Natureza e torna visível o modo como ele escolhe resolver problemas. O custo deve aparecer em sensações, ambientes, vínculos e consequências, além, claro, dos recursos mecânicos.

Refluxo não é punição arbitrária. É a volta desordenada de fios que não encontraram relaxamento seguro. Mesmo um sucesso pode deixar marca quando a Trama foi profunda. O narrador deve permitir que poder seja útil o bastante para seduzir e específico o bastante para nunca tornar escolha irrelevante.
