---
title: "Arden — Kemet Neter e a forma de Veth"
node_type: "concept"
summary: "Seção “Kemet Neter e a forma de Veth” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Kemet Neter e a forma de Veth"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Kemet Neter e a forma de Veth","source_order":24,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Kemet Neter e a forma de Veth

As massas atuais descendem de Kemet Neter, o grande conjunto continental antigo cuja fragmentação nunca se completou. Partes afastaram-se, mares nasceram entre elas, placas voltaram a convergir e cicatrizes oceânicas foram aprisionadas dentro de terra reunificada. A geografia de Arden conserva essa história em cordilheiras, desertos, riftes, arquipélagos e mares internos.

Essa forma aproximou civilizações sem torná-las vizinhas fáceis. Montanhas bloquearam exércitos e línguas. Desertos exigiram técnicas próprias de água. Mares internos ofereceram rotas que contornavam fronteiras terrestres. Nenhuma descrição geral substitui a geografia local, mas algumas estruturas definem o mundo narrável.
