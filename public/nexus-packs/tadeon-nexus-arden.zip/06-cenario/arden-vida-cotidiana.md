---
title: "Arden — Vida cotidiana"
node_type: "concept"
summary: "Seção “Vida cotidiana” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Vida cotidiana"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Vida cotidiana","source_order":34,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Vida cotidiana

A maior parte das pessoas acorda sem pensar no Véu. Pensa em preço, chuva, trabalho, dor, filhos, dívidas e na distância até a próxima refeição. Casas recebem água por poços, canais, aquedutos ou redes urbanas. Luz noturna vem de gás processado, óleos, cristais fotossensíveis e materiais bioalquímicos. Mensagens locais seguem por mensageiros, correio fluvial e oficinas; notícias urgentes atravessam torres de Hélio.

Medicina combina observação, cirurgia, higiene, compostos vegetais, culturas microbianas, tecidos cultivados e instrumentos ópticos. A qualidade varia enormemente. Um hospital ligado a uma academia pode reconstruir tecidos que uma aldeia remota ainda trata com ervas, repouso e conhecimento transmitido por família. Ambas as práticas podem conter verdade; nenhuma possui acesso uniforme.

Viagens são calculadas por terreno e rede, não apenas por distância. Um porto tético pode estar socialmente mais próximo de uma cidade do outro lado do mar do que de um vale situado a dois dias de cavalo. Fronteiras mudam o idioma dos documentos, a moeda aceita, a autoridade das guildas e a forma como um estranho deve apresentar-se.
