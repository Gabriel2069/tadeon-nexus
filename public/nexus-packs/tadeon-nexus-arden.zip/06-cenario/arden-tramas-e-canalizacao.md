---
title: "Arden — Tramas e Canalização"
node_type: "concept"
summary: "Seção “Tramas e Canalização” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Tramas e Canalização"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Tramas e Canalização","source_order":20,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Tramas e Canalização

Canalizar é aproximar fios que o Reflexo mantém separados e tecê-los numa relação temporária. A Trama é o padrão produzido. Seu efeito visível pode parecer simples: fechar uma ferida, deslocar um objeto, ocultar uma presença, conservar uma lembrança. A profundidade da alteração depende de quanto da malha precisa ser reorganizado para que o resultado exista.

Toda Canalização possui aproximação, tração, tecitura, expressão e relaxamento, mesmo quando o gesto é rápido demais para que o observador reconheça as etapas. O relaxamento é inevitável. O Reflexo tenta recuperar a forma anterior, e fios mal ordenados retornam com violência, produzem Refluxo ou encontram novas relações para ocupar.

Canalizadores não são pessoas externas ao mundo usando uma força estrangeira. São malhas conscientes que aprenderam a tocar relações profundas. Essa proximidade torna a prática possível e perigosa. O custo não vem de violar uma lei arbitrária, mas de obrigar corpo, mente e identidade a suportarem uma costura para a qual não foram feitos.
