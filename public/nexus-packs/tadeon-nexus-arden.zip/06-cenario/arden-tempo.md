---
title: "Arden — Tempo"
node_type: "concept"
summary: "Seção “Tempo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Tempo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Tempo","source_order":6,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Tempo

O Tempo é a passagem que impede toda existência de ocorrer ao mesmo tempo. Ele oferece distância entre causa e consequência, permite que uma forma se transforme sem desaparecer imediatamente e concede ao mundo a estranha misericórdia de ainda não ter acontecido por completo.

Sua manifestação recebe o nome de Fluxo. A Ordem registra o Fluxo menos como entidade e mais como direção. Ele aparece em repetições que não repetem exatamente, em lugares onde instantes se acumulam, em memórias que chegam antes do acontecimento ou em ruínas cujo desgaste pertence a uma idade que o entorno não viveu. O Tempo raramente parece agir. Tudo age porque ele abriu espaço para isso.
