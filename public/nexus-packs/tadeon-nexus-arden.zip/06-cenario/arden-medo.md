---
title: "Arden — Medo"
node_type: "concept"
summary: "Seção “Medo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Medo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Medo","source_order":7,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Medo

O Medo é a percepção de que uma forma pode ser perdida. Antes de possuir rosto, ele já era limite, resistência, incorporação e dissolução. Toda coisa que ocupa lugar exclui alguma outra; todo corpo preserva-se consumindo, evitando, reparando e fugindo. A matéria não é uma camada neutra sobre a qual o Medo trabalha. Ela já contém a possibilidade de permanecer e a ameaça de deixar de fazê-lo.

No Além-Véu, o Medo aproxima-se do que a Ordem chama de Inverso: uma condição em que forma e ameaça não podem ser separadas. O Primeiro é sua manifestação mais antiga reconhecível, embora nenhum arquivo prove que seja o primeiro em sentido absoluto. Ele não é todo o Medo, nem um soberano sentado sobre as outras manifestações. É o ponto em que o medo de perder a própria distinção adquire vontade suficiente para procurar o Reflexo.

Os Domínios de Eclis, Morae, Thyren e Zha’el são modos recorrentes pelos quais o Medo se organiza diante da consciência humana. Eclis encontra o corpo e aquilo que pode deformá-lo. Morae encontra a mente quando ela deixa de confiar em seus próprios limites. Thyren ocupa o que não pode ser visto, alcançado ou confirmado. Zha’el cresce onde julgamento, culpa e valor transformam-se em condenação. Nenhum Domínio se limita a um sentimento. Cada um é uma maneira de reescrever relações.
