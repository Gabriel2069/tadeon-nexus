---
title: "Arden — A Marca"
node_type: "concept"
summary: "Seção “A Marca” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["A Marca"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"A Marca","source_order":65,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# A Marca

A Marca de um personagem é o momento em que o mundo mostrou seus rasgos. Não precisa ser uma manifestação espetacular. Pode ser uma memória que outra pessoa também possui, uma cura impossível, uma ausência não reconhecida ou um Fragmento encontrado durante um trabalho comum.

A Marca liga identidade e cenário. Ela explica por que alguém continuará investigando quando a explicação mais segura seria afastar-se. Também oferece ao narrador um fio que pode retornar transformado.
