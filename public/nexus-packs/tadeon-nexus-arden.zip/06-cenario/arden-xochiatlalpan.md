---
title: "Arden — Xochiatlalpan"
node_type: "region"
summary: "Seção “Xochiatlalpan” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Xochiatlalpan"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Xochiatlalpan","source_order":28,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Xochiatlalpan

As Ilhas Verdes de Xochiatlalpan espalham-se a oeste do Ocíduo sobre uma plataforma de vulcanismo antigo e subsidência lenta. Recifes crescem enquanto partes da microplaca afundam; lagoas, domos erodidos e canais rasos fazem do arquipélago uma geografia de limites móveis. Sua bioalquímica marinha transformou medicina, anestesia e regeneração em toda Veth.
