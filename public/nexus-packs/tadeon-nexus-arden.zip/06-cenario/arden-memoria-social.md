---
title: "Arden — Memória social"
node_type: "concept"
summary: "Seção “Memória social” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Memória social"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Memória social","source_order":36,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Memória social

Em Arden, tradição possui efeito ontológico sem deixar de ser cultura. Um funeral repetido por séculos não é eficaz porque contém alguma fórmula secreta em cada gesto, mas porque organiza Memória, Significância, Linguagem e Alma ao redor da perda. Quando uma prática desaparece, a comunidade perde um modo de sustentar o mundo. Quando uma prática sobrevive apenas como obrigação vazia, pode conservar forma mas perder Costura.

Essa relação dá peso narrativo a arquivos, festas, ofícios, nomes de ruas, receitas, juramentos e ruínas. O que parece cenário pode ser parte ativa da estabilidade local. Proteger uma cidade nem sempre significa defender seus muros. Às vezes significa impedir que todos esqueçam por que um sino toca numa hora que ninguém mais considera importante.
