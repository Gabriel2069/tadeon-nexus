---
title: "Arden — Revérberos"
node_type: "concept"
summary: "Seção “Revérberos” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Revérberos"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Revérberos","source_order":18,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Revérberos

Um Revérbero é uma Dobra que aprendeu a permanecer quieta.

Pode surgir quando uma alteração se estabiliza naturalmente ou quando uma Âncora é pacificada por uma Selagem. A ligação com a malha primordial continua existindo, mas já não há Tensão ativa conduzindo-a para um estágio mais profundo. O local foi alterado e conserva essa alteração como parte de sua história.

Por isso um Revérbero não é seguro. É estável.

Revérberos de Conhecimento são os mais comuns e, muitas vezes, os mais difíceis de reconhecer. Conhecimento possui afinidade com padrões, repetição, linguagem, memória e identidade. Pode fixar-se numa biblioteca, numa escola, numa cidade, num arquivo, numa linhagem ou numa prática e parecer apenas tradição, clareza ou ordem. Seus efeitos confundem-se facilmente com aquilo que a sociedade já desejava preservar. Quando a diferença finalmente é percebida, o padrão pode existir há gerações.

Uma biblioteca pode recordar textos que foram destruídos. Um tribunal pode conservar a interpretação de uma lei depois que todas as palavras que a sustentavam mudaram. Uma cidade pode impedir que seus habitantes esqueçam, mesmo quando o esquecimento seria necessário para que continuassem vivendo. O Conhecimento estabiliza-se com facilidade porque oferece ao Reflexo formas muito convincentes de continuidade.

Revérberos de Medo também existem. Neles, o padrão estabilizado costuma expressar-se por corpo, instinto, território, tabu ou repetição visceral. Uma floresta pode incorporar o medo de ser atravessada e reorganizar caminhos para conservar distância. Uma comunidade pode transmitir uma resposta corporal a determinado nome. Um campo de batalha pode manter agressividade, vigilância ou dor sem que nenhuma manifestação permaneça ativa.

Esses lugares são mais perceptíveis, mas nem sempre mais violentos. Quando o Medo encontra uma forma social, biológica ou territorial suficientemente estável, pode deixar de avançar e tornar-se parte do modo como o lugar vive.

Revérberos de Fluxo são mais raros. A sequência tende a escapar da estabilidade ou a tornar-se tão regular que deixa de ser percebida como alteração. Quando permanecem, podem conservar um instante, uma repetição ou uma diferença de idade que o entorno aprendeu a contornar.

Revérberos podem ser estudados, utilizados como fonte para Tramas compatíveis e integrados a práticas locais. Também podem produzir pulsos quando perturbados. Extrações, Canalizações imprudentes, destruição de símbolos ou perda das relações que os pacificaram podem devolver Tensão ao que parecia inerte.

O Revérbero é uma cicatriz, e cicatrizes não significam que nada aconteceu. Significam que o corpo encontrou uma forma de continuar.

Revérberos permancem.
