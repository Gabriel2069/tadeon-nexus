---
title: "Arden — Era IV ~ A Expansão"
node_type: "historical_event"
summary: "Seção “Era IV ~ A Expansão” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Era IV ~ A Expansão"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Era IV ~ A Expansão","source_order":55,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Era IV ~ A Expansão

Anos 400 a 900

A Expansão foi o grande período de integração técnica e institucional. Cidades cresceram, canais foram ampliados, observatórios trocaram registros e casas bancárias financiaram obras que nenhum reino conseguiria manter sozinho.

Entre os anos 450 e 550, a Rede de Hélio conectou capitais e centros comerciais por torres de comunicação óptica. Mensagens que antes levavam semanas passaram a atravessar Veth em menos de um dia quando clima, manutenção e linha de visada permitiam. A velocidade alterou finanças, diplomacia, guerra e a própria experiência da distância.

Nos séculos seguintes, os Grandes Tratados consolidaram soberania, regras de guerra, trânsito, resgate marítimo e reconhecimento de instituições suprarregionais. A Ordem obteve proteção indireta por meio de ofícios eclesiais e anexos secretos, nunca por uma revelação pública de sua extensão.

A Cristandade viveu seu maior período de reconhecimento mútuo. Mosteiros, escolas e peregrinações aproximaram tradições. A Heresia dos Abissais rompeu esse equilíbrio ao afirmar que o sofrimento provava o aprisionamento do Criador e que forças mais antigas mereciam obediência. O movimento foi teológico, político e social antes de ser explorado por cultos. Sua absorção deixou escolas reformistas, perseguições locais e uma cautela duradoura diante de certezas que usam dor como prova.

A Expansão produziu maravilhas e dependências. Redes de crédito, pressão, informação e transporte aproximaram o mundo. Também fizeram com que uma falha regional pudesse viajar.
