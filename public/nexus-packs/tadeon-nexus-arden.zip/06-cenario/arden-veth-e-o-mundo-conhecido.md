---
title: "Arden — Veth e o mundo conhecido"
node_type: "concept"
summary: "Seção “Veth e o mundo conhecido” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Veth e o mundo conhecido"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Veth e o mundo conhecido","source_order":2,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Veth e o mundo conhecido

Veth é o nome dado ao conjunto de massas, mares internos, arquipélagos e rotas que concentram a maior parte da humanidade conhecida. O termo já significou continente, civilização, horizonte comercial e, em certos textos, simplesmente mundo. Nenhuma dessas acepções é inteiramente errada. Tramontana, Ocíduo, Alvor, Yawurua e as terras associadas não formam um único bloco geológico, mas permaneceram próximas o bastante para que seus mares fossem atravessados antes que a navegação oceânica profunda se tornasse segura. Essa proximidade alterou toda a história humana.

Povos separados por montanhas, desertos e línguas diferentes puderam encontrar-se por água. Mercadorias circularam antes de impérios continentais. Histórias foram traduzidas, deformadas e reconhecidas em portos distantes. Técnicas nascidas num vale alcançaram outro reino sem levar consigo a religião, a lei ou a forma de governo que as havia criado. Veth tornou-se integrado sem tornar-se uniforme.

Além dele ficam o Lobo Auster, vasto e glaciado; a Franja Norte, onde terra, gelo e mar raramente conservam os mesmos limites por muito tempo; e Veth Cinério, uma massa forânea isolada cuja costa pode ser cartografada com mais segurança do que aquilo que permanece em seu interior. Essas regiões não são margens vazias; elas são limites da experiência comum. E todo limite atrai histórias.
