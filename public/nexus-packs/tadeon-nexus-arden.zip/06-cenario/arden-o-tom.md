---
title: "Arden — O tom"
node_type: "concept"
summary: "Seção “O tom” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O tom"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O tom","source_order":64,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O tom

Arden combina maravilha, investigação, medo e continuidade. O horror deve surgir do reconhecimento, não da sucessão de imagens estranhas. Uma manifestação importa porque toca algo que os personagens já compreendiam. Uma tecnologia impressiona porque funciona dentro de uma vida. Uma instituição pesa porque pessoas dependem dela.

A beleza não serve de intervalo antes do horror. É parte daquilo que pode ser perdido. Mostre cidades, paisagens, fé, amizade, ofício e descoberta com sinceridade. Quando a ameaça aparecer, os jogadores saberão o que estão tentando preservar.
