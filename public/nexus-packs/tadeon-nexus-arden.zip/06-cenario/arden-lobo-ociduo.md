---
title: "Arden — Lobo Ocíduo"
node_type: "region"
summary: "Seção “Lobo Ocíduo” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Lobo Ocíduo"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Lobo Ocíduo","source_order":26,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Lobo Ocíduo

Ocíduo forma o grande escudo sudoeste. A Cordilheira Ocidental acompanha sua costa, deixando em Contigo uma faixa estreita entre montanha e mar e elevando os altiplanos de Tahuantinsuyu. Das vertentes orientais descem rios que alimentam Verdania, uma bacia florestal de águas lentas, tepuis, igapós e diversidade biológica difícil de catalogar.

Ao noroeste, o Lago Texcoco Central ocupa uma bacia sem saída permanente, rodeada por planaltos antigos e cidades que aprenderam a cultivar sobre água, lodo e sal. Ao sul, Riosola e Calçada abrem-se em planícies de Lös, estuários e terras frias que se aproximam dos mares austrais. Entre o centro do continente e Alvor, o Istmo de Veth comprime montanhas, rotas e ambições num corredor estreito.

Ocíduo é o melhor lugar para narrativas em que água e floresta ocultam distâncias. Um rio pode unir regiões que por terra parecem incomunicáveis. Uma cadeia montanhosa pode manter duas culturas próximas sem permitir que se reconheçam. Uma expedição científica encontra, em poucos meses, o equivalente a séculos de diferença ambiental.
