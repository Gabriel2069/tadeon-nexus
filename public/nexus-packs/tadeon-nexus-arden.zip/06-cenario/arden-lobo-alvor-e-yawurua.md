---
title: "Arden — Lobo Alvor e Yawurua"
node_type: "region"
summary: "Seção “Lobo Alvor e Yawurua” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Lobo Alvor e Yawurua"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Lobo Alvor e Yawurua","source_order":27,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Lobo Alvor e Yawurua

Alvor e Yawurua formam uma massa terrestre contínua sobre estruturas profundas diferentes. Alvor foi comprimido por múltiplas margens e ergueu-se num grande planalto. O Arco Montanhoso Norte retém umidade, e atrás dele se estende o Grande Deserto de Veth. O Vale do Netjer corta o planalto de sul a norte, conduzindo um rio cuja regularidade sustentou algumas das civilizações mais antigas do mundo.

Axum ocupa um planalto basáltico alimentado por calor intraplaca. Madzimbabwe conserva blocos falhados e lagos alongados. Mansa e Nzadi acompanham as transições entre deserto, savana e rios. Mais a leste, Yawurua apresenta uma superfície antiga, rebaixada por bilhões de anos de erosão, marcada por planícies vastas, inselbergs e sistemas fluviais de baixa inclinação.

A fronteira entre Alvor e Yawurua atravessa terra firme. Ao sul dela, Kitomena emerge sobre uma microplaca comprimida, rica em vales úmidos, minerais metamórficos e investigações científicas. Aotearoa forma, mais a sudeste, um arco vulcânico de atividade contínua e relevo abrupto.
