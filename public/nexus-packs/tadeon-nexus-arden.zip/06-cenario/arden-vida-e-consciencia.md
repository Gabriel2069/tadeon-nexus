---
title: "Arden — Vida e consciência"
node_type: "concept"
summary: "Seção “Vida e consciência” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["Vida e consciência"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"Vida e consciência","source_order":10,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# Vida e consciência

A vida surgiu nos mares antigos de Arden por processos longos, materiais e inteiramente reais. Moléculas tornaram-se sistemas, sistemas aprenderam a conservar-se e a reprodução levou adiante variações que nenhuma vontade planejou. A presença do Além-Véu não torna a evolução menos natural. Natureza é o nome dado à regularidade com que as mesmas forças primordiais permanecem organizadas no Reflexo.

A consciência humana não foi colocada num corpo vazio. Cresceu de percepção, cuidado, medo, memória e linguagem acumulados. Em algum ponto das margens do antigo Mar Tético, seres humanos passaram a reconhecer o próprio pensamento e a imaginar ausências que ainda não haviam ocorrido. O mundo ganhou uma forma nova de permanecer: podia agora ser lembrado por quem não estava mais diante dele, nomeado por quem jamais o havia visto e alterado em favor de futuros que nenhum indivíduo viveria.

As tradições mais antigas descrevem esse período como Tempo da Proximidade. Manifestações hoje classificadas como Primevos atravessavam assentamentos, rios e sonhos sem a separação conceitual que viria depois. Algumas eram temidas; outras recebiam alimento, canções ou lugares. Muitas práticas religiosas nasceram de tentativas de viver junto ao que não podia ser afastado. A história preservou essas relações como mitos porque o mito consegue carregar uma verdade cuja forma literal se tornou insuportável.
