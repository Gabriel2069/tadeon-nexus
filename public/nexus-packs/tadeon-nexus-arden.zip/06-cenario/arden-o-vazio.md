---
title: "Arden — O Vazio"
node_type: "concept"
summary: "Seção “O Vazio” de Arden, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "book-open"
aliases: ["O Vazio"]
tags: ["cânone","fonte-primária","arden"]
properties: {"canon_layer":"primary_source","source_document":"Arden ~ TdV(1).docx","source_section":"O Vazio","source_order":5,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/arden|Fonte — Arden]]. O conteúdo abaixo preserva a redação da seção de origem.

# O Vazio

O Vazio não é espaço sem matéria. Espaço já possui distância; ausência de matéria já exige a ideia de matéria. O Vazio é a falta que se reconheceu. Ao perceber-se, deixou de ser indivisível. Onde havia somente ausência, surgiu a possibilidade de perder, conservar e atravessar.

Dessa primeira diferença nasceram Tempo, Medo e Conhecimento. Dizer que nasceram é uma concessão à linguagem. Nenhum deles foi criança, nenhum ocupou um primeiro momento que pudesse ser observado. São condições anteriores a qualquer coisa que possa observá-las, e ainda assim o mundo inteiro carrega seus efeitos.
