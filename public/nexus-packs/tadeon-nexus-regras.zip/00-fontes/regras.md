---
title: "Fonte — Livro de Regras"
node_type: "document"
summary: "Índice de proveniência para Livro de Regras ~ TdV(3).docx."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["Livro de Regras"]
tags: ["cânone","fonte-primária","índice"]
properties: {"canon_layer":"primary_source_index","source_document":"Livro de Regras ~ TdV(3).docx","section_count":23}
---
# Fonte — Livro de Regras

Documento-fonte importado de `Livro de Regras ~ TdV(3).docx`. Esta página funciona como índice de proveniência. As páginas abaixo preservam o texto da obra; sínteses transversais aparecem separadamente e permanecem em revisão.

## Seções importadas

- [[../03-regras/regras-prologo|PRÓLOGO]]
- [[../03-regras/regras-capitulo-1-identidade|CAPÍTULO 1 ~ IDENTIDADE]]
- [[../03-regras/regras-capitulo-2-atributos-e-pericias|CAPÍTULO 2 ~ ATRIBUTOS E PERÍCIAS]]
- [[../03-regras/regras-capitulo-3-testes|CAPÍTULO 3 ~ TESTES]]
- [[../03-regras/regras-capitulo-4-pontos-rank-e-desenvolvimento|CAPÍTULO 4 ~ PONTOS, RANK E DESENVOLVIMENTO]]
- [[../03-regras/regras-capitulo-5-habilidades|CAPÍTULO 5 ~ HABILIDADES]]
- [[../03-regras/regras-capitulo-6-equipamentos|CAPÍTULO 6 ~ EQUIPAMENTOS]]
- [[../03-regras/regras-capitulo-7-canalizacao-e-tramas|CAPÍTULO 7 ~ CANALIZAÇÃO E TRAMAS]]
- [[../03-regras/regras-capitulo-8-fragmentos|CAPÍTULO 8 ~ FRAGMENTOS]]
- [[../03-regras/regras-capitulo-9-equilibrio-e-tensao|CAPÍTULO 9 ~ EQUILÍBRIO E TENSÃO]]
- [[../03-regras/regras-capitulo-10-combate-e-movimento|CAPÍTULO 10 ~ COMBATE E MOVIMENTO]]
- [[../03-regras/regras-capitulo-11-condicoes-morte-e-colapso|CAPÍTULO 11 ~ CONDIÇÕES, MORTE E COLAPSO]]
- [[../03-regras/regras-capitulo-12-interludios-e-vinculos|CAPÍTULO 12 ~ INTERLÚDIOS E VÍNCULOS]]
- [[../03-regras/regras-capitulo-13-investigacao|CAPÍTULO 13 ~ INVESTIGAÇÃO]]
- [[../03-regras/regras-capitulo-14-dobras-e-selagem|CAPÍTULO 14 ~ DOBRAS E SELAGEM]]
- [[../03-regras/regras-capitulo-15-narrar-tessitura-do-vazio|CAPÍTULO 15 ~ NARRAR TESSITURA DO VAZIO]]
- [[../03-regras/regras-capitulo-16-npcs-e-tessitura-social|CAPÍTULO 16 ~ NPCS E TESSITURA SOCIAL]]
- [[../03-regras/regras-capitulo-17-ameacas|CAPÍTULO 17 ~ AMEAÇAS]]
- [[../03-regras/regras-capitulo-18-construcao-e-balanceamento|CAPÍTULO 18 ~ CONSTRUÇÃO E BALANCEAMENTO]]
- [[../03-regras/regras-capitulo-19-misterios-zonas-e-campanhas|CAPÍTULO 19 ~ MISTÉRIOS, ZONAS E CAMPANHAS]]
- [[../03-regras/regras-capitulo-a-referencia-rapida|CAPÍTULO A ~ REFERÊNCIA RÁPIDA]]
- [[../03-regras/regras-capitulo-b-tabelas-consolidadas|CAPÍTULO B ~ TABELAS CONSOLIDADAS]]
- [[../03-regras/regras-capitulo-c-glossario-mecanico|CAPÍTULO C ~ GLOSSÁRIO MECÂNICO]]
