---
title: "Livro de Regras — CAPÍTULO 7 ~ CANALIZAÇÃO E TRAMAS"
node_type: "rule"
summary: "Seção “CAPÍTULO 7 ~ CANALIZAÇÃO E TRAMAS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 7 ~ CANALIZAÇÃO E TRAMAS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 7 ~ CANALIZAÇÃO E TRAMAS","source_order":8,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 7 ~ CANALIZAÇÃO E TRAMAS

Tecer não é ordenar que o mundo obedeça. É aproximar relações antigas o bastante para que a realidade precise responder.

A Urdidura afirma que toda forma existe por relações. A regra de Canalização começa quando uma pessoa aprende que relações também podem ser aproximadas, deslocadas e temporariamente organizadas. Mas isso não transforma o mundo em linguagem de comando. O Reflexo continua possuindo resistência, história e maneiras próprias de incorporar aquilo que foi tecido.

Duas Tramas podem produzir efeitos visuais semelhantes e tocar partes radicalmente diferentes da realidade. Uma cura por Eclis convence o corpo a fechar-se; uma cura por Memória devolve ao tecido a organização que possuía antes da lesão; uma cura pelo Fluxo adia o estado ferido ou aproxima um instante em que o corpo já havia reparado parte do dano. O resultado imediato não revela sozinho a relação escolhida. Assinatura, pistas e Refluxo revelam.

A Canalização é um processo inteiro, mesmo quando a mesa o resolve numa única ação.

Canalizar significa provocar uma Dobra temporária, alcançar fios que normalmente permaneceriam distribuídos além da percepção humana e organizá-los num padrão capaz de alterar uma relação do Reflexo. A Trama não é o fogo, o silêncio, o movimento ou a lembrança que aparece. É a costura anterior que faz o mundo expressar esse resultado.

Para Tramas comuns, os cinco momentos da Canalização acontecem numa única ação, mas dois riscos permanecem distintos. Temperança mede se a personagem suporta a Puxagem dos fios; Canalização mede se consegue organizá-los na forma pretendida. Os momentos são separados ainda mais quando escala, risco ou importância exigem que cada parte da aproximação possa falhar por si.

## Os cinco momentos

Separar os cinco momentos não significa que toda Trama exige cinco testes. A divisão existe para que o Narrador saiba onde uma operação profunda está falhando. Aproximação pode chamar atenção antes que qualquer efeito exista. Tração pode custar mais PE do que o esperado. Tecitura pode produzir um padrão contraditório. Expressão pode encontrar resistência. Relaxamento pode devolver ao mundo uma tensão que já não reconhece o caminho de volta.

| Momento | O que acontece | Risco principal |
| --- | --- | --- |
| I ~ Aproximação | O canalizador cria uma Dobra temporária e torna uma malha acessível. | Contato rejeitado, exposição precoce ou Pulso ambiental. |
| II ~ Tração | Fios são deslocados para dentro do alcance do Reflexo. | Perda de PS, PE insuficiente, perda de controle ou ser puxado pela malha. |
| III ~ Tecitura | Os fios recebem padrão, ordem e intenção. Aqui a Trama realmente nasce. | Costura incoerente, falha de Canalização ou conflito de Assinatura. |
| IV ~ Expressão | O Reflexo incorpora a alteração e produz efeito observável. | Resistência do alvo, alcance insuficiente ou consequência não prevista. |
| V ~ Relaxamento | A tensão é liberada e os fios tentam retornar. | Refluxo, resíduo, Tensão ou deformação persistente. |

## Ficha de uma Trama

| Campo | Função |
| --- | --- |
| Nome | Como o padrão é ensinado ou reconhecido. |
| Natureza e Domínio | Que relações profundas oferece à costura. |
| Verbo | O que a Trama tenta fazer: revelar, mover, conservar, romper, ocultar, ligar, repetir. |
| Alvo | Pessoa, objeto, corpo, memória, espaço, relação, sequência ou informação. |
| Intensidade | Repuxo, Tração ou Estiramento. |
| Alcance | Toque, próximo, distante, cena ou território. |
| Duração | Instantânea, rodada, cena, sustentada ou permanente por Selagem. |
| Resistência | Teste ou valor que pode reduzir ou anular o efeito. |
| Custo | PE gasto para criar e sustentar. |
| Refluxo | Como a costura retorna quando falha ou se rompe. |
| Assinatura | Forma particular que diferencia aquele padrão de outros efeitos semelhantes. |

## Intensidade

| Intensidade | DT base | Custo | Escala usual |
| --- | --- | --- | --- |
| Repuxo | 12 | 1 PE | efeito simples, um alvo, instante ou uma rodada |
| Tração | 16 | 2 PE | efeito relevante, múltiplos alvos próximos, cena curta ou alteração consistente |
| Estiramento | 20 | 4 PE | Alcance amplo, relação profunda, duração extensa ou alteração estrutural. (Normalmente exige Fragmento compatível, Dobra acessível, procedimento coletivo ou outra fonte capaz de sustentar a escala.) |

A DT recebe +2 quando a Trama amplia significativamente Alcance ou duração; +4 quando reorganiza múltiplas relações ao mesmo tempo ou tenta agir sem a condição necessária. Fragmentos, Dobras, preparação e Habilidades podem reduzir a DT.

## Pressão da Puxagem

Tração é o momento em que fios deixam de permanecer apenas além da percepção e passam a exercer pressão sobre quem os aproxima. Toda Canalização exige um teste de Temperança. Esse teste não decide se a Trama funciona: decide quanto da continuidade da personagem é gasto para tornar a costura possível. Em intensidades maiores, o contato deixa um Atrito mínimo mesmo quando a personagem resiste.

Temperança e Canalização pertencem à mesma ação e podem ser roladas em sequência ou simultaneamente com dados de cores diferentes. É possível resistir à Puxagem e falhar a Trama, perder PS e ainda tecê-la com sucesso, ou falhar em ambos. O contato possui preço próprio; o Refluxo possui forma própria. Atrito não é Refluxo e não pode ser convertido ou cancelado por efeitos que tratem apenas da falha da Trama.

| Intensidade | DT de Temperança | Sucesso / Falha |
| --- | --- | --- |
| Repuxo | 10 | 0 PS / perde 1 PS. |
| Tração | 15 | Perde 1 PS / perde 1d4 + 1 PS. |
| Estiramento | 20 | Perde 2 PS / perde 1d6 + 2 PS. |

MEN representa controle e compartimentalização; PRE, permanência de identidade; COR pode ser usado quando o contato atravessa diretamente o corpo; INS, quando a aproximação é reflexiva ou sensorial. Convicção pode substituir Temperança apenas quando uma relação concreta é nomeada. Fragmento compatível, preparação e condições favoráveis podem conceder Vantagem; Saturação, Dobra ativa e repetição excessiva podem aumentar a DT.

## Teste de Canalização

Escolha o Atributo que descreve a abordagem e role com Canalização. MEN representa controle; INS, percepção intuitiva do padrão; PRE, sustentação por identidade ou Convicção; ERU, reprodução técnica; COR é raro, mas pode aparecer quando o corpo é parte indispensável da costura.

Em sucesso, o efeito ocorre. Em sucesso excepcional, escolha uma vantagem apropriada: +1 alvo, aumento curto de duração, redução de 1 PE no custo de sustentação, menor sinal perceptível ou informação adicional sobre a reação da malha.

Resistência

Quando uma Trama tenta reorganizar um alvo capaz de resistir, sua DT de Resistência é:

| DT DE RESISTÊNCIA 10 + ATRIBUTO USADO NA CANALIZAÇÃO + POTÊNCIA DO GRAU + INTENSIDADE |
| --- |

Na DT de Resistência, a Potência do Grau é +0 sem treino, +2 para Iniciado, +4 para Apurado e +6 para Versado. Já para Intensidade, Repuxo acrescenta +0; Tração, +2; Estiramento, +4. O alvo usa a Perícia e o Atributo coerentes: Fortitude contra alteração corporal, Temperança ou Convicção contra intrusão, Reflexo contra efeito evitável, Canalização contra costura direta. As Tramas costumam indicar a defesa específica.

## Sustentação

A primeira rodada está incluída no custo inicial. Para manter a Trama além disso, pague ao início de cada rodada: 1 PE para Repuxo, 1 PE para Tração e 2 PE para Estiramento.

O personagem sustenta apenas uma Trama por vez, salvo por Habilidade.

Dano, condição ou interferência pode exigir Concentração. Falhar encerra a Trama e pode gerar Refluxo se o relaxamento for violento.

## Refluxo

Refluxo é o retorno desorganizado dos fios depois de uma Tecitura falha, de uma sustentação rompida ou de um Relaxamento violento. Ele é o segundo risco da Canalização: a Puxagem pressiona quem toca os fios; o Refluxo expressa como aquela Trama específica retorna. Não é punição moral e não precisa inverter literalmente o efeito. Sua forma nasce da Natureza, do Domínio, da Assinatura, da margem de falha e do ambiente.

| Grau | Quando ocorre | Efeito mínimo |
| --- | --- | --- |
| Comum | Falha por 1 a 4, ruptura simples de sustentação. | Aplica o Refluxo específico da Trama de forma localizada: sinal da Natureza, alteração breve, condição leve ou consequência ambiental pequena. Não exige dano genérico de PS ou PV. |
| Severo | Falha por 5 a 9, uso além do limite, fonte instável. | Amplia o Refluxo específico: condição, 1 Tensão, consequência ambiental importante ou 1d4 PS/PV quando a Natureza e a Assinatura justificarem. |
| Crítico | Falha por 10+, 1 natural escolhido, colapso de Estiramento. | Expressa o Refluxo em forma grave: condição severa, 2 Tensões, Pulso, efeito duradouro ou dano elevado de PS/PV quando coerente com a Trama. |

Dano de PS ou PV continua possível quando pertence à expressão da Trama, mas não é obrigatório: a Puxagem já carrega o risco universal de PS. Uma Trama de Memória pode fazer o corpo repetir uma ferida lembrada; uma Trama de Eclis pode pressionar PS quando a pessoa deixa de reconhecer os próprios limites; uma Trama de Linguagem pode apagar uma palavra sem causar dano direto.

*O Refluxo é especificado no texto de cada Trama

## Exemplos de Tramas

Os exemplos abaixo são modelos completos, e não uma lista de poderes permitidos. Eles mostram como Verbo, Alvo, Natureza e Assinatura trabalham juntos. Jogadores podem aprender variações, construir novas Tramas durante a campanha e utilizar o mesmo padrão com alterações de intensidade, desde que o Narrador consiga identificar custo, resistência e forma de Refluxo.

Trama em cena ~ Lembrança de Superfície

Nara toca uma válvula quebrada para descobrir quem a operou por último. A Trama é um Repuxo de Memória. Na mesma ação, primeiro testa Temperança DT 10 para suportar a Puxagem e depois usa ERU + Canalização: não tenta “ver o passado” de forma ampla, mas reconhecer a impressão significativa conservada pelo objeto. Se falhar em Temperança, perde 1 PS mesmo que a Trama funcione. Em sucesso de Canalização, recebe sensação breve de mãos tremendo e ouve três batidas dentro do tubo. Em falha próxima, ainda encontra a impressão, mas uma memória de sua própria infância mistura-se ao gesto e torna impossível saber qual medo pertencia a quem. A pista continua; o preço identifica a relação tocada.

*Veja mais na Expansão Transcendental.

| O MESMO EFEITO, OUTRA RELAÇÃO Ocultar uma porta por Thyren faz com que ela não seja percebida. Ocultá-la por Linguagem pode retirar das pessoas a palavra necessária para reconhecê-la como saída. A utilidade pode ser semelhante; a forma, as pistas e o Refluxo não são. |
| --- |

## Criando uma Trama durante a campanha

Uma nova Trama começa por intenção, não por efeito visual.o personagem precisa dizer que relação pretende alterar. O grupo encontrou um corredor que se repete. Em vez de pedir “um poder para sair”, a canalizadora formula: quer impedir que a sequência reconheça o grupo como recém-chegado.

1 ~ Defina o Verbo: conservar, ocultar, mover, repetir, ligar, impedir ou outro que descreva a alteração.

2 ~ Defina o Alvo: grupo, corredor, memória da chegada ou relação entre ambos.

3 ~ Escolha Natureza e Domínio: Memória poderia conservar a posição já alcançada; Fluxo poderia impedir a repetição; Thyren poderia retirar o grupo da percepção espacial do corredor.

4 ~ Escolha Intensidade pela profundidade necessária. Um Repuxo afeta uma passagem; Tração sustenta o grupo por uma cena; Estiramento poderia alterar toda a Zona.

5 ~ Defina Resistência e sinais. O corredor pode resistir como Dobra, e cada solução deixará pistas diferentes.

6 ~ Defina Refluxo antes de rolar. A falha de Memória pode apagar o caminho anterior; a de Fluxo pode repetir uma ação; a de Thyren pode ocultar uma pessoa do próprio grupo.

O Narrador não precisa aprovar qualquer formulação apenas porque parece criativa. A Trama deve caber na Natureza, respeitar escala e possuir preço. Quando esses elementos estão claros, a criação aberta deixa de ser improvisação sem limite e torna-se uma aplicação consistente da cosmologia.

| APRENDER E INVENTAR Tramas ensinadas são mais seguras porque já possuem padrão, linguagem e referências. Inventar uma Trama em campo pode acrescentar +2 à DT, exigir Teste Encadeado ou ampliar o Refluxo até que o personagem a estude num Interlúdio. |
| --- |
