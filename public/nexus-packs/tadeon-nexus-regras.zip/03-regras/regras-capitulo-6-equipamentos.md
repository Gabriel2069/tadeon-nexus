---
title: "Livro de Regras — CAPÍTULO 6 ~ EQUIPAMENTOS"
node_type: "rule"
summary: "Seção “CAPÍTULO 6 ~ EQUIPAMENTOS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 6 ~ EQUIPAMENTOS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 6 ~ EQUIPAMENTOS","source_order":7,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 6 ~ EQUIPAMENTOS

Tudo que um personagem carrega ocupa espaço no corpo e participa da história que o corpo consegue atravessar.

Em Arden, ferramenta e cultura material não formam um cenário separado da regra. Uma arma revela quais forças uma sociedade aprendeu a conduzir. Um estojo de contenção registra décadas de acidentes, pesquisa e medo institucional. Uma máscara filtrante existe porque alguém precisou transformar veneno invisível em problema técnico. Equipamentos são respostas acumuladas a condições concretas.

O capítulo apresenta propriedades operacionais, não um catálogo fechado de todos os objetos possíveis. Armas, armaduras e kits podem variar enormemente entre regiões. O mesmo perfil de besta pneumática pode aparecer como instrumento de caça em Yawurua, arma naval no Mar Tético ou peça refinada de uma guarda urbana. Aparência, material e história mudam; espaço, dano e propriedade permanecem legíveis.

| TECNOLOGIA SEM ORNAMENTO VAZIO O medievo-futurismo de Arden não exige válvulas e engrenagens em todo objeto. Um equipamento deve possuir função, fonte de energia, necessidade de manutenção e origem material. Quando esses elementos estão claros, o estilo aparece por consequência. |
| --- |

## Espaços de Carga

Carga não mede apenas massa. Mede volume, distribuição, acesso e interferência. Um instrumento leve pode ocupar muito espaço; uma peça pesada pode ser carregada de maneira eficiente se foi presa ao corpo para isso. O sistema usa Espaços para manter a decisão rápida sem fingir que todos os objetos cabem igualmente num bolso.

A capacidade de carga é igual a 2 × COR + 5 Espaços. Objetos pequenos e pessoais podem ter Espaço 0 quando não oferecem vantagem mecânica relevante. Equipamentos comuns ocupam 1 Espaço; objetos volumosos, 2; itens pesados, 3 ou mais.

Ultrapassar a capacidade aplica Fadigado. Carregar mais que o dobro impede deslocamento normal sem auxílio, animal, veículo ou mecanismo.

## Ficha de uma Arma

Uma arma não é apenas o dado que lança quando acerta. É a relação entre corpo, mecanismo, material, alcance e a forma de consequência para a qual foi construída. A ficha existe para que duas armas com o mesmo dano ainda possam ocupar lugares diferentes na cena, na cultura e nas decisões da personagem.

Nem todo campo precisa aparecer em toda linha de inventário. A ficha completa é usada para criar, revisar ou apresentar uma arma; depois, a versão resumida pode conservar apenas aquilo que entra em jogo com frequência.

| Campo | O que registra |
| --- | --- |
| Nome | Como a arma é conhecida. Pode incluir modelo, título, oficina, tradição ou nome pessoal. |
| Descrição e procedência | Forma, materiais, origem, instituição responsável e sinais visíveis de uso ou manutenção. |
| Família | Contato, projeção ou improvisada. Define o tipo de teste e as regras gerais de uso. |
| Categoria | Leve, Média, Pesada, Excepcional, Longa ou outra categoria prevista na tabela do capítulo. |
| Proficiência | Nível mínimo necessário para utilizá-la sem Desvantagem e ativar suas propriedades. |
| Teste de ataque | Normalmente Luta ou Pontaria, combinado ao Atributo coerente com a abordagem. |
| Atributo no dano | Indica se COR ou outro valor é somado. Armas sem participação física direta normalmente não somam Atributo. |
| Dano | Dados e modificadores rolados num acerto comum. |
| Tipo de dano | Corte, Perfuração, Impacto, Térmico, Elétrico, Químico ou Tessitural. Armas versáteis podem permitir escolha. |
| Margem de Ameaça | Resultados naturais que produzem crítico quando o ataque acerta. O multiplicador padrão é ×2. |
| Alcance | Perfil espacial completo do ataque ou uso: Engajado, Próximo, Distante, Longo, Extremo, Cone, Linha, Raio, Aura ou Corrente, com sua dimensão. |
| Mãos | Uma mão, duas mãos ou configuração variável. |
| Propriedades | Tags que alteram uso: Ágil, Ocultável, Versátil, Demolidora, Duas mãos, Frágil, Incômoda ou Especial. |
| Espaço | Quanto ocupa na Capacidade de Carga, já considerando modificações instaladas. |
| Munição ou fonte | Projéteis, pressão, reagente, carga óptica ou outra fonte limitada. Registre capacidade e recarga quando importarem. |
| PD e RD | Durabilidade e resistência do objeto quando ele for alvo, bloquear impacto ou sofrer desgaste relevante. |
| Modificações | Alterações Comuns, Especializadas, Táticas e de Ramo instaladas. |
| Condições de uso | Restrições próprias: preparação, recarga, terreno, montagem, postura, alvo ou custo adicional. |

## Armas corpo a corpo

Ataques corpo a corpo usam Luta e um Atributo coerente com a abordagem. O dano recebe o valor de COR quando a força física participa diretamente do impacto. Todas as armas causam crítico ×2.

| Categoria | Exemplos | Dano | Margem | Propriedades | Espaço |
| --- | --- | --- | --- | --- | --- |
| Leve | faca, punhal, bastão curto, ferramenta | 1d6 | 20 | Ágil, Ocultável | 1 |
| Média | espada, lança curta, machete, martelo | 1d8 | 20 | Versátil | 2 |
| Pesada | machado longo, montante, martelo de guerra | 1d10 | 20 | Pesada, Demolidora | 3 |
| Excepcional | arma de haste, lâmina pneumática, ferramenta industrial | 1d12 | 19 | Duas mãos, Especial | 4 |
| Improvisada | garrafa, cadeira, corrente, peça solta | 1d4 | 19 | Frágil ou Incômoda | 1 |

## Armas de projeção

Armas de projeção usam Pontaria. Arcos podem somar COR ao dano quando a potência da arma depende de tração compatível com o corpo da personagem; bestas e mecanismos pneumáticos não somam Atributo.

| Categoria | Exemplos | Dano | Margem | Alcance | Espaço |
| --- | --- | --- | --- | --- | --- |
| Leve | arco curto, funda técnica, lançador manual | 1d8 | 20 | até 20 m | 1 |
| Média | besta, arco longo, pistola pneumática | 1d10 | 20 | até 50 m | 2 |
| Longa | besta pesada, carabina pneumática, lançador de precisão | 2d6 | 19 | até 150 m | 3 |
| Dispersão | cápsula fragmentária, ampola incendiária, dispersor | 2d6 | — | Raio pequeno (3 m) | 1 |

## Proficiência

| Nível | Nome | Permissão |
| --- | --- | --- |
| I | Leigo | Armas leves, improvisadas e instrumentos comuns. |
| II | Operador | Armas de Espaço 2 e 3; mecanismos profissionais. |
| III | Combatente | Todas as armas de contato ou projeção de uma família escolhida. |
| IV | Armígero | Qualquer arma convencional e modificações de alto grau. |

| Proficiência | Rank mínimo | Custo | Aquisição |
| --- | --- | --- | --- |
| I ~ Leigo | 0 | gratuita | Universal na criação. |
| II ~ Operador | 0 | 1 PM | Uma gratuita, coerente com a Ocupação. |
| III ~ Combatente | 25 | 2 PM | Escolha Contato ou Projeção. |
| IV ~ Armígero | 50 | 3 PM | Domínio convencional amplo. |

Quando a história exigir justificativa, a aquisição pode ser preparada por Treinamento durante um Interlúdio. O custo em PM continua sendo pago; a cena explica de onde a capacidade veio.

## Equipamento inicial

| Escolha | Quantidade | Limite |
| --- | --- | --- |
| Arma | 1/2 (se coerente) | Dentro da Proficiência da personagem. |
| Proteção | 1 | Armadura, escudo ou vestimenta técnica coerente. |
| Kits ou instrumentos | 2 | Relacionados a Perícias, Ocupação ou função no grupo. |
| Consumíveis | 3 | Cicatrizantes, cápsulas, ampolas ou equivalentes. |
| Objetos pessoais | livres | Espaço 0 quando não concedem vantagem mecânica. |

Usar uma arma acima da Proficiência aplica Desvantagem e impede ativar suas propriedades especiais. Todos começam com Proficiência I e recebem uma Proficiência II coerente com a Ocupação. Graus posteriores são adquiridos com PM, Habilidade, treinamento de campanha ou decisão explícita do Narrador.

## Tipos de dano

O tipo de dano não concede benefício universal por si. Ele informa quais resistências, materiais, condições e ficções podem interagir com o ataque. Uma lâmina não faz alguém Sangrar apenas porque causa Corte; uma Habilidade, crítico ou situação precisa produzir a condição. Quando uma arma oferece dois tipos, o atacante escolhe um deles antes da rolagem.

| Tipo | Origem comum | Possíveis efeitos |
| --- | --- | --- |
| Corte ~ C | Lâminas, fios, bordas e fragmentos afiados. | Pode abrir ferimento, separar material e interagir com Sangrando. |
| Perfuração ~ P | Pontas, virotes, espinhos e projéteis concentrados. | Pode atravessar fendas, fixar ou atingir componentes internos quando uma propriedade permitir. |
| Impacto ~ I | Golpes contundentes, quedas, ondas de pressão e esmagamento. | Relaciona-se a empurrões, quedas, Abalado e dano a objetos. |
| Térmico ~ T | Calor, fogo, frio intenso e choque de temperatura. | Pode produzir Em Chamas, Fadigado, congelamento ou alteração de materiais. |
| Elétrico ~ E | Corrente, arco voltaico e descarga acumulada. | Pode afetar mecanismos, condução por água ou metal e condições de interrupção. |
| Químico ~ Q | Ácidos, toxinas, solventes, reagentes e corrosão. | Pode persistir, causar Doente, reduzir PD ou exigir proteção selada. |
| Tessitural ~ Ts | Alteração direta de Assinatura, Fios, Fragmentos, Selos ou Permanência. | Só existe quando a arma, Trama ou Habilidade explica seu acesso. Pode atingir PV, PS, PA, PP ou PD conforme o efeito; não ignora RD automaticamente. |

## Propriedades-padrão

Propriedade é uma regra curta incorporada ao desenho da arma. Quando uma propriedade e uma Habilidade tratam da mesma situação, aplique ambas apenas se seus efeitos forem diferentes; duas fontes que concedem exatamente a mesma vantagem não se acumulam.

| Propriedade | Regra |
| --- | --- |
| Ágil | Pode ser sacada, guardada ou ter a empunhadura alterada como Ação Livre uma vez por Turno. |
| Ocultável | Pode permanecer escondida sob vestimenta ou bagagem comum. Encontrá-la exige busca ativa ou motivo concreto. |
| Versátil | Pode ser usada com uma ou duas mãos. Com duas mãos, recebe +1 no dano; mudar a empunhadura é Ação Livre. |
| Pesada | Exige COR 2 para uso sem Desvantagem e não pode receber a propriedade Ocultável. |
| Demolidora | Ignora 1 RD de objetos e estruturas. Este nome substitui o antigo rótulo de propriedade “Impacto”, evitando confusão com o tipo de dano. |
| Duas mãos | Exige as duas mãos livres para atacar ou ativar suas propriedades. |
| Especial | Possui regra própria registrada na ficha, normalmente ligada a fonte, modo de ativação ou uso institucional. |
| Frágil | Perde 1 PD num 1 natural, num crítico recebido durante Bloqueio ou quando usada contra material claramente inadequado. |
| Incômoda | Recebe -1d20 em espaços estreitos, durante Contra-ataque ou quando a postura necessária não pode ser assumida. |
| Brutal | No crítico, calcule o dano ×2 normalmente e então acrescente um dado base adicional da arma. Obtida pela Habilidade Corpórea de Tier II. |
| Furtiva | Reduz ruído, clarão e vestígios do mecanismo. Obtida pela Habilidade Cinética de Tier II. |
| Mira Fria | Conserva alinhamento suficiente para que Mirar seja Ação Livre uma vez por Turno. Obtida pela Habilidade Cônscia de Tier II. |
| Condutor de Assinatura | Serve como foco de uma Natureza e Domínio, reduzindo em 1 a DT de Trama compatível. Obtida pela Habilidade Canalizada de Tier II. |
| Reforçada | Aumenta a Durabilidade do objeto em +2 PD, sem elevar RD. Pode ser aplicada mais de uma vez apenas quando a oficina e o material justificarem. |

## Durabilidade de referência

| Construção | PD | RD | Exemplos |
| --- | --- | --- | --- |
| Frágil | 4 PD | 0 RD | vidro, cerâmica fina, mecanismos leves |
| Comum | 6 PD | 1 RD | madeira tratada, lâmina comum, besta leve |
| Reforçada | 8 PD | 2 RD | aço, compósito, mecanismo profissional |
| Industrial | 10 PD | 3 RD | ferramenta pesada, arma excepcional, blindagem técnica |

## Modificações

| Grau | Exemplos de efeito | Requisito |
| --- | --- | --- |
| Comum | +1 no ataque; saque mais rápido; reduzir Espaço em 1, mínimo 1; reforçar Durabilidade. | Proficiência I |
| Especializada | margem 19~20; aumentar alcance; aplicar condição em crítico; silenciar mecanismo. | Proficiência II e acesso técnico |
| Tática | +1 dado de dano em condição específica; adquirir um perfil de Alcance coletivo (Cone, Linha, Raio ou Corrente); propriedade de Ramo. | Proficiência III ou Habilidade |

Cada modificação normalmente aumenta o Espaço em 1. Uma arma comporta modificações em quantidade igual à Proficiência do usuário, mas apenas uma pode ser do maior grau disponível.

## Armaduras

| Armadura | Espaço | DEF | RD | Exemplos |
| --- | --- | --- | --- | --- |
| Leve | 1 | +1 | 0 | tecido reforçado, couro cultivado, casaco de viagem |
| Média | 2 | +2 | 1 | malha metálica, placas compostas, proteção de guilda |
| Pesada | 3 | +3 | 2 | placas integrais, vestes pneumáticas assistidas, blindagem de contenção |

Armaduras Médias e Pesadas aplicam Desvantagem em certas ações de Carga quando o desenho não é adequado ao movimento. A RD reduz dano depois do crítico e antes de outras reduções.

## Cobertura e visibilidade

| Situação | Efeito |
| --- | --- |
| Cobertura leve | -1d20 em ataques de projeção que atravessem fumaça, vegetação ou mobiliário. |
| Cobertura parcial | -1d20 no ataque e +1 DEF para o alvo. |
| Cobertura sólida | -2d20 no ataque e +2 DEF; corpo a corpo não alcança sem contornar. |
| Cobertura total | Ataque direto impossível sem alterar posição ou cobertura. |
| Trevas | -2d20 em Percepção visual; ataques dependentes de visão recebem -1d20. |
| Terreno difícil | Deslocamento reduzido à metade, salvo propriedade ou teste apropriado. Não permite manobras de Investida. |

## Instrumentos e itens táticos

| Item | Espaço | Função |
| --- | --- | --- |
| Kit de Perícia | 1 | Permite usos técnicos da Perícia correspondente e pode remover Desvantagem por falta de instrumento. |
| Cicatrizante bioalquímico | 1 | Recupera 1d6 PV ou estabiliza Morrendo sem teste. Uma aplicação por cena por alvo. |
| Ampola de fumaça | 1 | Cria Cobertura Parcial e Trevas num Raio pequeno por 1d4 Rodadas. |
| Cápsula atordoante | 1 | Alvos testam Fortitude DT 15 ou ficam Atordoados até o fim do próximo turno. |
| Cápsula fragmentária | 1 | Causa 3d6 de Corte num Raio pequeno; Reflexo DT 15 reduz à metade. |
| Ampola incendiária | 1 | Causa 2d6 Térmico num Raio pequeno e pode aplicar Em Chamas. |
| Máscara filtrante | 1 | Protege contra fumaça, gás e partículas compatíveis com o filtro. |
| Lâmpada heliográfica | 1 | Remove Trevas próximas; pode transmitir sinais visuais simples. |
| Luneta prismática | 1 | Observação a longa distância; +1d20 quando ampliação é determinante. |
| Sonda de pressão | 1 | Lê vazamentos, variações pneumáticas e atividade mecânica. |
| Bastão de descarga | 1 | 1d6 Elétrico. Num Ataque Concentrado ou ao consumir uma carga, Fortitude DT 15 ou Atordoado. Alcance Engajado. |
| Corda e mosquetões | 1 | Escalada, resgate, amarração e movimentação de carga. |
| Kit de sobrevivência | 2 | Abrigo, fogo, água, alimento e primeiros cuidados para um pequeno grupo. |
| Mochila estruturada | 1 | Aumenta capacidade de carga em 3 Espaços; não acumula com outra mochila. |
| Bandoleira | 1 | Uma vez por turno, sacar ou guardar item de Espaço 1 como Ação Livre. |
| Estojo de contenção | 1 | Transporta Fragmento de Categoria II selado ou I sem selo sem risco ambiental comum. |

## Disponibilidade, manutenção e procedência

O preço de um equipamento não é apenas monetário. Alguns itens exigem oficinas autorizadas, reagentes, licenças, transporte ou confiança institucional. Uma carabina pneumática pode ser comum num corredor de caça e restrita numa cidade densamente pressurizada. Um estojo de contenção pode existir em qualquer base da Ordem e ser impossível de comprar legalmente.

Equipamentos também se desgastam quando a ficção oferece motivo. Bloquear um impacto excepcional, atravessar água salgada, operar acima da pressão segura ou receber Refluxo pode reduzir PD, impor manutenção ou alterar propriedades. O Narrador não deve criar burocracia para cada uso. O desgaste importa quando transforma preparação, acesso ou custo futuro.

Procedência cria história. Uma lâmina herdada, um instrumento da Eclésia e um kit montado por contrabandistas podem possuir o mesmo perfil mecânico e relações completamente diferentes. Quando o objeto participa de Vínculo, Ferida, dívida ou reputação, registre essa relação fora da linha de dano.

## Exemplo preenchido ~ Lâmina pneumática de contenção

| Nome | Lâmina pneumática de contenção |
| --- | --- |
| Descrição e procedência | Ferramenta da Ordem usada para cortar estruturas alteradas e abrir passagem em materiais pressionados. Possui câmara curta, travas de bronze e lâmina substituível. |
| Família e categoria | Contato ~ Excepcional |
| Proficiência | III ~ Combatente na família de armas de contato |
| Teste de ataque | Luta + Atributo da abordagem |
| Atributo no dano | Soma COR quando a força do corpo conduz o golpe |
| Dano e tipo | 1d12 + COR; Corte ou Impacto, escolhido antes do ataque |
| Margem e crítico | 19; crítico ×2 |
| Alcance | Engajado |
| Mãos e propriedades | Duas mãos; Demolidora; Especial ~ Pressurizada |
| Espaço | 4 antes de modificações |
| Fonte | Cartucho de pressão com 4 ativações. Um ataque pressurizado empurra 1,5 m; recarga exige Ação Padrão. |
| PD e RD | 10 PD; 3 RD |
| Modificações | Brutal e Reforçada |
| Condição de uso | Sem carga, funciona como arma comum, mas perde a propriedade Pressurizada. |
