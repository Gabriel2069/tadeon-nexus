---
title: "Livro de Regras — CAPÍTULO 5 ~ HABILIDADES"
node_type: "rule"
summary: "Seção “CAPÍTULO 5 ~ HABILIDADES” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 5 ~ HABILIDADES"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 5 ~ HABILIDADES","source_order":6,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 5 ~ HABILIDADES

Os Ramos não dizem quem alguém é. Dizem por quais formas aprendeu a agir quando a escolha precisa se tornar procedimento.

Ramos não são profissões, temperamentos ou destinos. Eles organizam efeitos para que a liberdade de compra não dissolva a identidade mecânica. Uma investigadora pode desenvolver Corpóreo porque aprendeu a proteger testemunhas; um combatente pode aprofundar Cônscio porque sobreviveu ao reconhecer padrões; uma sacerdotisa pode investir em Cinético para mover-se entre pessoas e momentos; um artesão pode tocar Canalizado sem abandonar o ofício que o define.

Cada Habilidade deve mudar alguma decisão. Bônus de dados continuam presentes, mas não ocupam sozinhos a progressão. Reações, permissões, conversões de recurso, movimentos e novas formas de utilizar as regras tornam personagens diferentes mesmo quando possuem Atributos semelhantes.

Habilidades são compradas com PM e organizadas em quatro Ramos abertos. Um personagem pode seguir apenas um, misturar dois ou construir uma combinação própria. O nome do Ramo descreve uma gramática de ação, não uma classe.

| Ramo | Verbos centrais |
| --- | --- |
| Corpóreo | suportar, romper, proteger, confrontar |
| Cônscio | compreender, perceber, planejar, concentrar |
| Cinético | mover, reagir, posicionar, executar |
| Canalizado | aproximar, tecer, expressar, selar |

Uma Habilidade pode exigir Atributo, Perícia, Rank, Equilíbrio ou acontecimento narrativo. Requisitos mecânicos são verificáveis; requisitos narrativos precisam ter acontecido na ficção e não podem ser substituídos por repetição vazia. Cada Tier oferece seis escolhas por Ramo. Na criação, duas Habilidades de Tier I são gratuitas; as demais são adquiridas com PM.

| MODIFICAÇÕES DE RAMO Toda Habilidade de Modificação do Tier II é tratada como Modificação Tática. Ela ocupa um espaço de modificação da arma ou do objeto, normalmente aumenta seu Espaço em 1 e precisa ser instalada, ajustada ou reconfigurada durante um Interlúdio com ferramentas, material e acesso plausíveis. Comprar a Habilidade permite construir e utilizar a modificação; e não cria o item a partir do nada. |
| --- |

| HABILIDADES POLARIZADAS Todo Tier IV possui uma opção ligada ao Equilíbrio -5 e outra ao +5. A Habilidade permanece comprada quando o personagem sai da faixa, mas fica inativa. A Tensão gerada por seu uso é uma fonte excepcional e pode atravessar o limite comum de ±5. |
| --- |

## Ramo Corpóreo

O Corpóreo não glorifica resistência sem consequência. Ele transforma o corpo em posição: escolher ficar, interceptar, carregar, romper ou terminar um movimento apesar do impacto. Suas Habilidades são mais fortes quando o espaço e outras pessoas importam.

Forma de jogar ~ Corpóreo

Um personagem Corpóreo não precisa atacar em todas as rodadas. Pode sustentar uma passagem, receber o impacto que alcançaria alguém, romper um obstáculo, impedir que uma ameaça reorganize posição ou continuar de pé tempo suficiente para que o grupo alcance a Costura. Seu poder aparece mais ainda no que permite aos outros fazer.

O Corpóreo trata do modo como uma pessoa ocupa espaço, recebe impacto e transforma esforço em permanência. Não é apenas força. É a capacidade de fazer do corpo uma decisão.

| Tier I ~ Impacto Bruto COR 2 Uma vez por turno, gaste 1 PE antes de um ataque corpo a corpo ou teste físico para receber Vantagem. |
| --- |
| Tier I ~ Resistência Inata COR 2 Receba +3 PV permanentes. Esta Habilidade pode ser comprada apenas uma vez. |
| Tier I ~ Postura de Combate COR 1 Se não usar sua Ação de Movimento, receba +1 DEF e RD 1 até o início do próximo Turno. |
| Tier I ~ Interposição COR 2, Fortitude Iniciada Quando um aliado a até 1,5 m for alvo de um ataque físico que você possa alcançar, use sua Reação para ocupar a linha do golpe e tornar-se o alvo. Se não houver espaço ou trajetória plausível, a Interposição não pode ser usada. |
| Tier I ~ Queda de Pedra COR 2 Uma vez por cena, reduza dano de queda, colisão ou deslocamento forçado em 1d6 + COR. Se permanecer consciente, pode terminar de pé. |
| Tier I ~ Mãos Firmes COR 2 Uma vez por Teste Prolongado em que força, carga ou contenção física sejam centrais, uma falha próxima sua não acrescenta Pressão. A ação ainda produz um preço local coerente. |
| Tier II ~ Modificação ~ Brutal COR 3, Proficiência adequada No crítico, aplique normalmente o multiplicador ×2 e depois acrescente um dado base adicional da arma. É uma Modificação de Ramo, ocupa um espaço de modificação e não amplia o multiplicador crítico. |
| Tier II ~ Sequência Fluida COR 3 Na primeira Sequência de dois golpes por Rodada, o primeiro ataque não sofre a penalidade de -1d20; o segundo sofre normalmente. O custo de 1 PE da Sequência permanece. |
| Tier II ~ Arrastão COR 3 Ao acertar com uma arma Média, Pesada ou Excepcional, pode empurrar o alvo 1,5 m. Ele resiste com Fortitude contra seu resultado de ataque. Junto de um arrastão, gaste 1 PE para usar a manobra Derrubar como ação livre. |
| Tier II ~ Guardar Impacto COR 3 Como Reação, gaste 2 PE para reduzir dano físico em 1d6 + COR. Não se aplica a efeitos que não possam ser interceptados pelo corpo. |
| Tier II ~ Corpo Habituado COR 3 A primeira condição Física leve recebida em cada cena não progride quando reaplicada pela primeira vez. |
| Tier II ~ Ponto de Apoio COR 3, Fortitude Iniciada Enquanto não tiver se deslocado desde o início do seu Turno, aliados adjacentes recebem Vantagem contra empurrões e quedas e podem tratá-lo como Cobertura Leve contra ataques que atravessem sua posição. |
| Tier III ~ Dilacerante COR 4 Ao gastar 1 PE, críticos corpo a corpo aplicam Sangrando se o tipo de dano puder abrir ferimento. |
| Tier III ~ Quebrar a Linha COR 4 Uma vez por Rodada, ao derrubar um alvo, causar crítico ou reduzi-lo a 0 PV ou PP, gaste 1 PE e mova-se até 3 m sem provocar Reações. |
| Tier III ~ Peso dos Músculos COR 4 Receba Vantagem contra empurrões, quedas e imobilizações. Efeitos comuns não podem deslocá-lo contra sua vontade enquanto estiver apoiado. |
| Tier III ~ Muralha Humana COR 4, Fortitude Apurada Ao Bloquear um ataque com Alcance de Linha, Cone, Raio ou Aura que também alcance um aliado adjacente, gaste 1 PE: o aliado recebe a mesma redução de dano. O objeto usado no Bloqueio perde 1 PD adicional. |
| Tier III ~ Golpe de Ruptura COR 4, Luta Apurada Como Ação Completa, gaste 2 PE e ataque com arma Média, Pesada ou Excepcional. O ataque ignora 3 RD e causa dano dobrado a objetos e estruturas. |
| Tier III ~ Trabalho (Im)possível COR 4 Uma vez por sessão, execute sozinho com Vantagem uma etapa física que normalmente exigiria várias pessoas ou um mecanismo, desde que permaneça dentro de escala humana possível. A DT mínima é 20; falha produz condição Física grave ou Pressão adicional. Causa |
| Tier IV ~ Encarnação do Medo COR 5, Equilíbrio -5 ou menor Uma vez por cena, gaste 2 PE e assuma por 3 Rodadas uma presença visceral: receba +1d20 em testes Corpóreos e ignore Machucado. Ao terminar, receba 1 Tensão de Medo. |
| Tier IV ~ Corpo de Geometria COR 5, Equilíbrio +5 ou maior Uma vez por cena, gaste 2 PE. Por 3 Rodadas, o dado escolhido em testes de COR, Fortitude e Acrobacia nunca é tratado como menor que 15; ignore penalidades de terreno instável e imprecisão física. Ao terminar, receba 1 Tensão de Conhecimento. |
| Tier IV ~ Último Movimento COR 5 Ao chegar a 0 PV, realize imediatamente uma Ação Padrão ou de Movimento antes de entrar em Morrendo. Uma vez por sessão. |
| Tier IV ~ Corpo Inadiável COR 5 Enquanto possuir ao menos 1 PV, condições Físicas não podem impedir completamente sua ação; elas ainda aplicam penalidades e consequências. |
| Tier IV ~ Colosso de Passagem COR 5, Fortitude Versada Uma vez por cena, escolha uma passagem de até 3 m que esteja ocupando. Enquanto não sair dela, inimigos só atravessam sua posição vencendo teste contestado contra COR + Fortitude; aliados atrás de você recebem Cobertura Parcial. |
| Tier IV ~ Reserva Profunda COR 5 Uma vez por sessão, gaste 3 PE e recupere 2d6 + COR PV. Remova Machucado, se presente, e fique Fadigado até o fim da cena. |

## Ramo Cônscio

O Cônscio transforma informação em ação antes que a cena se feche. Ele não concede onisciência e não substitui investigação. Suas Habilidades reconhecem vantagem, organizam colaboração, diminuem incerteza ou oferecem uma pergunta melhor. Quanto mais profundo o Ramo, maior o risco de confundir compreensão com controle.

Forma de jogar ~ Cônscio

Um personagem Cônscio prepara o confronto antes de produzir dano. Identifica o vetor mais perigoso, oferece instruções, reconhece uma Assinatura e converte a pista em abertura. Em cenas sociais, pode perceber que a informação verdadeira não é aquilo que alguém diz, mas a regra que precisa fingir obedecer.

O Cônscio trabalha com atenção, padrão e decisão informada. Seu poder não está em saber tudo, mas em reconhecer que parte de uma situação precisa ser compreendida antes que agir seja apenas repetir o erro anterior.

| Tier I ~ Olho Aguçado MEN 2 Uma vez por cena, depois de rolar Percepção ou Investigação, gaste 1 PE, acrescente 1d20 ao pool e refaça a escolha do dado. |
| --- |
| Tier I ~ Análise Rápida MEN 2 Depois de um teste bem-sucedido contra uma Ameaça, escolha DEF, ataque, mobilidade ou Habilidade. O Narrador revela uma informação operacional relevante. |
| Tier I ~ Lógica em Campo MEN 1 Ao liderar Teste Conjunto, gaste 1 PE e o bônus máximo de ajuda aumenta de +6 para +9. |
| Tier I ~ Hipótese de Trabalho MEN 2 Uma vez por cena, declare uma hipótese verificável. O primeiro teste realizado para confirmá-la ou negá-la recebe Vantagem. Se estiver errada, o Narrador ainda revela uma relação que ela não consegue explicar. |
| Tier I ~ Memória de Procedimento MEN 2 ou ERU 2 Depois de concluir com sucesso uma tarefa técnica ou acadêmica, repeti-la nas mesmas condições durante a cena não exige novo teste. Se tempo, ferramentas ou risco mudarem, receba +3 em vez disso. |
| Tier I ~ Vigília Compartilhada MEN 1, Percepção Iniciada Durante guarda ou observação prolongada, escolha um aliado capaz de receber suas instruções. Ele pode usar seu resultado de Percepção se o do próprio for menor; ambos compartilham a consequência de uma falha. |
| Tier II ~ Modificação ~ Mira Fria MEN 3, Pontaria Apurada ou Engenharia Iniciada Uma arma de projeção ou instrumento de precisão é adaptado para retenção de alinhamento. Mirar com ele pode ser realizado como Ação Livre uma vez por Turno. É uma Modificação de Ramo e ocupa um espaço de modificação. |
| Tier II ~ Memória Velada MEN 3 Reconheça sem teste Fragmentos, Selos e Assinaturas que já tenha estudado. Cópias, falsificações ou variações ainda podem exigir análise. |
| Tier II ~ Disciplina de Vidro MEN 3 Uma vez por cena, gaste 1 PE para repetir um teste de MEN ou Temperança. Deve aceitar o segundo resultado. |
| Tier II ~ Precisão Cirúrgica MEN 3, Pontaria Apurada Ataque Concentrado reduz o aumento de DT de +5 para +3. |
| Tier II ~ Mapa de Consequências MEN 3 Antes de um Teste Prolongado, o Narrador informa duas consequências prováveis de alcançar a Pressão máxima. |
| Tier II ~ Instrução Breve MEN 3, Tática Iniciada Uma vez por Rodada, quando um aliado a até 6 m declarar uma ação que possa compreender, use sua Reação e gaste 1 PE para conceder +3 ao teste. Se a ação falhar por 5 ou mais, você compartilha uma consequência ou Pressão coerente. |
| Tier III ~ Ponto Cego MEN 4 Ataques de projeção ignoram Cobertura Parcial. Cobertura Sólida continua aplicando seus efeitos. |
| Tier III ~ Fortaleza Mental MEN 4 Receba +1d20 em resistências a Tramas e efeitos que reescrevam memória, percepção ou raciocínio. |
| Tier III ~ Plano de Costura MEN 4 Quando o grupo resolver um Ponto de Costura, gaste 2 PE e escolha um aliado: ele recupera 2 PE ou remove uma condição leve. |
| Tier III ~ Cadeia de Causa MEN 4, Investigação Apurada Depois de um sucesso excepcional em Investigação ou Lógica, escolha uma ação diretamente sustentada pela descoberta. Aliados recebem +2 nessa ação até o fim da cena. Uma vez por cena. |
| Tier III ~ Mente Paralela MEN 4, Concentração Apurada Pode manter uma tarefa técnica ou intelectual Prolongada enquanto realiza Ações de Movimento e ações breves. Testes feitos enquanto divide a atenção recebem -1d20; falhar acrescenta Pressão a ambas as frentes. |
| Tier III ~ Diagnóstico em Movimento MEN 4, Análise Rápida Uma vez por Rodada, quando uma Ameaça usar pela primeira vez um ataque, Reação ou Habilidade, gaste 1 PE e sua Reação para realizar Análise Rápida imediatamente. |
| Tier IV ~ Instinto Cartografado MEN 5, Equilíbrio -5 ou menor Uma vez por cena, quando uma Ameaça o escolher como alvo, identifique imediatamente seu maior VT, Deslocamento e uma Reação. Por 3 Rodadas, receba +1d20 para resistir ou agir contra ela. Ao terminar, receba 1 Tensão de Medo. |
| Tier IV ~ Olho da Chama Fria MEN 5, Equilíbrio +5 ou maior Uma vez por sessão, formule uma pergunta objetiva sobre a cena, objeto ou padrão presente. O Narrador responde com uma verdade clara, limitada ao que a realidade contém ali. Custa 2 PS e concede 1 Tensão de Conhecimento. |
| Tier IV ~ Arquivo Vivo MEN 5, ERU 4 Informações estudadas com tempo suficiente não exigem teste para serem recordadase. Quando não sabe algo, reconhece ao menos que tipo de fonte poderia responder. |
| Tier IV ~ Precisão Irreversível MEN 5, Pontaria Versada Depois de Mirar, gaste 2 PE e a Margem de Ameaça do próximo ataque de projeção torna-se 18~20. |
| Tier IV ~ Plano Inevitável MEN 5, Tática Versada Uma vez por sessão, após ao menos um minuto de planejamento, crie três Preparações. Um aliado pode gastar uma Preparação depois de rolar para receber +3 ou transformar falha por 1 a 4 em sucesso com preço. Preparações não usadas terminam quando a cena muda. |
| Tier IV ~ Nomear a Regra MEN 5, Investigação Versada Depois de observar duas ocorrências do mesmo efeito sobrenatural, gaste 2 PE e declare a regra que acredita organizá-lo. O Narrador confirma o núcleo correto ou aponta a evidência que o contradiz. Até o fim da cena, o grupo recebe Vantagem para resistir ou explorar essa regra. Uma vez por cena. |

## Ramo Cinético

O Cinético trabalha com intervalo, não apenas velocidade. Ele modifica o momento em que uma ação pode acontecer, a posição a partir da qual se torna possível e a atenção que precisa ser desviada. Por isso reúne movimento, reflexo, disfarce e presença social: todos dependem de entrar na relação certa antes que ela se estabilize contra o personagem.

Forma de jogar ~ Cinético

Um personagem Cinético transforma a geometria da cena. Leva informação entre grupos separados, alcança um mecanismo antes do Pulso, ocupa o campo visual de quem precisa ser convencido ou deixa de estar onde a ameaça esperava. Sua força está em alterar o que conta como próximo, exposto ou oportuno.

O Cinético não trata apenas de velocidade. Ele registra a arte de agir no intervalo curto em que posição, atenção e relação ainda podem ser rearranjadas antes que a cena se feche.

| Tier I ~ Passo Silencioso INS 2 Uma vez por cena, gaste 1 PE e receba Vantagem em Furtividade ou Acrobacia ligada a deslocamento. |
| --- |
| Tier I ~ Tempo de Reação INS 1 Receba +2 em Iniciativa. Em empate, age antes de quem não possui esta Habilidade. |
| Tier I ~ Presença Magnética PRE 2 Uma vez por cena, gaste 1 PE e acrescente 1d20 a um teste de Diplomacia, Persuasão ou Intimidação depois de rolar. |
| Tier I ~ Mãos Rápidas INS 2 Uma vez por Turno, saque, guarde, troque ou utilize um item simples como Ação Livre. Operações técnicas ou complexas ainda exigem sua ação normal. |
| Tier I ~ Impulso INS 2 Uma vez por cena, gaste 1 PE para acrescentar 3 m a uma Ação de Movimento e ignorar os primeiros 1,5 m de Terreno Difícil. |
| Tier I ~ Janela de Ação INS 2 ou PRE 2 Quando um aliado a até 6 m falhar por 1 a 4 e você puder intervir física ou socialmente, use sua Reação para acrescentar +3. Se o resultado virar sucesso, você entra na exposição ou consequência da ação. Uma vez por cena. |
| Tier II ~ Modificação ~ Furtiva INS 3, Engenharia ou Intrusão Iniciada Uma arma ou instrumento reduz drasticamente ruído, clarão e sinais de uso. Ataques ainda podem ser percebidos pelo impacto e pelo alvo. É uma Modificação de Ramo e ocupa um espaço de modificação. |
| Tier II ~ Leitura de Sala PRE 3 Uma vez por cena, teste Intuição DT 15. Em sucesso, identifique a relação de maior Tensão presente e quem tenta escondê-la. |
| Tier II ~ Esquiva Instintiva INS 3 Depois de usar Esquiva com sucesso, mova 1,5 m sem provocar Reações. |
| Tier II ~ Movimento Concluído INS 3 Uma vez por Rodada, gaste 1 PE e termine até 3 m de um deslocamento interrompido por reação, dano ou terreno. |
| Tier II ~ Disfarce Reflexivo INS 3 Pode usar INS em Encenação quando a atuação depende de postura, ritmo, respiração ou imitação física. |
| Tier II ~ Acesso de Oportunidade INS 3 Quando uma criatura a até 3 m abandonar voluntariamente uma posição, gaste 1 PE e sua Reação para ocupar o espaço deixado, movendo-se até 1,5 m sem provocar Reações. |
| Tier III ~ Sombra Viva INS 4, Furtividade Apurada Pode tentar Ocultar-se sem cobertura total quando houver distração, multidão, iluminação irregular ou arquitetura complexa. DT mínima 20. |
| Tier III ~ Voz do Povo PRE 4 Uma vez por cena, use PRE no lugar de outro Atributo em interação social, explicando como sua identidade sustenta a abordagem. |
| Tier III ~ Contra-Golpe INS 4, Luta Apurada Contra-ataques não sofrem a penalidade de -1d20. |
| Tier III ~ Ação em Passagem INS 4 Uma vez por Turno, durante seu deslocamento, abra, feche, entregue, recolha ou acione um objeto simples sem gastar ação adicional. Um mecanismo complexo ainda exige teste e ação apropriados. |
| Tier III ~ Reposição Instantânea INS 4, Reflexo Apurado Quando um aliado a até 3 m for alvo de um ataque, use sua Reação e gaste 1 PE para trocar de posição com ele antes da resolução. O ataque passa a alvejá-lo se continuar válido. |
| Tier III ~ Presença de Multidões PRE 4, Diplomacia ou Persuasão Apurada Uma ação social dirigida a uma pessoa pode alcançar um pequeno grupo coeso ao aumentar a DT em +5. Cada alvo ainda reage conforme seus próprios Vínculos e Limites. |
| Tier IV ~ Caçada sem Distância INS 5, Equilíbrio -5 ou menor Uma vez por cena, escolha uma presença percebida. Por 3 Rodadas, ignore Terreno Difícil e Reações ao mover-se em direção a ela; o primeiro ataque após mover ao menos 3 m recebe +1d20. Ao terminar, receba 1 Tensão de Medo. |
| Tier IV ~ Frequência PRE 5, Equilíbrio +5 ou maior Uma vez por cena social, 3 resultados naturais inferior a 15 em teste de PRE pode ser tratado como 15 antes de bônus. Não funciona contra manifestações sem Tessitura Social reconhecível. Receba 1 Tensão de Conhecimento. |
| Tier IV ~ Entre os Fios INS 5 Uma vez por sessão, gaste 2 PE e evite automaticamente um ataque ou efeito de Trama que pudesse perceber. Depois, receba 1 Tensão na direção da Natureza envolvida. |
| Tier IV ~ Passo Ausente INS 5 Durante uma Ação de Movimento, gaste 2 PE e atravesse espaços ocupados, Terreno Difícil e zonas de ameaça sem provocar Reações. Não permite atravessar barreiras sólidas. |
| Tier IV ~ Momento Roubado INS 5 Uma vez por sessão, depois que qualquer participante terminar o Turno, gaste 3 PE para realizar imediatamente um Turno completo. Você perde seu próximo Turno normal e não pode Preparar ou Atrasar durante o Turno roubado. |
| Tier IV ~ Centro Móvel PRE 5 ou INS 5 Uma vez por cena, por 3 Rodadas, sempre que mover ao menos 3 m escolha um aliado a até 6 m: ele move 1,5 m sem provocar Reações ou recebe +1 DEF até o início do próximo Turno. Apenas um aliado por Rodada. |

## Ramo Canalizado

O Canalizado não é uma classe de conjuradores. É o conjunto de capacidades de quem aprendeu a fazer da aproximação ao Além-Véu um procedimento repetível. Suas Habilidades tornam Tramas mais seguras, legíveis ou amplas, mas nenhuma elimina Relaxamento, Assinatura ou preço. Quanto maior o domínio técnico, mais importante se torna decidir por que determinada relação deveria ser tocada.

Forma de jogar ~ Canalizado

Um personagem Canalizado raramente resolve tudo sozinho. Precisa de quem encontre a Costura, proteja sua concentração, ofereça Fragmentos, traduza sinais e lide com aquilo que a Trama não pode escolher por ele. O Ramo aumenta o alcance. A campanha continua decidindo o sentido.

O Canalizado reúne técnicas para aproximar-se da Tessitura sem tratar proximidade como domínio. Suas Habilidades reduzem risco, ampliam controle e permitem que costuras maiores existam por tempo suficiente para adquirir consequência.

| Tier I ~ Fio Estável Canalização Iniciada Depois de falhar por até 2 num teste de Canalização de Repuxo, gaste 1 PE para transformar a falha em sucesso. A Pressão da Puxagem e qualquer custo já sofrido permanecem. |
| --- |
| Tier I ~ Reserva de Véu Canalização Iniciada Receba +2 PE permanentes. Esta Habilidade pode ser comprada apenas uma vez. |
| Tier I ~ Leitura Rápida Canalização Iniciada Com uma Ação Padrão, teste Canalização DT 12 para identificar Natureza e Domínio predominantes de um Fragmento ou Dobra visível. |
| Tier I ~ Costura Antecipada Canalização Iniciada Escolha uma Trama conhecida ao fim de um Interlúdio. Seu primeiro uso após ele reduz o custo em 1 PE. |
| Tier I ~ Ritmo de Puxagem Canalização e Temperança Iniciadas Uma vez por cena, depois de falhar no teste de Temperança da Puxagem, refaça-o e aceite o segundo resultado. |
| Tier I ~ Relaxamento Consciente Canalização e Concentração Iniciadas Ao encerrar voluntariamente uma Trama sustentada por ao menos uma Rodada, recupere 1 PE. Uma vez por cena. |
| Tier II ~ Modificação ~ Condutor de Assinatura Rank 25, Canalização Apurada e Engenharia Iniciada Durante um Interlúdio, adapte uma arma ou objeto para uma Natureza e Domínio conhecidos. Ele passa a dar mais um dado padrão de dano (do tipo do domínio). Ao usá-lo como foco de Trama compatível, reduza a DT de Canalização em 2. Apenas um Condutor seu pode estar ativo; é uma Modificação de Ramo e ocupa um espaço de modificação. |
| Tier II ~ Trama Dupla Rank 25 Pode sustentar duas Tramas simultaneamente. Pague o custo de sustentação de ambas. |
| Tier II ~ Ancoragem Pessoal Rank 25, Convicção Iniciada Durante um Interlúdio de quietude e prática, gaste 1 PE, recupere 2 PA e reduza 1 Tensão em direção a 0. Uma vez por Interlúdio. |
| Tier II ~ Tração Natural Rank 25, Canalização Apurada Depois de falhar por até 2 num teste de Canalização de Tração, gaste 2 PE para transformar a falha em sucesso. A Pressão da Puxagem e qualquer custo já sofrido permanecem. |
| Tier II ~ Assinatura Guiada Rank 25 Ao usar Fragmento compatível, a redução de DT aumenta de -2 para -3. |
| Tier II ~ Selo Portátil Rank 25, Canalização Apurada Durante 10 minutos, gaste 2 PE para preparar um objeto contra uma Assinatura conhecida. A primeira resistência do portador contra essa Assinatura recebe +3 ou reduz uma consequência Comum em um grau; depois, o Selo perde função. |
| Tier III ~ Selador Nato Rank 50, Canalização Apurada Pode liderar Selagem sem teste preliminar para compreender o procedimento. O Diagnóstico da Dobra ainda precisa ser realizado. |
| Tier III ~ Absorção de Refluxo Rank 50 Uma vez por sessão, gaste 2 PE e reduza um Refluxo em um grau: Crítico para Severo ou Severo para Comum. |
| Tier III ~ Assinatura Composta Rank 50 Ao usar Fragmentos, pode alterar a expressão de uma Trama compatível sem aumentar a DT, desde que o efeito principal permaneça. |
| Tier III ~ Tecitura Encadeada Rank 50, Canalização Apurada Depois de uma Trama bem-sucedida, a próxima Trama compatível tecida por um aliado antes do início do seu próximo Turno reduz a DT em 2. Uma vez por Rodada. |
| Tier III ~ Costura de Emergência Rank 50, Canalização Versada Como Ação Completa, gaste 2 PE e teste Canalização contra a DT da Dobra para suprimir um Pulso ou efeito territorial até o início do seu próximo Turno. Falha produz Refluxo Severo. Uma vez por cena. |
| Tier III ~ Fragmento Responsivo Rank 50 Um Fragmento preparado pode guardar duas Tramas compatíveis em vez de uma. Ativar a segunda opção reduz sua Integridade em 1 ponto adicional. |
| Tier IV ~ Mergulho no Inverso Rank 75, Canalização Versada, Equilíbrio -5 ou menor Duas vezes por cena, teça uma Trama de Medo como se tivesse uma Intensidade acima, sem aumentar custo ou DT de Canalização. A DT da Puxagem aumenta em 5; depois, receba 1 Tensão de Medo e sofra Refluxo Comum mesmo em sucesso. Estiramento não sobe para uma quarta Intensidade: em vez disso, amplia apenas um parâmetro autorizado pelo Narrador. |
| Tier IV ~ Arquivo de Fios Rank 75, Canalização Versada, Equilíbrio +5 ou maior Uma vez por cena, depois de tecer Trama de Conhecimento, preserve-a por 3 Rodadas sem pagar sustentação. O efeito ainda pode ser rompido por sua regra normal. Receba 1 Tensão de Conhecimento. |
| Tier IV ~ Tocar o Fluxo Rank 75, Equilíbrio entre -2 e +2 Pode aprender e tecer Tramas de Fluxo. A primeira exige também um acontecimento narrativo de contato temporal. |
| Tier IV ~ Estiramento Interno Rank 75, Canalização Versada Uma vez por sessão, teça Estiramento sem Fragmento, Dobra ou auxílio externo. Depois, sofra Refluxo Comum mesmo em sucesso. |
| Tier IV ~ Pacificação Rank 75 Ao concluir uma Selagem de Âncora, pode tentar transformá-la diretamente em Revérbero sem etapa adicional, se todos os Pontos de Costura essenciais tiverem sido resolvidos. |
| Tier IV ~ Mão no Retorno Rank 75 Uma vez por sessão, quando Refluxo surgir a até 6 m, use sua Reação e gaste 2 PE para tornar-se o centro da consequência. Se aceitar todos os custos diretos de PV, PS e Tensão, reduza o Refluxo em um grau; caso contrário, pode apenas redistribuí-los entre você e o alvo original. |

## Habilidades Transcendentes

Transcendentes não são compradas, nem desbloqueadas por repetir uma ação determinado número de vezes. Surgem quando um arco de experiência produz transformação irreversível. O Narrador pode conceder uma habilidade específica ou oferecer opções compatíveis com o que realmente aconteceu.

Cada Transcendente precisa de quatro elementos: um Marco, uma Capacidade, um Preço e um Sinal. O Marco explica por que ela surgiu. A Capacidade é o efeito. O Preço impede que a transformação se torne apenas recompensa. O Sinal mostra que o mundo e o personagem já não conseguem fingir que nada mudou.

*Veja mais na Expansão Transcendental.

## Construções abertas

Os quatro Ramos podem ser combinados livremente. Os exemplos abaixo mostram direções, não conjuntos obrigatórios.

| A Guardiã de Passagem Corpóreo + Cinético Protege aliados, ocupa gargalos e conclui movimentos interrompidos. Pode ter PRE alto e Convicção ligada a responsabilidade comunitária, sem ser uma combatente profissional. |
| --- |
| O Cartógrafo de Rupturas Cônscio + Canalizado Lê padrões, identifica Costuras e utiliza Tramas pequenas para testar hipóteses. Seu valor aparece antes do confronto e durante a Selagem. |
| A Mediadora de Campo Cinético + Cônscio Move-se entre grupos, percebe tensões e transforma informação em acordo ou posição tática. Pode vencer cenas sem produzir dano. |
| O Corpo de Selo Corpóreo + Canalizado Utiliza o próprio corpo como parte de Tramas, sustenta operações sob dano e protege o Relaxamento de outros canalizadores. |
| A Especialista sem Ramo dominante Habilidades distribuídas Investe mais PM em Perícias, recursos e efeitos situacionais. O sistema não exige que toda personagem complete uma árvore. |

Uma construção permanece interessante quando possui capacidades que abrem decisões e lacunas que exigem colaboração. O objetivo da progressão aberta não é remover especialização, mas permitir que ela nasça da história em vez de ser determinada por uma classe escolhida na primeira sessão.
