---
title: "Livro de Regras — CAPÍTULO A ~ REFERÊNCIA RÁPIDA"
node_type: "rule"
summary: "Seção “CAPÍTULO A ~ REFERÊNCIA RÁPIDA” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO A ~ REFERÊNCIA RÁPIDA"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO A ~ REFERÊNCIA RÁPIDA","source_order":21,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO A ~ REFERÊNCIA RÁPIDA

A mesa não deve precisar abandonar a tensão de uma cena para reconstruir uma regra espalhada por capítulos distantes.

## Teste padrão

| Passo | Procedimento |
| --- | --- |
| 1 | descreva intenção e abordagem |
| 2 | escolha Atributo e Perícia |
| 3 | calcule Pool efetivo: Atributo + Vantagens - Desvantagens; 1+ escolhe maior, 0 ou menos escolhe menor com dados adicionais |
| 4 | role o pool resultante |
| 5 | escolha o dado e some +0/+3/+6/+9 |
| 6 | compare à DT e leia margem |

## Ações de combate

| Turno | Quantidade |
| --- | --- |
| Ação Padrão | 1 |
| Ação de Movimento | 1 |
| Ação Livre | conforme razoável |
| Reação | 1 por Rodada |
| Ação Completa | consome Padrão e Movimento |
| Preparar Ação | Padrão + reserva da Reação; gatilho até o próximo Turno |
| Atrasar Ação | move o Turno para posição posterior e fixa a nova Iniciativa |

## Cenas alternativas

| Módulo | Trilha | Mudança no limite |
| --- | --- | --- |
| Perseguição | posição + 4 Pressões | rota, veículo, objetivo ou participante muda |
| Infiltração | Rastro de Exposição 0~4 | a cena vira fuga, contenção, negociação ou confronto |
| Investigação | Compasso de Urgência 3~8 | a situação avança sem apagar pistas obtidas |

## Intensidades de Trama

| Intensidade | DT | PE | Sustentação |
| --- | --- | --- | --- |
| Repuxo | 12 | 1 | 1 PE por rodada adicional |
| Tração | 16 | 2 | 1 PE por rodada adicional |
| Estiramento | 20 | 4 | 2 PE por rodada adicional |

## Pressão da Puxagem

| Intensidade | Temperança | Sucesso / Falha |
| --- | --- | --- |
| Repuxo | DT 10 | 0 / 1 PS |
| Tração | DT 15 | 1 PS / 1d4 + 1 PS |
| Estiramento | DT 20 | 2 PS / 1d6 + 2 PS |

## Equilíbrio

| Regra | Resumo |
| --- | --- |
| Escala | -10 Medo a +10 Conhecimento; 0 Inteireza |
| Tensão | 4 pontos na mesma direção movem 1 Equilíbrio |
| Limite comum | não atravessa ±5 sem fonte excepcional |
| PA | 1 ponto absorve 1 Tensão forçada |

## Selagem

Selagem não é um único ritual universal. É uma família de procedimentos que oferece ao Reflexo relações suficientes para definir borda, reduzir tensão e impedir que uma Dobra continue avançando da mesma maneira. Símbolos, instrumentos, arquitetura, palavras, testemunhas e Tramas participam conforme o fenômeno. A forma precisa corresponder à Costura; caso contrário, o Selo pode conter a pressão sem resolver a permanência.

Diagnóstico pergunta o que está acontecendo. Tecitura constrói a resposta. Fixação decide como essa resposta continuará existindo depois que os personagens partirem. Uma operação pode vencer as duas primeiras etapas e fracassar meses depois porque ninguém preservou a prática, o objeto ou a instituição responsável pela terceira.

| Fenômeno | Verbo |
| --- | --- |
| Pré-Furo | aliviar |
| Furo | fechar |
| Âncora | cercar ou pacificar |
| Zona | reconquistar |
| Revérbero | manter e compreender |
