---
title: "Livro de Regras — CAPÍTULO 1 ~ IDENTIDADE"
node_type: "rule"
summary: "Seção “CAPÍTULO 1 ~ IDENTIDADE” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 1 ~ IDENTIDADE"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 1 ~ IDENTIDADE","source_order":2,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 1 ~ IDENTIDADE

Uma ficha começa onde uma pessoa se recusa a caber completamente nos campos que a descrevem.

Antes de uma personagem possuir defesa, armas ou Tramas, ela já ocupa uma posição no mundo. Nasceu em algum lugar, aprendeu a obedecer ou desconfiar de certas instituições, tornou-se competente em coisas que talvez nunca tenham parecido heróicas e encontrou pessoas diante das quais conseguia reconhecer a própria vida. A criação começa por essas continuidades porque é delas que o horror retirará peso.

Uma ficha sem relações pode ser eficiente, mas permanece difícil de ferir de maneira significativa. Uma ficha preenchida como uma biografia exaustiva pode conter muitos fatos e ainda não dizer o que importa quando chega a hora de escolher. Identidade, neste jogo, não é quantidade de passado. É a combinação entre aquilo que sustenta alguém, aquilo que ainda dói e aquilo que essa pessoa acredita que fará quando ambos forem pressionados ao mesmo tempo.

## O papel de ser outro

Há um lugar entre o que lembramos e o que evitamos lembrar. Um espaço pequeno, anterior às explicações, onde sentimentos aparecem antes de receberem nome e pensamentos atravessam a consciência sem anunciar de onde vieram. Interpretar um personagem é caminhar por esse lugar sem confundi-lo com a própria vida.

Você escolhe alguém que existe através de suas decisões, mas não é uma extensão automática de você. Decide o que essa pessoa teme, o que procura, que relações a sustentam e quais verdades seriam difíceis demais para permanecerem apenas como informação. Em Tessitura do Vazio, essas escolhas não servem apenas à caracterização. Elas indicam quais fios o mundo poderá pressionar.

Um personagem não nasce das capacidades que possui. Nasce das perguntas que carrega. Os números entram depois, quando já existe alguma coisa que valha a pena traduzir em regra.

## Os sete elementos da identidade

Os sete elementos abaixo não são departamentos separados da personalidade. Eles se atravessam. Uma Ocupação pode ter produzido uma Convicção; uma Ferida pode ter transformado o sentido do Nome; a Marca pode ter ocorrido justamente porque um Limite foi quebrado por outra pessoa. Ao preenchê-los, procure relações entre as respostas. Quanto mais elas conversarem, menos o Narrador precisará inventar motivos externos para envolver o personagem.

Convicção e Limite

Convicção é a relação que o personagem deseja sustentar. Não precisa ser uma frase grandiosa. “Ninguém deve morrer sozinho”, “conhecimento precisa circular” ou “minha família não será novamente expulsa” já oferecem direção suficiente. Uma Convicção pode estar errada, incompleta ou tornar-se cruel quando preservada sem medida. Ela é força porque orienta; não porque o jogo garante que seja moralmente correta.

Limite é a forma que o personagem acredita que jamais aceitará para si. Ele não existe para o Narrador procurar a primeira oportunidade de quebrá-lo. Existe para que, quando a história realmente o pressione, todos saibam o tamanho da decisão. Atravessar um Limite deve produzir transformação. Mantê-lo também pode exigir preço.

Ferida

Ferida é uma relação interrompida que ainda organiza escolhas. Perda, culpa e fracasso são formas evidentes, mas não as únicas. Uma ambição nunca reconhecida, um pertencimento negado ou uma promessa que continua sendo cumprida por alguém que já não acredita nela também podem funcionar como Ferida. Ela não precisa ser resolvida para que o personagem melhore. Algumas Feridas tornam-se parte da forma pela qual alguém aprende a cuidar sem fingir que nada aconteceu.

| Elemento | Pergunta |
| --- | --- |
| Nome | Como o mundo chama esta pessoa, e o que esse nome permite reconhecer? |
| Origem | De que território, classe, cultura, instituição ou experiência ela veio? |
| Ocupação | O que fazia quando a história ainda não exigia heroísmo, segredo ou violência? |
| Convicção | O que acredita que precisa ser preservado, mesmo quando preservar possui um custo? |
| Limite | O que acredita que jamais faria? Um Limite é uma promessa sobre si, não uma garantia. |
| Ferida | Que relação não encontrou forma de continuar? Pode ser perda, culpa, ausência, fracasso ou desejo. |
| Marca | Quando o mundo mostrou seus rasgos e tornou impossível voltar à ignorância anterior? |

A Marca

A Marca é o primeiro momento em que a realidade deixou de cumprir perfeitamente a relação que deveria sustentá-la. Não precisa ter sido uma criatura, um Furo aberto ou uma visão completa. Pode ter sido uma lembrança compartilhada por quem nunca esteve presente, um instrumento que respondeu a um nome, uma pessoa ausente de todos os registros ou uma explicação natural cuja verdade não eliminou aquilo que permanecia errado.

A Marca não oferece conhecimento gratuito. Ela oferece uma direção. É uma cicatriz sem obrigação de revelar o ferimento inteiro.

| EXEMPLOS DE MARCA “Durante três noites, a estação pneumática repetiu a voz de alguém morto antes de ser construída.” “Um médico devolveu minha respiração, mas desde então outra pessoa se lembra do momento em meu lugar.” “Eu vi uma rua inteira continuar existindo no reflexo de uma vitrine depois que virei a esquina.” |
| --- |

## Vínculos iniciais

Escolha dois Vínculos. Um Vínculo pode ser uma pessoa, comunidade, lugar, instituição, causa, ofício ou memória compartilhada. Ele não é apenas algo de que o personagem gosta. É uma relação à qual consegue retornar quando outras partes de si deixam de concordar.

| Estado do Vínculo | Significado |
| --- | --- |
| Presente | A relação existe e pode oferecer apoio, informação, cuidado ou Ancoragem. |
| Tensionado | Algo impede que a relação funcione com a confiança anterior. |
| Ferido | A relação sofreu dano concreto e exige ação para não se romper. |
| Rompido | A continuidade foi perdida. Ainda pode deixar consequências, mas já não oferece seus benefícios. |
| Costurado | A relação foi reconstruída depois de uma ruptura e carrega uma forma nova, nunca idêntica à anterior. |

## Ciclo de vida

Idade influencia experiência, corpo, autoridade e responsabilidade, mas não determina proibições automáticas. Pessoas da mesma idade podem ter histórias físicas, sociais e intelectuais completamente diferentes. Em vez de receber penalidades fixas, cada personagem escolhe um Traço de Ciclo de Vida que represente aquilo que o tempo já lhe ofereceu e aquilo que passou a exigir.

| Traço | Benefício | Implicação |
| --- | --- | --- |
| Formação recente | Começa Iniciado numa Perícia adicional ligada ao estudo ou ofício atual. | Sua experiência prática ainda pode ser limitada fora desse campo. |
| Corpo habituado | Uma vez por cena, ignore uma penalidade de Carga ou esforço por um teste. | O hábito veio de rotina, trabalho ou treinamento que também deixou marcas. |
| Nome reconhecido | Escolha uma rede social ou profissional na qual sua identidade abre portas. | O mesmo nome cria expectativas, deveres e pessoas capazes de encontrá-lo. |
| Experiência acumulada | Uma vez por sessão, declare ter encontrado situação semelhante e receba uma pista contextual. | A semelhança nunca significa repetição perfeita. |
| Responsabilidades | Começa com um Vínculo adicional. | O Vínculo exige tempo, cuidado ou recursos entre missões. |
| Cicatriz antiga | Escolha uma condição física ou mental leve que aprendeu a administrar; a primeira aplicação por sessão não progride. | Ela continua existindo e pode reaparecer em cenas apropriadas. |

## Sequência de criação

Uma personagem em construção

“Iria cresceu em Kitomena e trabalha na inspeção de cristais empregados em sistemas ópticos. Sua Convicção é que toda descoberta capaz de afetar uma comunidade deve ser explicada à própria comunidade. Seu Limite é falsificar um laudo. A Ferida vem de um acidente que matou uma colega e foi registrado como falha humana. Sua Marca ocorreu quando encontrou, no cristal partido da estação, a voz da colega descrevendo o acidente antes que ele acontecesse.” 
Nenhum desses elementos determina uma classe. Juntos, porém, já explicam por que Iria investigará, que instituições poderão pressioná-la e que tipo de verdade terá preço pessoal.

Ao terminar a sequência de criação, leia a ficha como um pequeno sistema. Pergunte onde há contradições produtivas: uma pessoa que valoriza a verdade, mas depende de uma instituição que vive de sigilo; alguém que nunca abandonaria a família, mas escolheu uma Ocupação que o mantém longe; uma personagem cuja Marca parece confirmar exatamente aquilo que sua formação ensinou a rejeitar. Essas tensões não são defeitos. São lugares onde a campanha poderá crescer.

1 ~ Defina Nome, Origem, Ocupação, Convicção, Limite, Ferida e Marca.

2 ~ Escolha dois Vínculos e um Traço de Ciclo de Vida.

3 ~ Distribua os Atributos.

4 ~ Escolha sete graus iniciais de Perícia. Uma mesma Perícia pode receber dois graus na criação, tornando-se Apurada. Esta é uma exceção apenas ao requisito de Rank de Apurado; Versado nunca pode ser obtido na criação.

5 ~ Escolha duas Habilidades de Tier I gratuitamente. Elas não consomem PM e precisam cumprir seus demais requisitos.

6 ~ Registre Proficiência I universal e uma Proficiência II coerente com a Ocupação.

7 ~ Calcule PV, PS, PE, PA, DEF, Deslocamento e Capacidade de Carga.

8 ~ Registre o pacote inicial de equipamentos e as Tramas liberadas pelo início da campanha.

9 ~ Escreva uma Pergunta: aquilo que o personagem ainda precisa descobrir para compreender a própria Marca ou a Ferida que carrega.

| A FICHA NÃO ENCERRA A PESSOA Campos de identidade podem mudar durante a campanha. Convicções podem amadurecer ou quebrar. Limites podem ser atravessados. Vínculos podem ser feridos e costurados. Quando isso acontecer, apenas atualize a ficha. A regra deve registrar a transformação, e não impedir que ela exista. |
| --- |

## Exemplo completo de identidade

Iria Nemez será usada em diferentes capítulos porque uma regra se torna mais clara quando permanece ligada à mesma pessoa. Ela nasceu numa comunidade de mineração e pesquisa em Kitomena, onde cristais de uso óptico são extraídos sob protocolos rígidos. Sua Ocupação é inspetora de integridade mineral. O trabalho exige que reconheça fraturas, acompanhe transporte e decida quando uma peça aparentemente valiosa é perigosa demais para permanecer em circulação.

Sua Convicção afirma que toda descoberta capaz de alterar a vida de uma comunidade precisa ser explicada à comunidade. Seu Limite é falsificar um laudo. A Ferida veio da morte de Rema, colega e mentora, num acidente atribuído oficialmente a um erro de procedimento. A Marca ocorreu semanas depois: Iria ouviu, dentro de uma lâmina rachada do mesmo lote, a voz de Rema descrevendo o acidente e como se antes do momento em que ele aconteceu.

Os Vínculos iniciais são a Cooperativa de Extração, ainda Presente, e Dalen, irmão de Rema, atualmente Tensionado. A Cooperativa oferece acesso, linguagem técnica e pessoas que conhecem Iria. Dalen oferece memória compartilhada e uma cobrança que ela não consegue tratar como injusta. O Traço de Ciclo de Vida é Formação recente, ligado à Engenharia. Sua Pergunta é curta: quem sabia que o cristal conseguia guardar acontecimentos ainda não ocorridos?

| O QUE A FICHA JÁ OFERECE A campanha pode pressionar a relação entre verdade e responsabilidade, usar a Cooperativa como apoio ou obstáculo, transformar Dalen em aliado ou acusador e ligar a Marca a Fluxo, Memória ou fraude institucional. Nenhuma dessas possibilidades precisou ser adicionada depois dos números. |
| --- |
