---
title: "Livro de Regras — CAPÍTULO 11 ~ CONDIÇÕES, MORTE E COLAPSO"
node_type: "rule"
summary: "Seção “CAPÍTULO 11 ~ CONDIÇÕES, MORTE E COLAPSO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 11 ~ CONDIÇÕES, MORTE E COLAPSO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 11 ~ CONDIÇÕES, MORTE E COLAPSO","source_order":12,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 11 ~ CONDIÇÕES, MORTE E COLAPSO

Uma condição não é um adjetivo. É uma mudança concreta no que o personagem consegue fazer e no preço de continuar.

Condições existem para que ferimentos, exaustão e alterações do Além-Véu mudem a forma de agir antes que um recurso chegue a zero. Elas devem produzir decisões reconhecíveis. Se duas condições apenas removem o mesmo dado sem mudar as escolhas, provavelmente podem ser reunidas. Se uma condição não interfere em nada que ocorrerá na cena, pode permanecer apenas na descrição.

Aqui Sanidade não significa normalidade, inteligência, moralidade ou ausência de transtorno. Mede a concordância funcional entre percepção, memória, corpo e identidade. Uma pessoa pode conviver com sofrimento psíquico e possuir PS completos; outra pode parecer calma enquanto uma manifestação reorganiza silenciosamente aquilo que reconhece como próprio.

## Aplicação e progressão

Condições leves normalmente progridem quando reaplicadas antes de serem removidas. Quando a mesma fonte produz efeito mais grave, a regra pode aplicar diretamente o estágio superior. Vantagem e Desvantagem por condições seguem o limite geral: múltiplas fontes iguais não acrescentam dados indefinidamente, mas podem produzir progressão.

## Condições físicas

| Condição | Efeito | Progressão ou remoção |
| --- | --- | --- |
| Machucado | -1d20 em ações de COR dependentes da região ferida. | Nova aplicação relevante torna Ferido; cuidado ou Interlúdio remove. |
| Ferido | -2d20 em ações de COR e INS (ou demais relacionadas ao físico); Deslocamento -2 m. | Nova aplicação torna Incapacitado; exige Medicina e repouso adequado. |
| Incapacitado | Apenas Ação Padrão ou Movimento, não ambas; quaisquer ações físicas recebem Desvantagem. | Dano grave ou nova progressão leva a Morrendo. |
| Caído | -2 DEF contra corpo a corpo; ataques de projeção distantes recebem Desvantagem. | Ação de Movimento para levantar. |
| Agarrado | Deslocamento 0; ações físicas que exigem liberdade recebem Desvantagem. | Vencer teste contestado ou libertação externa. |
| Sangrando | Perde 1d6 PV no início do Turno. | Medicina ou Fortitude DT 18 com instrumento adequado. |
| Em Chamas | Perde 1d6 PV no início do Turno e ilumina o entorno. | Ação Padrão, água, manta ou efeito apropriado. |
| Atordoado | Perde Reação e recebe Desvantagem geral até o fim do próximo Turno. | Termina automaticamente, salvo reaplicação. |
| Envenenado | -1d20 em COR e MEN; efeitos adicionais dependem da substância. | Tratamento, antídoto ou duração da fonte. |
| Inconsciente | Não age, não reage e falha testes físicos de defesa. | Causa definida, cuidado ou tempo. |
| Cego | Ações puramente visuais falham; não pode Mirar; ataques e testes que dependam principalmente de visão usam Pool efetivo -2. | Restaurar visão, remover a fonte ou adaptar a ação por outro sentido. |
| Surdo | Ações puramente auditivas falham; Percepção por som usa Pool efetivo -2; não recebe instruções verbais nem reage a gatilhos apenas sonoros. | Restaurar audição, remover a fonte ou estabelecer comunicação visual, tátil ou Tessitural. |
| Doente | Pool efetivo -1 em Fortitude e esforços físicos prolongados. Recuperações adicionais de PV, PS e PE concedidas por Atividades são reduzidas à metade. | Tratamento, fim da incubação ou superação da Progressão da doença. Nova aplicação pode impor Fadigado ou efeito específico. |

## Condições mentais e relacionais

| Condição | Efeito | Progressão ou remoção |
| --- | --- | --- |
| Abalado | -1d20 em MEN e PRE. | Nova aplicação torna Apavorado; segurança, Convicção ou fim da fonte. |
| Apavorado | -2d20 em MEN e PRE; deve afastar-se, esconder-se ou gastar Ação para resistir com Convicção. | Nova aplicação pode provocar Colapso. |
| Confuso | No início do Turno, teste Temperança DT indicada; falha impede distinguir prioridade, alvo ou direção com clareza. | Nova orientação, fim da fonte ou sucesso. |
| Compelido | Uma ação ou proibição específica pressiona o personagem. | Pode resistir quando pagar preço ou quando Convicção/Costura for ativada. |
| Silenciado | Não consegue usar fala ou linguagem definida pela fonte. | Fim da duração, alteração da condição ou nomeação correta. |
| Desorientado | Não recebe benefícios de cobertura, flanco ou direção; testes de Sobrevivência, Condução ou Percepção que dependam de orientação recebem Desvantagem. | Reconhecer referência, receber ajuda ou sair da região que causa a condição. |

## Condições energéticas e metafísicas

| Condição | Efeito | Progressão ou remoção |
| --- | --- | --- |
| Fadigado | Perícias de Carga recebem Desvantagem; Deslocamento pela metade. | Nova aplicação torna Esgotado; requer repouso, alimento e cuidado. |
| Esgotado | Não pode gastar PE voluntariamente; Desvantagem em todos os testes físicos. | Recuperar ao menos 1 PE e concluir descanso. |
| Saturado | Canalização recebe +2 DT e qualquer falha produz ao menos Refluxo Comum. | Relaxamento, PA, Selagem ou Interlúdio. |
| Instável | A primeira Trama, Fragmento ou Pulso que o tocar na cena recebe intensidade narrativa ampliada. | Remover fonte ou estabilização. |
| Descompassado | Sem Reação; em ações de agilidade ou reação, use o menor d20 do pool. | Referência temporal, repetição orientada, Trama ou fim da duração. |

## Morrendo e Marcas da Morte

Ao chegar a 0 PV, o personagem entra em Morrendo, cai e recebe uma Marca da Morte. No início de cada Turno, teste Fortitude DT 15. Sucesso mantém o estado; falha recebe outra Marca. Dano enquanto Morrendo concede uma Marca adicional; crítico concede duas.

Com três Marcas da Morte, o personagem morre. Estabilizar exige Medicina DT 15 e uma Ação Padrão com meios adequados. Em sucesso, ele permanece inconsciente em 0 PV e não realiza novos testes. Cura que a leve acima de 0 encerra Morrendo, mas não remove Marcas imediatamente.

Marcas da Morte são removidas por tratamento e Interlúdio: uma por Interlúdio adequado, ou todas após recuperação prolongada definida pela campanha. O Narrador pode associar cicatriz, limitação ou consequência a uma morte evitada por margem mínima.

## Colapso e Marcas da Loucura

Chegar a 0 PS precisa ser tão grave quanto perder toda a Vitalidade porque revela que o personagem já não consegue integrar a experiência que o atravessou. Colapso não diagnostica uma doença e não transforma sofrimento real em tabela de punição. Ele cria uma ruptura ligada à Natureza, Assinatura e cena que causaram a perda.

A Marca da Loucura permanece porque algo da ruptura encontrou continuidade. Ela deve possuir Gatilho, Manifestação e Resíduo. O Gatilho indica quando a cicatriz pode voltar a pressionar. A Manifestação descreve o que acontece durante sua ativação. O Resíduo registra a mudança persistente que o jogador incorporará à interpretação. Jogador e Narrador escolhem juntos, preservando consequência sem retirar autoria sobre o personagem.

Marca da Loucura ~ Palavra sem origem

Depois de um Colapso provocado por Linguagem, o personagem recebe uma Marca cujo Gatilho é ouvir o próprio nome pronunciado por alguém que não consegue ver. Quando ativada, todas as frases lhe parecem continuações de uma conversa anterior. O Resíduo é simples: ela já não consegue escrever o próprio nome sem copiar a grafia de outra pessoa. A Marca não imita um diagnóstico. Conserva a forma específica da ruptura.

Ao chegar a 0 PS, o personagem entra em Colapso e recebe uma Marca da Loucura. O Colapso acontece quando percepção, memória, corpo e identidade deixam de concordar o bastante para sustentar uma  ação comum.

Cada Marca possui Gatilho, Manifestação e Resíduo. O Jogador participa da escolha, orientado pela Natureza, Assinatura ou acontecimento que causou o Colapso. A Marca deve criar consequências jogáveis sem transformar transtornos reais em punições aleatórias.

| Origem | Exemplos de Manifestação | Exemplos de Resíduo |
| --- | --- | --- |
| Eclis | O corpo repete ferida, dor ou crescimento que não está presente. | Uma parte do corpo reage antes da intenção. |
| Morae | Uma memória deixa de possuir autoria clara; um rosto conhecido parece pertencer a outra história. | Certos nomes exigem teste para serem ligados à pessoa correta. |
| Thyren | Algo próximo deixa de ser percebido enquanto o personagem tenta observá-lo. | Ausências específicas tornam-se mais fáceis de sentir que presenças. |
| Zha’el | A personagem recebe julgamento impossível de ignorar. | Determinada escolha passa a carregar custo de PS quando contradita. |
| Memória | Uma cena passada sobrepõe-se ao presente. | Uma lembrança só pode ser acessada por objeto, lugar ou testemunha. |
| Linguagem | Palavras mudam de sentido ou desaparecem. | Uma verdade precisa ser dita numa forma específica. |
| Alma | Vínculos se tornam peso físico ou distância intolerável. | Isolamento prolongado reduz recuperação de PS. |
| Fluxo | A ação presente parece já ter acontecido ou ainda não ter começado. | Relógios, sequências ou rotinas podem reativar o Gatilho. |

## Perdição

A terceira Marca da Loucura leva à Perdição. O personagem ultrapassa a capacidade comum de permanecer jogável sem uma resolução específica. Isso não exige morte automática. Pode significar afastamento, contenção, transformação, integração excepcional ou retorno futuro profundamente alterado.

Antes da terceira Marca, Narrador e Jogador devem conversar sobre que desfechos seriam adequados. Perdição é uma consequência maior da campanha, e mesmo que inesperada não deveria ser usada para arrancar o controle de uma pessoa no meio da sessão.

## Recuperação de PS

PS é recuperado por Interlúdios, segurança, cuidado, compreensão e reconexão. Recuperar PS não remove Marcas. Uma Marca pode ser integrada, transformada ou ter seu Gatilho alterado por arco narrativo, mas não desaparece apenas porque a reserva retornou ao máximo.

## Condições como linguagem de consequência

Uma condição deve responder a três perguntas: o que mudou, que decisão agora ficou mais difícil e como o personagem pode alterar esse estado. Atordoado muda disponibilidade de ações; Sangrando transforma o tempo em dano; Descompassado torna a sequência incerta. Quando a condição só repete um modificador já presente, reúna os efeitos e preserve o nome que melhor descreve a ficção.

Marcas da Morte e da Loucura são diferentes de condições porque permanecem além da cena. Elas registram proximidade de um limite e exigem cuidado prolongado, transformação ou conclusão. Um personagem pode recuperar todos os PV e ainda carregar uma Marca da Morte; pode recuperar PS e continuar vivendo com a relação alterada pela Marca da Loucura.

Perdição após a terceira Marca da Loucura não precisa retirar o personagem sem conversa. Ela indica que a continuidade anterior deixou de ser suficiente para mantê-lo jogável nas mesmas condições. O grupo decide uma conclusão: afastamento, contenção, integração extraordinária, transformação em NPC ou retorno futuro por um procedimento raro. A terceira Marca sempre muda o estatuto do personagem.
