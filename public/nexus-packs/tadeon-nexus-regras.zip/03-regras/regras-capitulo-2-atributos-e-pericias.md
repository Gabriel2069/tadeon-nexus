---
title: "Livro de Regras — CAPÍTULO 2 ~ ATRIBUTOS E PERÍCIAS"
node_type: "rule"
summary: "Seção “CAPÍTULO 2 ~ ATRIBUTOS E PERÍCIAS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 2 ~ ATRIBUTOS E PERÍCIAS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 2 ~ ATRIBUTOS E PERÍCIAS","source_order":3,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 2 ~ ATRIBUTOS E PERÍCIAS

A Perícia diz o campo da ação. O Atributo revela de que maneira o personagem tenta atravessá-lo.

O sistema separa capacidade ampla e prática específica porque pessoas não chegam ao mesmo resultado pelo mesmo caminho. Atributos oferecem força à abordagem; Perícias oferecem vocabulário, hábito e método. A combinação entre ambos deve descrever a ação antes de calcular sua chance.

Essa liberdade não significa que qualquer Atributo possa ser utilizado apenas porque possui um valor maior. A abordagem precisa mudar a ficção. Pontaria com Instinto é um disparo tomado no instante em que o alvo aparece; com Mente, uma mira sustentada; com Erudição, cálculo de distância e instrumento; com Corpo, controle de uma arma cuja tensão ou peso constitui o principal obstáculo. Se o modo de agir não mudou, o Atributo também não mudou.

## Atributos

Atributos representam capacidades amplas. Nenhum deles pertence exclusivamente a uma Natureza primordial. Corpo não é Medo em miniatura; Erudição não é Conhecimento puro. Cada capacidade humana existe porque limite, reconhecimento e passagem do tempo permanecem organizados na mesma pessoa.

| Atributo | Sigla | O que representa |
| --- | --- | --- |
| Corpo | COR | Força, vigor, coordenação ampla, resistência física e capacidade de impor ou suportar impacto. |
| Mente | MEN | Atenção, disciplina, planejamento, estabilidade de raciocínio e continuidade sob pressão. |
| Instinto | INS | Percepção imediata, reflexo, leitura de risco, adaptação e resposta anterior à formulação consciente. |
| Presença | PRE | Coerência entre identidade, intenção e mundo; influência, postura, vínculo e capacidade de sustentar uma escolha. |
| Erudição | ERU | Conhecimento aprendido, repertório cultural e técnico, experiência organizada e capacidade de interpretar estruturas acumuladas. |

Todos os Atributos começam em 1. Distribua quatro pontos adicionais. O máximo inicial é 3. Você pode reduzir um único Atributo a 0 para receber um ponto adicional; isso representa uma limitação verdadeira, não apenas uma maneira eficiente de obter outro valor alto.

Corpo ~ ocupar e suportar

Corpo mede potência e permanência física, mas não é um catálogo de músculos. Um valor alto pode representar treinamento, adaptação a trabalho pesado, coordenação cultivada, resistência à privação ou um corpo extraordinariamente eficiente em transformar esforço em movimento. Um valor baixo pode nascer de doença, falta de treino, limitação, desgaste ou simplesmente de uma vida construída em torno de outras capacidades.

Mente ~ sustentar uma forma de pensar

Mente representa atenção, disciplina e organização sob pressão. Não indica inteligência absoluta. Uma pessoa brilhante pode possuir Mente baixa se perde o fio diante de conflito; alguém de educação limitada pode possuir Mente elevada porque aprendeu a manter sequência em condições que destruiriam o foco de outros. Mente é a capacidade de continuar pensando de uma maneira escolhida quando a cena tenta impor outra.

Instinto ~ perceber antes da frase

Instinto trabalha no intervalo anterior à explicação. Reconhece mudança de ritmo, perigo, intenção e oportunidade. Não é irracionalidade, e sim conhecimento incorporado que ainda não precisou tornar-se discurso. Um cirurgião experiente, uma navegadora e um animal de caça podem demonstrar Instinto elevado por razões completamente diferentes.

Presença ~ permanecer reconhecível

Presença não se resume a carisma. Ela mede quanta intenção, identidade e mundo conseguem alinhar-se numa ação. Pode aparecer como autoridade silenciosa, fé, capacidade de acolher, obstinação ou habilidade de fazer outras pessoas acreditarem que determinada relação ainda vale a pena. Alguém desagradável pode ter Presença alta. Alguém amado por todos pode possuir Presença baixa quando precisa sustentar uma escolha própria.

Erudição ~ organizar aquilo que foi recebido

Erudição registra conhecimento aprendido, experiência tornada método e capacidade de utilizar sistemas acumulados por outras pessoas. Livros são uma fonte, não a única. Oficinas, rotas, tradições orais, arquivos, observatórios, hospitais e anos de prática também constroem Erudição. Ela não é o Conhecimento primordial reduzido à escala humana; é a maneira humana de conservar e transmitir compreensão.

| ATRIBUTO 0 E POOL NEGATIVO Pool efetivo = Atributo + Vantagens - Desvantagens. Resultado 1 ou + escolhe o maior; 0 usa 2d20 menor; -1 usa 3d20 menor; -2 usa 4d20 menor, e assim por diante. |
| --- |

## Perícias

Uma Perícia não pretende listar tudo que uma pessoa sabe fazer. Ela reúne ações que compartilham método suficiente para serem aprendidas juntas. Quando duas Perícias parecem caber na mesma situação, a intenção e o risco determinam a escolha. Investigar uma oficina procura relações entre pistas; Engenharia procura compreender ou corrigir o mecanismo. Intuição percebe que alguém evita uma resposta; Diplomacia tenta construir um acordo a partir disso.

As descrições a seguir incluem diferentes Atributos porque o jogo deseja que a abordagem seja visível. O Narrador não precisa exigir uma justificativa longa em toda rolagem. Na maior parte do tempo, a combinação é evidente. A explicação torna-se importante quando altera uma consequência, informação obtida ou modo pelo qual outras pessoas perceberão a ação.

Perícias representam treinamento, prática e familiaridade com um campo de ação. Elas não possuem Atributo fixo. O Narrador escolhe o Atributo que melhor representa a abordagem descrita, ou aceita a combinação proposta pelo Jogador quando ela realmente altera a maneira de agir.

| Grau | Bônus | Sentido |
| --- | --- | --- |
| Sem treino | +0 | A personagem depende apenas do Atributo e das circunstâncias. |
| Iniciado | +3 | Possui prática básica e vocabulário suficiente para agir com método; o treinamento já altera de forma perceptível a chance de sucesso. |
| Apurado | +6 | Age com regularidade, reconhece erros comuns e adapta procedimentos mesmo sob pressão. |
| Versado | +9 | Domínio profundo, experiência extensa e capacidade de operar em condições incomuns sem tornar desafios extremos automáticos. |

Como o Atributo pode mudar conforme a abordagem, o bônus da Perícia representa aquilo que permanece: método, hábito, vocabulário e experiência. Iniciado, Apurado e Versado usam +3, +6 e +9. Versado é o maior grau geral; domínio além dele aparece por Especializações, Habilidades, equipamento, preparação e autoridade narrativa, não por um quarto bônus universal.

Perícias marcadas como Treinadas exigem ao menos o grau Iniciado para usos técnicos, profissionais ou perigosos. Sem treino, ainda podem ser tentadas quando a ação é plausível, mas o teste recebe Desvantagem ou produz resultados limitados. Perícias marcadas como Carga sofrem Desvantagem quando equipamento, armadura, terreno ou condição tornam o movimento relevante mais difícil.

| Acrobacia Carga Equilíbrio, quedas, saltos precisos, travessias estreitas e controle fino do corpo. COR para sustentar o próprio peso; INS para reagir a uma superfície que cede; MEN para repetir uma sequência ensaiada. | Adestramento Treinada Cuidar, conduzir e interpretar animais ou organismos domesticados. PRE para construir confiança; INS para ler comportamento; ERU para aplicar conhecimento de espécie. |
| --- | --- |
| Artes Treinada Criar, executar, interpretar e analisar obras artísticas. PRE para comunicar ou conduzir apresentação; MEN para compor e estruturar; ERU para reconhecer escola, técnica e contexto; INS para improvisar; COR para dança, escultura ou instrumentos fisicamente exigentes. | Atletismo Carga Corrida, natação, escalada, salto de distância e esforço físico prolongado. COR para potência; MEN para manter ritmo; INS para adaptar movimento a terreno instável. |
| Canalização Treinada Perceber, aproximar, tracionar e tecer fios da Tessitura. MEN para controle; INS para seguir um padrão sentido; PRE para sustentar a costura por identidade; ERU para reproduzir estrutura estudada. | Ciências Treinada Biologia, química, física, geologia, astronomia e métodos de observação. ERU para conhecimento formal; MEN para modelar um problema; INS para reconhecer anomalias em campo. |
| Concentração — Manter foco, sustentar Tramas e continuar uma ação sob distração ou dor. MEN na maioria dos casos; PRE quando o foco depende de Convicção; COR contra interferência física. | Condução Treinada Operar veículos terrestres, aquáticos, aéreos ou mecanismos de transporte e orientar percursos quando o deslocamento depende deles. INS em reação rápida; ERU para sistemas, cartas e instrumentos; MEN em rota prolongada ou procedimento preciso. |
| Convicção — Sustentar fé, propósito, identidade e decisões quando a pressão tenta reduzir tudo a impulso ou cálculo. PRE para permanecer reconhecível; MEN para formular razões; COR para suportar uma decisão no corpo. | Diplomacia — Negociar, criar confiança, mediar interesses e formular acordos. PRE para relação direta; ERU para protocolo e lei; MEN para estruturar concessões. |
| Encenação — Representar papéis, disfarçar intenção, imitar comportamento e sustentar uma identidade apresentada. PRE para presença; MEN para consistência; INS para adaptar a atuação às reações alheias. | Engenharia Treinada Construir, reparar e compreender sistemas mecânicos, pneumáticos, ópticos, hidráulicos e energéticos. ERU para projeto; MEN para diagnóstico; COR para trabalho pesado; INS para reparo emergencial. |
| Fortitude — Resistir a dor, doença, veneno, exaustão, temperatura, privação e impacto. COR como padrão; MEN quando a resistência depende de disciplina; PRE quando uma promessa impede a rendição. O Bloqueio automático exige Fortitude Iniciada. | Furtividade Carga Mover-se, observar ou ocultar-se sem ser percebido. INS para timing; COR para controle físico; MEN para planejar rota; PRE para misturar-se socialmente. |
| Iniciativa — Perceber o instante em que uma situação se transforma em conflito e agir antes que se feche. INS como padrão; MEN em emboscada prevista; PRE quando a ação nasce de comando ou decisão. | Intimidação — Impor custo, ameaça ou inevitabilidade à escolha de alguém. PRE por domínio; COR por ameaça física; ERU ao demonstrar conhecimento capaz de causar consequências. |
| Intuição — Ler tensões, intenções e relações antes que possam ser provadas. INS como padrão; PRE para vínculos; MEN para incoerências de comportamento. | Investigação — Procurar, relacionar e testar pistas, reconstruindo o que aconteceu e o que permanece ativo. MEN para análise; INS para leitura de cena; ERU para contexto técnico; PRE para compreender significado humano. |
| Intrusão Treinada Abrir fechaduras, contornar segurança, falsificar acesso e operar redes ilícitas. ERU para mecanismos; INS para oportunidade; PRE para obter acesso social; MEN para planejar uma entrada. | Lógica — Dedução, cálculo, estruturas abstratas e solução formal de problemas. MEN como padrão; ERU quando depende de conhecimento acumulado. |
| Luta Carga Combate corpo a corpo, agarrões, aparos e manobras ofensivas. COR para potência; INS para velocidade; MEN para técnica; PRE para manter posição sob medo. | Medicina Treinada Diagnóstico, estabilização, cirurgia, tratamento e cuidado continuado. ERU para conhecimento; MEN para procedimento; INS para emergência; PRE para cuidado e cooperação do paciente. |
| Percepção — Notar detalhes, movimento, som, presença e alteração sensorial. INS como padrão; MEN para vigilância prolongada; ERU para reconhecer um sinal técnico. | Persuasão — Convencer por argumento, emoção, exemplo ou promessa. PRE como padrão; MEN por raciocínio; ERU por autoridade técnica; INS para escolher o momento correto. |
| Pontaria Treinada Alinhar, disparar e controlar armas ou instrumentos de projeção. INS para disparo reflexivo; MEN para mira sustentada; ERU para trajetória; COR para controlar tensão, peso ou recuo. | Reflexo Carga Esquivar, aparar, agarrar algo em queda e responder a perigo imediato. INS como padrão; COR quando a resposta exige potência; MEN quando foi treinada como sequência. |
| Sociedade — Costumes, política, comércio, instituições, etiqueta, rumores e redes contemporâneas de Arden. ERU para conhecimento; PRE para circulação; INS para perceber hierarquias em funcionamento. | Sobrevivência — Rastrear, orientar-se pelo ambiente, obter abrigo, alimento e água e atravessar regiões hostis. INS para leitura do terreno e direção; ERU para técnica e cartografia aplicada; COR para esforço; MEN para planejamento de rota. |
| Tática — Coordenar pessoas, espaço, tempo e recursos em conflito ou operação. MEN como padrão; PRE para comando; ERU para doutrina; INS para adaptação imediata. | Temperança — Resistir à coerção, intrusão mental, compulsão e interferência metafísica. MEN para controle; PRE para identidade. |

## Temperança e Convicção

Temperança resiste ao que tenta entrar, interferir, compulsar ou desorganizar. Convicção sustenta uma relação escolhida quando a pressão tenta fazê-la deixar de importar.

Convicção só substitui Temperança quando o Jogador nomeia a Convicção, o Vínculo, a promessa ou a identidade usada como Ancoragem. Sem essa relação concreta, use Temperança. A distinção impede que Convicção seja apenas uma segunda Temperança com outro Atributo e faz a resistência deixar um rastro narrativo reconhecível.

| A COMBINAÇÃO PRECISA MUDAR A FICÇÃO Trocar o Atributo apenas para usar o maior valor não é “só uma abordagem diferente”. O Jogador precisa explicar o que faz de outra maneira e aceitar as consequências próprias dessa maneira. Uma intimidação por COR deixa um rastro diferente de uma intimidação por ERU. |
| --- |

A mesma porta, quatro personagens

Uma porta de oficina foi fechada depois do desaparecimento de sua proprietária. ERU + Intrusão desmonta a fechadura e pode deixar sinais técnicos. INS + Intrusão espera o instante em que a patrulha muda de direção e explora uma falha simples. PRE + Intrusão convence um aprendiz de que abrir a porta é a única maneira de proteger a mestra. COR + Intrusão força dobradiças antigas e transforma discrição em urgência. Todas as abordagens podem permitir a entrada. Nenhuma produz a mesma cena.

Especializações podem ser registradas livremente quando ajudam a definir experiência: Medicina ~ trauma, Engenharia ~ pneumática, Sociedade ~ Concordância, Artes ~ música litúrgica, Condução ~ navegação marítima ou Sobrevivência ~ em montanhas. Elas não acrescentam bônus por padrão, mas oferecem autoridade narrativa para reconhecer procedimentos, reduzir tempo ou evitar testes em situações rotineiras. Habilidades e equipamentos podem transformar uma especialização em um benefício mecânico.

## A abordagem como escolha mecânica

O Atributo escolhido não muda apenas a probabilidade. Ele define o tipo de pista que pode surgir, a consequência coerente de uma falha e o modo como outras pessoas interpretam a ação. A seguir, a mesma situação é atravessada de formas diferentes.

| Conter uma testemunha em pânico PRE + Diplomacia Cria relação suficiente para que a pessoa aceite orientação. Falhar pode produzir desconfiança ou dependência. | Conter uma testemunha em pânico MEN + Medicina Reconhece sinais fisiológicos e conduz respiração, postura e estímulos. Falhar pode agravar o quadro ou exigir intervenção física. |
| --- | --- |
| Conter uma testemunha em pânico INS + Intuição Percebe o detalhe que está alimentando a crise e o remove da cena. Falhar pode confundir causa e sintoma. | Conter uma testemunha em pânico COR + Fortitude Sustenta fisicamente a pessoa durante convulsão, fuga ou risco imediato. Falhar pode ferir ambos ou transformar cuidado em contenção violenta. |

Nenhuma combinação substitui automaticamente as outras. Diplomacia pode não ser suficiente durante envenenamento; Medicina pode estabilizar o corpo sem obter confiança; Fortitude pode impedir uma queda e ainda piorar o medo. A mesa escolhe a relação que está tentando alterar e aceita as limitações dessa escolha.
