---
title: "Livro de Regras — CAPÍTULO 10 ~ COMBATE E MOVIMENTO"
node_type: "rule"
summary: "Seção “CAPÍTULO 10 ~ COMBATE E MOVIMENTO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 10 ~ COMBATE E MOVIMENTO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 10 ~ COMBATE E MOVIMENTO","source_order":11,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 10 ~ COMBATE E MOVIMENTO

A violência é uma maneira rápida de alterar relações. O sistema não permite que seja uma maneira simples.

Combate entra no jogo quando intenções incompatíveis deixam de caber na mesma cena e alguém tenta impor essa incompatibilidade ao corpo, à posição ou à capacidade de agir de outro ser. A estrutura de rodadas organiza simultaneidade; não afirma que pessoas esperam imóveis por seus turnos. Movimento, ameaça, cobertura e Reações descrevem tudo que continua acontecendo enquanto cada decisão recebe foco.

Violência humana permanece perigosa em qualquer Rank. Desenvolvimento amplia recursos, técnicas e opções, mas não transforma carne em material abstrato. Contra manifestações, a dificuldade pode vir de PP e Pressão. Contra pessoas, costuma vir de terreno, quantidade, surpresa, equipamento e consequência política. Em ambos os casos, vencer uma troca de ataques não encerra necessariamente aquilo que produziu o conflito.

O combate começa quando posições, objetivos e riscos passam a exigir ordem de ação. Ele não substitui investigação nem transforma toda ameaça em reserva de pontos. Serve para resolver pressão imediata: impedir, alcançar, ferir, proteger, conter, fugir ou criar tempo suficiente para que outra solução se torne possível.

## Estrutura

Uma Cena de combate divide-se em Rodadas. Cada participante possui um Turno por Rodada, definido por Iniciativa. Em seu Turno, normalmente recebe uma Ação Padrão, uma Ação de Movimento e Ações Livres razoáveis. Cada personagem possui uma Reação por Rodada, recuperada no início do próprio Turno.

| Ação | Usos comuns |
| --- | --- |
| Padrão | atacar, Canalizar, realizar teste ativo, usar item complexo, prestar ajuda |
| Movimento | deslocar, levantar, sacar objeto, mirar, interagir com mecanismo simples |
| Livre | falar brevemente, soltar objeto, mudar empunhadura, observar algo óbvio |
| Completa | consome Padrão e Movimento para ação extensa ou poderosa |
| Reação | responder fora do Turno: Esquiva, Bloqueio, Aparo, Contra-ataque ou certas Habilidades |

## Iniciativa

Todos realizam um teste de Iniciativa. O maior resultado age primeiro. Empates favorecem maior INS; persistindo, quem estava em posição de agir antes da cena. O Narrador pode agrupar NPCs ou ameaças semelhantes numa única iniciativa.

## Iniciativa e Reflexo

Iniciativa reconhece o instante em que a situação se transforma em conflito e determina quando alguém ocupa espaço na ordem de ação. Reflexo responde a algo que já está acontecendo. Use Iniciativa para abertura, surpresa, posição inicial e tomada de frente; use Reflexo para esquiva, aparo, interceptação e reação imediata.

## Ataques

Ataques são testes contra DEF. Escolha Atributo e Perícia coerentes. Luta resolve combate corpo a corpo; Pontaria, projeção. Outras Perícias podem ser usadas quando uma Habilidade, Trama ou instrumento assim determinar.

Mirar ~ Ação de Movimento: escolha um alvo observável. Seu próximo ataque de Projeção contra ele, realizado até o fim do Turno, recebe +1d20. Perder a linha de percepção ou sofrer deslocamento involuntário encerra o benefício. Ataque Mirado combina Mirar e Ataque Direto numa Ação Completa.

| Ataque | Regra |
| --- | --- |
| Corpo a corpo | Pool do Atributo + Luta contra DEF. Dano da arma + COR quando força física participa do golpe. |
| Projeção | Pool do Atributo + Pontaria contra DEF. Dano da arma; some COR apenas quando a arma indicar Tração. |
| Trama ofensiva | Canalização contra DT da Trama; o alvo realiza Resistência quando indicado. |
| Ameaças | 1d20 + VT correspondente contra DEF, salvo Habilidade específica. Atributos da Ameaça são usados em testes não ofensivos e resistências. |

Crítico e desastre

O crítico natural preserva o instante em que execução, oportunidade e acaso encontram a melhor forma possível. Apenas o dado escolhido importa. Um 20 presente num dado descartado não produz crítico. Margens ampliadas por armas e Habilidades continuam exigindo que o ataque alcance a DEF.

O dano ×2 é simples de ler e suficientemente emocionante. Condições adicionais pertencem à propriedade da arma ou à Habilidade, permitindo que diferentes construções tenham críticos diferentes sem obrigar toda rolagem máxima a consultar uma lista universal.

O dado escolhido do pool determina o resultado natural. Um 20 natural acerta e causa crítico em qualquer ação possível. Armas com Margem 19~20 também causam crítico quando o ataque acerta. Crítico dobra o dano total rolado antes da RD, salvo propriedade específica. Nenhuma arma comum possui multiplicador ×3.

Um 1 natural escolhido é desastre. A arma pode travar,o personagem perde posição, atinge cobertura, expõe-se ou produz outra consequência coerente. Desastres não devem retirar turnos futuros sem relação com a ação realizada.

## Reações

Uma rodada de conflito

Uma ameaça avança sobre Iria. Ela ainda possui sua Reação. Pode Esquivar e tentar transformar o acerto em erro; Bloquear com a placa de contenção e aceitar que o equipamento se desgaste; Aparar se a forma do ataque puder ser desviada; ou guardar a Reação esperando que o inimigo erre e permita um Contra-ataque. A decisão acontece antes de conhecer toda a rodada. Defesa, portanto, não é apenas um valor fixo: é administração de posição e risco.

| Reação | Procedimento | Efeito |
| --- | --- | --- |
| Esquiva | Declare antes da rolagem e teste Reflexo. | Resultado 10~14: +1 DEF; 15~19: +2; 20+: +3 contra o ataque. Em sucesso que transforme acerto em erro, mova 1,5 m se possuir Esquiva Instintiva. |
| Bloqueio | Declare antes da rolagem; em condições normais, não exige teste. Exige Fortitude Iniciada e escudo, armadura ou objeto capaz de interceptar. | Se o ataque acertar, reduza o dano em 1d6 + RD do equipamento. Se reduzir qualquer dano, o objeto perde 1 PD; num crítico, perde 2 PD. Em 0 PD, deixa de oferecer Bloqueio até ser reparado. |
| Aparo | Declare com arma adequada e role Luta ou Reflexo contra o resultado de ataque. | Se igualar ou superar, o ataque é desviado. Falha recebe dano normal. |
| Contra-ataque | Declare antes da rolagem e teste depois que inimigo em alcance errar um ataque corpo a corpo. Exige Luta Iniciada. | Realize Ataque Direto com -1d20. A Habilidade Contra-Golpe remove a penalidade. |

Bloqueio automático exige Fortitude Iniciada porque interceptar não basta: a personagem precisa sustentar postura, distribuir o impacto e impedir que a proteção seja arrancada de sua linha. Sem esse grau, ainda pode buscar Cobertura, Esquivar ou Aparar, mas não escolher Bloqueio como Reação automática.

Bloquear por um aliado, interceptar projétil distante, usar objeto improvisado ou alcançar uma linha de ataque fora da postura pode exigir Reflexo contra o resultado do ataque. Fortitude é testada depois quando o impacto também tenta derrubar, empurrar, quebrar postura ou exceder o que o equipamento consegue sustentar.

Cada personagem usa apenas uma Reação por Rodada, salvo Habilidade. A escolha e rolagem precisa ocorrer antes de saber o resultado, exceto Contra-ataque, que a rolagem depende do erro já ocorrido.

## Manobras

| Manobra | Ação | Teste | Efeito |
| --- | --- | --- | --- |
| Ataque Direto | Padrão | Ataque contra DEF | Dano normal. |
| Ataque Mirado | Completa | Ataque com +1d20 | Recebe +1d20 no ataque; exige alvo observável e posição estável. |
| Ataque Concentrado | Padrão | Ataque contra DEF +5 | Em acerto, ativa propriedade especial; ao superar por 5, também causa dano crítico. |
| Sequência de 2 golpes | Padrão; 1 PE | Dois ataques com -1d20 em ambos | Cada acerto causa dano normal. |
| Sequência de 3 golpes | Completa; 2 PE | Três ataques com -2d20 | Cada acerto causa dano normal. |
| Derrubar | Padrão | Luta contra Luta ou Reflexo | Alvo fica Caído. |
| Desarmar | Padrão | Luta contra Luta ou Reflexo | Objeto é lançado a 1,5 m. |
| Imobilizar | Padrão | Luta contra Luta | Alvo fica Agarrado enquanto a ação for sustentada. |
| Interromper | Padrão ou Reação preparada | Ataque contra Concentração | Interrompe ação prolongada ou sustentação. |
| Investida | Completa | Ataque com +1d20 | Deslocamento dobrado com Ataque Direto ao final; -2 na DEF até seu próximo turno. |
| Suprimir | Padrão, arma adequada | Pontaria contra Temperança | A região alcançada fica Perigosa: atravessá-la exige Temperança ou causa Abalado. |

Manobras de Artifício

Envolvem coordenação e/ou pensamento tático.

| Manobra | Procedimento | Efeito |
| --- | --- | --- |
| Flanquear | Mova-se para a retaguarda de um alvo, em Furtividade (Vantagem se ele já estiver em corpo a corpo) contra Percepção. | Próximo ataque corpo a corpo recebe +1d20. |
| Cercar | Quatro ou mais atacantes adjacentes. | Alvo recebe -1 DEF por atacante acima de três, máximo -3. |
| Coordenar | Ação Completa e Tática DT: 3 × aliados beneficiados. | Aliados recebem +1d20 até o fim da Rodada. |
| Encobrir | Ação Completa e teste apropriado. | Cria Cobertura Parcial para um aliado até seu próximo Turno. |
| Desmoralizar | Ação de Movimento, Intimidação ou Encenação contra Temperança. | Alvo fica Abalado até o fim do próximo Turno. |
| Preparar Ação | Gaste uma Ação Padrão, declare um gatilho perceptível e uma Ação Padrão ou de Movimento; reserve sua Reação. | Quando o gatilho ocorrer antes do início do próximo Turno, execute a ação como Reação. Se usar a Reação de outro modo ou o gatilho não ocorrer, a ação é perdida. Ação Completa não pode ser preparada. |
| Atrasar Ação | Antes de agir, escolha uma posição posterior na Rodada. | Seu Turno move-se para essa posição, que se torna sua nova Iniciativa pelo restante do confronto. Não interrompe ação já iniciada; se chegar ao fim da Rodada sem agir, age por último ou perde o Turno. |

## Dano, RD e objetos

Role todos os dados de dano e some os modificadores. Se o ataque for crítico, multiplique o dano total conforme a regra do crítico. Em seguida, subtraia a RD do alvo. Reduções concedidas por Habilidades ou Reações são aplicadas depois, salvo indicação contrária. O dano final nunca pode ser inferior a 0. Dano só retorna ao atacante quando uma Habilidade ou propriedade declarar isso expressamente.

Objetos possuem Pontos de Durabilidade (PD) e Resistência a Dano (RD). Um objeto destruído não desaparece; deixa de cumprir sua função ou muda a cena conforme o tipo de dano.

## Distância e escala

As medidas em metros ajudam mapas e posicionamento, mas não precisam substituir a linguagem. Próximo corresponde aproximadamente a até 6 m; distante, até 20 m; muito distante, além disso. Em cenas sem mapa, o Narrador pode usar zonas: Engajado, Próximo, Distante e Fora de Alcance.

## Exemplo completo de combate

Quatro personagens enfrentam uma manifestação Predadora numa oficina inundada. O objetivo não é destruí-la, mas alcançar a válvula que mantém o Bolsão pressurizado. A ameaça possui DEF 17, PP 46 e uma reação de perseguição. O chão é terreno difícil; passarelas oferecem Cobertura Parcial.

Na primeira rodada, Toman usa sua Ação de Movimento para ocupar a passagem e Postura de Combate porque sabe que a manifestação tentará atravessá-lo. Iria não ataca: usa Engenharia para localizar a válvula correta. Seu sucesso excepcional reduz de três para duas as ações necessárias para fechá-la. Sora utiliza Persuasão com PRE para organizar trabalhadores em pânico; o teste não afeta a criatura, mas remove pessoas da área e impede que a próxima habilidade em cone atinja civis.

A manifestação ataca Toman. Iniciado em Fortitude, ele escolhe Bloqueio com uma placa de manutenção, reduz dano sem realizar um teste adicional e aceita perda de PD. A ameaça usa sua Reação para mover-se depois do acerto, mas a posição de Toman ainda impede que alcance Iria. Na segunda rodada, uma Canalização de Thyren oculta a passagem lateral. A manifestação falha em reconhecê-la e perde o caminho mais curto, mas o Refluxo deixa Sora Surdo por uma rodada.

Quando Iria alcança a válvula, o grupo já encontrou uma pista sobre a Costura: a criatura persegue apenas quem carrega o selo da antiga oficina. Remover o selo reduz seu VT. O combate tornou-se mais fácil porque investigação e objetivo modificaram a ficha. A vitória acontece quando a válvula é fechada e o Furo perde pressão. Restar PP não obriga que todos permaneçam atacando até zero.

| O COMBATE SERVE AO OBJETIVO Um encontro termina quando a intenção que o sustentava foi resolvida: fuga, proteção, contenção, acesso, retirada ou destruição. PP é ferramenta de permanência em confronto, não obrigação de transformar toda cena numa eliminação completa. |
| --- |
