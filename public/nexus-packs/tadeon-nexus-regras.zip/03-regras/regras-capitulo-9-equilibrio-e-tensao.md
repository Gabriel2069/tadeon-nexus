---
title: "Livro de Regras — CAPÍTULO 9 ~ EQUILÍBRIO E TENSÃO"
node_type: "rule"
summary: "Seção “CAPÍTULO 9 ~ EQUILÍBRIO E TENSÃO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 9 ~ EQUILÍBRIO E TENSÃO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 9 ~ EQUILÍBRIO E TENSÃO","source_order":10,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 9 ~ EQUILÍBRIO E TENSÃO

Zero não significa ausência. Significa que as partes de uma pessoa ainda conseguem reconhecer-se como pertencentes à mesma vida.

Equilíbrio não é uma régua moral. Medo não significa maldade; Conhecimento não significa virtude. Ambos sustentam a vida humana e ambos podem ocupá-la até que escolha, corpo e identidade deixem de encontrar qualquer medida comum. O eixo registra inclinação, não julgamento.

A lentidão da Tensão é deliberada. Canalizar uma vez não deveria reescrever alguém. Mudanças profundas acontecem porque experiências se acumulam, porque determinada maneira de resolver problemas se torna habitual ou porque uma única exposição excepcional atravessa defesas que antes pareciam suficientes. Quatro pontos intermediários permitem que a mesa perceba direção antes que o valor inteiro mude.

Equilíbrio registra posição; Tensão registra o caminho que ainda não terminou de deslocá-la.

Equilíbrio registra a direção em que Medo e Conhecimento pressionam a organização humana. Valores negativos indicam inclinação ao Medo; positivos, ao Conhecimento. O Tempo não ocupa um terceiro polo: ele é a condição pela qual qualquer inclinação pode acontecer, produzir consequência e, talvez, ser atravessada.

Equilíbrio não mede a quantidade de cada Natureza dentro de alguém. Todos são compostos pelas três. Ele mede qual forma de relação está dominando a malha pessoal naquele momento. Em 0, corpo, memória, identidade, pensamento e passagem do tempo ainda preservam concordância suficiente para que a pessoa continue inteira.

## Escala

Medo  ~  -10  -9  -8  -7  -6  -5  -4  -3  -2  -1  0  +1  +2  +3  +4  +5  +6  +7  +8  +9  +10  ~  Conhecimento

Uma pessoa em condições comuns não ultrapassa ±5. Atravessar esse limite exige fonte excepcional: Refluxo Crítico, Zona de Aspecto, contato com manifestação elevada, Habilidade Transcendente, procedimento deliberado ou decisão narrativa irreversível.

## Tensão direcional

Cada ponto de Equilíbrio exige quatro pontos de Tensão na mesma direção. Registre Tensão entre -4 e +4. Quando alcança +4, o Equilíbrio move um ponto em direção ao Conhecimento e a Tensão volta a 0. Ao alcançar -4, move-se em direção ao Medo.

Tensão oposta cancela Tensão já acumulada antes de voltar a 0. PA pode absorver um ponto de Tensão forçada. Interlúdios, Vínculos, Selagem e Habilidades podem aproximá-la de 0.

| DUAS TENSÕES DIFERENTES A Tensão de Equilíbrio pertence ao personagem. A Tensão de uma Dobra pertence ao fenômeno territorial. Usam a mesma palavra porque ambas medem pressão acumulada, mas possuem trilhas e consequências diferentes. |
| --- |

## Fontes comuns

| Fonte | Direção ou efeito |
| --- | --- |
| Trama de Medo | 1 Tensão de Medo quando a regra, a falha ou o efeito indicar. |
| Trama de Conhecimento | 1 Tensão de Conhecimento quando indicado. |
| Refluxo | Na direção da Natureza ou do Domínio envolvido. |
| Exposição profunda | Definida pela manifestação, Dobra ou Fragmento. |
| Aceitar uma transformação | Pode mover Equilíbrio diretamente quando a decisão for irreversível. |
| Interlúdio significativo | Remove Tensão em direção a 0; raramente move Equilíbrio diretamente. |
| PA | Absorve 1 Tensão forçada por ponto gasto. |

## Efeitos por valor

| Eq. | Estado | Abertura | Preço |
| --- | --- | --- | --- |
| -10 | Limite do Inverso | +3d20 em ações e Tramas de Medo. | -3d20 em Conhecimento; Tramas opostas acima de Repuxo impossíveis. O personagem está em risco de Perdição. |
| -9 | Dissolução Visceral | +3d20 em Medo. | -2d20 em Conhecimento; uma compulsão corporal ou instintiva torna-se permanente até Costura narrativa. |
| -8 | Profundidade Visceral | +2d20 em Medo. | -2d20 em Conhecimento. |
| -7 | Corpo Dominante | +2d20 em Medo. | -1d20 em Conhecimento. |
| -6 | Instinto Sobreposto | +1d20 em Medo. | -1d20 em Conhecimento; toda cena de forte ameaça exige Convicção para não agir por impulso. |
| -5 | Ponto de Inflexão | +1d20 em Medo. | Estiramento de Conhecimento exige fonte excepcional. |
| -4 | Inclinação ao Medo | +1d20 em testes ou Tramas claramente alinhados ao Medo. | — |
| -3 | Afinidade Visceral | Uma vez por cena, trate Perícia sem treino como Iniciada em ação alinhada ao Medo. | — |
| -2 | Sensação Ampliada | Uma vez por cena, repita um d20 em percepção de risco corporal ou presença ameaçadora. | — |
| -1 | Toque de Instinto | Sinais sutis: sono, fome, dor e reflexo respondem mais cedo. | — |
| 0 | Inteireza | Plenamente capaz de mudar sem uma relação dominante | Nenhum bônus ou penalidade. |
| 1 | Toque de Clareza | Padrões, palavras e lembranças aproximam-se da atenção. | — |
| 2 | Sensibilidade Estrutural | Uma vez por cena, repita um d20 em análise de padrão, linguagem ou memória. | — |
| 3 | Afinidade Cognoscível | Uma vez por cena, trate Perícia sem treino como Iniciada em ação alinhada ao Conhecimento. | — |
| 4 | Inclinação ao Conhecimento | +1d20 em testes ou Tramas claramente alinhados ao Conhecimento. | — |
| 5 | Ponto de Inflexão | +1d20 em Conhecimento. | Estiramento de Medo exige fonte excepcional. |
| 6 | Razão Sobreposta | +1d20 em Conhecimento. | -1d20 em Medo; toda cena de forte vínculo exige Convicção para não tratá-lo como estrutura abstrata. |
| 7 | Mente Dominante | +2d20 em Conhecimento. | -1d20 em Medo. |
| 8 | Profundidade Abstrata | +2d20 em Conhecimento. | -2d20 em Medo. |
| 9 | Dissolução Racional | +3d20 em Conhecimento. | -2d20 em Medo; uma compulsão por ordem, registro ou definição permanece até Costura narrativa. |
| 10 | Limite da Chama Fria | +3d20 em ações e Tramas de Conhecimento. | -3d20 em Medo; Tramas opostas acima de Repuxo impossíveis. O personagem está em risco de Perdição. |

## Afinidade

Afinidade exige relação verdadeira com o polo. Uma personagem em -4 não recebe vantagem automática para erguer uma caixa, atacar com uma faca ou correr. O bônus de Medo surge quando a ação trabalha limite, incorporação, ameaça, instinto ou dissolução. Da mesma maneira, Conhecimento não beneficia qualquer cálculo ou lembrança, mas ações em que reconhecimento, linguagem, Significância ou organização profunda participam do resultado.

Inclinação sem caricatura

Em -3, Levan continua capaz de planejar, conversar e cuidar. A inclinação aparece quando perigo se aproxima: percebe tensão no corpo antes dos outros, age por proteção e encontra dificuldade crescente em distinguir cuidado de controle. Em +3, Sora continua sentindo medo e afeto, mas começa a transformar experiências em padrões antes de permitir que existam como contradição. Nenhum deles se tornou uma criatura. Ambos começaram a pagar pela forma que mais utilizam para permanecer.

Bônus de Equilíbrio só se aplicam quando a ação toca de maneira clara a Natureza correspondente. Uma luta comum não recebe bônus de Medo apenas por usar o corpo. Uma investigação não recebe bônus de Conhecimento apenas por envolver raciocínio. A ação precisa operar sobre limite, dissolução, memória, linguagem, Significância, identidade ou outro padrão reconhecível do polo.

## Retorno a 0

Equilíbrio não se corrige por repouso automático. Tensão pode ser reduzida por descanso, cuidado e Vínculos. Mover o próprio Equilíbrio exige experiência capaz de reorganizar a malha pessoal: aceitar uma verdade, recuperar um vínculo, atravessar uma Costura, abandonar um padrão ou integrar aquilo que antes só podia ser combatido.

## Exemplo de deslocamento gradual

Sora começa em Equilíbrio 0. Durante três sessões, Canaliza Conhecimento apenas em situações preparadas e não recebe Tensão. Depois, força uma Trama de Linguagem através de um Fragmento instável e recebe 2 Tensões de Conhecimento. Num encontro seguinte, aceita conscientemente conservar uma memória que deveria ter sido devolvida ao dono, recebendo mais 1. Um Refluxo acrescenta a quarta: seu Equilíbrio passa a +1 e a Tensão retorna a 0.

Nas sessões seguintes, Sora participa de Interlúdio em que devolve parte da memória e remove Tensões novas antes que completem outro movimento. O valor +1 permanece; não desaparece porque dormiu. Ele registra que determinada maneira de tocar o mundo já encontrou continuidade nela.

Meses depois, uma Zona de Significância tenta levá-la diretamente de +3 a +6. O limite comum de ±5 impede o movimento ordinário, mas a exposição é excepcional. Ela pode gastar PA, aceitar uma Marca, receber ajuda numa Selagem ou permitir que a transformação aconteça. A regra não decide qual escolha é correta. Garante que a decisão tenha um tamanho visível.
