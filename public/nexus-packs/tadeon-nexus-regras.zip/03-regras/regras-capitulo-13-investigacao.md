---
title: "Livro de Regras — CAPÍTULO 13 ~ INVESTIGAÇÃO"
node_type: "rule"
summary: "Seção “CAPÍTULO 13 ~ INVESTIGAÇÃO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 13 ~ INVESTIGAÇÃO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 13 ~ INVESTIGAÇÃO","source_order":14,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 13 ~ INVESTIGAÇÃO

Uma pista não é uma recompensa por rolar bem. É uma parte do mundo que já estava ali e precisa produzir consequências quando encontrada.

Investigar é reconstruir relações a partir do que elas deixaram. O objetivo raramente é apenas descobrir quem fez algo. Uma investigação de TdV pergunta o que continua ativo, por que determinado padrão encontrou permanência e que interpretação do acontecimento beneficia pessoas, instituições ou manifestações.

Pistas Diretas garantem que o mistério avance. Testes oferecem profundidade, contexto e preço. Uma falha pode consumir tempo, danificar evidência, expor o grupo ou produzir Pulso; não precisa retirar a informação central. O Narrador não necessita de tabela universal de falhas. Precisa conhecer a cena o bastante para escolher o custo que mais altera sua relação atual.

## Princípio das pistas garantidas

Em vez de contar uma quantidade rígida de pistas para liberar cada resposta, construa Perguntas Centrais. Uma pista pode tocar várias perguntas e nenhuma precisa responder sozinha. A mesa sente progresso quando consegue formular hipóteses melhores, não apenas quando alcança um número.

Mistério breve ~ as vozes da pressão

Perguntas Centrais: por que a rede pneumática transmite vozes; por que apenas algumas casas as escutam; o que mantém o padrão. Pistas Diretas: todas as casas pertenciam à mesma cooperativa e as vozes surgem no horário de troca de turno. Uma investigação bem-sucedida revela que a pressão reproduz ritmos de nomes riscados do registro de um acidente. Uma falha próxima entrega a mesma relação, mas ativa a estação e faz a cidade inteira ouvir uma frase incompleta. A história não para. A ameaça agora sabe que foi escutada.

Todo local, testemunha ou objeto central possui ao menos duas Pistas Diretas que podem ser encontradas sem teste quando os personagens procuram de forma coerente. Testes determinam profundidade, rapidez, interpretação e custo. A investigação nunca deve parar porque ninguém superou uma DT.

## Estrutura de uma cena

1 ~ Leitura do ambiente: apresente o que qualquer pessoa presente perceberia.

2 ~ Pistas Diretas: entregue as informações necessárias ao movimento da história.

3 ~ Pistas Profundas: testes revelam contexto, padrão, contradição, autoria ou Ponto de Costura.

4 ~ Teia: permita que o grupo relacione descobertas e formule hipóteses.

5 ~ Custo do conhecimento: mostre que compreender também altera posição, segurança, Vínculo ou Tensão.

6 ~ Próximo passo: toda cena oferece ao menos uma direção concreta de ação.

## Compasso de Urgência

Algumas investigações podem continuar enquanto o mundo ao redor permanece imóvel. Outras acontecem sob chegada institucional, degradação de evidência, deslocamento de uma testemunha ou aproximação de um Pulso. Nesses casos, use um Compasso de Urgência de 3 a 8 espaços. Ele não decide se as pistas deixam de existir; ele registra quando a situação muda de forma.

| Tamanho | Uso | Quando avança |
| --- | --- | --- |
| 3 espaços | cena curta ou intervenção iminente | ação demorada, falha grave ou gatilho específico |
| 4~5 espaços | investigação comum sob pressão | tempo, ruído, exposição, antagonista ou Pulso |
| 6~8 espaços | operação extensa ou múltiplas frentes | marcos definidos pelo Narrador e consequências acumuladas |

Quando o Compasso se completa, a investigação não perde o que foi descoberto. A cena muda: alguém chega, um acesso se fecha, a Dobra pulsa, a testemunha foge, a evidência é transferida ou o problema atravessa outra relação. Depois da mudança, o Narrador pode encerrar o Compasso, reiniciá-lo menor ou substituí-lo por outro.

## Ações de síntese

| Ação | Procedimento | Resultado |
| --- | --- | --- |
| Recapitular | Ação Padrão ou alguns minutos fora de conflito; reúna ao menos duas pistas já obtidas. | Formule uma pergunta nova. Um teste apropriado revela uma relação sustentada pelo material; falha ainda oferece direção, mas avança o Compasso ou cria preço. |
| Compartilhar Perspectiva | Entregue a pista a outro personagem e explique sua leitura. | O outro personagem pode reinterpretá-la com Atributo, Perícia, Ocupação ou Vínculo próprios. O segundo teste não repete a busca; muda o repertório aplicado. |

## Perguntas centrais

Em vez de exigir número fixo de pistas para revelar “o quê”, “como”, “quem” e “por quê”, construa cada mistério a partir de perguntas próprias.

| Pergunta exemplo | Tipo de resposta |
| --- | --- |
| O que aconteceu? | evento, alteração ou ausência inicial |
| O que ainda está acontecendo? | mecanismo ativo, prazo ou repetição |
| O que sustenta a Dobra? | fonte, relação, território ou Ponto de Costura |
| Quem depende da interpretação atual? | instituição, testemunha, antagonista ou comunidade |
| O que será perdido se a Costura for rompida? | preço que impede solução simples |
| O que a Ordem compreendeu errado? | contradição que abre escolha e não apenas resposta |

## Falha em investigação

Falhar não elimina a pista. O Narrador apresenta a verdade com uma complicação criada para aquela cena. Não existe tabela obrigatória: a consequência deve nascer do local, do método e da pressão existente.

~ tempo é perdido e a Tensão da Dobra aumenta;

~ alguém percebe que o grupo está investigando;

~ a evidência é danificada depois de revelar parte do conteúdo;

~ o personagem sofre exposição, condição ou custo de PS;

~ a pista é verdadeira, mas incompleta ou ligada a uma interpretação perigosa;

~ um Pulso ocorre antes que o grupo possa sair ou reorganizar-se.

Informação falsa só deve aparecer quando existe fonte capaz de mentir, manipular ou registrar errado. O teste não inventa falsidade apenas porque falhou.

## Dificuldade de Testes

| DT | Exemplo de investigação |
| --- | --- |
| 10 | reconhecer sinal evidente para alguém atento |
| 15 | encontrar padrão entre evidências dispersas |
| 20 | identificar método técnico, Assinatura ou contradição bem escondida |
| 25 | reconstruir relação apagada, adulterada ou metafisicamente alterada |
| 30 | compreender estrutura que exige conhecimento além do humano comum |

## Custo de PS

Ver algo estranho não causa automaticamente dano de PS. A perda ocorre quando a descoberta contradiz uma relação fundamental, reescreve percepção, toca Marca ou Vínculo, exige integrar uma verdade incompatível ou revela a manifestação verdadeira de uma Ameaça. Quando a pressão pertence a uma Ameaça, use seu Abalo de Manifestação: Temperança é a resistência padrão, e Convicção pode substituí-la apenas quando uma relação concreta é nomeada. O teste reduz, evita ou transforma o custo conforme a ficha.

## Construindo um mistério conectado

Comece pela relação alterada: uma cidade esquece nomes pronunciados sob chuva. Escolha o que isso produz na vida comum: registros divergem, famílias utilizam gestos para se apresentar, contratos de estação chuvosa tornam-se frágeis. Escolha quem depende da situação: uma casa comercial preserva monopólio porque dívidas antigas não podem ser atribuídas corretamente.

Defina a Dobra: Âncora de Linguagem estabilizada num sistema de cisternas. Defina sinais anteriores à explicação: inscrições com espaços vazios, pessoas que reconhecem rostos sem conseguir chamar, músicas locais sem nomes próprios. Defina Ponto de Costura: o primeiro nome apagado pertence a uma criança que a cidade decidiu registrar como inexistente para impedir uma disputa sucessória.

Distribua pistas entre lugares e pessoas. O arquivo oferece a rasura; uma parteira conserva a canção; um técnico percebe que a água reage a assinaturas; a casa comercial tenta impedir acessos. Testes não liberam a existência da criança, mas revelam contexto, autoria e preço. Romper a Costura devolverá nomes e também restaurará contratos, heranças e acusações que a cidade construiu sobre o esquecimento.

Somente depois escolha ameaças, Pulsos e DTs. O mistério permanece conectado porque cada regra aponta para a mesma relação. A solução não precisa ser destruir a cisterna. Pode exigir reconhecer o nome, reconstruir sua cidadania e criar prática coletiva que permita à cidade continuar lembrando quando a chuva voltar.
