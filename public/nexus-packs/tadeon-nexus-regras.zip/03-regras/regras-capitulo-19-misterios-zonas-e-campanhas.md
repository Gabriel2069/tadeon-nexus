---
title: "Livro de Regras — CAPÍTULO 19 ~ MISTÉRIOS, ZONAS E CAMPANHAS"
node_type: "rule"
summary: "Seção “CAPÍTULO 19 ~ MISTÉRIOS, ZONAS E CAMPANHAS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 19 ~ MISTÉRIOS, ZONAS E CAMPANHAS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 19 ~ MISTÉRIOS, ZONAS E CAMPANHAS","source_order":20,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 19 ~ MISTÉRIOS, ZONAS E CAMPANHAS

Uma campanha cresce quando cada resposta revela que a relação descoberta já participava de algo maior.

Campanhas longas não precisam crescer apenas em Magnitude. A escala pode aumentar porque responsabilidades se multiplicam, instituições respondem, Vínculos entram em conflito e soluções locais produzem efeitos em redes distantes. Personagens de Rank elevado ainda podem ser profundamente pressionados por uma ameaça pequena quando agir com força destruiria aquilo que precisam preservar.

A conexão entre arcos deve nascer de relações existentes, não apenas de uma organização secreta por trás de tudo. Um Fragmento circula por rotas comerciais; um método de Selagem foi copiado por mosteiros; uma crise de água altera práticas que mantinham um Revérbero estável; a decisão de revelar a Ordem muda alianças. O mundo cresce porque suas partes já dependiam umas das outras.

## Anatomia de uma operação

Uma operação pode assumir muitas ordens, mas Narradores iniciantes se beneficiam de reconhecer seus movimentos. A sequência abaixo não é roteiro obrigatório. É uma forma de verificar se o grupo recebeu mundo suficiente para perceber a alteração, escolha suficiente para responder e consequência suficiente para que a sessão deixe permanência.

| Movimento | Função |
| --- | --- |
| Continuidade | mostre a vida, prática ou relação que funciona antes da falha |
| Sinal | introduza alteração perceptível sem exigir explicação imediata |
| Investigação | permita reunir pistas, hipóteses e Compasso de Urgência |
| Preparação | escolha ferramentas, vínculos, rotas, Tramas e responsabilidades |
| Travessia | use infiltração, perseguição, perigo, confronto ou negociação |
| Contato | enfrente manifestação, instituição, Dobra ou Ponto de Costura |
| Resolução | feche, cerque, pacifique, fuja, contenha ou aceite objetivo parcial |
| Permanência | registre Interlúdio, relação alterada, Selo, dívida, Marca ou novo costume |

## Estrutura de mistério

Um mistério de Tessitura do Vazio possui uma ferida local, uma relação que a sustenta, forças que dependem de determinada interpretação e um preço para qualquer solução. Não precisa começar com escala cósmica. Uma casa, um contrato, um hospital ou uma rota podem carregar profundidade suficiente.

| Camada | Pergunta |
| --- | --- |
| Ferida | O que deixou de funcionar como antes? |
| Sinal | Como essa falha aparece sem revelar a causa inteira? |
| Sustentação | Que relação permite que continue? |
| Interesse | Quem precisa que o problema seja negado, mantido ou usado? |
| Costura | O que pode alterar sua permanência? |
| Preço | O que uma solução destruiria, revelaria ou tornaria responsabilidade do grupo? |

## Relógios de campanha

Use trilhas simples quando forças continuam agindo fora das cenas.

| Relógio | Espaços | Quando avança |
| --- | --- | --- |
| Tensão da Dobra | 4 | falha grave, tempo, Canalização local, ação antagonista |
| Suspeita institucional | 4 a 8 | evidência pública, testemunha, violação de jurisdição |
| Ruptura de Vínculo | 3 a 6 | abandono, mentira, dano, escolha contraditória |
| Preparação adversária | 4 a 8 | tempo perdido, informação vazada, recurso adquirido |
| Reconquista de Zona | objetivos | cada Costura, território ou comunidade recuperada |

## Zonas de Aspecto

Uma Zona não é apenas um cenário com penalidades. É um território que aprendeu outra lógica. Divida-a em regiões, Costuras e populações. Cada objetivo recuperado reduz Pressão, altera Pulsos ou devolve escolhas aos habitantes.

1 ~ Defina a lei local: que relação passou a funcionar de outro modo?

2 ~ Defina quem se adaptou e o que perderia se a Zona fosse simplesmente apagada.

3 ~ Divida o território em três a sete objetivos de reconquista.

4 ~ Associe cada objetivo a uma Costura, ameaça, instituição ou decisão.

5 ~ Permita redução, isolamento, evacuação, pacificação ou convivência; reconquistar não significa restaurar um passado intacto.

## Arcos de campanha

| Escala | Estrutura exemplo |
| --- | --- |
| Local | uma ferida, uma comunidade, uma instituição próxima e um Ponto de Costura |
| Regional | múltiplos locais ligados por rota, arquivo, rio, rede técnica ou política |
| Institucional | a resposta da Ordem, Eclésia, governo, guilda ou academia torna-se parte do problema |
| Continental | redes de Veth, Liga de Osva, Base Sul, comércio de Fragmentos e grandes Zonas |
| Cosmológica | o Primeiro, Chama Fria, Fluxo ou estrutura da Urdidura alteram escolhas sem substituir a vida humana por abstração |

## Progressão sem escalada obrigatória

O último arco de uma campanha pode retornar à primeira casa visitada e ainda parecer maior. Talvez os personagens compreendam agora que o pequeno rito preservado ali sustentava uma rede continental. Talvez possuam poder suficiente para destruir a Âncora, mas relações demais para aceitar esse preço. Desenvolvimento não é apenas enfrentar algo mais forte. É perceber mais consequências na mesma escolha.

Rank alto não exige ameaças cada vez maiores em toda sessão. Personagens experientes podem enfrentar situações menores cuja dificuldade nasce de responsabilidade, política, Vínculo, sigilo ou impossibilidade de usar força. A escala de uma história não determina seu peso.

## Princípios finais

~ O mundo comum precisa funcionar antes de falhar.

~ Investigação modifica o confronto e a Selagem.

~ Pontos de Costura são relações, não códigos escondidos.

~ Tecnologia resolve problemas concretos e cria dependências concretas.

~ Vínculos oferecem força porque podem ser feridos, não porque devam ser punidos sempre.

~ Ameaças possuem lógica suficiente para produzir pistas.

~ Consequências permanecem quando a história encontra motivos para lembrá-las.

~ O desconhecido amplia a imaginação quando possui contorno suficiente para orientar uma escolha.

A regra termina quando todos sabem o que aconteceu.
A história começa quando precisam decidir o que fazer com isso.
