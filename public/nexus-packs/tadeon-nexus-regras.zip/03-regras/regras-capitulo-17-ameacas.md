---
title: "Livro de Regras — CAPÍTULO 17 ~ AMEAÇAS"
node_type: "rule"
summary: "Seção “CAPÍTULO 17 ~ AMEAÇAS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 17 ~ AMEAÇAS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 17 ~ AMEAÇAS","source_order":18,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 17 ~ AMEAÇAS

Uma Ameaça é a forma operacional de algo que, antes de possuir estatísticas, já alterava relações.

Uma ficha de Ameaça não pretende explicar a totalidade da manifestação. Registra aquilo que pode entrar em cena, resistir, agir e ser transformado pelas decisões do grupo. Magnitude mede força e escala; CP distribui essa força; ID mede quanto a compreensão e o preparo alteram o encontro; Arquétipo organiza comportamento; Ponto de Costura conecta investigação e resolução.

Ameaças de mesma Magnitude podem ser radicalmente diferentes. Uma existe como predador físico; outra como regra territorial; outra como conjunto de corpos; outra quase não ataca, mas torna impossível conservar registros. O orçamento impede que individualidade se transforme em vantagem sem custo. O conceito decide onde o orçamento deve ser gasto.

Uma Ameaça permanece legível quando conceito, força, comportamento e Costura apontam para a mesma presença.

## O que é uma Ameaça

Ameaças incluem criaturas, humanos transformados, sistemas autônomos, manifestações sem corpo e fenômenos capazes de responder em conflito. Sua ficha não pretende explicar toda a ontologia. Registra quanto daquela presença consegue permanecer, como pressiona, que espaço ocupa e que Costura impede que seja apenas uma quantidade de dano.

## Ficha

| Campo | Conteúdo |
| --- | --- |
| Nome | como é chamada ou reconhecida |
| Taxonomia | Natureza, Domínio, origem e tipo de manifestação |
| Manifestação | aparência, presença e efeitos ambientais |
| Abalo de Manifestação | gatilho, resistência, consequência, familiarização e formas de preparação |
| Magnitude | I a XX; força estrutural, PP, DEF, Reações e CP base |
| Arquétipo | Predador, Colosso, Manifestação, Emboscador ou Enxame |
| Índice de Desafio | I a V; investigação, preparo e dependência do Ponto de Costura |
| Atributos | COR, MEN, AGI, INT |
| PP / DEF / RD | permanência e resistência operacional |
| Deslocamento | distância e valores de movimento |
| Mobilidade | Deslocamento terrestre e todos os modos e meios adicionais |
| VT | Corpo, Projétil, Manipulação, Irradiação e Territorial |
| Ataques e Habilidades | pressões ativas, passivas e Reações |
| Alcance | perfil espacial de cada ataque ou Habilidade: Engajado, Próximo, Distante, Extremo, Cone, Linha, Raio, Aura, Corrente, Cena ou Território |
| Condições especiais | regras que definem seu modo de existir |
| Ponto de Costura | manifestação narrativa, condição de acesso e consequência |

## Animais e presenças mundanas

Nem todo ser perigoso é uma manifestação. Animais possuem necessidade, território, medo, fome, cuidado, aprendizado e limite físico. Quando funcionam apenas como parte do mundo, podem usar ficha abreviada de Ameaça: Magnitude, Atributos, PP, DEF, um ou dois ataques, sentidos, Mobilidade e comportamento. Seu ID costuma ser I, e Abalo de Manifestação só existe quando algo além de sua natureza comum pressiona a continuidade.

| Escala | Magnitude comum | Leitura |
| --- | --- | --- |
| Pequeno ou defensivo | I | ameaça local, fuga, mordida, veneno ou distração |
| Predador médio ou animal treinado | II~III | perseguição, emboscada, proteção de território |
| Grande territorial | III~IV | força, carga, resistência e controle de passagem |
| Enxame | II~IV | use Arquétipo Enxame e Alcance coletivo |
| Excepcional ou alterado | V+ | somente quando tamanho, ambiente, treinamento ou Dobra justificarem |

## Perigos mundanos

Perigos mundanos não precisam de PP. Possuem Intensidade, DT, frequência e consequência. Um teste isolado resolve exposição breve; mas uma travessia, epidemia, incêndio ou colapso extenso usa Teste Prolongado. Preparação adequada pode reduzir DT, frequência ou consequência, e às vezes até elimina a necessidade de rolar.

| Intensidade | DT comum | Consequência de referência |
| --- | --- | --- |
| I | 10 | 1d4 PV/PS, condição leve ou perda pequena de recurso |
| II | 15 | 1d6, condição ou 1 Pressão |
| III | 18 | 2d6, progressão de condição ou obstáculo relevante |
| IV | 22 | 3d6, condição grave, separação ou perda estrutural |
| V | 25 | 4d6+, múltiplas consequências ou Teste Prolongado obrigatório |

| Perigo | Resistência comum | Consequências e mitigação |
| --- | --- | --- |
| Frio ou calor | Fortitude, Sobrevivência | Fadigado, Doente ou dano Térmico; abrigo, roupa e ritmo reduzem exposição. |
| Altitude e pressão | Fortitude, Medicina, Engenharia | Doente, Esgotado, perda de PE; aclimatação e equipamento vedado ajudam. |
| Fumaça e sufocamento | Fortitude, Acrobacia, Engenharia | Cego, Doente, dano e perda de ação; máscara e ventilação reduzem. |
| Correnteza e inundação | Atletismo, Condução, Sobrevivência | Deslocamento forçado, perda de carga, Afogamento como Teste Prolongado. |
| Desabamento e queda | Reflexo, Acrobacia, Engenharia | Impacto, Caído, soterramento e rotas bloqueadas. |
| Fome, sede e privação | Fortitude, Sobrevivência | Fadigado, Esgotado, recuperação reduzida; suprimento interrompe progressão. |
| Doença | Fortitude, Medicina | Doente e efeitos específicos; tratamento age sobre exposição e progressão. |

## Doenças

Uma doença possui Exposição, Incubação, Progressão, Tratamento e Resolução. Depois da Exposição, o Narrador realiza ou solicita Fortitude na frequência indicada. A primeira falha aplica Doente; falhas seguintes produzem estágios próprios, Fadigado, Esgotado, dano ou limitação definida. Sucesso pode estabilizar; sucessos consecutivos ou tratamento adequado encerram a Progressão. Doença não deve existir apenas para retirar recursos: ela altera rotas, cuidado, instituições e relações.

| Campo | Pergunta |
| --- | --- |
| Exposição | Que contato torna a doença possível? |
| Incubação | Quando os sinais aparecem e o que pode ser percebido antes? |
| Progressão | Com que frequência se testa e o que cada falha modifica? |
| Tratamento | Que conhecimento, material, tempo ou instituição interfere? |
| Resolução | Quantos sucessos, quanto tempo ou que mudança encerra o risco? |

## Abalo de Manifestação

Abalo de Manifestação registra o momento em que a presença deixa de ser apenas estranha e contradiz uma relação que o personagem precisava considerar estável. O teste ocorre na primeira vez em que a manifestação verdadeira é reconhecida, não necessariamente quando seu corpo é visto. Uma criatura pode ser observada sem Abalo até que alguém compreenda que ela não aparece em lembranças; um arquivo pode causar Abalo quando se percebe que seus registros estão substituindo testemunhas vivas.

Temperança é a resistência padrão. Convicção pode substituí-la quando o Jogador nomeia a relação que ancora a personagem. O Abalo normalmente ocorre uma vez por Assinatura; pode repetir quando a Ameaça revela forma mais profunda, aumenta de Magnitude, transforma-se em Zona, toca diretamente Marca ou Vínculo ou produz uma revelação que não existia no primeiro contato.

| Grau | Resistência | Consequência básica |
| --- | --- | --- |
| Inquietante | DT 12 | 1 PS ou condição Abalado. |
| Perturbador | DT 15 | 1d4 PS. |
| Rupturante | DT 18 | 1d6 PS e possível condição coerente. |
| Inconcebível | DT 20 | 2d6 PS, condição grave ou 1 Tensão. |

Investigação e preparação podem conceder Vantagem, reduzir DT ou dano, substituir o teste por uma escolha consciente ou eliminar o Abalo ao revelar o Ponto de Costura. Nem toda Ameaça precisa de Abalo elevado; a intensidade mede a ruptura produzida pela compreensão, não a feiura ou o tamanho da presença.

## Magnitude

Magnitude não é apenas uma medida metafísica, nem apenas um nível de combate. Ela expressa quanta força a manifestação consegue sustentar no Reflexo: resistência, capacidade ofensiva, número de respostas e orçamento de propriedades. O ID permanece responsável pela diferença mediada por uma investigação. Uma ameaça de Magnitude alta e ID baixo pode ser brutal, porém direta. Uma ameaça de Magnitude moderada e ID alto pode destruir grupos que a enfrentem sem compreender a regra que organiza suas ações.

Magnitude mede força estrutural e capacidade de pressionar o Reflexo. Ela fornece o chassi de combate. O ID mede quanto conhecimento e preparo são necessários para lidar com esse chassi sem pagar o preço máximo.

| Mag. | PP | DEF | Reações | CP |
| --- | --- | --- | --- | --- |
| I | 15 | 15 | 0 | 8 |
| II | 20 | 15 | 0 | 10 |
| III | 25 | 16 | 0 | 12 |
| IV | 31 | 16 | 1 | 15 |
| V | 38 | 17 | 1 | 18 |
| VI | 46 | 17 | 1 | 22 |
| VII | 55 | 17 | 1 | 26 |
| VIII | 65 | 19 | 1 | 31 |
| IX | 76 | 19 | 2 | 36 |
| X | 88 | 20 | 2 | 42 |
| XI | 101 | 20 | 2 | 49 |
| XII | 115 | 20 | 2 | 57 |
| XIII | 130 | 21 | 2 | 66 |
| XIV | 146 | 21 | 3 | 76 |
| XV | 163 | 21 | 3 | 87 |
| XVI | 181 | 22 | 3 | 99 |
| XVII | 200 | 23 | 3 | 112 |
| XVIII | 220 | 23 | 4 | 126 |
| XIX | 241 | 23 | 4 | 141 |
| XX | 263 | 23 | 4 | 158 |

## Índice de Desafio

| ID | Leitura |
| --- | --- |
| I | Padrão direto. Investigação reduz risco, mas confronto inicial é viável. |
| II | Comportamento parcialmente previsível. Alguma preparação é recomendada. |
| III | Mecânicas exigem atenção. Sem informação, o grupo enfrenta custos significativos. |
| IV | Compreender o Ponto de Costura é praticamente essencial. |
| V | Complexidade máxima. Confronto sem investigação tende ao fracasso, contenção provisória ou preço irreversível. |

## Atributos e ataques

Os quatro Atributos desta seção pertencem exclusivamente às Ameaças. Eles condensam capacidades que, em personagens, são distribuídas entre cinco Atributos e Perícias.

| Atributo | Função |
| --- | --- |
| COR | força, impacto, resistência e testes de corpo |
| MEN | resistência metafísica e sustentação de Habilidades |
| AGI | mobilidade, precisão e reação |
| INT | planejamento, manipulação complexa e leitura tática |

| Magnitude | Distribuição sugerida entre COR, MEN, AGI e INT |
| --- | --- |
| I~IV | 3, 2, 1, 1 |
| V~VIII | 4, 3, 2, 1 |
| IX~XII | 4, 4, 3, 2 |
| XIII~XVI | 5, 4, 4, 3 |
| XVII~XX | 5, 5, 4, 4 |

Distribua os valores segundo a forma da Ameaça. Eles não elevam o ataque comum; indicam como ela resiste, caça, interpreta, sustenta campos, atravessa ambiente ou disputa ações fora de seus Vetores ofensivos.

Ataques comuns usam 1d20 + VT contra DEF. Habilidades podem usar Atributo, DT fixa ou teste contestado. Os Atributos da Ameaça formam pools apenas em resistências, ações ambientais, sustentação e testes não ofensivos. Um 20 natural é crítico quando o ataque causa dano; um 1 natural produz abertura ou consequência coerente, salvo manifestações que ignorem desastre por natureza.

## Arquétipos

| Arquétipo | Regra |
| --- | --- |
| Predador | Escolha um alvo Isolado no início da Rodada. Recebe +1d20 no primeiro ataque contra ele e pode mover 3 m após acertá-lo. Perde o benefício quando outro personagem entra em Engajado. |
| Colosso | Vantagem contra deslocamento, queda e imobilização. Habilidades que utilizem VT Territorial custam 1 CP a menos, mínimo 1. A redução não se aplica automaticamente ao perfil de Alcance Território. Não pode usar cobertura leve e costuma ter menor AGI. |
| Manifestação | Não depende de anatomia comum. Escolha duas condições físicas às quais é imune; ataques sem relação com sua forma podem exigir método específico. |
| Emboscador | Se iniciar oculto ou preparado, recebe uma Ação de Movimento adicional na primeira Rodada e +2 em Iniciativa. Depois de sofrer dano, perde os benefícios de abertura. Quando Flanqueia, recebe +1d20 no primeiro ataque contra o alvo durante aquele Turno. |
| Enxame | Representa múltiplos corpos numa única ficha. Ataques de alvo único causam metade do dano depois da RD; ataques ou Habilidades com Alcance de Cone, Linha, Raio, Aura ou Cena causam +1 dado de dano antes da RD. Perde capacidades quando cai abaixo de metade dos PP. |

## Vetores de Tensão

| VT | Uso |
| --- | --- |
| Corpo | ataques físicos diretos e contato |
| Projétil | ataques físicos à distância |
| Manipulação | telecinese, alteração de seres, objetos ou relações |
| Irradiação | auras, olhares, sons, campos e presença |
| Territorial | ataques cujo alvo principal é ambiente, região ou Dobra |

## Ponto de Costura

| Componente | Descrição |
| --- | --- |
| Manifestação narrativa | sinal que pode ser observado antes de compreender a fragilidade |
| Condição de descoberta | pistas, estudo, testemunha ou experiência necessária |
| Condição de acesso | ação, posição, ritual ou escolha que permite tocá-la |
| Consequência | redução de PP, RD, VT, Reações, Habilidade, território ou possibilidade de Selagem |

Resolver uma Costura reduz normalmente entre 25% e 35% da Pressão funcional da ameaça. A forma dessa perda deve corresponder ao conceito. Uma Costura pode retirar uma Reação, expor PP, impedir regeneração, desfazer território ou permitir que a ameaça seja Selada.
