---
title: "Livro de Regras — CAPÍTULO 15 ~ NARRAR TESSITURA DO VAZIO"
node_type: "rule"
summary: "Seção “CAPÍTULO 15 ~ NARRAR TESSITURA DO VAZIO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 15 ~ NARRAR TESSITURA DO VAZIO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 15 ~ NARRAR TESSITURA DO VAZIO","source_order":16,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 15 ~ NARRAR TESSITURA DO VAZIO

O Narrador não controla uma história pronta. Sustenta condições para que escolhas produzam uma forma que ninguém possuía antes da mesa.

A função do Narrador não é esconder a solução certa até que jogadores adivinhem seu pensamento. É construir um mundo que responde com coerência suficiente para que hipóteses possam ser testadas. O mistério nasce da distância entre sinal e relação, não da ausência arbitrária de informação.

A Urdidura oferece escala; Arden oferece matéria; as regras oferecem procedimento. Narrar consiste em escolher o ponto onde as três se encontram. Uma Dobra de Memória precisa existir em algum edifício, comunidade ou corpo. Esse lugar precisa ter história. As pessoas precisam desejar coisas que não dependam da chegada dos personagens. Somente então o conceito adquire um peso prático.

| A BELEZA PARTICIPA DO RISCO Mostre aquilo que funciona antes de ameaçá-lo. Uma cidade precisa ser mais que cenário de investigação; uma amizade precisa existir além da função de ser ferida; uma tecnologia precisa resolver problemas antes de falhar. O horror pesa porque o mundo possuía valor antes dele. |
| --- |

## Descobertas e preços

Toda sessão deve permitir que os personagens compreendam algo e pagar por essa compreensão de maneira proporcional ao que foi alcançado. O preço não precisa ser dano. Pode ser tempo, exposição, Vínculo, posição política, recurso, responsabilidade ou a perda de uma interpretação confortável.

A descoberta também não precisa ser a resposta total. Uma boa pista altera o que o grupo pode fazer. Uma boa revelação modifica a pergunta. Uma verdade que apenas confirma o que todos já sabiam pode construir atmosfera, mas não deve ocupar o lugar do movimento.

## O mundo comum funciona

Antes que algo falhe, mostre o que costumava funcionar. Uma estação tem operadores, ruídos reconhecíveis e horários. Um mosteiro possui cuidados, tarefas, discordâncias e memórias. Uma família sabe quem senta em cada lugar. O horror ganha forma quando a relação quebrada já tinha valor.

| COMECE PELA CONTINUIDADE A ameaça não precisa aparecer cedo. Mostre primeiro o caminho, a prática, o objeto ou o Vínculo que será pressionado. O grupo precisa saber o que existe para perceber o que deixou de existir do mesmo modo. |
| --- |

## Procedimento de cena

1 ~ Defina o que cada força presente deseja preservar, obter ou impedir.

2 ~ Apresente o ambiente e as relações que já estão funcionando.

3 ~ Introduza uma alteração capaz de ser percebida, ainda que não compreendida.

4 ~ Permita ações sem exigir que o grupo descubra a explicação correta primeiro.

5 ~ Aplique consequências que nasçam do método usado, não de uma punição genérica.

6 ~ Termine com mudança: informação, posição, Tensão, Vínculo, ameaça ou decisão.

## Módulos de cena alternativos

Nem toda tensão precisa adquirir a forma do combate. Os módulos abaixo usam o mesmo princípio de Progresso e Pressão dos Testes Prolongados, mas acrescentam posições e rastros próprios. Eles são molduras, não minijogos separados: Perícias, Habilidades, Tramas, animais, perigos e Costuras continuam funcionando normalmente.

## Perseguição

Uma perseguição termina quando um lado alcança o objetivo antes que o outro reorganize a distância. Registre quatro posições: Encostado, Próximo, Distante e Fora de Alcance. O perseguidor tenta aproximar; o perseguido tenta afastar, ocultar-se ou alcançar um destino. A cada ciclo, ambos os lados escolhem ações e enfrentam o mesmo obstáculo por métodos diferentes.

| Ação | Teste comum | Efeito |
| --- | --- | --- |
| Avançar | Atletismo, Condução, Acrobacia ou Mobilidade da Ameaça | Sucesso move uma posição a favor; excepcional move duas. Falha recebe Pressão |
| Criar obstáculo | Engenharia, Sobrevivência, Pontaria, Artes ou Trama | O outro lado precisa superar a DT ou perde posição e recebe Pressão. |
| Tomar atalho | Investigação, Percepção, Ciências ou conhecimento local | Reduz uma etapa, mas falha aproxima perigo ou fecha rota. |
| Ocultar rastro | Furtividade, Intrusão, Encenação ou Trama | Em Distante, sucesso pode levar diretamente a Fora de Alcance; falha aumenta o Rastro. |
| Proteger alguém | Fortitude, Tática, Medicina ou Vínculo | Impede que uma consequência retire aliado, veículo ou recurso da cena. Mas nenhum avança. |

Use 4 Pressões como limite comum. Ao alcançá-las, o lado sofre uma mudança: veículo perde função, rota fecha, alguém fica para trás, a perseguição entra em território hostil ou o objetivo muda. Ataques durante a perseguição consomem a ação do ciclo e não substituem automaticamente a disputa de posição.

## Furtividade e infiltração

Infiltração não deve depender de um único teste capaz de apagar toda a cena. Registre um Rastro de Exposição de 0 a 4. Ações coerentes avançam objetivos; falhas, demora, testemunhas, mecanismos e consequências aumentam o Rastro. O grupo pode continuar depois de ser percebido parcialmente, mas o lugar passa a responder.

| Ação | Função | Preço comum |
| --- | --- | --- |
| Avançar | Atravessar zona, porta, guarda ou mecanismo | Falha aumenta o Rastro e muda posição |
| Observar | Descobrir rotina, rota, cobertura ou autoridade | Consome tempo ou aproxima o Compasso |
| Distrair | Mover atenção sem remover a presença | Cria obrigação, ruído ou testemunha |
| Encobrir | Reduzir em 1 o Rastro quando a ficção permitir | Abandona pista, recurso ou posição |
| Corrigir | Reparar falha de aliado, documento ou equipamento | Divide consequência e usa Reação ou ação própria |

Em Rastro 1, algo foi notado; em 2, o local investiga; em 3, rotas e pessoas mudam; em 4, a infiltração se transforma em fuga, contenção, interrogatório, combate ou negociação. O grupo não perde automaticamente a missão: perde o direito de continuar sob as mesmas condições.

## Testes e autoridade

O Narrador define quando existe risco, escolhe DT e descreve consequências. O Jogador descreve a intenção e abordagem, propõe Atributo e aceita que cada abordagem produza um tipo diferente de rastro. Quando houver dúvida, privilegie a combinação que cria decisões mais claras, não a que preserva uma interpretação secreta da regra.

Antes de rolar, todos devem compreender ao menos o objetivo e o risco imediato. Consequências ocultas podem existir, mas não transforme todo teste numa armadilha de informação que o personagem teria pequenas condições de perceber.

## Segurança e intensidade

Horror depende de confiança. Antes da campanha, o grupo define temas proibidos, temas que permanecem fora de cena e sinais para pausar ou reduzir intensidade. Durante o jogo, qualquer pessoa pode solicitar mudanças sem precisar justificar uma experiência pessoal.

A pressão deve recair sobre personagens e relações ficcionais. Surpreender jogadores com conteúdo que recusariam não torna a história mais profunda. Apenas remove a base que permitiria atravessar temas difíceis com segurança.

## Consequências permanentes

Permanência não significa que toda falha precisa deixar mutilação, Marca ou catástrofe. Significa que a história registra mudanças importantes. Uma instituição lembra da intervenção. Um Selo precisa de manutenção. Um NPC revê Convicção. Uma região aprende um novo costume. O personagem não recupera automaticamente a interpretação que possuía antes da verdade.
