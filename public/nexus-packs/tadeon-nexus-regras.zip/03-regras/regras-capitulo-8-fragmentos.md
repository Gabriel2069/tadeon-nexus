---
title: "Livro de Regras — CAPÍTULO 8 ~ FRAGMENTOS"
node_type: "rule"
summary: "Seção “CAPÍTULO 8 ~ FRAGMENTOS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 8 ~ FRAGMENTOS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 8 ~ FRAGMENTOS","source_order":9,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 8 ~ FRAGMENTOS

Um Fragmento é uma relação que não conseguiu terminar de voltar.

Fragmentos aproximam a Canalização porque carregam um caminho já aberto. Essa facilidade é também uma limitação: o retalho não oferece fios neutros. Ele conhece uma maneira específica de existir e conduz toda Trama por essa forma. Utilizar um Fragmento é aceitar ajuda de algo que não sabe separar auxílio, memória e tentativa de completar-se.

Por isso, o objeto nunca deve ser reduzido ao bônus que concede. Forma, origem, Selo e comportamento informam como pode ser transportado, quem o reconhece e que sinais deixa no mundo. Um Fragmento capaz de repetir vozes pode servir a investigações, comunicação ou fraude; também pode construir, lentamente, uma comunidade que já não sabe quais frases foram pronunciadas por pessoas vivas.

Quando uma Dobra se desfaz de maneira incompleta, o Reflexo recupera grande parte de sua forma, mas um retalho do padrão permanece separado da malha original. Esse retalho conserva tensão, organização e Assinatura suficientes para continuar existindo. Não é bateria, prisão ou item mágico. É uma cicatriz materializada.

## Estado e Selo

Fragmento ~ Vidro da Última Janela

Uma lâmina de vidro amarelado conserva o reflexo de tudo que foi visto pela última pessoa a morrer diante dela. É Conhecimento ~ Memória ~ testemunho sem sucessor, Categoria II. Selada, mostra apenas pequenas alterações de luz. Ao sustentar Tramas de revelação, reduz custo e DT, mas todo efeito aparece pela perspectiva limitada de alguém que acreditava estar vendo pela última vez. Se perder Integridade, rostos ausentes começam a permanecer no reflexo depois que o observador se afasta.

| Estado | Consequência |
| --- | --- |
| Selado | Possui borda estável. Não produz Pulsos comuns, não perde Integridade por tempo e pode ser transportado em contenção adequada. |
| Não selado | Dispersa sinais e pequenas Dobras, perde estabilidade e reage com maior intensidade ao uso. |

O Selo funciona como bainha: define onde o Fragmento termina e impede que seus fios continuem se desfazendo nas bordas. Selar não remove a Assinatura nem torna o objeto inofensivo. Apenas oferece um limite.

## Categoria e Integridade

| Categoria | Integridade máxima | Limite seguro |
| --- | --- | --- |
| I | 3 | Repuxo |
| II | 6 | Tração |
| III | 10 | Estiramento |

Usar um Fragmento dentro do Limite Seguro não consome Integridade. Forçá-lo uma intensidade acima perde 1 Integridade. Sacrifícios maiores podem ampliar a Trama conforme decisão do Narrador. Em Integridade 0, o padrão se desfaz e o Fragmento deixa de existir.

## Assinatura

A Assinatura registra como a Dobra anterior organizou seus fios. A classificação recomendada é Natureza ~ Domínio ~ padrão específico. “Conhecimento ~ Memória ~ arquivo que recusa apagamento” informa mais que chamar o objeto apenas de Fragmento de Memória.

| Natureza | Domínios ou expressões frequentes |
| --- | --- |
| Medo | Eclis, Morae, Thyren, Zha’el e aproximações do Primeiro. |
| Conhecimento | Memória, Significância, Linguagem, Alma e padrões da Chama Fria. |
| Tempo | “Fluxo”: repetição, atraso, sobreposição, lacuna e sequência. |

## Usar um Fragmento compatível

~ reduz a DT de Canalização em 2;

~ reduz o custo inicial em 1 PE, mínimo 1;

~ reduz em 1 a Tensão produzida por falha, mínimo 0;

~ obriga a expressão da Trama a carregar a Assinatura do Fragmento.

Um Fragmento incompatível reduz o custo de PE, mas não concede demais benefícios. Quando os padrões entram em conflito direto, o Narrador pode aplicar +2 DT, +1 Tensão ou ambos.

## Identificação

| Método | Resultado |
| --- | --- |
| Observação | Reconhece anomalias e sinais externos, sem definir Categoria ou Assinatura. |
| Canalização DT 12 + Categoria | Revela Natureza, Domínio, estado do Selo e Limite Seguro. |
| Estudo em Interlúdio | Revela Categoria, Integridade, padrão específico e reduz em 1 a DT do primeiro uso posterior. |
| Análise completa ERU + Canalização DT 18 + Categoria | Registra todas as propriedades e condições conhecidas de restauração ou dispersão. |

## Selar um Fragmento

| Elemento | Regra |
| --- | --- |
| Tempo | Atividade Principal de Interlúdio; em emergência, 2 Ações Completas consecutivas. |
| Teste | ERU + Canalização, DT 15 + 2 × Categoria. |
| Custo | PE da intensidade correspondente à Categoria e 1 PS por Categoria. |
| Modificadores | -2 com referência da mesma Assinatura; +3 se não identificado; +5 se abaixo de metade da Integridade. |
| Sucesso | Fragmento Selado. |
| Falha | Perde 1 Integridade e permanece instável. |
| Desastre | Perde metade da Integridade e produz Refluxo Comum ou Severo. |

## Dispersão deliberada

| Categoria | Resultado |
| --- | --- |
| I | Expressão intensa da Assinatura e Refluxo Severo. |
| II | Expressão ampla, alteração ambiental temporária e Refluxo Severo. |
| III | Evento de escala narrativa. O Narrador determina a consequência; nenhuma tabela garante contenção. |

Destruir um Fragmento é uma escolha permanente. A realidade pode produzir outro retalho semelhante. Não produzirá novamente aquela mesma história.

## O ciclo de um Fragmento

Um Fragmento pode atravessar a campanha inteira sem permanecer o mesmo objeto. É encontrado instável, identificado, Selado, utilizado, forçado, negociado, integrado a outro Selo ou deliberadamente dispersado. Cada etapa muda quem sabe de sua existência e que relações dependem dele.

A Integridade não mede apenas durabilidade física. Um cristal pode permanecer intacto e perder Integridade porque sua Assinatura foi puxada além do limite. Uma folha pode rasgar sem perder Integridade caso o padrão continue distribuído entre os fragmentos. Reparar o suporte não restaura automaticamente a malha; restaurar a malha pode exigir materiais que nunca fizeram parte do suporte original.

O Narrador deve registrar três coisas além da ficha: quem deseja o Fragmento, que prática permite contê-lo e o que o mundo perde quando ele deixa de existir. Assim, utilizar Integridade torna-se uma decisão de campanha, não apenas qualquer consumo de recurso.
