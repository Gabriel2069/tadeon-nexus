---
title: "Livro de Regras — CAPÍTULO 3 ~ TESTES"
node_type: "rule"
summary: "Seção “CAPÍTULO 3 ~ TESTES” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 3 ~ TESTES"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 3 ~ TESTES","source_order":4,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 3 ~ TESTES

Os dados entram quando a continuidade da cena já não consegue decidir sozinha o que acontece.

Um teste é uma pergunta feita à situação, não uma pergunta sobre o valor da personagem. Falhar em Medicina não prova que alguém é um mau médico; pode indicar falta de tempo, instrumento inadequado, um corpo alterado por Eclis ou a decisão de salvar uma pessoa quando duas precisavam de cuidado. O resultado pertence ao encontro entre capacidade e circunstância.

A rolagem tem função porque a mesa ainda não sabe qual consequência surgirá. Quando todos já conhecem a resposta, os dados apenas atrasam. Quando nenhuma consequência foi preparada, os dados produzem ruído. Antes de pedir um teste, o Narrador deve conseguir imaginar pelo menos duas formas diferentes de a cena continuar.

O motor escolhe uma abordagem, mede sua capacidade e devolve consequência à ficção.

## Quando rolar

O Narrador solicita um teste quando existe incerteza real e quando mais de um resultado possível pode alterar a cena. Uma ação não precisa de teste apenas por ser difícil. Se o personagem possui tempo, meios e capacidade suficiente, o procedimento pode ser resolvido sem rolagem.

~ Não role quando a falha apenas faria a cena parar.

~ Não role para esconder informação indispensável à continuação.

~ Não role repetidamente até que alguém obtenha o resultado que a história precisava desde o início.

~ Role quando sucesso, preço, atraso, exposição ou agravamento produzirem caminhos diferentes.

## Mecânica central

Escolha um Atributo e uma Perícia. Role uma quantidade de d20 igual ao Atributo, escolha o maior resultado e some o bônus do grau de treino. Se o total igualar ou superar a DT, a ação tem sucesso.

| FÓRMULA POOL DE d20 DO ATRIBUTO + MAIOR RESULTADO + BÔNUS DA PERÍCIA + MODIFICADORES |
| --- |

Calcule o Pool efetivo somando o Atributo e as Vantagens e subtraindo as Desvantagens. Com resultado 1 ou maior, role essa quantidade de d20 e escolha o maior. Com resultado 0, ro le 2d20 e escolha o menor; com -1, role 3d20 e escolha o menor; com -2, role 4d20 e escolha o menor, e assim por diante. Assim, Atributo 0 com uma Vantagem usa 1d20, enquanto uma Desvantagem aprofunda o risco em vez de produzir o mesmo pool.

Dificuldades de referência

| DT | Escala | Exemplo |
| --- | --- | --- |
| 10 | Simples sob pressão | Uma tarefa conhecida em condições desfavoráveis. |
| 15 | Desafiadora | Exige treino, atenção ou bom Atributo. |
| 20 | Complexa | Exige especialização, preparação ou circunstância favorável. |
| 25 | Extrema | Continua difícil mesmo para Versados. |
| 30 | Além do limite comum | Precisa de ajuda, equipamento, Trama, Ponto de Costura ou condição extraordinária. |

## Margens e resultados

Margem não precisa ser calculada com precisão quando a diferença é óbvia, mas torna os resultados mais expressivos. Um sucesso que apenas alcança a DT cumpre a intenção principal. Uma margem ampla revela domínio, oportunidade ou economia. Da mesma forma, uma falha próxima mantém parte do avanço, enquanto uma Ruptura permite que outra força ocupe o espaço aberto pela tentativa.

O Narrador não precisa escolher sempre entre sucesso total e fracasso. Muitas ações interessantes mudam a relação entre objetivo e preço. O personagem abre a comporta, mas perde a ferramenta dentro do mecanismo. Consegue convencer o oficial, mas agora ele acredita que ele lhe deve um favor. Encontra a pista completa, mas a Dobra percebe que foi reconhecida. Esses resultados não enfraquecem a competência; mostram que o mundo também age.

| Resultado | Leitura |
| --- | --- |
| 20 natural | Sucesso crítico em uma ação possível. O efeito principal ocorre e recebe benefício extraordinário adequado à cena. |
| DT +10 ou mais | Sucesso excepcional, o personagem consegue mais, mais rápido, com menor custo ou com informação adicional. |
| Igual ou acima da DT | Sucesso. A intenção principal é cumprida. |
| Abaixo da DT por 1 a 4 | Falha próxima. A ação pode avançar com preço, resultado parcial ou posição pior. |
| Abaixo por 5 ou mais | Falha com consequência. A intenção não se cumpre como planejado e algo novo pressiona a cena. |
| Abaixo por 10 ou mais | Ruptura. A falha altera a situação de forma grave, abre oportunidade a outra força ou agrava um risco existente. |
| 1 natural | Desastre. Além da falha, surge uma consequência coerente com os meios usados e o risco assumido. |

O 20 natural não cria meios que não existem. Ele não permite que alguém atravesse uma parede sem ferramentas, recorde uma informação que nunca conheceu ou sobreviva indefinidamente sem ar. Dentro do que é possível tentar, representa a melhor relação que aquela ação poderia encontrar.

Leitura de uma margem

Toman tenta atravessar uma ponte de manutenção durante uma tempestade. A DT é 15. Com 14, ele não simplesmente “não atravessa”: alcança o centro, mas uma placa se desprende e o retorno deixa de ser seguro. Com 9, a estrutura cede antes que chegue ao ponto de apoio e a cena muda para resgate. Com 25, atravessa rápido o bastante para perceber que os cabos vibram num ritmo que não pertence ao vento.

## Tipos de teste

| Tipo | Procedimento |
| --- | --- |
| Padrão | Uma rolagem resolve a ação e suas consequências imediatas. |
| Prolongado | A ação exige sucessos acumulados. Falhas aumentam risco, tempo ou desgaste. |
| Encadeado | Etapas diferentes usam Perícias ou Atributos diferentes. Cada resultado modifica a etapa seguinte. |
| Contestado | Todos os envolvidos rolam. O maior total vence; empate favorece quem preservava a situação anterior. |
| Conjunto | Uma pessoa lidera. Cada ajudante realiza teste apropriado: sucesso concede +1, excepcional +2, até +6 total. |
| Forçado | Antes de rolar, gaste 2 PE para receber Vantagem. Se falhar, sofre 1d4 PV ou PS conforme a natureza do esforço. |

Testes prolongados

Testes Prolongados são úteis quando a tarefa precisa ocupar um espaço dramático. O objetivo não é pedir a mesma rolagem várias vezes, e sim permitir que diferentes personagens alterem o problema por ângulos distintos. Progresso mede a aproximação do objetivo. Pressão mede tudo que a ação está oferecendo ao risco enquanto continua.

Defina a quantidade de Progresso necessária, normalmente de 3 a 8. Um sucesso concede 1 Progresso; um sucesso excepcional concede 2. Falhas acumulam Pressão. Quando a Pressão alcança o limite definido pelo Narrador, a ação termina, muda de forma ou cobra um preço inevitável.

| EXEMPLO Para reparar uma válvula central durante uma inundação, o grupo precisa de 5 Progresso antes de acumular 3 Pressões. Engenharia pode realizar o reparo; Atletismo pode manter uma comporta; Tática pode organizar auxiliares. Todos contribuem para o mesmo problema sem realizar a mesma ação. |
| --- |

## Uma sequência de testes em jogo

O grupo entra numa estação de comunicação depois que todas as mensagens transmitidas por ela passaram a chegar com a mesma assinatura. O Narrador não pede Percepção imediatamente. Primeiro descreve o que qualquer pessoa notaria: prismas giram sem vento, técnicos deixaram ferramentas no chão e uma frase continua acesa na lâmina da recepção.

Iria examina o mecanismo com ERU + Engenharia. Supera a DT por 3: descobre que nenhuma peça está quebrada e que o movimento vem da própria pressão da linha. Sora usa PRE + Diplomacia para interrogar a supervisora. Falha por 2. A supervisora revela que mensagens semelhantes já ocorreram, mas exige que o grupo entregue os registros ao governo local antes de sair. A pista foi obtida; o preço criou uma obrigação.

Toman tenta abrir a câmara central com COR + Intrusão. A DT é 20 porque a porta está pressurizada. Ele falha por 7. A trava não se abre e a pressão é desviada para outra ala, iniciando um Teste Prolongado para impedir que o sistema se rompa. A falha não significa que Toman se tornou incapaz de abrir portas. Significa que escolheu força diante de um mecanismo que respondia à força de maneira perigosa.

Durante o Teste Prolongado, Engenharia reconfigura válvulas, Atletismo mantém uma alavanca e Tática organiza os técnicos. A variedade não é decoração. Cada sucesso muda a situação de forma diferente. Quando o grupo alcança o Progresso necessário, a estação volta a uma pressão segura, mas a frase luminosa foi substituída por um nome que apenas Iria reconhece.
