---
title: "Livro de Regras — CAPÍTULO 14 ~ DOBRAS E SELAGEM"
node_type: "rule"
summary: "Seção “CAPÍTULO 14 ~ DOBRAS E SELAGEM” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 14 ~ DOBRAS E SELAGEM"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 14 ~ DOBRAS E SELAGEM","source_order":15,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 14 ~ DOBRAS E SELAGEM

O mundo não se rompe de uma vez. Primeiro, uma relação deixa de retornar exatamente ao lugar onde costumava caber.

A anatomia das Dobras transforma a cosmologia em procedimentos sem reduzi-la a fenômenos e a uma única escada de perigo. Prega, Bolsão e Ancoragem descrevem movimentos da malha. Pré-Furo, Furo, Âncora, Zona e Revérbero descrevem estados que exigem respostas diferentes. Reconhecer o estado correto é parte da investigação porque determina o que ainda pode ser devolvido e o que já precisa ser integrado ou cercado.

A progressão não é inevitável. Intervenção, perda de fonte, Selagem ou pacificação podem alterar o caminho.

A Urdidura explica a natureza das Dobras. Este capítulo se encarrega de apresentar procedimentos. Uma Dobra é a alteração da disposição habitual de uma malha. Prega, Bolsão e Ancoragem descrevem seus movimentos; Pré-Furos, Furos, Âncoras, Zonas e Revérberos, estados reconhecíveis no Reflexo.

## Escala estrutural

| Movimento | Estado | Descrição |
| --- | --- | --- |
| Prega | Pré-Furo | O Véu cede e sofre pressão, mas não existe passagem estável. |
| Bolsão | Furo I a III | A Dobra atravessa o Véu e ocupa o Reflexo sem fixação completa. |
| Ancoragem | Âncora I a III | A malha local passou a sustentar a Dobra por relações próprias. |
| Territorialização | Zona de Aspecto | A região começa a aceitar a lógica do Domínio como condição local. |
| Estabilização | Revérbero | A Dobra permanece sem Tensão ativa, natural ou pacificada por Selagem. |

## Estágios

| Estágio | Sinais | Tensão máxima antes de avançar | Resolução comum |
| --- | --- | --- | --- |
| Pré-Furo | incoerências pequenas, sinais sem padrão completo | 4 | prevenção ou Selagem simples |
| Furo I | passagem leve, manifestações breves | 4 | fechar |
| Furo II | efeitos recorrentes, presença ativa | 4 | fechar com diagnóstico |
| Furo III | passagem crítica, tentativa de fixação | 4 | impedir Ancoragem |
| Âncora I | centro reconhecível e retorno de efeitos | 4 | conter ou pacificar |
| Âncora II | território local reorganizado | 4 | cercar e separar relações |
| Âncora III | o lugar preserva parte da malha estrangeira | 4 | operação extensa ou pacificação |
| Zona de Aspecto | região territorializada | expande em vez de avançar | reduzir, isolar ou reconquistar |
| Revérbero | padrão estável, sem progressão espontânea | — | estudar, manter ou usar com cautela |

## Tensão da Dobra

| Tensão | Estado |
| --- | --- |
| 0 | Estável dentro do estágio atual. |
| 1 | Pressionada. Sinais e Pulsos tornam-se mais frequentes. |
| 2 | Saturada. Efeitos ambientais persistem. |
| 3 | À beira de agravamento. Uma falha relevante pode ser suficiente. |
| 4 | Avança um estágio; Zona expande ou aprofunda no território. |

## Pulso

Uma Dobra pulsa quando recebe pressão: entrada de personagens, falha crítica, Canalização local, violação de Costura, passagem de tempo ou decisão do Narrador. Role 1d6 e some o modificador do estágio.

| Estágio | Mod. |
| --- | --- |
| Pré-Furo | +0 |
| Furo I | +1 |
| Furo II | +2 |
| Furo III | +3 |
| Âncora I | +4 |
| Âncora II | +5 |
| Âncora III | +6 |
| Zona | +7 |

| Resultado | Pulso |
| --- | --- |
| 1~3 | Eco sensorial: sinal, pista ou alteração sem dano direto. |
| 4~5 | Pressão local: 1d4 PS ou +3 DT numa ação ligada ao ambiente. |
| 6~7 | Manifestação menor: condição leve, distorção ou pista metafísica. |
| 8~9 | Manifestação ativa: ameaça menor, Fragmento instável ou alteração persistente. |
| 10~11 | Agravamento: +1 Tensão e efeito ambiental forte. |
| 12+ | Resposta profunda: +2 Tensão, Refluxo ambiental ou manifestação maior. |

## Pontos de Costura

Ponto de Costura não é a fraqueza secreta colocada para que o grupo derrote o fenômeno. É a relação sem a qual aquela forma de permanência deixaria de fazer sentido. Pode ser material, histórica, linguística, temporal ou humana. Descobri-la não obriga que seja destruída. Algumas Costuras precisam ser reconhecidas, cumpridas, transferidas, contraditas ou cuidadas.

Dobra completa ~ A Casa que Termina o Luto

Uma residência tornou-se Âncora depois que três gerações repetiram o mesmo funeral para uma pessoa cujo corpo nunca foi encontrado. A manifestação faz novos moradores receberem lembranças da família e impede que portas externas sejam reconhecidas durante a noite. O Ponto de Costura não é o retrato nem o sino usado no rito. É a obrigação de que alguém continue esperando. Queimar a casa dispersaria parte da malha, mas espalharia o padrão pelos objetos retirados. A Selagem exige encontrar quem foi perdido, provar a morte ou construir uma despedida que a família aceite como continuidade diferente da espera.

Ponto de Costura é a relação específica que permite à Dobra continuar existindo daquela maneira. Não existe lista universal de quatro respostas. Memória, Significância, Linguagem e Alma são lentes diagnósticas úteis, mas uma Dobra pode depender de objeto, rotina, promessa, posição, ausência, sequência, vínculo, segredo ou contradição.

| Componente | Pergunta |
| --- | --- |
| Manifestação | Como a dependência aparece antes de ser compreendida? |
| Descoberta | Que pistas permitem reconhecê-la? |
| Acesso | O que precisa acontecer para que possa ser alterada? |
| Ação | Que escolha, ritual, destruição, restituição ou vínculo toca a Costura? |
| Consequência | O que a Dobra perde, transforma ou revela depois? |

## Três etapas da Selagem

1 ~ Diagnóstico

Identifique estágio, Natureza, Domínio, Assinatura, Tensão, território e Pontos de Costura. Cada Costura essencial não resolvida acrescenta +3 à DT de Tecitura ou impede resultado definitivo.

2 ~ Tecitura do Selo

O líder realiza Canalização. Outros personagens podem contribuir por Teste Conjunto usando Engenharia, Convicção, Ciências, Linguagem, ritual, proteção ou ação específica determinada pelo diagnóstico.

3 ~ Fixação

O Selo precisa ser ligado a relações capazes de sobreviver ao momento da operação: arquitetura, prática, calendário, comunidade, objeto, registro, manutenção ou Vínculo. Um símbolo sem relação não sustenta a borda.

## DT e Cargas de Selagem

| Estágio | DT base | Cargas necessárias |
| --- | --- | --- |
| Pré-Furo | 12 | 2 |
| Furo I | 15 | 3 |
| Furo II | 18 | 5 |
| Furo III | 21 | 7 |
| Âncora I | 22 | 8 |
| Âncora II | 25 | 10 |
| Âncora III | 28 | 12 |
| Zona | Operação por objetivos | definida pelo território |

Cada sucesso na Tecitura concede 1 Carga; sucesso excepcional ou 20 natural, 2. Falha adiciona 1 Pressão à operação; falha por 5+, 2 Pressões. Em 4 Pressões, ocorre um Pulso e a Pressão retorna a 0. O grupo escolhe Retomar, perdendo metade das Cargas acumuladas, arredondada para cima, ou Transformar, conservando as Cargas e aceitando mudança na forma, Permanência, preço ou Alcance do Selo determinada pelo Pulso.

## Resultado

| Fenômeno | Resultado possível |
| --- | --- |
| Pré-Furo | Aliviar pressão e recompor continuidade. |
| Furo | Fechar a passagem e devolver a Dobra para além do limite atravessado. |
| Âncora | Conter, separar relações, cercar território ou pacificar em Revérbero. |
| Zona | Reduzir, isolar e reconquistar por objetivos sucessivos. |
| Revérbero | Não precisa ser apagado. Exige compreensão, manutenção e limites de uso. |

Furos se fecham. Âncoras se cercam. Zonas se reconquistam. Revérberos permanecem.

## Permanência

Selos possuem Permanência, normalmente entre 3 e 12. Perdem pontos apenas quando algo narrativamente relevante altera a relação que os sustenta: abandono, sabotagem, mudança territorial, Canalização incompatível, ruptura da prática ou ação da própria Dobra.

| Fenômeno | Permanência-base |
| --- | --- |
| Pré-Furo / Furo I | 3 |
| Furo II / Furo III | 5 |
| Âncora I | 6 |
| Âncora II | 8 |
| Âncora III | 10 |
| Revérbero ou resposta territorial profunda | 12 |

Fixação excepcional acrescenta +1. Resolver todas as Costuras essenciais acrescenta +1. Permanência nunca ultrapassa 12. O valor não mede apenas resistência material: registra quantas perturbações relevantes a relação consegue atravessar antes de deixar de sustentar o Selo.

| Manutenção | Teste | Resultado |
| --- | --- | --- |
| Simples | Perícia apropriada DT 15 | Recupera 1 Permanência; falha não altera, mas revela problema. |
| Completa | Canalização ou procedimento definido, DT do estágio | Recupera 1d4; excepcional recupera 1d4+1 ou reforça Costura. |
| Falha grave | — | Perde 1 Permanência e pode produzir Pulso. |

## Dobras como fonte

| Fonte | Benefício | Risco |
| --- | --- | --- |
| Pré-Furo | -1 DT em Repuxo | +1 DT de resistência pessoal ao contato |
| Furo I | -2 DT em Repuxo | Pulso em falha |
| Furo II | -2 DT até Tração | +1 Tensão em falha grave |
| Furo III | -3 DT até Tração | +1 Tensão em qualquer falha |
| Âncora aberta | -3 a -5 DT até Estiramento | falha aumenta Tensão e pode alterar Costura |
| Âncora contida | -2 DT, intensidade limitada | falha reduz Permanência |
| Revérbero | -1 DT em Trama compatível | incompatível +2 DT; desastre produz Pulso residual |

## Expressões por Domínio

| Domínio | Sinais | Efeitos comuns |
| --- | --- | --- |
| Eclis | dor fantasma, crescimento, cicatrização excessiva, carne em matéria inerte | Machucado, Sangrando, doença, alteração de corpo |
| Morae | nomes trocados, espelhos borrados, lembranças sem autoria | dano de PS, Confuso, perda temporária de reconhecimento |
| Thyren | sombras sem fonte, espaços fora do foco, ausência ativa | Trevas, Desorientado, ocultação, falhas de percepção |
| Zha’el | vozes acusatórias, marcas, arquitetura de julgamento | Abalado, Compelido, custos ligados a culpa ou valor |
| Memória | passado sobreposto, objetos que recordam, repetição de lembrança | pistas, memórias intrusas, dano de PS |
| Significância | símbolos com peso, promessas que alteram ambiente | bônus ou restrições por sentido, Costuras fortalecidas |
| Linguagem | palavras em superfícies, nomes que alteram, silêncio ativo | Silenciado, compulsão verbal, necessidade de nome correto |
| Alma | vínculos perceptíveis, solidão material, lugares que reconhecem | PA, Convicção, relações como defesa ou alvo |
| Fluxo | repetição, anacronismo, relógios contraditórios | Descompassado, perda de Reação, ações fora de ordem |

## Operação completa de Selagem

O grupo retorna à Casa que Termina o Luto depois de descobrir sua Costura. A Âncora possui Tensão 3 e Permanência suficiente para resistir a uma resposta improvisada. Diagnóstico confirma que o rito funerário não alimenta a manifestação por simbolismo genérico, mas porque cada repetição reafirma que a espera ainda está incompleta.

Na Tecitura, personagens dividem funções. Uma pessoa prepara o espaço e remove objetos que carregariam o padrão para fora. Outra conduz testemunhas e reconstrói a sequência do funeral. A canalizadora utiliza Linguagem para separar o nome da pessoa perdida da obrigação de esperar. Dalen oferece o registro de morte encontrado em um arquivo distante. Cada ação contribui para Progresso de formas diferentes; falhas aumentam Tensão ou produzem Pulso.

A Fixação exige algo que sobreviva ao grupo. A comunidade decide substituir o funeral anual por uma leitura pública dos nomes de todos que partiram sem corpo recuperado. A Eclésia oferece o lugar e calendário; a família aceita entregar o sino ao arquivo. O Selo não funciona porque o novo rito é “mais correto”. Funciona porque oferece continuidade capaz de carregar a perda sem repetir a espera.

Meses depois, abandonar a prática poderia reduzir Permanência. A Selagem terminou como operação, mas o Selo continua como relação social. Essa diferença separa fechar um efeito durante a sessão de construir uma resposta que o mundo consegue sustentar depois dela.
