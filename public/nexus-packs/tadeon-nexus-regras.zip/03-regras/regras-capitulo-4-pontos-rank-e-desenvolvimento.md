---
title: "Livro de Regras — CAPÍTULO 4 ~ PONTOS, RANK E DESENVOLVIMENTO"
node_type: "rule"
summary: "Seção “CAPÍTULO 4 ~ PONTOS, RANK E DESENVOLVIMENTO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 4 ~ PONTOS, RANK E DESENVOLVIMENTO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 4 ~ PONTOS, RANK E DESENVOLVIMENTO","source_order":5,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 4 ~ PONTOS, RANK E DESENVOLVIMENTO

Exposição não torna alguém invulnerável. Torna mais extensa a quantidade de relações que consegue sustentar antes de falhar.

O desenvolvimento em Tessitura do Vazio não transforma uma pessoa numa categoria diferente de ser. Personagens experientes continuam possuindo corpos que sangram, vínculos que podem ser perdidos e decisões que nenhum valor realiza por elas. O que cresce é o repertório: mais formas de agir, mais capacidade de reconhecer padrões, mais recursos para permanecer funcional diante de experiências que antes encerrariam a participação na cena.

Rank registra essa transformação sem presumir que ela é regular. Os intervalos de cinco pontos são marcos, não semanas de treinamento. Um avanço pode representar meses de prática ou uma única noite que reorganizou para sempre aquilo que o personagem consegue perceber. O Narrador concede Rank quando a campanha produziu exposição, aprendizado e consequência suficientes para justificar outra camada de capacidade.

A curva amplia recursos de forma contida. O crescimento decisivo acontece em PM, Habilidades, Atributos e acesso.

## Rank

Rank mede exposição acumulada ao Além-Véu, experiência operacional e transformação. Começa em 0 e avança em intervalos de 5 por marcos narrativos confirmados pelo Narrador. Não representa apenas tempo de serviço: alguém pode passar anos próximo da Ordem e permanecer em Rank baixo, enquanto uma sequência extraordinária de crises produz mudanças em poucos meses.

Chegar acima de Rank 75 é raro. Esses personagens já atravessaram experiências suficientes para que habilidade, acesso e identidade tenham se tornado difíceis de separar. Rank 100 não é a expectativa de uma campanha; é um limite para histórias em que alguém permaneceu jogável depois de tocar quase tudo que o sistema consegue medir.

| Rank | PV base | PS base | PE base | PA base | DEF base | PM recebido | PM total |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 15 | 13 | 5 | 0 | 10 | 0 | 0 |
| 5 | 16 | 14 | 5 | 0 | 10 | 5 | 5 |
| 10 | 18 | 15 | 6 | 0 | 10 | 5 | 10 |
| 15 | 19 | 16 | 6 | 0 | 10 | 5 | 15 |
| 20 | 21 | 17 | 7 | 1 | 10 | 5 | 20 |
| 25 | 22 | 18 | 7 | 1 | 11 | 7 | 27 |
| 30 | 24 | 19 | 8 | 1 | 11 | 7 | 34 |
| 35 | 25 | 20 | 8 | 1 | 11 | 7 | 41 |
| 40 | 27 | 21 | 9 | 2 | 11 | 7 | 48 |
| 45 | 28 | 22 | 9 | 2 | 11 | 7 | 55 |
| 50 | 30 | 23 | 10 | 2 | 12 | 9 | 64 |
| 55 | 31 | 24 | 10 | 2 | 12 | 9 | 73 |
| 60 | 33 | 25 | 11 | 3 | 12 | 9 | 82 |
| 65 | 34 | 26 | 11 | 3 | 12 | 9 | 91 |
| 70 | 36 | 27 | 12 | 3 | 12 | 9 | 100 |
| 75 | 37 | 28 | 12 | 3 | 13 | 11 | 111 |
| 80 | 39 | 29 | 13 | 4 | 13 | 11 | 122 |
| 85 | 40 | 30 | 13 | 4 | 13 | 11 | 133 |
| 90 | 42 | 31 | 14 | 4 | 13 | 11 | 144 |
| 95 | 43 | 32 | 14 | 4 | 13 | 13 | 157 |
| 100 | 45 | 33 | 15 | 5 | 14 | 13 | 170 |

## Fórmulas

| Valor | Fórmula |
| --- | --- |
| PV máximo | PV base + COR × 3 + modificadores |
| PS máximo | PS base + MEN × 3 + modificadores |
| PE máximo | PE base + PRE × 2 + modificadores |
| PA máximo | PA base + ERU + modificadores |
| DEF | DEF base + INS + armadura + modificadores |
| Carga | 2 × COR + 5 Espaços |

## O que cada valor registra

Os recursos abaixo não são substâncias invisíveis presentes no corpo. São escalas de jogo. Cada uma escolhe uma continuidade que precisa ser acompanhada separadamente porque suas perdas produzem decisões diferentes. Recuperar PV não recompõe confiança. Recuperar PS não fecha um ferimento. PA não substitui nenhum dos dois; adia ou absorve a pressão metafísica por meio de relações às quais o personagem ainda consegue retornar.

| Valor | Função |
| --- | --- |
| PV ~ Vitalidade | Quanto dano físico o corpo suporta antes de entrar em Morrendo. |
| PS ~ Sanidade | Quanto a percepção, a memória, o corpo e a identidade ainda concordam sobre o que é real e sobre quem vive essa realidade. PS não mede diagnóstico ou estabilidade moral. |
| PE ~ Energia | Esforço disponível para Canalização, habilidades e ações que excedem a capacidade comum. |
| PA ~ Ancoragem | Reserva de relações internas e externas que absorve efeitos diretos do Além-Véu antes que atinjam outros recursos. |
| PM ~ Maestria | Pontos permanentes recebidos em cada avanço. PM gastos permanecem gastos. |
| DEF ~ Defesa | Valor que um ataque precisa igualar ou superar para acertar. |

Gastando PA

Gaste 1 PA para realizar uma destas ações:

~ absorver 1 ponto de Tensão causada por Refluxo ou exposição forçada;

~ reduzir em 1d6 um dano de PS causado por Trama, Fragmento ou Dobra;

~ impedir uma aplicação de condição energética ou metafísica;

~ manter um Vínculo funcional por uma cena quando um efeito tentaria apagá-lo, invertê-lo ou torná-lo inacessível.

Sempre que possível, nomeie a relação utilizada. PA não é uma camada abstrata de armadura: é o momento em que o personagem retorna a algo que ainda sabe reconhecê-lo.

## Gastando PM

PM é como escolha acumulada. A tabela foi construída para permitir personagens amplos sem tornar todos equivalentes em Ranks elevados. Comprar toda possibilidade continua impossível. Um personagem pode dominar diversas Perícias, atravessar mais de um Ramo e ainda assim preservar lacunas que tornam a cooperação relevante.

Gastar PM deve corresponder a algum desenvolvimento reconhecível. O jogo não exige cenas de treinamento para cada compra, mas a mesa deve conseguir imaginar de onde veio a capacidade: prática, orientação, sobrevivência, estudo, transformação ou convivência. Quando uma Habilidade parece surgir sem relação com nada vivido, talvez seja melhor registrá-la como objetivo do próximo Interlúdio antes de adquiri-la.

Treino de Perícias

| Grau adquirido | Rank mínimo | Custo |
| --- | --- | --- |
| Iniciado | 5 | 1 PM |
| Apurado | 25 | 2 PM |
| Versado | 50 | 3 PM |

O custo é pago para adquirir aquele grau depois do anterior. Tornar uma Perícia Versada custa 6 PM no total. Graus recebidos na criação ou por efeitos específicos não exigem PM.

Habilidades

| Tier | Rank mínimo | Custo |
| --- | --- | --- |
| I | 0 | 1 PM |
| II | 25 | 2 PM |
| III | 50 | 3 PM |
| IV | 75 | 4 PM |

Melhorias de recursos

| Melhoria | Custo inicial | Aumento por compra | Limite |
| --- | --- | --- | --- |
| +3 PV | 2 PM | +1 PM | 2 compras por Tier liberado |
| +2 PS | 2 PM | +1 PM | 2 compras por Tier liberado |
| +1 PE | 3 PM | +1 PM | 2 compras por Tier liberado |
| +1 DEF | 8 / 12 / 16 PM | — | Uma compra no Rank 25, outra no 50 e outra no 75 |

Tier I está disponível desde a criação; portanto, antes do Rank 25, o limite é de duas compras em cada recurso. Ao alcançar os Ranks 25, 50 e 75, o limite passa a quatro, seis e oito, respectivamente. DEF nunca recebe mais de +3 permanente por PM.

Aprimoramento de Atributos

Nos Ranks 25, 50, 75 e 100, o personagem recebe 1 Ponto de Atributo. Ele pode elevar um Atributo em 1, até o máximo de 5. Esses pontos não são PM e não podem ser transferidos, acumulados para comprar outra coisa ou obtidos por treinamento comum.

## Deslocamento

| Categoria | Distância por Ação de Movimento |
| --- | --- |
| Muito lento | 3 m |
| Lento | 4 m |
| Normal | 6 m |
| Ágil | 8 m |
| Muito ágil | 10 m |
| Excepcional | 12 m |
| Sobrenatural | 15 m |

O Deslocamento humano padrão é 6 m. Correr, nadar, escalar, atravessar terreno difícil ou carregar peso pode exigir Atletismo e modificar a distância.

## O que muda ao longo dos Ranks

| Rank 0 ~ Contato O personagem ainda interpreta a falha com categorias anteriores. Possui recursos limitados, Habilidades iniciais e depende fortemente de preparação, instrumentos e pessoas mais experientes. |
| --- |
| Rank 25 ~ Reconhecimento O personagem já viu padrões suficientes para saber que coincidência não explica tudo. Tier II, primeiro aumento de Atributo e repertório capaz de definir uma função própria dentro do grupo. |
| Rank 50 ~ Imersão A Tessitura deixou de ser assunto externo à biografia. Tier III, Perícias Versadas e capacidade de liderar operações que antes exigiam proteção ou supervisão. |
| Rank 75 ~ Transfiguração O personagem permanece humano, mas sua maneira de agir já não pode ser explicada apenas por treino comum. Tier IV, Transcendentes e acesso a procedimentos capazes de alterar Zonas, Fluxo ou manifestações elevadas. |
| Rank 100 ~ Ápice raro A campanha alcançou o limite em que experiência, instituição e transformação se confundem. Não significa invulnerabilidade. Significa que quase toda decisão mobiliza uma história extensa e consequências proporcionais. |

A passagem entre essas faixas deve aparecer na ficção. Pessoas reconhecem o nome do personagem, instituições oferecem ou negam acesso, Fragmentos respondem de maneira diferente e antigas escolhas retornam com outro peso. O avanço não é apenas uma linha na tabela; é a quantidade de mundo que agora sabe quem ele é.
