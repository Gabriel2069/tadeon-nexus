---
title: "Livro de Regras — PRÓLOGO"
node_type: "rule"
summary: "Seção “PRÓLOGO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["PRÓLOGO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"PRÓLOGO","source_order":1,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# PRÓLOGO

Tessitura do Vazio é um jogo de descobertas e preços. Seus personagens não são escolhidos por uma profecia, nem separados do restante da humanidade por alguma virtude anterior à história. São pessoas que viram uma continuidade falhar e, por razões que talvez ainda não compreendam, não conseguiram tratar a falha como um acidente.

Este livro ocupa o terceiro lugar de uma sequência. A Urdidura apresenta as relações anteriores ao mundo. Arden mostra o que essas relações sustentaram quando se tornaram história, território, ciência, fé e vida cotidiana. O Livro de Regras começa onde ambas encontram pessoas sentadas ao redor de uma mesa e precisam adquirir  mecânicas.

Por isso, sua escrita alterna duas necessidades. Quando uma regra exige precisão, a linguagem se fecha o bastante para que todos saibam o que acontece. Quando a regra toca uma escolha, identidade, perda ou transformação, ela volta a abrir espaço. Uma mecânica não serve apenas para decidir resultados. Em Tessitura do Vazio, ela também registra que tipo de relação foi pressionada para que aquele resultado pudesse existir.

O jogo possui três movimentos amplos. Primeiro, alguém existe: cria vínculos, carrega uma Marca, aprende a agir e escolhe o que pretende preservar. Depois, essa pessoa se conecta à Tessitura: Canaliza, sofre, investiga, luta, descansa e muda. Por fim, o Narrador transforma conceitos em cenas, ameaças, Dobras e campanhas capazes de continuar produzindo consequências depois que a primeira resposta foi encontrada.

## Da Urdidura à mesa

A Urdidura descreve uma realidade feita de relações. Arden mostra como essas relações se tornaram rio, corpo, cidade, fé, instituição e tecnologia. Este livro não repete nenhum dos dois. Ele responde a uma pergunta diferente: quando uma pessoa decide agir dentro desse mundo, o que a mesa precisa saber para que sua decisão tenha forma, limite e consequência?

A passagem entre conceito e regra não é uma redução. Uma regra não substitui a filosofia que a originou; oferece um modo compartilhado de tocá-la. Pontos de Vitalidade não encerram o corpo. Pontos de Sanidade não encerram a mente. Equilíbrio não mede a alma. Cada valor apenas escolhe uma parte da experiência que precisa permanecer legível quando várias pessoas imaginam a mesma cena e discordam sobre o que poderia acontecer em seguida.

Por isso, Tessitura do Vazio não trata a mecânica como uma segunda linguagem colocada sobre a narrativa. A mecânica é uma forma de memória. Ela registra que o personagem já foi ferido, que um Vínculo está sob pressão, que uma Trama puxou fios demais ou que uma ameaça continua presente porque sua Costura ainda não foi alcançada. Quando os números mudam, alguma relação também mudou. Quando nenhuma relação mudou, talvez não houvesse motivo para rolar.

| LEITURA EM CAMADAS As explicações longas existem para revelar a intenção e o lugar de cada regra. Quadros, tabelas e referências existem para que essa intenção possa ser usada sem interromper a cena. Leia o texto para compreender; consulte os resumos para conduzir. |
| --- |

| PRINCÍPIO CENTRAL Uma rolagem só deve ocorrer quando o resultado puder modificar a cena. Quando a história precisa de uma informação para continuar, o teste não decide se ela será encontrada. Decide quanto custará encontrá-la, quão completa será a compreensão e o que perceberá a aproximação dos personagens. |
| --- |

## Como usar este livro

Este livro pode ser lido em ordem, mas não exige que todas as suas regras sejam introduzidas na primeira sessão. Personagens podem começar sem Canalização, Fragmentos ou contato institucional. O Narrador pode apresentar cada camada quando a história oferecer motivo para que ela exista.

| Bloco | Pergunta que responde | Capítulos |
| --- | --- | --- |
| I ~ O Jogador | Quem é esta pessoa e de que maneira consegue agir? | 1 a 8 |
| II ~ A Conexão | O que acontece quando suas capacidades encontram risco, vínculo e Além-Véu? | 9 a 14 |
| III ~ A Prática | Como o Narrador transforma conceitos em pessoas, ameaças e campanhas? | 15 a 19 |
| Apêndices | Que informação precisa ser consultada sem interromper a cena? | Referências rápidas |

## Vocabulário essencial

| Termo | Uso neste livro |
| --- | --- |
| Jogador | Pessoa que interpreta um personagem e participa das decisões da história. |
| Narrador | Pessoa que apresenta o mundo, interpreta suas respostas e aplica as consequências. |
| Personagem | Ser conduzido por um Jogador. |
| NPC | Pessoa ou ser conduzido pelo Narrador. |
| Ser | Qualquer presença tratada pelas regras como capaz de agir ou resistir. |
| Cena | Unidade narrativa em que espaço, objetivo e tensão permanecem reconhecíveis. |
| Rodada | Medida de tempo usada em conflitos. Reúne um turno de cada participante. |
| Pool | Conjunto de d20 rolados num teste antes que o maior ou menor seja escolhido. |
| DT | Dificuldade que precisa ser igualada ou superada. |
