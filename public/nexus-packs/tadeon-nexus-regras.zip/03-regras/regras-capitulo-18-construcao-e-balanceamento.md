---
title: "Livro de Regras — CAPÍTULO 18 ~ CONSTRUÇÃO E BALANCEAMENTO"
node_type: "rule"
summary: "Seção “CAPÍTULO 18 ~ CONSTRUÇÃO E BALANCEAMENTO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 18 ~ CONSTRUÇÃO E BALANCEAMENTO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 18 ~ CONSTRUÇÃO E BALANCEAMENTO","source_order":19,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 18 ~ CONSTRUÇÃO E BALANCEAMENTO

O orçamento mede pressão. O conceito decide onde essa pressão precisa existir para parecer inevitável.

Construir uma Ameaça começa antes do CP. Primeiro escreva uma frase que descreva o que ela faz ao mundo. Depois escolha a experiência que deve produzir na mesa. Somente então distribua números. Quando o orçamento vem primeiro, habilidades tendem a parecer peças independentes; quando o conceito vem primeiro, cada compra reforça a mesma lógica.

Balanceamento oferece referência, não garantia. Terreno, objetivo, quantidade de corpos, informação disponível, composição do grupo e disposição para recuar alteram mais que um ponto isolado. O sistema procura impedir extremos matemáticos e oferecer durações prováveis. O Narrador continua responsável por ler a situação concreta.

## Cômputo de Pressão

Construção comentada ~ O Arquivista de Sal

Conceito: uma manifestação conserva documentos destruindo toda versão que contradiga o arquivo central. Magnitude VIII, ID IV, Arquétipo Manifestação. O CP é investido menos em dano e mais em RD, alcance de Irradiação, reação que apaga uma pista utilizada contra ela e habilidade que substitui uma lembrança por registro escrito. Seu Ponto de Costura é o primeiro documento aceito como verdadeiro sem testemunha. A investigação pode remover a reação e reduzir RD antes do confronto. Os números não criam o conceito; tornam operacionais as maneiras pelas quais ele insiste.

CP é a moeda de construção de Ameaças. Distribua o valor da Magnitude entre resistência, Vetores, dano, Alcance, mobilidade e Habilidades. O orçamento não substitui revisão: concentrações extremas são limitadas para impedir fichas matematicamente válidas e narrativamente inutilizáveis.

| Resistência | Custo |
| --- | --- |
| +6 PP | 1 CP |
| +1 DEF | 2 CP |
| RD universal | 1º ponto 2 CP; 2º 3; 3º 4; 4º 5; 5º 6; 6º 7 |
| +1 RD contra um tipo específico | 2 CP |
| +1 Reação | 8 CP |
| +1 VT | 1 CP |

| Impacto | Dano | CP |
| --- | --- | --- |
| I | 1d6 | 2 |
| II | 2d6 | 4 |
| III | 3d6 | 6 |
| IV | 4d6 | 9 |
| V | 5d6 | 12 |
| VI | 6d6 | 16 |

| Alcance | Custo | Dimensão de referência | Usos comuns |
| --- | --- | --- | --- |
| Engajado | 0 CP | Um alvo ou ponto a até 1,5 m. | Golpes corporais, toque, agarrão, emissão imediata. |
| Próximo | 1 CP | Um alvo ou ponto a até 6 m. | Projétil curto, voz dirigida, Trama breve, membro alongado. |
| Distante | 2 CP | Um alvo ou ponto a até 20 m. | Disparo, feixe, ordem sobrenatural, ação à distância comum. |
| Longo | 4 CP | Um alvo ou ponto a até 50 m. | Precisão de campo, artilharia leve, percepção ou Trama ampliada. |
| Extremo | 6 CP | Um alvo ou ponto a até 150 m; exige linha de visão, marca ou meio definido. | Tiro de precisão, comunicação dirigida, ataque de grande campo. |
| Cone curto | 2 CP | Cone de 6 m, com cerca de 3 m de largura no extremo. | Sopro, grito, descarga frontal, varredura de membros. |
| Cone longo | 4 CP | Cone de 12 m, com cerca de 6 m de largura no extremo. | Onda expansiva, iluminação, emissão ou varredura ampla. |
| Linha curta | 2 CP | Linha de 12 m por 1,5 m. | Feixe, jato, investida reta, corte territorial. |
| Linha longa | 4 CP | Linha de 24 m por 1,5 m. | Descarga sustentada, perfuração de campo, passagem destrutiva. |
| Raio pequeno | 3 CP | Raio de 3 m centrado na fonte ou num ponto a até 6 m. | Cápsula, impacto localizado, ruptura de piso, convocação breve. |
| Raio médio | 5 CP | Raio de 6 m centrado na fonte ou num ponto a até 20 m. | Onda de pressão, campo de alteração, emissão coletiva. |
| Raio grande | 8 CP | Raio de 9 m centrado na fonte ou num ponto a até 20 m. | Pulso de grande cena, colapso de estrutura, manifestação ampla. |
| Aura curta | 2 CP | Raio de 3 m ao redor da fonte ou de um alvo vinculado. | Presença, proteção, contaminação ou pressão que acompanha seu centro. |
| Aura ampla | 5 CP | Raio de 6 m ao redor da fonte ou de um alvo vinculado. | Domínio móvel, influência coletiva, proteção ou desgaste próximos. |
| Corrente | 4 CP | Um alvo a até 20 m e até três saltos; cada salto alcança 6 m. | Descarga, contágio, memória compartilhada, propagação por relação. |
| Cena | 10 CP | Todos os alvos válidos numa cena claramente delimitada, normalmente até 20 m de raio. | Somente Habilidades de Complexidade III+ e Ameaças de Magnitude IX+. |
| Território | 15 CP | Edifício, quarteirão, instalação ou região definida pela ficção. | Somente Pulsos, Zonas ou Habilidades de Complexidade IV+; não é ataque comum. |

| ALCANCE NÃO DESCREVE DURAÇÃO Aura, Cena e Território descrevem onde o efeito alcança quando é resolvido. Para permanecer, repetir-se, mover-se independentemente, criar uma zona perigosa ou alterar regras locais, o efeito também precisa de duração e de uma Habilidade com Complexidade apropriada. Alcance tampouco exclui aliados, escolhe alvos ou concede novas ativações sem que a ficha diga isso. |
| --- |

| Mobilidade | Custo | Regra |
| --- | --- | --- |
| +3 m | 1 CP | Aumenta em 3 m um modo de movimento já possuído. Pode ser comprado repetidamente. |
| Escalada | 1 CP | Move-se em paredes, inclinações e superfícies verticais no Deslocamento normal, sem teste em condições comuns. Tetos exigem Habilidade ou propriedade Aderente. |
| Natação | 1 CP | Move-se na água no Deslocamento normal e não realiza testes em corrente comum. Não concede respiração submersa. |
| Voo | 5 CP | Move-se livremente em três dimensões usando o Deslocamento indicado. Pode permanecer parado no ar, salvo limitação escrita na ficha. Barreiras e cobertura continuam existindo. |
| Deslocamento por Costura | 4 CP | Entra e emerge por uma relação contínua — sombra conectada, tubulação, escrita, tecido orgânico, reflexo ou outro meio definido. Percorre até seu Deslocamento e não atravessa Selos ou interrupções do meio. Não é teleporte. |
| Teleporte curto | 6 CP | Move-se até 6 m para espaço livre que consiga perceber ou localizar pela própria Assinatura. Ignora caminho, Terreno Difícil e Reações, mas não atravessa barreira selada. |
| Teleporte médio | 10 CP | Como o Teleporte curto, com alcance de até 20 m. Pode exigir linha de visão, marca ou condição descrita na ficha. |

| Complexidade de Habilidade | CP |
| --- | --- |
| I | 2 |
| II | 4 |
| III | 7 |
| IV | 11 |
| V | 16 |

## Limites de compra

| Categoria | Limite |
| --- | --- |
| PP adicional | até 50% dos PP base |
| DEF adicional | máximo +4 |
| RD | máximo 2 nas Magnitudes I~IV; 3 em V~VIII; 4 em IX~XII; 5 em XIII~XVI; 6 em XVII~XX |
| Reações | no máximo uma além do valor base |
| VT | máximo 5 + metade da Magnitude, arredondada para cima |
| Impacto | I~III até II; IV~VII até III; VIII~XI até IV; XII~XV até V; XVI~XX até VI |
| Habilidade | I~III até Complexidade I; IV~VII II; VIII~XI III; XII~XV IV; XVI~XX V |

## Potencial Operacional

PO é ponto de partida para uma equipe em condições razoáveis, mas não é promessa de vitória. O ID desloca o encontro conforme preparo; múltiplas ameaças ampliam economia de ações; Ponto de Costura pode reduzir Pressão; objetivos diferentes de eliminar todos os oponentes mudam completamente a duração esperada.

Ao testar uma construção, observe três perguntas: a Ameaça consegue apresentar sua identidade antes de cair; o grupo possui decisões além de repetir o maior dano; e a investigação produz diferença mensurável. Se a resposta for negativa, o problema pode estar no desenho mesmo quando os números parecem corretos.

PO estima a Magnitude de referência de um encontro para determinado grupo. Ele não determina resultado, apenas oferece o ponto de partida.

| FÓRMULA PO = RANK MÉDIO × FATOR DA EQUIPE |
| --- |

| Participantes | Fator |
| --- | --- |
| 2 | 0,65 |
| 3 | 0,82 |
| 4 | 1,00 |
| 5 | 1,15 |
| 6 | 1,28 |
| 7 | 1,40 |

| PO | Magnitude de referência |
| --- | --- |
| 0~4 | I |
| 5~9 | II |
| 10~14 | III |
| 15~19 | IV |
| 20~24 | V |
| 25~29 | VI |
| 30~34 | VII |
| 35~39 | VIII |
| 40~44 | IX |
| 45~49 | X |
| 50~54 | XI |
| 55~59 | XII |
| 60~64 | XIII |
| 65~69 | XIV |
| 70~74 | XV |
| 75~79 | XVI |
| 80~84 | XVII |
| 85~89 | XVIII |
| 90~94 | XIX |
| 95+ | XX |

A Magnitude de referência nunca pode ser inferior ao número de participantes ativos, independentemente do Rank. Isso evita que uma equipe pareça enfrentar referência menor depois de avançar de Rank e corrige a zona em que valores baixos de PO ainda não representam sua economia de ações.

## Leitura do encontro

| Diferença | Resultado esperado |
| --- | --- |
| -1 | Leve. A equipe possui vantagem estrutural. |
| 0 | Equilibrado. Decisões, recursos e Costura definem o resultado. |
| +1 | Difícil. Erros possuem um custo real. |
| +2 | Extremo. Confronto direto sem preparo não é recomendado. |
| +3 ou mais | A manifestação supera amplamente a equipe; exige Costura, alternativa ou objetivo parcial. |

## Múltiplas Ameaças

Some as Magnitudes como base. A economia de ações aumenta perigosamente quando muitas fichas independentes agem. Aplique o ajuste abaixo:

| Ameaças independentes | Ajuste à soma |
| --- | --- |
| 1 a 3 | nenhum |
| 4 a 5 | +1 Magnitude |
| 6 a 8 | +2 Magnitudes |
| 9 ou mais | +3 ou converta em Enxame |

Corpos representados por um único Arquétipo Enxame não contam separadamente.

## Construção passo a passo

1 ~ Defina o conceito: que relação foi alterada e que forma de presença nasceu disso?

2 ~ Defina o Abalo de Manifestação: o que precisa ser reconhecido, qual a resistência, o custo e como preparação altera o primeiro contato.

3 ~ Escolha Magnitude conforme a força desejada e a referência da equipe.

4 ~ Registre PP, DEF, Reações e CP base.

5 ~ Escolha o Arquétipo e aplique sua regra.

6 ~ Defina ID conforme investigação e preparo necessários.

7 ~ Distribua CP respeitando limites.

8 ~ Escolha Atributos e VT conforme o modo de agir.

9 ~ Escreva ataques, Habilidades e Reações.

10 ~ Crie o Ponto de Costura e suas consequências.

11 ~ Simule três Rodadas: a ameaça consegue agir, pressionar e revelar sua identidade sem encerrar a cena cedo demais?

12 ~ Se não, revise e faça ajustes com novos testes; Se sim, sua Ameaça está pronta!

## Referência ofensiva

| Rank da equipe | DEF típica | VT comum | Impacto comum |
| --- | --- | --- | --- |
| 0 | 13 | +5 | II |
| 25 | 16 | +8 | III |
| 50 | 18 | +10 | IV |
| 75 | 21 | +13 | V |
| 100 | 22 | +14 | VI |

Esses valores representam uma ameaça equilibrada e ofensiva. Arquétipos, Costuras, Alcance coletivo e controle alteram a dificuldade real. Uma ameaça não precisa atingir todos os limites ao mesmo tempo.

Uma Ameaça solitária de referência deve possuir ao menos duas formas de pressionar a Rodada: Alcance coletivo, campo persistente, Reação ofensiva, invocação, condição territorial ou Habilidade que produza uma segunda decisão sem equivaler a outro Turno completo. Sobreviver por várias Rodadas só é interessante quando esse tempo permite que sua identidade apareça.

## Duração esperada

Contra quatro personagens, uma ameaça única de referência tende a permanecer de duas a três Rodadas nos Ranks baixos, três a cinco nos intermediários e cinco a sete nos extremos. Costuras, Selagem e objetivos alternativos podem encerrar ou transformar o confronto antes de zerar PP.

## Ameaça completa ~ O Arquivista de Sal

O Arquivista de Sal nasce de uma Âncora de Memória e Significância num depósito jurídico inundado. Ele não deseja informação; deseja uma versão única. Documentos aceitos pelo arquivo tornam-se mais reais que testemunhas, corpos e objetos. Contradições perdem peso até desaparecerem da percepção institucional.

Magnitude VIII oferece força suficiente para dominar uma grande cena. ID IV indica que enfrentá-lo sem compreender a Costura será muito mais perigoso. Arquétipo Manifestação permite agir por meio de documentos, selos e paredes salinizadas, sem depender de um corpo único. O CP compra PP moderado, RD, Irradiação e uma Reação chamada Versão Oficial: quando alguém utiliza uma pista contra ele, pode apagar temporariamente uma cópia ou impor PS ao portador. Seu Abalo é Rupturante, DT 18: ele acontece quando um personagem percebe que o documento mais antigo não está apenas mentindo, mas substituindo aquilo que pessoas vivas conseguem afirmar. Conhecer a existência da Versão Oficial concede Vantagem; encontrar o primeiro testemunho apagado elimina o Abalo para quem participou da descoberta.

Seu ataque principal não é uma garra. É Retificação, VT de Manipulação contra DEF ou resistência apropriada, causando PS e condição em que o personagem só consegue declarar fatos presentes no arquivo. Um ataque físico existe, mas não representa sua identidade central. A habilidade de Complexidade III faz uma sala inteira aceitar o documento mais antigo como configuração atual.

O Ponto de Costura é o primeiro registro que recebeu autoridade sem qualquer testemunha: uma declaração produzida para encerrar uma disputa durante a Grande Pestilência. Encontrar as pessoas apagadas por esse registro reduz RD e remove a Versão Oficial. Reconstruir testemunho coletivo permite Selagem. Destruir o arquivo reduz PP, mas espalha cópias salinizadas pela água, criando outro tipo de problema.

A ficha funciona porque Magnitude, CP, ID, Arquétipo e Costura contam a mesma história. Se o Arquivista recebesse apenas muito dano e teleporte, poderia continuar equilibrado em números e ainda perder identidade.
