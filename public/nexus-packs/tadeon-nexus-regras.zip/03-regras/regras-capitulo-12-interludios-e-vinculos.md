---
title: "Livro de Regras — CAPÍTULO 12 ~ INTERLÚDIOS E VÍNCULOS"
node_type: "rule"
summary: "Seção “CAPÍTULO 12 ~ INTERLÚDIOS E VÍNCULOS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 12 ~ INTERLÚDIOS E VÍNCULOS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 12 ~ INTERLÚDIOS E VÍNCULOS","source_order":13,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 12 ~ INTERLÚDIOS E VÍNCULOS

Descansar é oferecer ao mundo relações suficientes para que alguém deixe de existir apenas em resposta ao perigo.

Interlúdio não é uma pausa fora da campanha. É sua parte em que consequências encontram tempo para adquirir um nome. Um personagem pode recuperar recursos numa noite de sono, mas compreender o que perdeu, pedir cuidado, reparar um instrumento ou reconhecer que um Vínculo mudou exigem cena. O sistema recompensa essas ações porque a continuidade também precisa ser praticada.

A qualidade de um Interlúdio não depende da extensão da atuação. Uma frase pode conter uma decisão inteira. Um jogador silencioso não recebe menos porque outra pessoa improvisa longos diálogos. Benefícios vêm de elementos verificáveis: aceitar ajuda, revelar algo, enfrentar Ferida, desenvolver Vínculo, mudar Convicção ou gastar tempo e recursos em cuidado.

Interlúdio é uma cena de recuperação, reorganização e desenvolvimento entre pressões maiores. Ele pode durar horas, dias ou semanas conforme a campanha. Sua função não é apenas restaurar pontos; é mostrar de que maneira o personagem tenta retornar a si e o que encontra quando retorna.

## Qualidade do Interlúdio

Interlúdio ~ o objeto reparado

Depois de uma missão, Toman não faz um discurso. Senta-se ao lado da irmã e repara em silêncio o relógio que pertencia ao pai. Quando termina, admite que o mecanismo parou na mesma hora em que ouviu a voz na estação. A cena desenvolve o Vínculo, revela informação e enfrenta a Ferida. Isso basta para produzir os benefícios apropriados, mesmo que tenha durado poucos minutos de mesa.

| Qualidade | Condição | Recuperação base |
| --- | --- | --- |
| Precário | perigo próximo, abrigo insuficiente, interrupção provável | 1d4 PV, 1d4 PS, metade do PE; 1 Atividade Secundária |
| Tranquilo | segurança razoável, alimento, cuidado e tempo | metade dos PV e PS perdidos, todo PE, 1 PA; 1 Atividade de cada |
| Profundo | local seguro, apoio, tratamento e atividade significativa | todos os PV e PE; metade dos PS perdidos; 2 Atividades de cada; 2 PA |
| Prolongado | dias ou semanas com infraestrutura e continuidade | recursos máximos; tratamento das condições tratáveis e de todas as Marcas da Morte; 3 Atividades Principais e 3 Secundárias; PA máximo. Marcas da Loucura não desaparecem por recuperação comum. |

## As quatro perguntas

1 ~ Onde o personagem tenta retornar a si?

2 ~ O que ela faz além de esperar o tempo passar?

3 ~ Com quem, com o quê ou com qual prática se conecta?

4 ~ O que precisa reconhecer para que a recuperação aconteça?

A cena recebe benefício narrativo quando contém ao menos um elemento objetivo: revelar algo importante, aceitar cuidado, desenvolver Vínculo, enfrentar Ferida, reafirmar ou mudar Convicção, pagar recurso, assumir responsabilidade ou reconhecer transformação. O benefício não depende de discurso longo ou atuação teatral.

## Atividades Principais

| Atividade | Efeito |
| --- | --- |
| Conexão | Recupere +1d6 PS ou 1 PA e altere o estado de um Vínculo quando a cena justificar. |
| Tratamento | Medicina remove uma condição física, recupera +1d6 PV e pode restaurar uma Marca da Morte. Apenas uma Marca pode ser removida por Interlúdio, salvo no Prolongado. |
| Treinamento | Prepare compra de Perícia, Proficiência ou Habilidade quando a campanha exigir justificativa. |
| Investigação | Estude pista, Fragmento, Selo ou arquivo e receba informação que exige tempo, não risco imediato. |
| Manutenção | Repare equipamento, Selo, veículo ou estrutura; restaure PD ou PP. |
| Ancoragem | Reduza 1 Tensão em direção a 0 e recupere 1 PA adicional. |

Todas as atividades que requerem testes utilizam uma versão amena da lógica de Margens de Sucesso.

## Atividades Secundárias

| Atividade | Efeito |
| --- | --- |
| Respiro | Escolha PV, PS ou PE: recupere +1d4 do recurso escolhido, sem ultrapassar o máximo. |
| Preparação de Ofício | Escolha uma Perícia e uma tarefa concreta. Receba +2 no primeiro teste diretamente ligado a ela antes do próximo Interlúdio. |
| Ajuste de Equipamento | Restaure 2 PD de um item, recarregue uma fonte simples com suprimentos ou prepare um consumível já possuído para saque imediato. |
| Conversa Breve | Escolha um Vínculo presente ou alcançável. Recupere 1 PA; se já estiver no máximo, receba +2 no primeiro teste realizado diretamente para agir com, por ou contra aquela relação. |
| Organização de Carga | Redistribua equipamentos e escolha um item de Espaço 1: até o próximo Interlúdio, ele conta como pronto e pode ser sacado como Ação Livre uma vez. |
| Registro e Recapitulação | Organize pistas, mapas ou anotações. Receba +2 na primeira ação de Investigação, Ciências ou Recapitulação que use esse material. |

## Vínculos em jogo

Cada Vínculo possui um estado e pode oferecer um benefício uma vez por sessão quando é invocado de maneira concreta. O Jogador explica como a relação participa da ação; o Narrador define se concede +1d20, 1 PA, informação, acesso ou outra vantagem equivalente.

Invocar um Vínculo também o expõe. Falhas graves, decisões contraditórias ou custo imposto pela ficção podem Tensioná-lo. Um Vínculo Ferido não oferece benefício até receber cuidado. Um Vínculo Rompido pode continuar produzindo pistas, inimigos, luto ou Significância, mas deixou de funcionar como apoio.

| VÍNCULO NÃO É MOEDA Não ameace todo Vínculo apenas porque foi usado. A relação precisa ter sido colocada em risco pela ação ou pela consequência. Caso contrário, jogadores aprenderão a não trazer para a história aquilo que deveria torná-la humana. |
| --- |

## Comida, sono e rotina

Refeições, higiene, oração, exercício, estudo, conversa e sono podem permanecer breves. Tornam-se uma cena quando revelam relação, contraste, mudança ou preparação. O cotidiano não é decoração antes do horror. É a forma pela qual o grupo reconhece o que ainda está tentando preservar.

## Um Vínculo ao longo da campanha

Dalen começa Tensionado com Iria. Ele acredita que ela aceitou rápido demais a explicação oficial para a morte da irmã. Durante uma investigação, Iria invoca o Vínculo para obter acesso às anotações de Rema. O benefício é a informação; a exposição é real, porque Dalen exige acompanhar o grupo.

Mais tarde, Iria esconde dele um Fragmento perigoso. A decisão contradiz a forma como vinha tentando reconstruir confiança e o Vínculo torna-se Ferido. Nenhuma rolagem social o devolve imediatamente. Num Interlúdio, ela revela o objeto e admite que repetiu a mesma lógica institucional que condenava. Dalen não precisa perdoá-la para que exista Costura. O Vínculo pode tornar-se Costurado com nova condição: ele participa de toda decisão sobre os registros da irmã.

Estados de Vínculo servem para lembrar que relações também possuem história. Não são uma trilha de afeição que sobe quando alguém recebe presentes. Uma Costura pode produzir vínculo menos confortável e mais verdadeiro.
