---
title: "Livro de Regras — CAPÍTULO 16 ~ NPCS E TESSITURA SOCIAL"
node_type: "rule"
summary: "Seção “CAPÍTULO 16 ~ NPCS E TESSITURA SOCIAL” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO 16 ~ NPCS E TESSITURA SOCIAL"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO 16 ~ NPCS E TESSITURA SOCIAL","source_order":17,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO 16 ~ NPCS E TESSITURA SOCIAL

Uma pessoa secundária para a trama continua sendo central para a própria vida.

NPCs não precisam de profundidade igual, mas todos precisam de direção suficiente para responder sem que o Narrador reinvente sua personalidade a cada fala. Convicção, Limite, procedimento e Relações oferecem essa direção. Estatísticas entram conforme a pessoa se torna operacionalmente relevante.

Tessitura Social existe porque vínculos também são estruturas de jogo. Confiança, dívida, proteção, rivalidade e medo produzem acesso, resistência e ruptura. Nenhuma dessas relações precisa ser saudável para ser forte. A regra registra a intensidade e estado; a narrativa que decide o valor.

## Classificação

| Classe | Uso | Detalhe mecânico |
| --- | --- | --- |
| Incidental | aparece brevemente e cumpre função local | nome, intenção e um Vetor de Competência |
| Secundário | retorna, possui relação ou obstáculo reconhecível | Convicção, Limite, pontos simplificados, dois Vetores |
| Operacional | atua em conflitos, investigação ou instituição | ficha resumida, recursos, Habilidades e Moral |
| Principal | possui arco, relações e transformação comparáveis às personagens | ficha completa adaptada, Tessitura Social e evolução |

NPC completo ~ Maela Vor

Maela é inspetora da Rede de Hélio. Convicção: informação pública não deve depender da boa vontade de casas privadas. Limite: jamais falsificar a origem de uma mensagem. Procedimento: isola o sistema, copia sinais, entrevista técnicos e só então acusa. Moral 4. Seu Vínculo mais forte é Proteção com a equipe de manutenção; sua maior Tensão é Rivalidade com a Casa que financia a torre. Quando uma transmissão impossível aparece, Maela não “entrega a missão”. Primeiro tenta impedir pânico, preservar os trabalhadores e manter os registros fora do alcance de quem já tentou comprá-la.

## Convicção e Limite

Convicção é aquilo que o NPC tenta preservar quando os procedimentos deixam de bastar. Limite é a ação que acredita não poder realizar sem deixar de reconhecer a si mesmo. Ambos podem mudar; a mudança precisa de acontecimento, não apenas de qualquer rolagem social alta.

| PERSUASÃO NÃO REESCREVE UMA PESSOA Um sucesso social pode revelar condição, criar confiança, oferecer razão ou mudar decisão compatível com Convicção e Limite. Para atravessar estruturas profundas, a cena precisa alterar as relações que as sustentam. |
| --- |

## Vetores de Competência

NPCs que não precisam de Perícias detalhadas usam Vetores. Role 1d20 + valor do Vetor contra DT ou DEF.

| Vetor | Abrange |
| --- | --- |
| Físico | força, resistência, trabalho corporal, combate próximo |
| Técnico | ciências, medicina, engenharia, condução, ofício |
| Perceptivo | atenção, intuição, rastreamento, iniciativa |
| Social | negociação, comando, mentira, reputação |
| Metafísico | Canalização, Temperança, Selagem, leitura de Assinatura |

| Nível | Bônus |
| --- | --- |
| Comum | +2 |
| Competente | +4 |
| Especialista | +6 |
| Excepcional | +8 |
| Lendário | +10 |

## Moral

Moral mede disposição para permanecer numa situação, não coragem abstrata. Quando um NPC sofre perda grave, vê o Limite ameaçado, fica isolado ou percebe que o objetivo se tornou impossível, teste Temperança, Convicção ou Vetor Social/Metafísico contra DT 10 a 25.

| Resultado | Resposta |
| --- | --- |
| Sucesso excepcional | mantém posição e pode reorganizar aliados próximos |
| Sucesso | continua agindo de acordo com o Procedimento |
| Falha próxima | hesita, recua ou exige nova condição para permanecer |
| Falha grave | foge, rende-se, rompe ordem ou age segundo Convicção acima do Procedimento |

## Tessitura Social

A Tessitura Social registra relações que continuam produzindo ações quando nenhum personagem ou jogador está presente. Seus elementos não formam uma matemática obrigatória; organizam causa, pressão e mudança.

| Elemento | Definição |
| --- | --- |
| Nós | pessoas, grupos, lugares, instituições, objetos ou causas que sustentam relações |
| Fios | tipo de relação entre dois Nós |
| Tensões | pressões que tornam a relação instável ou exigem escolha |
| Costuras | ações capazes de reforçar, transformar ou reparar o Fio |
| Rupturas | acontecimentos que alteram a relação de forma permanente |

| Fio | O que representa |
| --- | --- |
| Confiança | um acredita que o outro não o trairá, mesmo quando não controla a decisão |
| Proteção | um aceita custo para preservar o outro |
| Dependência | a continuidade de um Nó precisa do outro |
| Rivalidade | a presença de um muda como o outro mede a si mesmo |
| Respeito | algo no outro não pode ser ignorado, mesmo sem afeto |
| Medo | a possibilidade do que o outro fará altera decisões |
| Dívida | existe algo ainda não restituído |
| Admiração | um reconhece no outro uma forma de vida que deseja alcançar |

## Ficha resumida

| Campo | Conteúdo |
| --- | --- |
| Identificação | nome, função, aparência e presença |
| Convicção | o que preserva |
| Limite | o que não aceita fazer |
| Procedimento | como age enquanto a situação permanece dentro do esperado |
| Moral | o que a faz permanecer ou recuar |
| Vetores | áreas em que consegue agir |
| Recursos | PV, PS, PE, DEF e equipamentos quando relevantes |
| Relações | Nós e Fios mais importantes |
| Estado | ferimentos, condições, suspeitas e pressões atuais |

## Evolução

| Acontecimento | Possível mudança |
| --- | --- |
| Convicção confirmada por custo real | torna-se mais difícil de negociar, mas mais capaz de sustentar Moral |
| Limite atravessado | revisão de identidade, mudança de Procedimento ou Colapso |
| Vínculo construído | pode tornar-se Vínculo de personagem ou Nó central da campanha |
| Exposição prolongada | Marca, sensibilidade, Habilidade ou alteração de Equilíbrio |
| Fragmento adquirido | nova Assinatura, recurso e risco institucional |
| Responsabilidade assumida | recursos e deveres aumentam juntos |

## Evolução de NPCs

NPCs mudam quando acontecimentos alteram Convicção, Limite, Procedimento ou Fios sociais. Maela pode começar acreditando que preservar registros públicos justifica toda desobediência. Depois de divulgar uma mensagem contaminada que produz pânico, sua Convicção permanece, mas o Procedimento muda: passa a exigir testemunhas e análise antes de liberar informação. A evolução não precisa aumentar bônus.

Quando um NPC se torna Principal, não é necessário reconstruí-lo do zero. Expanda o que já existia. Converta Vetores em Atributos e Perícias apenas quando decisões detalhadas exigirem; preserve Convicção, Limite e Relações como centro. Estatísticas devem acompanhar a importância alcançada, não fingir que a pessoa não possuía capacidades antes de entrar em foco.
