---
title: "Livro de Regras — CAPÍTULO B ~ TABELAS CONSOLIDADAS"
node_type: "rule"
summary: "Seção “CAPÍTULO B ~ TABELAS CONSOLIDADAS” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO B ~ TABELAS CONSOLIDADAS"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO B ~ TABELAS CONSOLIDADAS","source_order":22,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO B ~ TABELAS CONSOLIDADAS

Valores reunidos para criação, avanço e construção.

## Rank

| Rank | PV | PS | PE | PA | DEF | PM recebido | PM total |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 15 | 13 | 5 | 0 | 10 | 0 | 0 |
| 5 | 16 | 14 | 5 | 0 | 10 | 5 | 5 |
| 10 | 18 | 15 | 6 | 0 | 10 | 5 | 10 |
| 15 | 19 | 16 | 6 | 0 | 10 | 5 | 15 |
| 20 | 21 | 17 | 7 | 1 | 10 | 5 | 20 |
| 25 | 22 | 18 | 7 | 1 | 11 | 7 | 27 |
| 30 | 24 | 19 | 8 | 1 | 11 | 7 | 34 |
| 35 | 25 | 20 | 8 | 1 | 11 | 7 | 41 |
| 40 | 27 | 21 | 9 | 2 | 11 | 7 | 48 |
| 45 | 28 | 22 | 9 | 2 | 11 | 7 | 55 |
| 50 | 30 | 23 | 10 | 2 | 12 | 9 | 64 |
| 55 | 31 | 24 | 10 | 2 | 12 | 9 | 73 |
| 60 | 33 | 25 | 11 | 3 | 12 | 9 | 82 |
| 65 | 34 | 26 | 11 | 3 | 12 | 9 | 91 |
| 70 | 36 | 27 | 12 | 3 | 12 | 9 | 100 |
| 75 | 37 | 28 | 12 | 3 | 13 | 11 | 111 |
| 80 | 39 | 29 | 13 | 4 | 13 | 11 | 122 |
| 85 | 40 | 30 | 13 | 4 | 13 | 11 | 133 |
| 90 | 42 | 31 | 14 | 4 | 13 | 11 | 144 |
| 95 | 43 | 32 | 14 | 4 | 13 | 13 | 157 |
| 100 | 45 | 33 | 15 | 5 | 14 | 13 | 170 |

## Magnitude

| Mag. | PP | DEF | Reações | CP |
| --- | --- | --- | --- | --- |
| I | 15 | 15 | 0 | 8 |
| II | 20 | 15 | 0 | 10 |
| III | 25 | 16 | 0 | 12 |
| IV | 31 | 16 | 1 | 15 |
| V | 38 | 17 | 1 | 18 |
| VI | 46 | 17 | 1 | 22 |
| VII | 55 | 17 | 1 | 26 |
| VIII | 65 | 19 | 1 | 31 |
| IX | 76 | 19 | 2 | 36 |
| X | 88 | 20 | 2 | 42 |
| XI | 101 | 20 | 2 | 49 |
| XII | 115 | 20 | 2 | 57 |
| XIII | 130 | 21 | 2 | 66 |
| XIV | 146 | 21 | 3 | 76 |
| XV | 163 | 21 | 3 | 87 |
| XVI | 181 | 22 | 3 | 99 |
| XVII | 200 | 23 | 3 | 112 |
| XVIII | 220 | 23 | 4 | 126 |
| XIX | 241 | 23 | 4 | 141 |
| XX | 263 | 23 | 4 | 158 |
