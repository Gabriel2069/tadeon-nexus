---
title: "Livro de Regras — CAPÍTULO C ~ GLOSSÁRIO MECÂNICO"
node_type: "rule"
summary: "Seção “CAPÍTULO C ~ GLOSSÁRIO MECÂNICO” de Livro de Regras, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "scroll-text"
aliases: ["CAPÍTULO C ~ GLOSSÁRIO MECÂNICO"]
tags: ["cânone","fonte-primária","regras"]
properties: {"canon_layer":"primary_source","source_document":"Livro de Regras ~ TdV(3).docx","source_section":"CAPÍTULO C ~ GLOSSÁRIO MECÂNICO","source_order":23,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/regras|Fonte — Livro de Regras]]. O conteúdo abaixo preserva a redação da seção de origem.

# CAPÍTULO C ~ GLOSSÁRIO MECÂNICO

Os termos abaixo são definidos pela função que cumprem no jogo.

Ação Completa ~ Ação que consome Padrão e Movimento.

Ancoragem ~ Movimento em que uma Dobra se fixa ao Reflexo.

Arquétipo ~ Pacote de comportamento e regra de uma Ameaça.

Abalo de Manifestação ~ Pressão de PS causada quando a forma verdadeira de uma Ameaça é reconhecida.

Alcance ~ Perfil espacial completo de ataque ou Habilidade; substitui a antiga separação de Área.

Assinatura ~ Padrão específico conservado por uma Dobra, Fragmento ou manifestação.

Âncora ~ Dobra fixada e sustentada por relações locais.

Canalização ~ Processo de aproximar, tracionar e tecer fios.

Carga ~ Espaços que um personagem consegue transportar.

Cego ~ Condição sensorial que impede ações puramente visuais e Mirar.

Colapso ~ Estado ao chegar a 0 PS.

Compasso de Urgência ~ Trilha que registra quando uma investigação mudará de condições.

Costura ~ Relação/arranjo/sequência que conecta partes distintas para sustentar uma continuidade, Trama ou Selo.

CP ~ Cômputo de Pressão usado para construir Ameaças.

DEF ~ Valor que ataques precisam igualar ou superar.

Descompassado ~ Condição de sequência temporal instável.

Dobra ~ Alteração da disposição habitual de uma malha.

Doente ~ Condição orgânica que reduz resistência e recuperação adicional.

DT ~ Dificuldade de um teste.

Equilíbrio ~ Inclinação pessoal entre Medo e Conhecimento.

Fragmento ~ Retalho de Dobra que não completou o retorno.

Furo ~ Dobra que atravessou o Véu sem fixação completa.

ID ~ Índice de Desafio; preparo e investigação necessários.

Inteireza ~ Estado de Equilíbrio 0.

Magnitude ~ Força estrutural de Ameaça.

Marca ~ Primeiro contato que tornou a falha impossível de ignorar.

Marca da Loucura ~ Consequência permanente de Colapsos.

Marca da Morte ~ Passo da trilha de Morrendo.

PA ~ Pontos de Ancoragem.

PE ~ Pontos de Energia.

Perigo Mundano ~ Risco ambiental ou biológico resolvido por Intensidade, DT e consequência, sem PP.

Permanência ~ Integridade de um Selo.

PM ~ Pontos de Maestria.

PO ~ Potencial Operacional de uma equipe.

Ponto de Costura ~ Relação que sustenta e dá forma a uma dobra, manifestação ou ameaça.

PP ~ Pontos de Permanência de Ameaça.

PS ~ Pontos de Sanidade.

Puxagem ~ Pressão exercida pelos fios sobre quem os aproxima; resistida por Temperança em toda Canalização.

PV ~ Pontos de Vitalidade.

Pulso ~ Resposta de uma Dobra sob pressão.

Rank ~ Exposição e experiência acumuladas.

Rastro de Exposição ~ Trilha de 0 a 4 usada em infiltrações.

RD ~ Resistência a Dano.

Refluxo ~ Retorno desorganizado de fios após Canalização.

Revérbero ~ Dobra estabilizada sem Tensão ativa.

Selo ~ Estrutura que oferece borda e continuidade.

Surdo ~ Condição sensorial que impede ações puramente auditivas e limita comunicação por som.

Tecitura ~ Ação de utilizar fios para formar (tecer) algo.

Tessitura ~ Conjunto de malhas e relações que se atravessam.

Tensão ~ Pressão acumulada numa personagem ou Dobra; trilhas distintas.

Trama ~ Padrão de fios produzido por Canalização.

Vetor de Competência ~ Versão abrangente das perícias; usados por NPCs.

Vínculo ~ Relação capaz de sustentar identidade e ação.

VT ~ Vetor de Tensão usado nos ataques de Ameaças.

Zona de Aspecto ~ Território reorganizado pela lógica de um Domínio.
