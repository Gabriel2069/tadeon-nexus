---
title: "Geografia de Veth — PEDOSFERA E RECURSOS GEOLÓGICOS"
node_type: "concept"
summary: "Seção “PEDOSFERA E RECURSOS GEOLÓGICOS” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["PEDOSFERA E RECURSOS GEOLÓGICOS"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"PEDOSFERA E RECURSOS GEOLÓGICOS","source_order":5,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# PEDOSFERA E RECURSOS GEOLÓGICOS

Solos, intemperismo e materiais primários

O solo parece imóvel porque sua transformação é pequena diante de um dia. Diante de um século, ele avança, perde, acumula e muda de composição como qualquer rio.

## FORMAÇÃO DOS SOLOS

Solo é rocha alterada, matéria orgânica, água, ar e vida reunidos em uma só estrutura. Sua formação começa quando minerais se fraturam, dissolvem ou reagem com a atmosfera. Raízes ampliam fissuras; fungos liberam ácidos; animais misturam camadas; cheias depositam sedimentos novos. A velocidade depende de temperatura, água, relevo, composição da rocha e tempo de estabilidade da superfície.

Intemperismo físico quebra rochas sem alterar sua composição. Ocorre por gelo em fissuras, expansão térmica, cristalização de sais e abrasão. Intemperismo químico transforma minerais por dissolução, oxidação e hidrólise. É rápido nos trópicos úmidos e lento em desertos frios. O intemperismo biológico atravessa ambos: organismos fragmentam, dissolvem, concentram e transportam material.

Um perfil de solo costuma possuir horizontes. A superfície recebe restos orgânicos; abaixo, a água remove certos compostos; mais fundo, argila, ferro ou sais se acumulam. O contato com a rocha pouco alterada encerra o perfil. Agricultura modifica essa organização por arado, irrigação, adubação e erosão. Uma terra fértil pode perder em décadas o que levou milênios para formar.

## GRANDES FAMÍLIAS DE SOLO

Os solos de pradaria de Grauth e Riosola possuem um horizonte escuro rico em matéria orgânica, formado por raízes de gramíneas que morrem e se renovam. Retêm nutrientes e água, mas compactam sob tráfego pesado. Solos aluviais do Han Ji, Netjer, Meduna e Soiena são jovens, estratificados e renovados por cheias. Sua fertilidade varia conforme a bacia de origem.

Nos trópicos úmidos de Verdania, chuva intensa remove bases e sílica, concentrando óxidos de ferro e alumínio. Esses solos podem parecer profundos e vermelhos, mas grande parte dos nutrientes circula na biomassa. Quando a floresta é removida, a fertilidade cai rapidamente e a superfície endurece. Várzeas e terras vulcânicas constituem exceções mais produtivas.

Regiões frias de Myrova e Nordhavn apresentam solos ácidos, com matéria orgânica pouco decomposta e horizontes lavados. O permaglacis impede drenagem e cria turfeiras. No Alvor, evaporação superior à chuva leva sais para a superfície. Irrigação sem drenagem transforma campos em crostas salinas. Solos vulcânicos de Yamashiro, Axum e Aotearoa retêm água e nutrientes, mas podem sofrer erosão rápida, quando recém-formados, por cinzas.

| Família | Regiões principais | Propriedades e limites |
| --- | --- | --- |
| Solos negros de pradaria | Grauth, Riosola, Calçada | férteis, profundos, sensíveis à compactação e erosão eólica |
| Aluviais jovens | Han Ji, Netjer, Meduna, Soiena | renovados por cheias, heterogêneos e produtivos |
| Tropicais lixiviados | Verdania, Colhara úmida, Kitomena | profundos, ácidos, nutrientes concentrados na biomassa |
| Vulcânicos | Yamashiro, Axum, Aotearoa, Huexotl | porosos, férteis, alta retenção de água, instáveis em encostas |
| Desérticos salinos | Alvor interior, Tlacua, Yawurua seca | pouca matéria orgânica, crostas e risco de salinização |
| Frios podzolizados | Myrova, Nordhavn, Frontier-Sud | ácidos, drenagem variável, decomposição lenta |
| Alpinos rasos | Valdmere, Rethmark, Tahuantinsuyu | pouco desenvolvidos, pedregosos, vulneráveis à perda |
| Recifais e calcários | Xochiatlalpan, Tyrenia, Qalat costeiro | alcalinos, drenagem rápida, pouca retenção de nutrientes |

## EROSÃO, DESERTIFICAÇÃO E SALINIZAÇÃO

Erosão torna-se degradação quando remove o solo mais rápido que sua formação. Chuvas intensas sobre encostas desmatadas abrem ravinas; vento retira partículas finas de campos secos; rios confinados deixam de depositar sedimento nas planícies e escavam o próprio leito. Terraços, coberturas vegetais e rotação reduzem as perdas, mas exigem manutenção contínua.

Desertificação não significa o simples avanço de dunas. É a redução da capacidade do solo de sustentar água e vegetação. Sobrepastoreio quebra crostas, remove cobertura e amplia a evaporação. Tlacua preserva rotas para evitar uso contínuo das mesmas áreas; Mansa e Yawurua alternam pastagem segundo as chuvas; fracassos políticos podem destruir esse equilíbrio sem que o clima mude.

Salinização acompanha a irrigação em regiões áridas. Água evapora e deixa sais. Se o lençol sobe, esses sais retornam à zona das raízes. Kemet mantém canais de drenagem e períodos de lavagem; Huexotl administra salinidade pela circulação entre lagos e chinampas; Qalat usa águas de qualidade diferente para impedir acumulação. O conhecimento surgiu de campos perdidos, bem antes de teorias abstratas.

## GEOLOGIA DOS RECURSOS

Recursos não são substâncias distribuídas ao acaso. Dependem dos processos capazes de concentrá-las. Magmas separam metais durante seu resfriamento; fluidos hidrotermais depositam veios; rios acumulam minerais densos; evaporação forma sais; bacias sedimentares preservam matéria orgânica; intemperismo remove alguns componentes e deixa outros.

A abundância econômica depende ainda de acesso, pureza e tecnologia. Ferro disperso em rocha comum não constitui minério. Um cristal de excelente qualidade sob montanha instável pode ser menos útil que depósito inferior próximo a porto. O Livro III trata de transformação e uso; esta seção descreve formação e localização.

## RETHITA DE RETHMARK

A rethita ocorre em camadas metamórficas atravessadas por fluidos ricos em sílica e metais leves. Sua estrutura lamelar surgiu quando minerais preexistentes re-cristalizaram sob a pressão orientada. Veios acompanham zonas de cisalhamento no Arco Central. Os melhores depósitos possuem lâminas contínuas, poucas inclusões e orientação capaz de ser preservada durante corte.

A mineração segue o mergulho das camadas e produz galerias longas. Água ácida dissolve metais associados e exige drenagem. Rejeitos finos podem cobrir rios e alterar o fluxo. A posição das minas explica disputas entre Rethmark, Grauth e Valdmere: o recurso não se distribui por fronteira política, mas por cinturão geológico.

## METAIS DO TRAMONTANA

Grauth possui ferro em formações sedimentares antigas e depósitos metamorfizados próximos ao Arco. Carvão mineral ocorre em bacias onde florestas pantanosas foram soterradas, embora não sustente a matriz energética principal. Cobre e chumbo aparecem em veios de Valdmere e Rethmark; estanho e prata concentram-se em intrusões de Albrath.

A metalurgia de precisão depende menos de minas enormes que de pureza controlada. Albrath importa ferro comum e reserva seus depósitos locais para elementos de liga e padrões. Myrova possui níquel, cobalto e minerais associados a basaltos do norte. A exploração é limitada por clima e distância.

## RECURSOS DO OCÍDUO

A Cordilheira Ocidental concentra cobre, estanho e prata em sistemas hidrotermais. Rios de Tahuantinsuyu transportam ouro secundário para cascalhos, onde pode ser separado por densidade. Colhara possui ferro e manganês em bordas de planalto. Huexotl reúne obsidiana, argilas vulcânicas e sais lacustres.

Verdania é menos importante por minérios metálicos que por diversidade biológica, argilas, resinas, fibras e compostos de origem viva. Seu substrato antigo contém bauxitas e ferro laterítico, mas a extração em floresta úmida produz custo ambiental elevado. Xochiatlalpan oferece calcário recifal, obsidiana antiga e recursos marinhos. Contigo possui bacias sedimentares profundas, óleo de organismos abissais, sal e depósitos costeiros renovados por rios.

## CRISTAIS E MINERAIS DO ALVOR

Yawurua concentra quartzo e sílica de alta pureza porque longos ciclos de intemperismo removeram minerais menos estáveis. Areias selecionadas por rios e vento fornecem matéria prima para o vidro óptico. Qalat possui hialino em pegmatitos e cavidades onde cristais crescem lentamente a partir de fluidos ricos em elementos luminescentes.

Kitomena produz Cristal Azul em veios metamórficos. Aotearoa fornece pounamu óptico em zonas de alta pressão e circulação hidrotermal. Axum possui basalto, ferro e minerais magnéticos. Kemet extrai calcário, granito, gipsita e sais do entorno do Netjer. O deserto concentra evaporitos, mas a ausência de água torna a extração difícil.

| Recurso | Formação geológica | Regiões principais |
| --- | --- | --- |
| Rethita | metamorfismo orientado em zonas de cisalhamento | Rethmark e borda do Arco Central |
| Ferro de alta qualidade | sedimentos antigos e metamorfismo | Grauth, Madzimbabwe, Axum |
| Cobre e estanho | veios hidrotermais e intrusões | Tahuantinsuyu, Valdmere, Mansa |
| Sílica óptica | intemperismo prolongado e seleção sedimentar | Yawurua |
| Hialino | pegmatitos e cavidades hidrotermais | Qalat |
| Cristal Azul | metamorfismo de baixa temperatura e fluidos | Kitomena |
| Pounamu óptico | metamorfismo de alta pressão | Aotearoa |
| Obsidiana | resfriamento rápido de magma rico em sílica | Yamashiro, Huexotl, Xochiatlalpan antiga |
| Óleo de profundidade | adaptações de fauna abissal e cadeias alimentares frias | Contigo |
| Sais e evaporitos | evaporação em bacias fechadas | Huexotl, Alvor interior, Yawurua seca |

| ANOTAÇÃO MARGINAL RECURSOS E FRAGMENTOS A presença de um Fragmento pode alterar corrosão, cristalização ou crescimento local, mas não deve ser usada como explicação geral para depósitos extensos. Veios que atravessam quilômetros exigem processo geológico. Quando uma anomalia metafísica existe, ela costuma modificar uma formação preexistente, não criá-la do nada. |
| --- |

PARTE VI
