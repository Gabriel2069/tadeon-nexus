---
title: "Geografia de Veth — O CORPO DE ARDEN"
node_type: "concept"
summary: "Seção “O CORPO DE ARDEN” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["O CORPO DE ARDEN"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"O CORPO DE ARDEN","source_order":1,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# O CORPO DE ARDEN

Órbita, matéria, atmosfera e medida planetária

Arden não oferece sua escala ao observador. Ela precisou ser reconstruída a partir de sombras, quedas, marés, estrelas e ondas que atravessam pedra.

## A MEDIDA DO PLANETA

Os primeiros cálculos do tamanho de Arden foram realizados por escolas de Kemet e Qalat a partir da diferença de sombra entre cidades alinhadas aproximadamente no mesmo meridiano. A precisão cresceu quando relógios albrathianos permitiram comparar o meio-dia local e quando expedições costeiras mediram arcos suficientemente longos para corrigir irregularidades do relevo. O valor aceito no ano 1.847 atribui ao planeta raio médio de aproximadamente 6.480 quilômetros. A forma não é uma esfera perfeita: a rotação produz leve alargamento equatorial e achatamento polar, diferença pequena na paisagem comum, mas suficiente para alterar cálculos astronômicos e rotas de longa distância.

A gravidade superficial média é de 9,87 metros por segundo ao quadrado. Varia discretamente com latitude, altitude e densidade das rochas. Instrumentos sensíveis detectam anomalias sobre grandes cadeias, bacias sedimentares e corpos minerais profundos. A variação não altera a experiência cotidiana, mas serve à prospecção e ao estudo da estrutura subterrânea. Em Yawurua, medições gravimétricas revelaram raízes antigas de montanhas desaparecidas; em Axum, indicaram a presença de material denso sob o planalto muito antes que a teoria do ponto quente fosse aceita.

A superfície de Arden distribui-se em aproximadamente sessenta e oito por cento de água e trinta e dois por cento de terras emersas. O valor oculta a concentração dessas terras. A maior parte se encontra em Veth, enquanto extensas porções do Mar de Fora permanecem sem massas continentais significativas. Essa assimetria permite correntes de longo percurso, amplia a influência oceânica sobre as costas e torna os mares internos mais importantes do que sua área sugeriria.

| Medida | Valor aceito | Observação |
| --- | --- | --- |
| Raio médio | 6.480 km | ligeiro achatamento nos polos |
| Gravidade superficial | 9,87 m/s² | varia com latitude, altitude e densidade subterrânea |
| Duração do dia | 24 h 11 min | medida pelo ciclo estelar, não pelo estelar aparente |
| Duração do ano | 365 dias, 7 h e 18 min | corrigida por intercalação no calendário da Concordância |
| Inclinação axial | 23,5° | responsável pela amplitude das estações |
| Superfície coberta por água | aprox. 68% | maior parte no Mar de Fora |
| Pressão média ao nível do mar | 1,03 atmosfera | variação sazonal e regional |

## ÓRBITA, ROTAÇÃO E ESTAÇÕES

Arden é o terceiro planeta de sua estrela e percorre uma órbita de baixa excentricidade. A distância varia o bastante para ser medida, mas pouco o suficiente para que as estações dependam sobretudo da inclinação axial de 23,5°. Quando o hemisfério norte se inclina em direção à estrela, recebe dias mais longos e luz mais direta; seis meses depois, a condição se inverte. A diferença orbital reforça levemente o verão austral e prolonga o verão setentrional, efeito perceptível em séries climáticas longas e quase irrelevante para um único ano agrícola.

O dia estelar dura vinte e quatro horas e onze minutos. O calendário civil arredonda o ciclo estelar em vinte e quatro horas, absorvendo a diferença em ajustes de relógio astronômico e tabelas de navegação. O ano contém pouco mais de trezentos e sessenta e cinco dias. Os calendários anteriores à Concordância resolveram o excesso de maneiras diferentes; o sistema atual acrescenta dias de correção segundo uma sequência de oito anos administrada pelos observatórios de Qalat. A regra parece distante da geografia, mas determina o alinhamento de registros de maré, floração, neve e migração. Um erro de calendário repetido por décadas pode transformar a comparação climática em ruído.

A rotação desvia massas de ar e água. Correntes que partem do equador não seguem diretamente aos polos, e ventos que descem das altas latitudes curvam-se antes de alcançar os trópicos. Esse desvio organiza giros oceânicos, cinturões de vento e parte da assimetria entre as costas orientais e ocidentais dos lobos. Os navegadores conheciam o efeito pela prática muito antes que os matemáticos o descrevessem. Suas rotas tradicionais preservam soluções para uma força cujo nome acadêmico surgiu depois.

## A ATMOSFERA

A atmosfera de Arden é composta principalmente por nitrogênio, oxigênio e uma fração menor de gases inertes, vapor de água e dióxido de carbono. A proporção média de oxigênio é próxima de vinte e um por cento, suficiente para sustentar combustão e metabolismo aeróbio sem tornar incêndios espontaneamente incontroláveis. A pressão ao nível médio do mar é levemente superior à unidade adotada pelas academias de Grauth, diferença que favorece a troca gasosa em baixas altitudes e acentua o contraste fisiológico acima de quatro mil metros.

A atmosfera não possui uma fronteira abrupta. Torna-se menos densa com a altitude, alterando pressão, temperatura e capacidade de reter água. A camada inferior contém quase todo o vapor e concentra os fenômenos meteorológicos. Acima dela, a temperatura volta a subir onde certos gases absorvem radiação de alta energia, uma proteção que permitiu à vida ocupar a superfície. Balões de alta altitude de Qalat e Myrova registraram correntes rápidas muito acima das nuvens, hoje reconhecidas como faixas que conduzem sistemas de tempestade ao redor do planeta.

A composição varia localmente. Florestas úmidas liberam vapor e compostos orgânicos; desertos carregam poeira mineral por milhares de quilômetros; erupções introduzem enxofre e partículas capazes de reduzir temporariamente a luz recebida. Cidades industriais acumulam óleo aerossolizado, fuligem de forjas e névoas ácidas em vales mal ventilados. A baixa dependência de combustão evitou concentrações continentais de fumaça, mas não eliminou a poluição. Redes pneumáticas vazam lubrificantes, biofábricas liberam esporos e oficinas ópticas usam ácidos que precisam ser neutralizados antes de alcançar rios.

## INTERIOR, CALOR E CAMPO MAGNÉTICO

Arden é dividido em crosta, manto e núcleo. A crosta continental varia em geral entre trinta e cinquenta quilômetros, tornando-se mais espessa sob grandes cadeias; a oceânica é mais fina, densa e continuamente renovada. O manto é uma rocha sólida em escala humana, mas se deforma ao longo de milhões de anos. Seu calor provém da formação do planeta e da desintegração lenta de elementos instáveis. Diferenças de temperatura produzem movimentos convectivos que transferem material, arrastam placas e mantêm o planeta geologicamente ativo.

O núcleo externo permanece líquido e rico em ferro. Seu movimento, combinado à rotação, gera o campo magnético que desvia grande parte das partículas emitidas pela estrela. O núcleo interno é sólido pela pressão, apesar de mais quente. Ondas sísmicas permitiram deduzir essa estrutura: algumas atravessam líquidos de forma diferente; outras deixam de se propagar. A rede de sismógrafos criada após os terremotos de Yamashiro tornou possível comparar as trajetórias que cruzam o planeta e transformar os abalos locais em sondas do interior.

O campo magnético não é uniforme. Varia lentamente e sofre perturbações durante tempestades estelares. Bússolas permanecem confiáveis na maior parte de Veth, mas apresentam desvios próximos a depósitos ferrosos de Axum, colunas basálticas magnetizadas e certas regiões de Veth Cinério. Cartas náuticas registram declinação por época, pois um mapa antigo pode conduzir um navio alguns graus para fora da rota mesmo quando a costa e a estrela não mudaram.

| ANOTAÇÃO MARGINAL DESVIOS DE VETH CINÉRIO As anomalias magnéticas do Continente Cinzento não correspondem apenas à composição das rochas. Em três levantamentos separados, a direção medida mudou durante horas sem alteração equivalente em observatórios externos. A hipótese de instrumentos contaminados foi testada e permanece insuficiente. O fenômeno não deve ser incluído em modelos globais até que possa ser repetido sob condições controladas. |
| --- |

## O SATÉLITE E AS MARÉS

Arden possui um único satélite natural de grande porte relativo. Seu período orbital organiza o ciclo principal das marés e estabiliza a inclinação do eixo em escalas longas. O nome varia por língua; os tratados da Concordância evitam privilegiar um termo regional e empregam uma em Veth Comum: Lúnia, termo derivado do Veliano Antigo associado à luz noturna e ao acompanhamento dos ciclos. Calendários costeiros, festas, pesca, navegação e matrizes mareopneumáticas dependem de seu movimento.

As marés resultam da diferença de atração gravitacional entre o lado do planeta mais próximo do satélite e o lado oposto. A estrela acrescenta um segundo componente. Quando estrela, Arden e satélite se alinham, a amplitude aumenta; quando formam ângulo próximo de um quarto de ciclo, diminui. Costas abertas do Mar de Fora podem registrar diferenças superiores a seis metros em baías afuniladas. O Mar Tético, quase fechado, possui amplitude menor e forte variação local determinada por ressonância das bacias. Xochiatlalpan combina plataforma rasa, recifes e estreitos que atrasam a passagem da onda de maré; duas ilhas próximas podem atingir o preamar em horas diferentes.

A maré trabalha sobre a costa. Remove sedimento de um lado, deposita-o em outro, mantém estuários abertos, expõe planícies salinas e mistura águas de composições distintas. Ecossistemas intertidais vivem sob a alternância de imersão, dessecação e salinidade. Portos precisaram aprender a prever essa alternância antes de construir cais fixos. A engenharia mareopneumática de Yamashiro e das cidades téticas depende menos da força de uma única maré que da precisão com que seu ciclo pode ser antecipado.

## ESFERAS E INTERFACES

Para fins de estudo, Arden é dividido em seis esferas. A litosfera reúne crosta e porção superior rígida do manto. A pedosfera compreende os solos formados na interface entre rocha, ar, água e vida. A hidrosfera inclui mares, rios, lagos, águas subterrâneas e vapor. A criosfera reúne gelo continental, geleiras, neve persistente, permaglacis e gelo marinho. A atmosfera transporta gases, calor e partículas. A biosfera contém os organismos e os ambientes que a transformam.

As divisões servem ao método, não à realidade. Uma geleira pertence à criosfera, mas desgasta a litosfera, alimenta a hidrosfera, modifica a atmosfera e transporta organismos. Um manguezal é biosfera, solo, água salobra e sedimentação ao mesmo tempo. Os processos geográficos mais importantes ocorrem nas interfaces, onde uma esfera altera o comportamento da outra.

## COORDENADAS E CONVENÇÕES CARTOGRÁFICAS

A rede moderna de coordenadas adotou o equator astronômico como referência de latitude e o meridiano do Observatório de Qalat como origem de longitude. A escolha resultou de uma negociação técnica. Qalat possuía a série contínua mais longa de observações estelares e uma rede óptica capaz de distribuir horários. Vélia aceitou a referência em troca da adoção de suas convenções comerciais para cartas portuárias. A solução não tornou a geografia neutra; tornou suas disputas suficientemente padronizadas para que mapas de regiões diferentes pudessem ser sobrepostos.

As cartas de Orbis Ardex usam projeção pseudocilíndrica para o mapa-múndi, preservando melhor as áreas intermediárias e deformando progressivamente as altas latitudes. Mapas de navegação empregam projeções conformes que conservam ângulos, ainda que ampliem a Franja Norte e o Auster. Levantamentos territoriais usam redes locais. Nenhuma projeção preserva área, distância, direção e forma ao mesmo tempo. A escolha sempre depende da pergunta feita ao mapa.

PARTE II
