---
title: "Geografia de Veth — REFERÊNCIAS DE CONSULTA"
node_type: "concept"
summary: "Seção “REFERÊNCIAS DE CONSULTA” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["REFERÊNCIAS DE CONSULTA"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"REFERÊNCIAS DE CONSULTA","source_order":10,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# REFERÊNCIAS DE CONSULTA

Referências de consulta

## CONSTANTES PLANETÁRIAS

| Parâmetro | Valor de referência |
| --- | --- |
| Raio médio | 6.480 km |
| Gravidade superficial média | 9,87 m/s² |
| Dia estelar | 24 h 11 min |
| Ano orbital | 365 dias, 7 h e 18 min |
| Inclinação axial | 23,5° |
| Pressão média ao nível do mar | 1,03 atmosfera |
| Cobertura oceânica | aprox. 68% |
| Ponto mais alto conhecido | Pico Inti, 6.200 m |
| Maior profundidade confirmada | fossa oriental de Aotearoa, pouco acima de 7.000 m |

## ALTITUDES E FORMAS PRINCIPAIS

| Formação | Altitude ou dimensão | Observação |
| --- | --- | --- |
| Arco Montanhoso Central | 2.800–3.500 m; picos até 4.900 m | sutura antiga da Placa Tramontana |
| Cordilheira Ocidental | cristas 4.000–4.800 m | Pico Inti atinge 6.200 m |
| Grande Planalto do Alvor | 600–900 m em média | setores internos acima de 1.500 m |
| Arco Norte do Alvor | 2.200–3.400 m | barreira entre costa tética e deserto |
| Planalto de Axum | até 3.000 m | província basáltica de ponto quente |
| Planalto de Huexotl | 2.200–2.400 m | bacia endorreica elevada |
| Veth Cinério central | levantamento incompleto | maciço e Cerne sem altimetria final |
| Gelo central do Auster | mais de 2 km de espessura | rocha subjacente pouco mapeada |

## NOMES HIDROGRÁFICOS ALTERNATIVOS

A diversidade linguística de Veth produziu nomes diferentes para a mesma formação. Orbis Ardex usa a forma de maior circulação no texto e registra variantes quando possuem uso amplo.

| Forma principal | Forma regional ou antiga | Uso |
| --- | --- | --- |
| Rio Han Ji | Huang-Lin | Han Ji no Vethi atual; Huang-Lin em registros imperiais de Qin |
| Rio Meduna | Rio Grande de Verdania | Meduna em línguas locais; Rio Grande no comércio |
| Rio Altea | Rio Mansa | Altea em cartas da Concordância; Mansa em trechos ocidentais |
| Canal de Albrath | Estreito Lateral em cartas antigas | Canal de Albrath é a padronização moderna |
| Xochiatlalpan | Ilhas Verdes | nome nativo e tradução corrente |
| Kitomena | Ínsula Verde | forma política e nome tradicional |
| Mar de Fora | Oceano Norte, Central, Lateral, Austral ou Forâneo | nomes regionais do mesmo oceano |

## GLOSSÁRIO GEOGRÁFICO

| Cráton | núcleo continental antigo e resistente. |
| --- | --- |
| Orogenia | processo de formação de montanhas. |
| Rifte | zona onde a crosta se distende e pode separar-se. |
| Subducção | ocorre quando uma placa mergulha sob outra. |
| Margem passiva | costa formada por separação antiga sem um limite ativo atual. |
| Bacia endorreica | recebe água sem saída superficial para o oceano. |
| Aquífero | corpo subterrâneo capaz de armazenar e transmitir água. |
| Permaglacis | solo que permanece congelado por mais de um ciclo anual. |
| Endemismo | descreve espécie restrita a determinada região. |

Revérbero, Furo, Âncora, Fragmento e Selo pertencem ao vocabulário da Ordem e não devem ser tratados como categorias geológicas. Um Revérbero pode ocupar uma montanha; e não se torna, por isso, um tipo de montanha. A descrição física e a descrição cosmológica registram relações diferentes do mesmo lugar.

## NOTA FINAL DE GARTZA

A geografia não determina o que um povo será. Ela determina aquilo que esse povo precisará enfrentar antes que suas escolhas produzam qualquer continuidade. Um vale oferece água e também confina. Uma costa permite comércio e recebe tempestades. Uma montanha protege, separa e concentra nascentes. As civilizações de Veth não são reflexos automáticos do terreno, mas nenhuma delas surgiu fora das condições que o terreno impôs.

O conhecimento geográfico possui a mesma humildade exigida por qualquer ciência madura. Mapas envelhecem, rios mudam, medições melhoram e teorias perdem explicações que pareciam definitivas. A correção não diminui o mapa anterior; revela que ele cumpriu seu papel até que observações melhores se tornassem possíveis. O mundo continua antes, durante e depois de nossa tentativa de descrevê-lo.

| ANOTAÇÃO FINAL ARQUIVO DE GARTZA A edição pública encerra-se no parágrafo anterior. Esta cópia conserva uma ressalva: a Ordem costuma falar do Véu como se fosse uma camada colocada sobre uma geografia pronta. Arden sugere uma relação menos simples. Pessoas, instituições e Significância sustentam o Véu, mas o lugar oferece ritmos, materiais, fronteiras e memórias que condicionam essa sustentação. Ainda não sabemos se certas paisagens apenas recebem cicatrizes do Além-Véu ou se sua longa organização participa da forma que essas cicatrizes assumem. O desconhecimento não autoriza culto ao território. Autoriza atenção. |
| --- |

FIM DO LIVRO IV

GEOGRAFIA DE VETH

━━━━━━━━━━━━━━  ◇  ━━━━━━━━━━━━━━

PRÓXIMO VOLUME

LIVRO V

INSTITUIÇÕES DE VETH

Governos, organizações, ordens, guildas e estruturas que transformam território em continuidade humana.
