---
title: "Geografia de Veth — CLIMATOLOGIA"
node_type: "concept"
summary: "Seção “CLIMATOLOGIA” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["CLIMATOLOGIA"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"CLIMATOLOGIA","source_order":7,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# CLIMATOLOGIA

Circulação atmosférica, zonas térmicas e regimes regionais

O clima não pertence a um lugar do mesmo modo que uma montanha pertence. Ele atravessa, retorna, falha e se reorganiza. Um território conhece seu clima pela repetição, nunca pela promessa.

## A MÁQUINA ATMOSFÉRICA

A atmosfera recebe mais energia nas baixas latitudes do que nos polos. Se o ar não se movesse, esse contraste cresceria até tornar os trópicos mais quentes e as altas latitudes mais frias do que são. A circulação transporta calor, vapor e movimento. Ar aquecido sobe nas proximidades do equador, perde parte da umidade em chuva e desloca-se em altitude. Ao esfriar, desce nas faixas subtropicais, criando cinturões de alta pressão e favorecendo desertos. Parte retorna ao equador como ventos alísios; parte segue para latitudes médias.

Nas regiões temperadas, massas quentes e frias encontram-se em frentes móveis. Ventos de oeste conduzem sistemas de tempestade. Nas altas latitudes, o ar frio desce e escoa em direção às zonas subpolares. A rotação curva esses fluxos e organiza três células principais em cada hemisfério. As fronteiras migram com as estações, levando chuva para norte ou sul.

A configuração atual de Veth modifica o padrão ideal. O eixo predominantemente norte-sul permite que correntes oceânicas transportem o calor por grande distância. Mares internos aquecem e resfriam mais devagar que a terra, criando brisas, monções e contrastes regionais. Cordilheiras obrigam o ar a subir, resfriar e precipitar; o lado oposto recebe ar mais seco e quente.

## UMIDADE, NUVENS E PRECIPITAÇÃO

Ar quente pode conter mais vapor que ar frio. Quando sobe e esfria, alcança saturação e condensa sobre partículas de poeira, sal ou material biológico. Gotas pequenas formam nuvens; precisam crescer por colisão ou formação de cristais antes de cair. A temperatura da camada atravessada determina se a precipitação chega como chuva, neve, granizo ou chuva congelante.

Precipitação convectiva domina os trópicos: superfícies aquecidas geram colunas de ar que produzem tempestades intensas e localizadas. Precipitação frontal acompanha encontro de massas em latitudes temperadas. Chuva orográfica ocorre quando montanhas forçam uma ascensão. Uma região pode receber a mesma quantidade anual por mecanismos distintos, com consequências diferentes para rios e agricultura.

A umidade relativa descreve a proximidade da saturação, não a quantidade absoluta de água. Um ar frio com pouca água pode estar quase saturado; um ar quente com muito vapor, ainda distante. Essa distinção é importante para saúde, secagem, neblina e conservação. Observatórios registram temperatura, pressão, umidade, vento e precipitação em horários padronizados.

## VENTOS PLANETÁRIOS E CORRENTES DE ALTITUDE

Os alísios sopram das faixas subtropicais para o equador. Sobre o Mar Lateral e o entorno de Xochiatlalpan, acumulam umidade e a conduzem para Verdania. Ventos de oeste dominam zonas temperadas, levando tempestades do Mar de Fora para Albrath, Nordhavn, Contigo austral e Frontier-Sud. No Auster, esses ventos circundam o planeta com pouca interrupção.

Correntes rápidas em altitude percorrem as fronteiras entre massas de temperatura diferente. Seu deslocamento altera trajetórias de tempestade. Quando ondulam, permitem que o ar polar avance ao sul ou que o ar tropical alcance regiões temperadas. Os observatórios não conseguem medir toda a corrente diretamente; reconstroem-na por balões, nuvens altas, pressão e velocidade de sistemas.

Ventos locais podem dominar a experiência. Brisas marítimas entram durante o dia e retornam à noite. Ventos de vale sobem encostas aquecidas e descem após o pôr do sol. Ar frio escorre do Auster e de geleiras como corrente densa. No Alvor, ventos descendo do Arco Norte aquecem e secam rapidamente, agravando incêndios e tempestades de poeira.

## MONÇÕES

Monção é uma reversão sazonal ampla do vento causada pelo aquecimento diferente entre continente e oceano. No verão do Tramontana oriental, a terra aquece, a pressão cai e o ar úmido entra do Mar de Fora. Qin e Daesung recebem meses de chuva; o Han Ji cresce. No inverno, o continente frio produz vento seco em direção ao mar.

Axum e o sul do Alvor recebem monção austral. Umidade do Oceano Sul sobe as escarpas, chove no planalto e alimenta o Netjer. A regularidade média permitiu calendários agrícolas, mas a posição e intensidade variam. Anos de monção fraca reduzem a cheia em Kemet meses depois. Anos intensos produzem deslizamentos em Axum e enchentes no vale.

Verdania não possui monção simples. A convergência equatorial, o giro de Xochiatlalpan e a reciclagem da floresta mantém umidade por grande parte do ano. Ainda assim, a faixa de chuva máxima migra, criando estações relativamente mais úmidas ou secas.

## CONTINENTALIDADE E MARITIMIDADE

Oceanos moderam a temperatura porque armazenam muito calor e misturam suas camadas. Costas possuem verões menos quentes e invernos menos frios que interiores na mesma latitude. Albrath, Nordhavn e Tyrenia refletem essa influência. Grauth, Myrova interior e Yawurua central apresentam maior amplitude diária e anual.

Mares internos produzem efeitos intermediários. O Mar Tético aquece as margens no inverno e fornece umidade para chuvas costeiras. O Mar de Veth congela parcialmente e resfria regiões próximas na primavera. Lagos grandes de Huexotl suavizam noites e geram tempestades locais.

A continentalidade também afeta a precipitação. Ar que atravessa grande distância sobre terra perde umidade. O interior do Alvor, distante do mar e cercado por relevos, permanece árido. Rios e aquíferos permitem vida, mas não mudam a circulação de escala continental.

## O PAPEL DAS CORRENTES OCEÂNICAS

A Corrente Tética mantém Tyrenia, Qalat costeiro e sul de Vélia mais amenos do que o interior na mesma latitude. O Giro Equatorial Central-Oeste leva calor para Albrath e Nordhavn. A Corrente Polar de Nordhavn resfria o Mar de Veth e o norte de Daesung. A Corrente de Contigo cria costa fria, neblina e baixa evaporação diante de terras que poderiam ser mais quentes.

O Giro de Xochiatlalpan mantém água quente e aumenta a convecção. A umidade entra em Verdania e retorna ao ar pela floresta. Kitomena recebe chuva no leste pela corrente quente e apresenta faixa mais seca no oeste sob água fria. A Corrente Circumpolar Auster limita o calor e sustenta o gelo meridional.

Oscilações na posição dessas correntes produzem anos anômalos. Quando a água quente avança sobre a costa de Contigo, a pesca de espécies frias diminui e as chuvas aumentam. Quando o giro de Xochiatlalpan enfraquece, Verdania pode iniciar a estação seca antes do esperado. Climatólogos procuram relações entre os sistemas, mas séries longas ainda são limitadas.

## CLASSIFICAÇÃO CLIMÁTICA DA CONCORDÂNCIA

A classificação moderna combina temperatura, precipitação e sazonalidade. Uma categoria não descreve cada dia; ela resume os padrões de décadas. Clima oceânico exige amplitude térmica pequena e precipitação distribuída. Mediterrâneo possui verão seco e inverno úmido. Tropical sazonal mantém calor, mas alterna estação chuvosa e seca. Desértico é definido pela relação entre precipitação e perda potencial de água, não por temperatura elevada.

Altitudes criam classes sobrepostas. Uma montanha tropical pode apresentar base úmida, floresta de neblina, campo frio e gelo no mesmo paralelo. O modificador de montanha acompanha a categoria térmica. Os limites são transições, não linhas exatas.

| Classe | Critérios gerais | Regiões exemplares |
| --- | --- | --- |
| Polar glacial | mês mais quente abaixo do degelo amplo | Lobo Auster, interior da Franja Norte |
| Tundra / subpolar | verão curto, sem floresta contínua | Myrova norte, ilhas polares |
| Subártico | inverno longo, verão breve, taiga | Myrova central, norte de Nordhavn |
| Temperado oceânico | baixa amplitude, chuva distribuída | Albrath, Nordhavn oeste, Contigo austral |
| Temperado continental | grande amplitude, quatro estações | Grauth, Rethmark, Daesung interior, Riosola |
| Mediterrâneo | verão seco, inverno úmido | sul de Vélia, Tyrenia, Qalat costeiro |
| Subtropical úmido | verão quente e úmido, inverno ameno | Qin sul, Calçada, setores de Kitomena |
| Tropical sazonal | calor anual, estação seca definida | Colhara sul, Mansa, Nzadi, savanas de Axum |
| Equatorial úmido | calor estável, chuva abundante | Verdania central, Xochiatlalpan úmida |
| Semiárido | chuva insuficiente e variável | Tlacua, bordas do Alvor, Yawurua interior |
| Desértico | perda de água muito superior à chuva | Grande Deserto de Veth |
| Montanha | temperatura e chuva controladas por altitude | Valdmere, Tahuantinsuyu, Axum, Aotearoa |

## FAIXAS CLIMÁTICAS GLOBAIS

A faixa polar norte cobre o interior da Franja Norte e extremos setentrionais. Ao sul encontra zona subpolar de tundra e depois subártica, que atravessa Myrova e norte de Nordhavn. A faixa temperada norte ocupa a maior parte do Tramontana. Seu lado oceânico é ameno; o interior, continental.

A faixa subtropical norte alcança o sul de Vélia, ilhas do Tético, Tyrenia, Qalat e norte de Kemet. Em direção ao equador, climas tropicais e semiáridos ocupam Tlacua, Huexotl, bordas de Verdania e norte do Alvor. A faixa equatorial cruza Xochiatlalpan, Verdania central e setores correspondentes de Nzadi e Kitomena.

Ao sul, tropical sazonal domina savanas e planaltos. Riosola e Calçada entram no subtropical e temperado quente; Frontier-Sud e Contigo austral, no temperado frio. O Lobo Auster ocupa a faixa polar meridional. As linhas ondulam conforme relevo e oceano.

## CLIMAS DO TRAMONTANA

Myrova varia de polar de montanha a subártico. Nordhavn é oceânico frio nas costas e subártico no interior. Albrath recebe clima temperado oceânico, com chuva frequente e pouca amplitude. Grauth é continental, mais seco a leste e mais úmido próximo ao Arco. Solane e Vélia interior são temperados; a costa tética meridional torna-se mediterrânea.

Valdmere apresenta pisos de altitude. Vales baixos são temperados; encostas, frias; picos, alpinos e glaciais. Rethmark combina continental e montanha. Daesung e Qin recebem monção, com inverno mais seco e verão úmido. Yamashiro é oceânico insular, com chuva orográfica e variação vulcânica.

O Mar de Veth prolonga o frio da primavera. Neve acumulada no Arco sustenta rios. Secas continentais ocorrem quando ventos de oeste desviam-se para norte. Ondas de frio descem de Myrova; calor tético pode avançar ao sul de Grauth.

## CLIMAS DO OCÍDUO

Verdania central é equatorial úmida, com temperaturas estáveis e chuva superior a dois mil milímetros em grande área. Bordas de planalto possuem estação seca mais clara. Tepuis são frios e nebulosos no topo. Colhara transita de tropical úmido para savânico.

Tlacua é árida a semiárida, com chuva irregular e grande amplitude diária. Huexotl, pela altitude, é mais amena; a bacia lacustre aumenta umidade local. Xochiatlalpan é tropical marítima, com ciclones e chuva de convecção. Contigo apresenta costa oceânica fria, neblina e encostas úmidas; os altiplanos de Tahuantinsuyu são frios e secos.

Riosola varia de subtropical úmida no norte a temperada de verão quente no sul. Calçada recebe influência marítima e tempestades. Frontier-Sud combina temperado frio, taiga e clima de montanha. A longa extensão latitudinal explica a diversidade sem exigir fronteiras abruptas.

## CLIMAS DO ALVOR

Tyrenia e Qalat costeiro possuem clima mediterrâneo. O Arco Norte concentra chuva no lado do mar e produz sombra seca no interior. Kemet é desértica fora do Netjer; o vale possui microclima mais úmido por irrigação e evaporação, sem deixar de depender do entorno árido.

O Grande Deserto apresenta dias muito quentes, noites frias e chuva rara. Bordas semiáridas sustentam estepe e savana. Mansa e Yawurua interior recebem chuva variável; Nzadi é mais úmida. Axum, elevado, possui temperaturas moderadas e chuvas de monção. Madzimbabwe alterna microclimas conforme blocos e bacias.

Kitomena é úmida no leste, tropical ou subtropical no centro e mais seca no oeste. Aotearoa é oceânica úmida, com montanhas frias e costa sujeita a tempestades.

## VETH CINÉRIO E AUSTER

Veth Cinério não é polar. A corrente ao redor e a posição latitudinal produzem temperaturas temperadas a frias. O maciço central recebe neve; costas permanecem úmidas. A cobertura de nuvens é alta e a variação de vento incomum. Séries meteorológicas são curtas e podem conter falhas de instrumento.

O Auster é um deserto polar. O interior recebe pouca neve, embora conserve grande espessura acumulada. Ventos catabáticos descem do planalto glacial e podem ultrapassar qualquer vento sustentado de Veth habitado. Costas têm verão breve, neblina e tempestades; gelo marinho avança e recua sazonalmente.

## EVENTOS EXTREMOS

Ciclones tropicais formam-se sobre águas quentes de Xochiatlalpan e setores orientais. Precisam de umidade, rotação e baixa variação de vento em altitude. Podem atingir as Ilhas Verdes, Contigo norte, Kitomena e partes de Nzadi. Sua trajetória muda com cinturões de pressão.

Qin e Daesung enfrentam enchentes de monção. Alvor sofre secas plurianuais, tempestades de areia e ondas de calor. Myrova recebe nevascas e chuva congelante. Contigo e Frontier-Sud enfrentam tempestades oceânicas. Yamashiro e Aotearoa combinam tufões, erupções, terremotos e tsunamis.

Incêndios fazem parte de savanas e florestas mediterrâneas. Algumas plantas dependem deles para germinar. A supressão completa acumula combustível e pode produzir eventos maiores. Em Verdania, incêndio natural é raro no núcleo úmido; sua presença extensa costuma indicar seca excepcional ou alteração humana.

| Risco climático | Regiões principais | Consequências recorrentes |
| --- | --- | --- |
| Ciclones tropicais | Xochiatlalpan, Verdania costeira, Kitomena | maré de tempestade, vento, deslizamento e quebra de recifes |
| Monções extremas | Qin, Daesung, Axum | cheias, erosão, colheitas e transporte de sedimento |
| Seca plurianual | Tlacua, Huexotl, Alvor, Yawurua | falha de pastagem, salinização, migração e conflito de água |
| Tempestade de areia | Grande Deserto, Mansa, Yawurua | perda de solo, redução de visibilidade e abrasão |
| Nevasca e gelo | Myrova, Nordhavn, Valdmere, Frontier-Sud | isolamento, avalanches e ruptura de infraestrutura |
| Tempestade oceânica | Contigo, Aotearoa, Calçada, Braço Sul | ondas longas, erosão costeira e naufrágios |

## MUDANÇA CLIMÁTICA EM ESCALA LONGA

Clima muda sem alguma direção única. Ciclos orbitais alteram a distribuição de luz; vulcanismo reduz temperatura por alguns anos; continentes reorganizam as correntes; vegetação modifica carbono e umidade. Registros de gelo, sedimento e anéis de árvore mostram alternância de períodos mais frios e mais quentes.

A atividade humana já possui efeitos regionais. Desmatamento reduz reciclagem de umidade; irrigação altera salinidade e evaporação; cidades formam ilhas de calor; drenagem de pântanos libera matéria orgânica. As emissões por combustão são menores que em uma civilização dependente de carvão, mas forjas, produção de cal e perda de floresta ainda alteram a atmosfera.

A série de 1.847 é curta para atribuir tendência planetária precisa. Observatórios registram recuo de algumas geleiras e avanço de outras, aquecimento tético e variações no Auster. Gartza recomenda conservar os dados sem transformá-los em certeza política antes que o período de observação seja suficiente.

PARTE VIII
