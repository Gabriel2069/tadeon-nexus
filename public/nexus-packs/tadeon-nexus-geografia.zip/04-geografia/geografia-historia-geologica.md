---
title: "Geografia de Veth — HISTÓRIA GEOLÓGICA"
node_type: "concept"
summary: "Seção “HISTÓRIA GEOLÓGICA” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["HISTÓRIA GEOLÓGICA"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"HISTÓRIA GEOLÓGICA","source_order":2,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# HISTÓRIA GEOLÓGICA

Crátons, Plaganeter e a formação dos lobos

A rocha conserva uma memória sem intenção. Ela não registra acontecimentos em palavras, mas em grãos quebrados, minerais orientados, fósseis interrompidos e superfícies que um dia foram fundo de mar.

## A ESCALA DO TEMPO PROFUNDO

A história escrita ocupa uma fração quase invisível da história de Arden. Mesmo os mitos mais antigos surgiram depois que montanhas inteiras já haviam se elevado e desaparecido. Geólogos reconstroem esse passado por relações entre camadas, minerais que se formam sob condições conhecidas, fósseis e desintegração de elementos instáveis. As idades são aproximações com margem declarada. Um número apresentado em bilhões de anos não pretende localizar um acontecimento num dia remoto; identifica a ordem e a duração dos processos que o separaram do presente.

A cronologia moderna divide a história planetária em seis grandes eras. Os nomes derivam de tradições acadêmicas diferentes e foram harmonizados pela Conferência de Yawurua. Nenhuma fronteira corresponde a mudança instantânea. Cada uma marca uma transformação suficientemente ampla para alterar a organização da superfície, dos oceanos ou da vida.

| Era geológica | Intervalo aproximado | Processos dominantes |
| --- | --- | --- |
| Fundação Cratônica | 4,1 a 2,7 bilhões de anos | solidificação inicial, primeiros crátons, oceanos primitivos |
| Era de Plaganeter | 2,7 bilhões a 620 milhões de anos | agregação continental, longas cadeias internas, estabilização atmosférica |
| Grande Fragmentação | 620 a 280 milhões de anos | riftes, abertura de mares, cisão parcial do Tramontana, isolamento biológico e vulcanismo extenso |
| Reconvergência dos Lobos | 280 a 70 milhões de anos | consumo de oceanos, formação do arco yamashirense, colisões, Sutura Central e Cordilheira Ocidental |
| Elevação do Alvor | 70 a 12 milhões de anos | compressão múltipla, planaltos, Netjer, Axum, estabilização da Bacia Yamashirense e arcos orientais |
| Configuração Recente | 12 milhões de anos ao presente | glaciações, deltas, desertos atuais, estabilização das costas |

## FUNDAÇÃO CRATÔNICA

As primeiras crostas formaram-se quando a superfície do planeta perdeu calor suficiente para permanecer sólida entre grandes episódios de fusão. Eram finas e continuamente recicladas. Partes menos densas sobreviveram, reuniram-se e engrossaram até formar núcleos resistentes. O Cráton de Yawurua conserva rochas com cerca de 3,4 bilhões de anos; o Tramontano, 2,8 bilhões; o núcleo Ocíduo-Central, aproximadamente 1,2 bilhão em sua forma atual, embora incorpore fragmentos mais antigos.

Crátons não são blocos imóveis. São porções cuja espessura, baixa temperatura e composição as tornam difíceis de deformar. Suas bordas podem ser comprimidas, cobertas por sedimentos ou cortadas por falhas, enquanto o núcleo permanece reconhecível. A estabilidade de Vélia, Grauth, Verdania e grande parte de Yawurua deriva dessa fundação. As cidades não foram construídas conscientemente sobre um terreno quieto; elas simplesmente cresceram onde o terreno lhes permitiu acumular séculos de infraestrutura sem repetidos recomeços sísmicos.

## PLAGANETER

Plaganeter é o nome dado ao antigo conjunto continental que reuniu quase toda a crosta leve de Arden. A expressão, preservada por geólogos kemetinos, significa aproximadamente “grande terra de forças cósmicas” ou “vasta região dos princípios naturais”. Não se tratava de uma cópia ampliada de Veth. Suas costas, montanhas e posição eram diferentes. A união prolongada reduziu os litorais, produziu interiores secos e reuniu linhagens biológicas que mais tarde seriam separadas.

As cadeias formadas durante a agregação foram erodidas até suas raízes. Alguns afloramentos de Yawurua, Verdania e norte do Tramontana pertencem ao mesmo cinturão mineral antigo, hoje separado por milhares de quilômetros e coberto por rochas mais jovens. Essa correspondência foi uma das primeiras provas de que os lobos haviam se deslocado. Fósseis de organismos de água doce encontrados em margens hoje separadas pelo Mar Tético forneceram outra: não poderiam ter atravessado um oceano amplo, mas viveram quando as bacias ainda estavam unidas.

## A GRANDE FRAGMENTAÇÃO

O calor acumulado sob Plaganeter elevou regiões da crosta e abriu sistemas de riftes. Vales alongados tornaram-se mares, derrames vulcânicos cobriram grandes áreas e blocos começaram a afastar-se. O processo não avançou de maneira uniforme. Alguns riftes cessaram ainda como depressões continentais. Outros produziram crostas oceânicas antes de serem novamente comprimidos. A forma lobada de Veth deriva dessa fragmentação incompleta, na qual separação e reunião ocorreram em momentos e velocidades diferentes.

Uma das maiores rupturas atravessou o leste do proto-Tramontana ao longo de uma faixa de crosta já enfraquecida por colisões anteriores. O terreno a leste afastou-se do cráton principal, e as depressões iniciais foram preenchidas por lagos, sedimentos e derrames basálticos. A continuidade da extensão permitiu que material do manto ascendesse e formasse crosta oceânica. Surgiu assim o Mar Antigo de Yamashiro, uma bacia longa e estreita entre o Tramontana ocidental e o bloco que hoje sustenta Daesung, Qin e as terras orientais.

O afastamento nunca alcançou dimensões o suficiente para criar dois continentes independentes. O mar possuía bacias profundas, plataformas estreitas, falhas transformantes e fragmentos continentais que permaneceram isolados entre os dois lados. Alguns desses fragmentos serviriam mais tarde de base ao arco de Yamashiro. Enquanto isso, o Lobo Ocíduo avançava para oeste, o Alvor girava sob compressões sucessivas e Kitomena, Aotearoa e Xochiatlalpan conservavam movimentos próprios.

A fragmentação modificou a vida. Populações antes contínuas foram separadas por mares, desertos e montanhas. Arquipélagos preservaram linhagens que desapareceram no continente; outras se diversificaram rapidamente ao ocupar ambientes sem competidores equivalentes. A biogeografia atual ainda carrega essa assinatura, sobretudo em Aotearoa, Xochiatlalpan e nos tepuis de Verdania.

## RE-CONVERGÊNCIA E OROGENIAS

A abertura dos oceanos modificou a circulação do manto e, com ela, a direção de algumas placas. O movimento entre Ocíduo e Tramontana desacelerou, a crosta tética começou a ser consumida e o Alvor aproximou-se do Ocíduo pelo Istmo de Veth e de Yawurua pelo leste. Dentro do próprio Tramontana, a extensão do Mar Antigo de Yamashiro cessou. As duas margens permaneceram afastadas durante milhões de anos antes que a convergência começasse.

O fundo oceânico yamashirense era mais frio e denso que os blocos continentais ao redor. Quando a compressão se estabeleceu, ele começou a mergulhar para leste sob terrenos ligados ao Tramontana oriental. Água e compostos voláteis foram liberados dos minerais em profundidade, favorecendo a fusão parcial do manto superior. Os magmas resultantes ascenderam por fraturas e construíram uma cadeia de vulcões submarinos. Alguns cresceram até ultrapassar a superfície e deram origem ao primeiro arco de Yamashiro.

A convergência prosseguiu até que a margem ocidental do Tramontana encontrou os sedimentos comprimidos, fragmentos continentais e terrenos do arco. A crosta engrossou, dobrou-se e foi empilhada por falhas de empurrão. Dessa colisão surgiu o Arco Montanhoso Central. Rochas do antigo fundo marinho foram elevadas junto a sedimentos costeiros, fragmentos do manto, intrusões magmáticas e minerais recristalizados sob pressão.

O fechamento ocorreu primeiro nos extremos da ruptura e avançou de maneira irregular. Uma porção central do antigo mar permaneceu rebaixada entre o Arco Montanhoso e o bloco oriental. A bacia aprisionada conservou uma crosta oceânica, fossas residuais e o arco insular de Yamashiro. Os dois lados passaram a transmitir movimento como partes da mesma Placa Tramontana, embora a região central nunca tenha perdido inteiramente sua autonomia mecânica.

Outras colisões formaram estruturas distintas. A Cordilheira Ocidental nasceu de terrenos acrescidos ao Ocíduo e comprimidos contra seu cráton. O Grande Planalto do Alvor surgiu do espessamento de uma área continental ampla. Cada orogenia alterou o clima e a erosão além de sua zona de falhas. O Arco Norte do Alvor bloqueou a umidade e favoreceu o Grande Deserto; a Cordilheira Ocidental alimentou os rios de Verdania; o Arco Central dividiu drenagens e estabeleceu a separação física entre o Tramontana ocidental, a Bacia Yamashirense e as terras orientais.

## GLACIAÇÕES E CONFIGURAÇÃO RECENTE

Nos últimos doze milhões de anos, oscilações orbitais e mudanças nas correntes permitiram repetidos avanços de gelo nas altas latitudes e montanhas. A Franja Norte sustentou mantos que avançaram sobre Myrova e escavaram vales até a costa de Nordhavn. No sul, o Lobo Auster acumulou gelo espesso e alimentou uma corrente circumpolar fria. Geleiras de Tahuantinsuyu, Valdmere e Veth Cinério cresceram e retraíram, deixando morainas, lagos e depósitos de sedimento fino.

O nível do mar caiu durante máximos glaciais, expondo plataformas entre ilhas e estreitando mares internos. Xochiatlalpan tornou-se um conjunto mais conectado; partes do Istmo de Veth alargaram-se; rotas terrestres temporárias permitiram migração de espécies. Quando o gelo derreteu, o mar retornou, isolando populações e inundando vales. Muitas baías atuais são rios antigos submersos.

A configuração presente é recente em escala geológica. Deltas do Han Ji, Meduna e Netjer continuam avançando. O Mar Tético continua estreitando lentamente. O Auster perde e ganha massa conforme ciclos de séculos. A paisagem descrita por este livro não é destino final; é uma pausa longa o suficiente para que civilizações a tratem como permanência.

| ANOTAÇÃO MARGINAL O CERNE As camadas superficiais do Cerne registram uma interrupção que não se encaixa na cronologia geológica comum. Rochas de idades diferentes foram vitrificadas na mesma superfície sem evidência de calor suficiente para produzir o efeito, e minerais ferrosos exibem oxidação recente sob crostas muito antigas. A Grande Contenção pertence à história humana ou pré-humana, não à tectônica. Sua marca, porém, tornou-se parte da geografia e precisa ser registrada sem receber uma causa falsa. |
| --- |

PARTE III
