---
title: "Geografia de Veth — HIDROSFERA, OCEANOGRAFIA E CRIOSFERA"
node_type: "concept"
summary: "Seção “HIDROSFERA, OCEANOGRAFIA E CRIOSFERA” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["HIDROSFERA, OCEANOGRAFIA E CRIOSFERA"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"HIDROSFERA, OCEANOGRAFIA E CRIOSFERA","source_order":6,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# HIDROSFERA, OCEANOGRAFIA E CRIOSFERA

Mares, bacias, rios, aquíferos e gelo

A água liga regiões que a pedra separa. Cai sobre uma encosta, atravessa o solo, entra num rio, alcança o mar e retorna pelo ar sem conservar fronteiras humanas.

## O CICLO DA ÁGUA

A energia de Estela evapora a água dos oceanos, lagos, solos e organismos. O vapor sobe, esfria e condensa em nuvens. Precipitação a retorna como chuva, neve ou gelo; parte escoa, parte infiltra e parte volta rapidamente à atmosfera. A circulação parece simples apenas quando descrita em escala planetária. Cada região modifica o tempo de permanência: uma geleira armazena água por séculos; um rio tropical, por semanas; um aquífero profundo, por milhares de anos.

Vegetação também participa do ciclo. Árvores retiram a água do solo e liberam como vapor, aumentando umidade e favorecendo chuva a sotavento. Verdania recicla grande parte da precipitação antes que ela alcance o oceano. Solos compactados reduzem a infiltração e aumentam as cheias. Cidades canalizam a água e aceleram seu retorno aos rios.

## O MAR DE FORA E AS BACIAS OCEÂNICAS

O Mar de Fora circunda Veth e ocupa a maior parte do planeta. Seus nomes regionais, Oceano Norte, Oceano Central, Mar Lateral e Oceano Austral, descrevem setores de uma mesma massa de água. A circulação profunda conecta esses setores em escalas de séculos. Água fria e salgada afunda nas altas latitudes; correntes profundas deslocam-se para regiões quentes; ressurgências devolvem nutrientes à superfície.

A profundidade média é de cerca de 3.900 metros. Fossas ultrapassam sete mil junto a Yamashiro e Aotearoa. Dorsais elevam-se milhares de metros acima das planícies abissais sem alcançar a superfície. Montes submarinos alteram as correntes, concentram vida e podem formar ilhas se receberem vulcanismo suficiente.

A plataforma continental é rasa e recebe luz. Sustenta recifes, pesca e portos, mas também preserva vales inundados e sedimentos instáveis. O talude desce para bacias profundas. Em Contigo, a plataforma é estreita; em Xochiatlalpan e no Mar Tético, ampla.

## MAR TÉTICO

O Mar Tético possui aproximadamente 2,8 milhões de quilômetros quadrados e comunica-se com o Mar de Fora pelo Canal de Albrath a oeste e pelo Canal de Qalat a leste. A evaporação supera a chuva em grande parte da bacia, elevando a salinidade. Água superficial entra pelos canais; água mais salgada e densa retorna em profundidade. A troca mantém a oxigenação, mas setores fechados podem desenvolver águas pobres em oxigênio durante verões quentes.

Temperaturas superficiais variam em geral entre dezoito e vinte e seis graus no verão e dez a dezesseis no inverno. A Corrente Tética distribui calor ao longo das margens e sustenta climas mediterrâneos. Ventos canalizados pelos estreitos criam áreas de ondas curtas e fortes. Bancos, ilhas e deltas tornam o mar navegável, porém exigem cartas detalhadas.

O Tético é geologicamente jovem e continua estreitando. Sedimentos do Netjer, Soiena e rios menores avançam sobre a plataforma. Portos antigos hoje ficam no interior; cidades modernas precisam dragar canais. A navegação e a arqueologia compartilham o mesmo problema: distinguir a costa atual da costa histórica.

## MAR DE VETH

O Mar de Veth é uma bacia interna salobra conectada ao oceano norte por canais estreitos. Recebe rios de Grauth, Rethmark, Myrova e parte do Arco Central. A entrada de água doce reduz a salinidade, enquanto a troca limitada impede uniformidade. O norte congela parcialmente; o sul permanece aberto na maioria dos anos.

A Corrente Polar de Nordhavn entra com água fria e rica em nutrientes. Primavera e verão produzem florações de algas que sustentam a pesca. O fundo central contém sedimentos finos e antigas camadas de matéria orgânica. Ventos podem empurrar água para uma margem, expondo baixios na outra e alterando portos por horas.

## MAR LATERAL, CONTIGO E XOCHIATLALPAN

O Mar Lateral acompanha a costa oeste do Ocíduo e comunica-se sem barreira com o oceano austral. A Corrente de Contigo sobe fria, favorecendo ressurgência e neblina. Água profunda aproxima-se da costa por causa do talude íngreme. Essa proximidade fornece nutrientes e organismos abissais, mas reduz o tempo de aviso para ondas geradas em falhas ou deslizamentos.

O Mar de Xochiatlalpan ocupa uma plataforma rasa e quente entre as Ilhas Verdes. Temperaturas de vinte e seis a trinta graus sustentam os recifes. O giro local resulta do encontro entre correntes quentes equatoriais e a borda da Corrente de Contigo. Lagoas podem ser muito mais salinas que o mar aberto; canais estreitos alternam fluxo com a maré.

## BRAÇO SUL E OCEANO AUSTRAL

O Braço Sul separa terras austrais do Ocíduo e Alvor das margens do Auster. Ventos de oeste percorrem grande distância sem encontrar continentes, levantando ondas longas. Correntes frias circumpolares limitam o transporte de calor para o polo e ajudam a manter o gelo do Auster.

Ilhas e penínsulas alteram a corrente em remoinhos. Águas superficiais ricas em oxigênio afundam durante o inverno. A navegação é difícil devido a neblina, gelo e tempestades; a cartografia permanece incompleta fora das rotas de Calçada, Frontier-Sud, Madzimbabwe e Aotearoa.

## CORRENTES SUPERFICIAIS

O Giro Equatorial Central-Oeste transporta água quente para o norte e ameniza Albrath e Nordhavn. A Corrente Polar de Nordhavn retorna fria pelo Mar de Veth e a costa de Myrova. A Corrente Tética circula pelas margens do mar interno. A Corrente de Contigo sobe do sul, fria e nutritiva. O Giro de Xochiatlalpan mantém água quente em torno das ilhas. Kitomena recebe corrente quente no leste e ramo frio no oeste.

Correntes não são rios de borda fixa. Mudam de largura, velocidade e posição com vento e estação. Anos de deslocamento alteram a pesca e chuva. Os mapas representam trajetórias médias; navegadores usam observações locais para corrigir a carta.

| Corrente | Temperatura | Trajeto e efeitos |
| --- | --- | --- |
| Giro Equatorial Central-Oeste | quente | transporta calor tropical para Albrath e Nordhavn |
| Polar de Nordhavn | fria | resfria Mar de Veth e norte de Myrova; favorece pesca |
| Tética | morna | circula no Mar Tético e ameniza Tyrenia, Verdania e sul de Vélia |
| Contigo | fria | ressurgência, neblina e alta produtividade na costa ocídua |
| Giro de Xochiatlalpan | quente | mantém recifes e também alimenta a umidade de Verdania |
| Oriental de Kitomena | quente | aumenta chuva no leste da ilha |
| Ocidental de Kitomena | fria | seca e resfria a costa oeste |
| Circumpolar Auster | fria | isola termicamente o continente polar e organiza o Braço Sul |

## GRANDES BACIAS HIDROGRÁFICAS

Bacia hidrográfica é a área cuja água converge para uma saída comum. Divisores seguem cristas e superfícies elevadas. Uma fronteira de bacia pode atravessar reinos, línguas e climas. Intervenção em montantes produz efeitos em jusantes; por isso, tratados de água frequentemente anteciparam tratados políticos.

A Bacia do Mar de Veth recebe o Brennwald, rios de Rethmark, tributários de Valdmere e cursos de Myrova. A Bacia Tética Ocidental inclui Soiena e rios vêlios. A Bacia do Han Ji drena o leste tramontano. No Ocíduo, Meduna integra Verdania; Qhapaq nasce na cordilheira; Huexotl é endorreica. No Alvor, Netjer, Altea e sistemas austrais ocupam corredores separados por planaltos.

| Bacia | Saída | Características |
| --- | --- | --- |
| Mar de Veth | mar interno salobro | rios de neve e chuva, planícies industriais e agrícolas |
| Tética Ocidental | Mar Tético | Soiena e rios curtos de Vélia; forte regulação humana |
| Han Ji | Mar de Fora oriental | monção, sedimento abundante, delta móvel |
| Verdania-Meduna | Costa ocídua | rede densa, planícies inundáveis, alta reciclagem de umidade |
| Huexotl | Lago Texcoco Central | endorreica, salina, controlada por canais e evaporação |
| Qhapaq | Meduna e terras baixas | altitude elevada, degelo e chuvas orográficas |
| Netjer | Mar Tético | cheia monçônica regular, vale estreito e delta fértil |
| Altea | litoral do Alvor | planaltos austrais, falhas e regime sazonal |
| Contigo costeira | Mar Lateral | rios curtos, íngremes e sedimentares |
| Auster | Oceano Austral | escoamento glacial e cursos sazonais mínimos |

## RIOS DO TRAMONTANA

O Soiena nasce no Arco do Canal de Albrath e percorre cerca de 890 quilômetros até o Mar Tético. Degelo gradual e chuvas mantêm regime relativamente regular. Atravessa vinhedos, cidades e aquedutos de Solane. Barragens e derivações reduziram o sedimento no baixo curso, obrigando a manutenção do delta.

O Brennwald percorre 1.240 quilômetros por Grauth antes de alcançar o Mar de Veth. Seu sistema de eclusas, canais e reservatórios sustenta transporte e hidropneumática. Cheias de primavera são desviadas para campos e bacias de armazenamento. A canalização estabilizou cidades, mas reduziu áreas úmidas que absorviam picos de vazão.

O Han Ji, conhecido em registros antigos de Qin como Huang-Lin, possui cerca de 3.200 quilômetros e o maior volume médio do Tramontana. A monção de verão produz cheias intensas e grande carga de sedimento. Diques protegem as planícies, porém elevam o leito quando os sedimentos ficam confinados. Rompimentos podem deslocar o rio para canais antigos.

O Nether nasce em planaltos de Myrova e segue por aproximadamente 4.100 quilômetros até o mar polar. Congela por meses; o degelo começa no sul enquanto o norte permanece bloqueado, causando represamentos e inundações. Lagos e pântanos moderam parte do fluxo.

## RIOS DO OCÍDUO

O Meduna, chamado Rio Grande em parte do Vethi Comum, organiza a Bacia de Verdania. Recebe afluentes da Cordilheira, de Colhara e do norte. Seu curso é lento na planície e muda por avulsão. Durante cheias, a água ocupa a floresta por dezenas de quilômetros. Cidades importantes ficam sobre terraços ou margens artificialmente elevadas.

O Qhapaq percorre cerca de 1.800 quilômetros em altitude antes de descer para Verdania. Urubamba e Apurimac são seus principais afluentes. A vazão combina degelo, chuva de montanha e monção. Deslizamentos podem represar vales, criando lagos temporários que se rompem meses depois.

Rios de Contigo são curtos e violentos. Seus nomes mudam por vale e comunidade. Transportam carga grossa, constroem deltas e servem de corredores à Estrada Real. O regime varia com chuva orográfica e degelo. Obras portuárias precisam acomodar canais que migram dentro do delta.

Riosola possui cursos largos e lentos. O baixo gradiente favorece meandros, lagoas e inundações sazonais. Calçada concentra estuários e marés. Na Frontier-Sud, rios recebem neve, chuva e lagos glaciais, com regime mais distribuído.

## RIOS DO ALVOR

O Netjer percorre aproximadamente 2.800 quilômetros desde lagos e nascentes no planalto de Axum até o delta tético. Sua cheia começa com as chuvas de monção nas terras altas, cresce durante meses e recua de modo previsível. A regularidade sustentou Kemet, mas não é perfeita. Erupções, secas ou alteração de uso do solo em Axum modificam volume e sedimento.

O Altea, chamado Rio Mansa em trechos ocidentais, drena planaltos do sul do Alvor. A nomenclatura muda conforme línguas e reinos. Tributários atravessam Nzadi e Madzimbabwe; o regime é sazonal, com cheias rápidas em vales falhados. Barragens naturais de deslizamento são comuns.

Yawurua possui rios de baixo gradiente, alguns permanentes nas costas e outros sazonais no interior. Canais podem desaparecer em planícies e reaparecer em depressões. Kitomena tem rios radiais curtos; Aotearoa, cursos vulcânicos íngremes e lagos de caldeira.

## LAGOS, PÂNTANOS E ESTUÁRIOS

O Lago Texcoco Central é raso, salino e endorreico. Canais separam águas de salinidade diferente e sustentam chinampas. Lagos de Myrova resultam de gelo e permaglacis; muitos mudam de forma quando o solo descongela. Yamashiro e Aotearoa possuem lagos de caldeira, alguns ácidos ou aquecidos.

Verdania contém lagos de meandro, igapós e pântanos permanentes. Esses ambientes armazenam carbono, filtram água e servem como berçário. Estuários de Calçada, Contigo e Vélia misturam água doce e salgada, criando gradientes que mudam com maré e estação. Manguezais estabilizam sedimentos onde a temperatura permite.

## ÁGUAS SUBTERRÂNEAS

Água infiltra por poros e fraturas até encontrar camadas impermeáveis. Aquíferos livres respondem rapidamente à chuva; confinados podem manter pressão e idade de milhares de anos. O Alvor depende de aquíferos sob arenito e calcário. Poços artesianos alcançam água que entrou quando o clima era mais úmido; sua retirada excede a recarga em várias cidades.

Os falaj de Qalat conduzem água subterrânea por túneis de baixa inclinação, reduzindo evaporação. Kemet usa poços no rift e canais superficiais. Tlacua conhece aquíferos suspensos sobre camadas argilosas. Em regiões cársticas, contaminação percorre longas distâncias por cavernas e emerge sem filtragem.

Fontes termais pertencem ao mesmo sistema, aquecidas em profundidade. Mineração pode drenar aquíferos ou conectar águas de composições diferentes. A proteção de bacias subterrâneas exige mapear algo que não pode ser visto diretamente; corantes, pressão e alquímica ajudam a reconstruir trajetórias.

## CRIOSFERA

A criosfera inclui o Lobo Auster, Franja Norte, gelo marinho, geleiras de montanha, neve persistente e permaglacis. O gelo reflete a luz e resfria o clima. Ao crescer, reduz o nível do mar; ao derreter, eleva-o. Geleiras armazenam água e liberam-na no verão, sustentando rios de Valdmere e Tahuantinsuyu.

Permaglacis de Myrova conserva solo congelado por anos. A camada ativa descongela no verão, e construções aquecidas podem causar subsidência. Gelo marinho forma-se a partir da superfície do oceano e rejeita sal, tornando a água abaixo mais densa. Plataformas do Auster flutuam; sua ruptura não eleva diretamente o mar, mas permite que o gelo continental alcance o oceano mais rápido.

Lagos subglaciais podem permanecer líquidos sob pressão e calor geotérmico. Nenhum foi perfurado até o presente. Instrumentos indicam superfícies de água sob o Auster e talvez sob Veth Cinério. A Ordem proibiu perfuração nas duas áreas por razões descritas como sanitárias e estruturais nos registros públicos.

PARTE VII
