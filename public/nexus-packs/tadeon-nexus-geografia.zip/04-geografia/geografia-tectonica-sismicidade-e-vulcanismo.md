---
title: "Geografia de Veth — TECTÔNICA, SISMICIDADE E VULCANISMO"
node_type: "concept"
summary: "Seção “TECTÔNICA, SISMICIDADE E VULCANISMO” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["TECTÔNICA, SISMICIDADE E VULCANISMO"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"TECTÔNICA, SISMICIDADE E VULCANISMO","source_order":3,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# TECTÔNICA, SISMICIDADE E VULCANISMO

As placas que sustentam Veth e as regiões onde continuam a ceder

As placas avançam à velocidade de unhas crescendo. A lentidão não reduz sua força; apenas distribui o acontecimento por tempo suficiente para que uma montanha pareça imóvel.

## O SISTEMA DAS DOZE PLACAS

A superfície rígida de Arden está dividida em doze placas principais e diversos terrenos menores. A contagem depende do critério usado. Um bloco pode ser tratado como microplaca quando mantém movimento próprio, ou como parte de uma placa maior quando esse movimento é pequeno diante da escala global. A classificação adotada por Orbis Ardex privilegia limites capazes de produzir deformação mensurável, sismicidade ou vulcanismo independente.

As placas continentais carregam crosta espessa e relativamente leve. As oceânicas são mais finas, densas e jovens. Quando ambas convergem, a crosta oceânica tende a mergulhar no manto; quando dois continentes se encontram, nenhum desce com facilidade e a crosta se dobra, falha e engrossa. Limites divergentes criam nova crosta. Falhas transformantes acomodam o movimento lateral. Margens passivas conservam a cicatriz de antigas separações sem permanecer como limites ativos.

| Placa | Natureza | Limites dominantes | Expressão atual |
| --- | --- | --- | --- |
| Tramontana | continental antiga | Polar Norte, Forânea, sistema tético e Sutura Yamashirense | Cráton Tramontano, Arco Central, Myrova, Bacia Yamashirense e Tramontana Oriental |
| Ocídua | continental composta | sistema tético, Alvor, margem antiga de Contigo | Cordilheira Ocidental, Istmo, bacias sedimentares |
| Alvor | continental comprimida | Oceânica Norte, Auster, Yawurua | Grande Planalto, Arco Norte, falhas austrais |
| Yamashirense | microplaca oceânico-arquense residual | Tramontana ocidental e oriental | bacia interior, arco vulcânico relicto, lâmina subduzida e sismicidade própria |
| Yawurua | continental cratônica | Alvor, Forânea | planícies antigas, margem ocidental comprimida e borda oriental deformada |
| Kitomena | microplaca continental | Alvor, Yawurua | metamorfismo, falhas e elevação insular |
| Aotearoa | microplaca oceânico-continental | Alvor, Forânea | arcos vulcânicos, metamorfismo e alta sismicidade |
| Xochiatlalpan | microplaca de plataforma | Ocídua, microplacas oceânicas ocidentais | domos riolíticos extintos e subsidência recifal |
| Polar Norte | mista | Tramontana e dorsais setentrionais | Franja Norte e margem de Myrova |
| Auster | continental polar | Alvor, Ocídua austral e dorsais do sul | Lobo Auster e cisalhamento meridional |
| Oceânica Norte | oceânica | Alvor e dorsais do Mar de Fora | subducção no Arco Norte do Alvor |
| Forânea | oceânica extensa | Tramontana oriental, Aotearoa, Yawurua e dorsais orientais | fossas externas, falhas oblíquas e compressão insular |

## PLACA TRAMONTANA

A Placa Tramontana sustenta tanto o bloco ocidental quanto as terras orientais que se estendem além de Yamashiro. Sua crosta continental alcança quarenta a cinquenta quilômetros sob o cráton e ultrapassa essa espessura abaixo do Arco Montanhoso Central. O núcleo de 2,8 bilhões de anos estende-se sob Grauth, Vélia, Rethmark e partes interiores de Daesung e Qin. Apesar das diferenças entre seus terrenos, os dois lados transmitem hoje o movimento geral como uma única placa.

Ao norte, a borda oceânica da Placa Polar Norte mergulha lentamente sob Tramontana. A convergência média de 1,8 centímetro por ano elevou as montanhas setentrionais de Myrova e alimenta o vulcanismo basáltico espaçado. A geometria varia ao longo do contato. Alguns segmentos apresentam subducção definida; outros distribuem a deformação por falhas oblíquas. Os abalos são frequentes, mas grandes erupções permanecem separadas por décadas ou séculos.

O interior da placa conserva a Sutura Yamashirense, formada durante a reunião entre seus blocos ocidental e oriental. O Arco Montanhoso Central ocupa a porção mais espessa dessa sutura. A leste das cristas encontra-se a Bacia Yamashirense, remanescente do mar que existiu entre os blocos. Sob a bacia permanece uma lâmina de crosta oceânica que iniciou sua descida durante a re-convergência e nunca foi inteiramente absorvida pelo manto.

A superfície da bacia e o arco insular movem-se alguns milímetros por ano em relação às terras circundantes. Essa diferença justifica a classificação da Microplaca Yamashirense. Seus limites não formam uma borda simples. Falhas profundas atravessam o fundo, segmentos de crosta continental estão misturados a rochas oceânicas e parte da deformação é absorvida pelas encostas orientais do Arco Central. Na escala mundial, o conjunto pertence ao Tramontana. Na escala regional, comporta-se como unidade própria.

A lâmina subduzida apresenta rasgos e diferenças de inclinação. Onde permanece contínua, os terremotos aprofundam-se progressivamente sob o arco. Onde foi rompida, o material quente do manto ascende por janelas abertas na placa. Mutsuro ocupa a maior dessas janelas conhecidas. O calor fornecido por esse sistema mantém o vulcanismo, a circulação hidrotermal e a deformação muito depois do encerramento da antiga abertura oceânica.

A margem exterior do Tramontana oriental encontra a Placa Forânea. O contato é oblíquo e predominantemente transformante em grande parte de sua extensão, alternando com curtos segmentos convergentes. Produz terremotos costeiros, fossas descontínuas e deformação submarina, mas não sustenta um arco vulcânico contínuo. Essa borda pertence a um sistema distinto e não participa diretamente da origem de Yamashiro.

Ao sul, a relação com o Ocíduo é mediada pelo sistema tético. Uma faixa de crosta oceânica remanescente que está sendo consumida enquanto segmentos laterais deslizam por falhas transformantes. A geometria alterna compressão e movimento horizontal. Por isso o Mar Tético não possui uma única linha tectônica e seu fechamento avança de forma desigual.

## PLACA OCÍDUA

A Placa Ocídua é um mosaico de terrenos acrescidos a um núcleo relativamente estável. Seu cráton central, consolidado há aproximadamente 1,2 bilhão de anos, sustenta grande parte de Verdania e Colhara. A diversidade mineral das margens resulta da incorporação de antigos arcos insulares, sedimentos oceânicos, fragmentos de crosta e intrusões magmáticas. Duas montanhas próximas podem expor histórias alquímicas que se formaram em lados diferentes de um oceano desaparecido.

A borda norte aproxima-se do Tramontana enquanto a crosta tética intermediária mergulha. A plataforma rasa do Mar Tético é o remanescente de uma bacia mais ampla. Em cerca de trinta milhões de anos, se as velocidades atuais persistirem, o mar poderá fechar-se ou reduzir-se a lagos e estreitos. Essa previsão não descreve uma linha reta inevitável. Colisões podem alterar o movimento das placas; ainda assim, a tendência de encurtamento é inequívoca.

A costa de Contigo ocupa uma margem passiva herdada de um rifte antigo. A separação ativa cessou, mas a crosta continua esfriando e afundando lentamente. Rios curtos depositaram espessas camadas de sedimento no talude. Matéria orgânica soterrada formou bacias de hidrocarbonetos ainda inacessíveis às técnicas correntes e, mais importante para o presente, ambientes ricos em organismos abissais e óleos de profundidade. A ausência de vulcanismo recente não significa ausência de risco: deslizamentos submarinos podem produzir ondas destrutivas nas estreitas planícies costeiras.

A leste, a placa comprime-se contra o Alvor. O Istmo de Veth representa uma zona de sutura elevada, construída por blocos dobrados e falhas inversas. A compressão não gerou uma cadeia única porque a crosta estava fragmentada antes do encontro. Montanhas áridas, bacias fechadas e corredores estreitos alternam-se, tornando a fronteira física mais complexa que qualquer limite político desenhado sobre ela.

## PLACA DO ALVOR

A Placa do Alvor recebeu compressão de três direções durante dezenas de milhões de anos. O efeito principal foi o espessamento de uma área continental ampla. O Grande Planalto do Alvor parece plano quando observado de longe, mas essa planura ocupa altitude elevada e é cercada por escarpas que registram falhas, flexão e erosão. O planalto não surgiu como uma mesa inteira; ele cresceu pela integração de blocos levantados e bacias preenchidas até que diferenças locais fossem suavizadas por sedimentos e pelo vento.

Ao norte, a Placa Oceânica Norte mergulha sob Alvor. A compressão elevou o Arco Montanhoso Norte, aproximou rochas profundas da superfície e criou uma fossa externa. O vulcanismo recente é menos contínuo que em Yamashiro porque a placa oceânica chega com menor teor de água e ângulo diferente. A cadeia é sobretudo orogênica: dobramentos, falhas inversas e intrusões antigas sustentam seus picos.

Ao sul, o contato com a Placa Auster ocorre por uma ampla zona de cisalhamento. Blocos deslocam-se lateralmente, sobem ou afundam conforme as falhas se cruzam. Madzimbabwe, Axum e as bacias austrais ocupam esse mosaico. Terremotos podem ocorrer longe da linha costeira porque a deformação se distribui por centenas de quilômetros. A elevação de Axum recebe influência adicional de um ponto quente sob a placa.

A leste, o Alvor converge com Yawurua. A crosta oceânica que antes separava os blocos foi quase inteiramente consumida. O estágio atual é de colisão continental progressiva, com Kitomena comprimida entre as margens. A deformação produz metamorfismo, elevação insular e falhas profundas. A união completa levará milhões de anos, mas cada grande terremoto reorganiza uma fração desse contato.

O Vale do Netjer é uma ruptura intraplaca. Tensões de distensão abriram um corredor alongado dentro do planalto sem separar uma nova placa. Falhas normais rebaixaram o bloco central, e sedimentos fluviais cobriram parte das escarpas. A atividade é baixa no presente, porém fontes quentes e pequenos abalos mostram que o rift não está inteiramente morto.

## YAWURUA, KITOMENA E AOTEAROA

Yawurua conserva o cráton mais antigo conhecido, com 3,4 bilhões de anos. Sua longa estabilidade permitiu erosão alquímica intensa, remoção de minerais menos resistentes e concentração de quartzo. O interior apresenta baixa sismicidade e relevo reduzido. A margem ocidental, comprimida pelo Alvor, é mais jovem e deformada. A oriental encontra a Placa Forânea por segmentos de falha, compressão e subducção que permanecem afastados do núcleo cratônico.

Kitomena, também chamada Ínsula Verde, ocupa uma microplaca continental entre Alvor e Yawurua. Camadas sedimentares ricas em sílica e matéria orgânica foram soterradas, fraturadas e atravessadas por fluidos hidrotermais durante a compressão. O metamorfismo de baixa temperatura produziu minerais fibrosos, cristais azuis e veios que seguem falhas antigas. A ilha possui terremotos moderados, fontes quentes e deslizamentos frequentes, mas não constitui arco vulcânico ativo.

Aotearoa encontra-se mais a leste e recebe compressão entre terrenos ligados ao Alvor e a Placa Forânea. Sua crosta é fina, fraturada e parcialmente oceânica. Magma ascende por falhas, criando ilhas vulcânicas e campos geotérmicos. O pounamu óptico forma-se em zonas metamórficas nas quais pressão, circulação de fluidos e composição mineral coincidiram. Construções tradicionais distribuem peso, empregam juntas flexíveis e evitam encostas cujo solo já deslizou em gerações anteriores.

## XOCHIATLALPAN E AS MICROPLACAS OCIDENTAIS

Xochiatlalpan, as Ilhas Verdes, ocupa plataforma rasa sobre uma microplaca em compressão residual. A fase vulcânica principal terminou há milhões de anos. Magmas ricos em sílica formaram domos de riolito viscoso, baixos e arredondados, hoje profundamente erodidos. A subsidência posterior permitiu que recifes crescessem sobre antigas bordas vulcânicas e transformassem depressões em lagoas.

A região ainda registra pequenos terremotos e deformação lenta, mas não sustenta vulcanismo ativo comparável a Yamashiro. Falhas submarinas reorganizam canais entre ilhas e podem romper recifes. A origem geológica explica a variedade de águas: algumas lagoas quase não trocam com o Mar Lateral, enquanto estreitos próximos recebem correntes fortes e nutrientes de profundidade.

A microplaca oceânica a oeste do Ocíduo afasta-se lentamente da margem de Contigo. O movimento atual é fraco; a maior parte da abertura aconteceu durante a Grande Fragmentação. A linha de separação mantém montes submarinos, falhas e fontes hidrotermais dispersas. Seu papel sobre o clima é indireto, por controlar a profundidade e a trajetória da Corrente de Contigo.

## PLACAS POLARES E OCEÂNICAS

A Placa Polar Norte sustenta a Franja Norte e parte do oceano setentrional. Sua borda com Tramontana alterna subducção e colisão oblíqua. Dorsais no oceano renovam a crosta e afastam material para ambos os lados. O gelo esconde muitos limites; sua posição é inferida por terremotos, magnetismo e variações do fundo medidas por sondagem.

A Placa Auster sustenta o continente polar meridional. Ao norte, encontra o Alvor por cisalhamento e o Ocíduo austral por limites mistos. A espessa carga de gelo deprime a crosta. Quando o gelo diminui, a superfície sobe lentamente, movimento que continua séculos depois do derretimento. Esse ajuste altera costas, inclinação de rios e tensão em falhas sob o continente.

As placas oceânicas Norte e Forânea são continuamente formadas em dorsais e consumidas em fossas ou zonas de convergência. A idade do fundo aumenta à medida que se afasta das dorsais. Faixas magnéticas simétricas registram inversões antigas do campo e permitem calcular velocidades de abertura. A Microplaca Yamashirense possui origem diferente: sua crosta não está sendo criada por uma dorsal atual. É o remanescente deformado do Mar Antigo de Yamashiro, preservado dentro de uma placa continental reunificada. A comparação entre os padrões magnéticos de Yamashiro, Aotearoa e do Mar de Fora permitiu separar crosta oceânica ativa de crosta residual aprisionada.

## SISMICIDADE E FALHAS

Terremotos ocorrem quando rochas deformadas ultrapassam a resistência que mantinha uma falha presa. A ruptura libera energia acumulada e envia ondas pela crosta. Magnitude mede a energia; intensidade descreve o efeito em determinado lugar. Um abalo profundo e distante pode ser amplamente sentido mesmo sem destruir, enquanto uma ruptura rasa sob uma cidade menor pode produzir danos severos.

Arden possui quatro grandes sistemas de instabilidade. A Sutura Yamashirense concentra terremotos profundos, falhas de bacia e vulcanismo residual dentro do Tramontana. A Margem Forânea reúne a borda oriental do Tramontana, Aotearoa e o leste de Yawurua, embora a geometria varie entre transformação e convergência. O sul do Alvor atravessa Madzimbabwe, Axum, Kitomena e a margem ocidental de Yawurua. O cinturão setentrional acompanha Myrova e a Franja Norte.

Os terremotos de Yamashiro distinguem-se pela distribuição em profundidade. Abalos rasos acompanham falhas da Microplaca Yamashirense e fraturas vulcânicas. Outros formam uma faixa inclinada sob as ilhas e alcançam profundidades maiores em direção ao Tramontana oriental. Essa geometria revela a lâmina oceânica residual. O Istmo de Veth, o rift do Netjer e falhas antigas do Arco Central apresentam atividade moderada. Os interiores de Vélia, Grauth, Verdania, Kemet e Yawurua central permanecem pouco sísmicos.

A Rede Sismográfica da Concordância registra hora, direção e amplitude das ondas. Três estações permitem localizar o epicentro; muitas permitem estimar profundidade e reconstruir a ruptura. A prevenção depende de mapas de solo tanto quanto de mapas de falha. Sedimentos moles amplificam vibração; encostas saturadas deslizam; aterros portuários podem perder resistência. Yamashiro e Aotearoa aprenderam a tratar o terreno como parte da construção.

| Faixa de risco | Regiões | Processos dominantes |
| --- | --- | --- |
| Muito elevada | Mutsuro e Aotearoa | janelas de lâmina, vulcanismo ativo, falhas insulares e tsunamis |
| Elevada | demais ilhas de Yamashiro, margem Forânea, sul do Alvor, Kitomena e margem ocidental de Yawurua | subducção residual, transformação oblíqua, cisalhamento e colisão continental |
| Moderada | Myrova norte, Istmo de Veth, Netjer e bordas da Bacia Yamashirense | subducção lenta, compressão, rifte intraplaca e falhas antigas reativadas |
| Baixa | Arco Central fora da sutura ativa, Xochiatlalpan e margens sedimentares | ajuste crustal, deformação residual e deslizamentos submarinos |
| Muito baixa | crátons de Tramontana, Verdania e Yawurua | interiores frios, espessos e mecanicamente estáveis |

## A SUTURA E O ARCO VULCÂNICO DE YAMASHIRO

As cinco ilhas de Yamashiro ocupam a porção emersa de um arco formado durante o fechamento do Mar Antigo de Yamashiro. A crosta oceânica da bacia começou a mergulhar para leste sob terrenos associados ao bloco oriental do Tramontana. Os magmas produzidos acima da lâmina construíram vulcões submarinos, plataformas de cinza e corpos intrusivos. A maior parte da antiga cadeia permanece abaixo da água; as ilhas atuais correspondem aos edifícios que conservaram elevação suficiente para ultrapassar a superfície.

A colisão que formou o Arco Montanhoso Central reduziu o espaço da bacia e deformou o arco insular, mas não encerrou sua atividade. A lâmina oceânica residual continua descendendo em alguns segmentos. Em outros, rompeu-se e abriu janelas pelas quais material quente do manto alcança a base da crosta. O sistema moderno resulta da combinação entre essa subducção tardia, o movimento da Microplaca Yamashirense e a extensão produzida pelo relaxamento da raiz montanhosa a oeste.

Mutsuro encontra-se sobre a maior janela reconhecida. Seus dois vulcões recebem magma basáltico e intermediário com frequência suficiente para manter atividade quase contínua. As ilhas centrais ocupam trechos onde a lâmina permanece mais profunda ou descontínua. Suas caldeiras são dormentes, mas reservatórios magmáticos e hidrotermais ainda transferem calor para a superfície. Mudanças na composição dos gases, na temperatura das nascentes e na elevação do terreno são observadas em conjunto porque nenhum desses sinais isolados oferece previsão segura.

Água da Bacia Yamashirense infiltra-se em falhas, aquece em profundidade, dissolve minerais e retorna por nascentes e fumarolas. Onde as passagens permanecem abertas, a pressão é liberada gradualmente. A precipitação mineral pode fechar condutos e permitir que vapor se acumule, produzindo explosões hidrotermais sem novo magma. Os onsens dependem desse circuito. Cada complexo registra temperatura, acidez, sais e vazão, pois alterações persistentes podem anunciar uma mudança subterrânea ou contaminação por fluidos mais profundos.

Yamashiro possui obsidiana, enxofre, metais hidrotermais e minerais ópticos próprios. Mesmo com a confusão, o pounamu de Aotearoa não se formou nesse sistema. Atribuições antigas resultaram da aparência semelhante de certos cristais verdes. Mas inclusões microscópicas e padrões de pressão demonstraram que o pounamu pertence à história metamórfica da microplaca aotearoana.

## O PONTO QUENTE DE AXUM

Axum assenta sobre uma coluna quente que transfere material do manto profundo para a base da placa. Ao contrário de uma zona de subducção, o ponto quente permanece aproximadamente fixo enquanto a placa se move. Derrames basálticos sucessivos cobriram o terreno por cerca de trinta milhões de anos, construindo um planalto de camadas sobrepostas. A maior parte do vulcanismo superficial terminou, mas calor residual alimenta fontes, altera águas subterrâneas e mantém atividade sísmica localizada.

O basalto de Axum é rico em ferro e magnésio. Intemperismo sob chuva sazonal produz solos escuros e férteis. Colunas prismáticas formam-se quando grandes massas de lava esfriam e contraem. Os obeliscos antigos foram extraídos de afloramentos onde fraturas naturais facilitaram a retirada de longos blocos. A orientação magnética dos minerais varia por derrame e registra a direção do campo quando cada camada solidificou.

| ANOTAÇÃO MARGINAL BASALTO AXUMITA Certas colunas apresentam estabilidade incomum quando incorporadas a Selos, mas a relação não acompanha apenas o teor de ferro. Orientação dos grãos, histórico térmico e Significância acumulada nos locais de extração parecem contribuir. Os experimentos de 1.829 confundiram essas variáveis e não devem ser citados como uma demonstração causal. |
| --- |

## MYROVA DO NORTE

O vulcanismo setentrional de Myrova produz escudos baixos e largos. O magma basáltico flui com facilidade, cobrindo grandes áreas em camadas finas. Erupções são raras diante da escala de uma vida humana, porém podem durar meses. Os eventos de 1.203 e 1.441 lançaram cinzas suficientes para reduzir colheitas no norte de Grauth e Daesung durante duas estações.

A cobertura de gelo altera o perigo. Lava sob gelo derrete em água rapidamente; lagos represados podem romper e descer vales como enxurradas carregadas de sedimento. Cinza sobre neve reduz a reflexão da luz e acelera o derretimento. Por isso os observatórios de Myrova monitoram não apenas tremores, mas temperatura de rios subglaciais e composição de gases que atravessam fissuras.

## AOTEAROA E XOCHIATLALPAN

Aotearoa combina vulcões de cone, caldeiras, fontes termais e falhas superficiais. A posição de centros eruptivos muda conforme fraturas são seladas e reabertas. Algumas ilhas cresceram pela união de cones antes separados. Outras perderam encostas inteiras para o mar. Depósitos de cinza preservam sucessivas erupções e permitem comparar intervalos, embora nenhum ciclo seja regular o bastante para funcionar como calendário seguro.

Xochiatlalpan registra o estágio posterior de um sistema vulcânico. Domos riolíticos endureceram, fraturaram e foram erodidos. Solos derivados de cinza antiga permanecem férteis, e fraturas conduzem água doce para lagoas costeiras. Não há evidência de magma raso atual. Pequenos fluxos de gás e calor em duas ilhas resultam de circulação profunda e não indicam reativação iminente.

## KITOMENA E O CRISTAL AZUL

Kitomena não é um simples vulcão extinto. Sua geologia resulta de compressão, metamorfismo e circulação hidrotermal. Camadas sedimentares, incluindo depósitos ricos em matéria orgânica e sílica, foram dobradas e atravessadas por fluidos aquecidos em profundidade. O Cristal Azul cresceu em fraturas onde a composição da água, a pressão e o resfriamento permitiram uma estrutura fibrosa capaz de conduzir radiação de alta energia.

Veios economicamente úteis são estreitos e descontínuos. A cor não basta para identificar qualidade; inclusões, orientação e microfraturas que determinam a condução. Uma extração descontrolada altera a pressão em encostas e pode drenar fontes. Por isso, o governo kitomenense limita as galerias por bacia hidrográfica, uma medida geológica que também protege a agricultura da ilha.

## GEOTERMIA E FONTES TERMAIS

Calor geotérmico alcança a superfície em regiões vulcânicas, riftes e falhas profundas. A temperatura cresce em média com a profundidade, mas o gradiente é maior em Yamashiro, Aotearoa, Axum, Myrova e sul do Alvor. Água circula por fraturas, aquece e retorna transportando sais. A composição revela as rochas atravessadas e pode indicar mistura com fluidos magmáticos.

A exploração geotérmica exige equilíbrio. Retirar água mais rápido que a recarga reduz pressão, resfria reservatórios e pode causar subsidência. Reinjeção preserva o ciclo, mas fluidos frios em falhas tensionadas podem induzir pequenos terremotos. O Livro III descreve a conversão técnica desse calor; aqui importa sua origem e distribuição.

PARTE IV
