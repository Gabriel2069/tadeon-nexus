---
title: "Geografia de Veth — TOPOGRAFIA E GEOMORFOLOGIA"
node_type: "concept"
summary: "Seção “TOPOGRAFIA E GEOMORFOLOGIA” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["TOPOGRAFIA E GEOMORFOLOGIA"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"TOPOGRAFIA E GEOMORFOLOGIA","source_order":4,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# TOPOGRAFIA E GEOMORFOLOGIA

Relevos, altitudes e processos de superfície

Relevo é tectônica submetida ao tempo. A elevação oferece matéria; água, gelo, vento e vida decidem a forma que permanecerá visível.

## PROCESSOS QUE MODELAM A SUPERFÍCIE

Montanhas surgem por elevação, mas sua aparência resulta de erosão. Água abre vales, gelo alarga corredores, vento transporta grãos e variações térmicas fragmentam pedra. A composição da rocha controla a resistência: calcário dissolve-se e forma cavernas; granito produz blocos; basalto origina escarpas e solos escuros; arenito preserva mesas e inselbergs onde camadas duras protegem material mais fraco.

Rios transportam sedimento das alturas para planícies e mares. Quando perdem velocidade, depositam primeiro cascalho, depois areia, silte e argila. Deltas crescem, canais mudam e terras férteis ocupam antigas superfícies de inundação. Encostas nunca estão inteiramente em repouso. O solo desloca-se lentamente; chuvas ou terremotos podem acelerar o processo com deslizamentos.

A ação humana já modifica a geomorfologia em escala regional. Terraços de Tahuantinsuyu reduzem erosão; canais de Huexotl redistribuem sedimentos; diques do Han Ji confinam cheias; mineração rebaixa encostas; cidades portuárias avançam sobre aterros. Essas formas recentes não competem em idade com montanhas, mas alteram o caminho de água e solo o bastante para se tornarem parte da paisagem.

## LOBO TRAMONTANA

A GRANDE PLANÍCIE CENTRAL

A planície central ocupa o interior de Grauth, Rethmark, Daesung e parte de Qin. Sua superfície resulta de sedimentos marinhos antigos cobertos por depósitos fluviais e eólicos. Em muitos trechos, a diferença de altitude ao longo de cinquenta quilômetros é inferior a quinze metros. A aparência plana esconde vales rasos, terraços abandonados e antigas linhas de costa.

A oeste, rios vindos do Arco Central depositam silte fértil e sustentam agricultura intensiva. Ao leste, areias e cascalhos antigos drenam rapidamente e favorecem pastagens ou culturas adaptadas. O mesmo fundamento geológico permitiu economias diferentes. Grauth canalizou água para grãos e indústria; Rethmark combinou planície pastoril com mineração montanhosa; Qin construiu sistemas de diques sobre a faixa aluvial do Han Ji.

O ARCO MONTANHOSO CENTRAL

O Arco estende-se por cerca de 4.200 quilômetros, do entorno do Mar Tético até o planalto de Nordhavn. As cristas médias variam entre 2.800 e 3.500 metros; picos centrais atingem 4.900. A cadeia ocupa a principal zona de colisão entre os antigos blocos ocidental e oriental do Tramontana. Sua largura não corresponde a uma única falha. Dobramentos, escamas de crosta empilhada, intrusões e terrenos oceânicos acrescidos formam uma faixa cuja história muda de um vale para outro.

Rochas encontradas nas partes altas registram ambientes que já não existem naquele lugar. Basaltos formados no fundo do Mar Antigo de Yamashiro aparecem junto a sedimentos marinhos metamorfizados, fragmentos de manto e granitos produzidos durante o engrossamento da crosta. A erosão expôs esses materiais e abriu vales profundos. Em segmentos antigos, os picos tornaram-se arredondados; onde rochas mais resistentes sustentam a crista, permanecem paredes abruptas.

Doze passes naturais atravessam a cadeia acima de dois mil metros. A neve fecha os mais altos durante grande parte do ano. Valdmere ocupa vales e terraços onde a superfície permite cultivo e as encostas dão acesso a pastagem, rocha e água de degelo. O Arco também divide drenagens. As vertentes ocidentais alimentam o Mar Tético; as orientais descem para a Bacia Yamashirense e para o Mar de Veth. Setores ao norte enviam rios para Myrova e Nordhavn.

A face oriental apresenta escarpas mais complexas que a ocidental. Falhas de empurrão antigas foram cortadas por falhas posteriores de relaxamento. Blocos descem em degraus até a bacia interior, formando vales estreitos, lagos alongados e corredores sujeitos a deslizamentos. Essa borda permanece a parte mais ativa da cordilheira, embora sua deformação seja pequena diante da atividade das ilhas.

VÉLIA, SOLANE E GRAUTH

A oeste do Arco, o relevo desce em três degraus. Vales de transição ocupam altitudes entre quinhentos e mil e oitocentos metros. Colinas de sopé reúnem solos bem drenados e exposição estelar, favoráveis às vinhas de Solane e do sul de Vélia. Mais próximo dos mares, planícies aluviais e costeiras concentram portos, cidades e agricultura.

Vélia apresenta costa recortada por penínsulas, ilhas e antigas desembocaduras submersas. A limitação de terra plana estimulou cidades densas. Solane ocupa bacia ampla atravessada pelo Soiena; suas colinas se organizam em torno de tributários e aquedutos. Grauth possui planície interior mais contínua, interrompida por morainas antigas e terraços do Brennwald.

ALBRATH E O CANAL

Albrath é um conjunto insular e peninsular de rochas antigas, separado do continente pelo Canal de Albrath. As ilhas maiores possuem colinas arredondadas, lagos glaciais e costas rochosas. O gelo setentrional não cobriu toda a região, mas línguas glaciais escavaram vales posteriormente inundados. Portos naturais surgiram onde esses vales encontram o mar.

O canal ocupa uma falha e antiga passagem de gelo. Correntes fortes atravessam sua seção estreita e expõem bancos em maré baixa. Falésias de rocha resistente alternam-se com enseadas sedimentares. A posição fez de Albrath passagem entre o Mar Tético e o Oceano Central, ao mesmo tempo protegida e difícil de dominar a partir da terra.

RETHMARK E VALDMERE

Rethmark ocupa vales mineralizados na borda do Arco. Rochas metamórficas e intrusões antigas concentram rethita, cobre e metais associados. A topografia é compartimentada: bacias pequenas comunicam-se por gargantas, e estradas seguem rios ou passes. As cidades cresceram onde vales, minas e águas se encontram, o que as torna vulneráveis a deslizamentos e contaminação de nascentes.

Valdmere está mais alto e mais próximo das cristas. Seus cantões correspondem em parte a bacias independentes. A separação física contribuiu para autonomia política, mas não a determinou sozinha. Casas de Guarda aproveitam maciços de rocha estável e temperatura subterrânea constante. Postos de Clareza situam-se acima da faixa de floresta, onde o ar seco favorece a observação óptica.

NORDHAVN, MYROVA E FRANJA NORTE

Nordhavn possui costa recortada por fiordes, vales escavados pelos mantos da Franja Norte durante máximos glaciais. Paredes rochosas descem ao mar, e terras agrícolas concentram-se em terraços, deltas e fundos de vale. Ilhas exteriores quebram ondas e oferecem portos; também criam canais estreitos sujeitos a correntes violentas.

Myrova forma transição entre planaltos, taiga, tundra e montanhas polares. O interior contém superfícies antigas cobertas por permaglacis. No verão, apenas a camada superior descongela, produzindo lagos rasos e solos saturados. Ao norte, montanhas vulcânicas e glaciares elevam-se diante da Franja Norte. Rios seguem para o Mar Polar ou para o Mar de Veth, transportando pouca matéria durante o inverno e enormes cargas no degelo.

A Franja Norte reúne arquipélagos, plataformas de gelo e fragmentos continentais. Parte permanece coberta por gelo durante todo o ano; parte emerge no verão como tundra pedregosa. O relevo subglacial é conhecido por sondagens incompletas. Canais profundos indicam antigos rios ou geleiras anteriores ao atual manto.

DAESUNG, QIN E O ORIENTE

O Tramontana oriental desce do Arco para planícies fluviais amplas. Daesung possui terraços antigos e colinas baixas, com costa setentrional mais fria e recortada. Qin ocupa a bacia do Han Ji, onde o rio depositou sedimentos por milhões de anos. O delta avança sobre o mar e exige manutenção constante de canais.

Montanhas costeiras menores recebem umidade de monção e produzem rios curtos. Entre elas e o Arco há bacias agrícolas densas. A topografia facilita comunicação norte-sul, mas cheias e deslocamento de canais obrigaram cidades a construir sobre terraços ou aterros elevados.

YAMASHIRO

As cinco ilhas elevam-se abruptamente do oceano. Planícies costeiras são estreitas e formadas por deltas, cinza e material de deslizamento. Cones vulcânicos ocupam o interior; caldeiras abrigam lagos e cidades protegidas do vento. Encostas de barlavento recebem as chuvas intensas e são cortadas por rios curtos.

A ilha de Mutsuro possui relevo mais jovem, com campos de lava, cinza instável e pouca terra plana. As ilhas centrais apresentam solos profundos e terraços agrícolas. A construção humana acompanha curvas de nível e evita canais de lahar reconhecidos por depósitos antigos.

## LOBO OCÍDUO

A BACIA DE VERDANIA

Verdania ocupa uma depressão continental ampla cercada por terrenos mais altos. A altitude central varia em grande parte entre cem e trezentos metros, embora tepuis e serras isoladas ultrapassem dois mil. Rios vindos da Cordilheira Ocidental, de Colhara e do norte convergem para o Meduna. A baixa declividade produz meandros, igapós, lagos abandonados e planícies inundáveis.

Os tepuis são blocos de arenito antigo protegidos por camadas resistentes. Suas paredes isolam superfícies superiores há milhões de anos. Cachoeiras caem diretamente das bordas, e solos rasos sustentam a flora endêmica. A floresta oculta grande parte do relevo, mas não o elimina: pequenas diferenças de altura decidem quais áreas permanecem inundadas e quais conservam terra firme.

CORDILHEIRA OCIDENTAL E TAHUANTINSUYU

A Cordilheira Ocidental estende-se por cerca de sete mil quilômetros, do norte de Colhara ao sul de Contigo. O Pico Inti, em Tahuantinsuyu, atinge aproximadamente 6.200 metros e é o ponto mais alto conhecido de Arden. Cristas comuns variam entre quatro mil e quatro mil e oitocentos metros. Entre cadeias externas e internas há altiplanos de 3.500 a 4.200 metros.

Tahuantinsuyu ocupa esses altiplanos e vales altos. Geleiras alimentam lagoas e rios; bacias fechadas acumulam sais; encostas foram convertidas em terraços. A altitude reduz oxigênio e temperatura, mas amplia radiação estelar. Passes controlam o deslocamento. A Estrada Real segue divisores estáveis e evita fundos de vale, sujeitos a inundação ou deslizamento.

CONTIGO

A costa de Contigo tem em média oitenta quilômetros entre a cordilheira e o Mar Lateral. Escarpas descem de quatro mil metros até o nível do mar em distâncias curtas. Rios percorrem menos de cem quilômetros com declives elevados, transportando cascalho, areia e matéria orgânica. Deltas são as principais superfícies planas disponíveis para cidades.

A Corrente de Contigo resfria a costa e favorece neblina. Onde montanhas interceptam umidade, florestas úmidas ocupam encostas; sotaventos formam vales secos. O talude submarino cai rapidamente, permitindo acesso a águas profundas próximo do litoral. Essa proximidade sustenta pesca abissal e também expõe portos a ondas geradas por deslizamentos.

HUEXOTL E TLACUA

O noroeste do Ocíduo reúne planaltos áridos, bacias fechadas e cadeias vulcânicas antigas. Huexotl ocupa planalto entre 2.200 e 2.400 metros, cercado por montanhas que atingem 4.800. O Lago Texcoco Central é raso e salino, sem saída permanente para o oceano. Sedimentos e evaporação concentraram sais; canais e chinampas transformaram as margens instáveis em um sistema agrícola.

Tlacua estende-se por planaltos mais secos, mesas e depressões onde a água aparece sazonalmente. A topografia organiza rotas de pastoreio. Escarpas servem como referência; vales secos podem tornar-se rios por poucas horas após tempestades. Pontos de água dependem de falhas, camadas porosas e aquíferos suspensos.

XOCHIATLALPAN

As Ilhas Verdes ocupam domos riolíticos antigos cercados por plataforma recifal. O interior das ilhas maiores apresenta colinas arredondadas, solos vulcânicos e pequenas bacias de água doce. Costas de barlavento são mais altas; lagoas protegidas acumulam sedimentos finos e manguezais.

Recifes formam parte do relevo. Crescem em direção à luz, acompanham a subsidência lenta e quebram ondas antes que alcancem as praias. Canais entre recifes podem concentrar correntes. A topografia submarina determina a navegação e distribuição biológica com a mesma força que as montanhas determinam rotas terrestres.

COLHARA, RIOSOLA, CALÇADA E FRONTIER-SUD

Colhara é um planalto de transição entre Verdania, a cordilheira e as planícies meridionais. Superfícies antigas foram cortadas por rios e separadas em chapadas. O norte é mais úmido; o sul possui savanas e vales amplos. Recursos minerais concentram-se nas bordas onde a erosão expõe rochas profundas.

Riosola ocupa uma planície de Lös formada por poeira transportada da cordilheira. Ondulações de dez a trinta metros são quase invisíveis no horizonte, mas controlam drenagem e divisão de propriedades. Solos profundos sustentam pastagens; rios tornam-se lentos e meandrantes.

Calçada reúne estuários, cordões de areia e planícies costeiras. A Frontier-Sud alonga-se por latitudes e altitudes diferentes, combinando serras, florestas frias e pradarias. Seu relevo foi parcialmente modelado por glaciações austrais, que deixaram lagos, vales largos e depósitos de cascalho.

## LOBO ALVOR

O GRANDE PLANALTO E O DESERTO

O Grande Planalto do Alvor possui uma altitude média entre seiscentos e novecentos metros, com setores internos acima de mil e quinhentos. Escarpas de quatrocentos a setecentos metros marcam várias bordas. A superfície superior reúne bacias preenchidas, rochas expostas, dunas e planícies pedregosas. De longe parece só mesa; mas em escala local é um mosaico de depressões, mesas e corredores.

O Grande Deserto de Veth ocupa o interior onde cadeias e altitude bloqueiam umidade. Dunas móveis cobrem parte da região; áreas maiores são desertos de cascalho ou rocha. Lagos temporários recebem água de tempestades e deixam sal. Ventos removem partículas finas, polindo superfícies e transportando poeira para o Mar Tético e Yawurua.

O VALE DO NETJER E KEMET

O rift do Netjer corta o planalto por cerca de 1.200 quilômetros. O bloco central está entre trinta e sessenta metros abaixo das margens próximas, e em alguns trechos muito mais abaixo do planalto regional. Escarpas delimitam a faixa irrigável. Tributários são curtos, descendo de forma abrupta antes de alcançar o rio.

O vale alarga-se próximo ao delta tético. Séculos de cheias depositaram silte sobre os cascalhos antigos. Canais abandonados e diques naturais marcam os deslocamentos passados. A agricultura ocupa uma superfície estreita; já acima das escarpas, a aridez retorna em poucos quilômetros.

TYRENIA, QALAT E O ARCO NORTE

O Arco Montanhoso Norte alcança entre 2.200 e 3.400 metros e acompanha a costa tética. Sua vertente norte recebe chuva de inverno; a sul desce para o planalto seco. Tyrenia ocupa planícies costeiras, colinas calcárias e baías abrigadas. Qalat combina litoral, oásis, vales montanhosos e corredores desérticos.

Calcários do arco formam cavernas e aquíferos. Nascentes emergem onde camadas permeáveis encontram rochas impermeáveis, permitindo cidades longe de rios permanentes. Falésias costeiras e plataformas marinhas registram mudanças do nível do mar e elevação lenta.

MANSA, NZADI, AXUM E MADZIMBABWE

O sul do Alvor é dividido por falhas transcorrentes. Mansa ocupa serras e planaltos secos, com rios sazonais que seguem fraturas. Nzadi reúne bacias mais úmidas e vales que recebem água das terras altas. O Rio Altea é parte integrante desse sistema e atravessa zonas de altitude diferente antes de alcançar o mar.

Axum é um planalto basáltico que chega a três mil metros. A superfície foi cortada por desfiladeiros, e mesas de lava preservam solos férteis. Escarpas controlam monções e isolam comunidades. Madzimbabwe combina blocos levantados, vales de rift e planícies de savana; o relevo muda em distâncias curtas e produz grande variedade local de chuva.

YAWURUA

Yawurua é a maior planície antiga de Arden. Fora das montanhas costeiras recentes, o ponto mais alto alcança cerca de 843 metros. Bilhões de anos de intemperismo reduziram antigas cadeias a superfícies suaves. Inselbergs de rocha resistente e platôs de arenito surgem isolados e servem como marcos de navegação.

Rios possuem baixo gradiente e podem dispersar-se em canais sazonais. Áreas secas acumulam crostas e dunas baixas; o litoral oriental apresenta elevações recentes ligadas ao contato com a placa oceânica. As songlines seguem afloramentos, poços e corredores cuja importância não é evidente para visitantes sem conhecimento local.

KITOMENA E AOTEAROA

Kitomena possui núcleo montanhoso de altitude moderada, vales úmidos e costas recortadas. A compressão elevou blocos e abriu falhas que conduzem fontes. O leste recebe mais chuva; o interior sustenta a floresta e a agricultura; o oeste possui savanas e encostas secas. Minas de Cristal Azul seguem veios no núcleo, e sua exploração precisa evitar bacias de nascente.

Aotearoa é mais acidentada. Cones, caldeiras, planícies de lava e cadeias costeiras ocupam as ilhas próximas. Fiordes austrais foram escavados por gelo de altitude; costas orientais recebem ondas longas do Mar de Fora. Terras planas concentram-se em deltas e caldeiras antigas.

## VETH CINÉRIO

Veth Cinério possui maciço central elevado, costas úmidas e planícies estreitas. O Cerne ocupa um platô de bordas abruptas, cercado por vales radiais. A geologia confirmada inclui rochas metamórficas antigas, intrusões e grandes falhas. A idade de algumas superfícies permanece contraditória porque métodos diferentes produzem resultados incompatíveis.

Rios são curtos e descem do maciço para o mar. A vegetação dificulta levantamento, e neblina reduz a observação aérea. Certos mapas antigos registram vales que expedições recentes não localizaram; erros de posição, deslizamentos e deformação de memória são hipóteses concorrentes. A costa continua cartografável. O interior não deve ser apresentado com precisão que os dados não sustentam.

## LOBO AUSTER

O Lobo Auster é um continente rochoso sob camada de gelo que ultrapassa dois quilômetros em áreas centrais. Montanhas emergem como nunataks; outras permanecem inteiramente cobertas. A carga do gelo deprime a crosta, e plataformas avançam sobre o mar. O interior é planalto glacial de baixa precipitação, equivalente a deserto frio.

Sondagens revelam vales, bacias e possíveis lagos subglaciais. Correntes de gelo deslocam-se mais rápido que o entorno e descarregam em plataformas. A borda norte possui penínsulas e ilhas que ficam parcialmente livres no verão. A topografia rochosa é conhecida apenas em linhas de expedição e por medidas gravimétricas.

PARTE V
