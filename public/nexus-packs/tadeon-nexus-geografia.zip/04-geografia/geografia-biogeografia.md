---
title: "Geografia de Veth — BIOGEOGRAFIA"
node_type: "concept"
summary: "Seção “BIOGEOGRAFIA” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["BIOGEOGRAFIA"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"BIOGEOGRAFIA","source_order":8,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# BIOGEOGRAFIA

A distribuição da vida e os ambientes que a sustentam

A vida não cobre o mundo como tecido colocado sobre pedra. Ela penetra fendas, produz solos, altera água e muda a própria superfície que parecia apenas a receber.

## ORIGEM, DISPERSÃO E ISOLAMENTO

A distribuição das espécies reflete Plaganeter, a fragmentação dos lobos, a elevação das montanhas e as glaciações. Linhagens antigas aparecem em continentes separados porque existiam antes da abertura dos mares. Outras atravessaram pontes expostas durante níveis baixos ou foram transportadas por correntes, aves e humanos.

O isolamento produz endemismo. Aotearoa, Xochiatlalpan, Yamashiro e tepuis de Verdania conservam espécies ausentes em outras regiões. Ilhas pequenas favorecem populações reduzidas, vulneráveis a doenças e introdução de competidores. Grandes cadeias atuam como barreira: espécies de Contigo e Tahau podem viver em lados opostos da mesma cordilheira sem se encontrar.

A ação humana acelerou o intercâmbio. Grãos, animais, pragas e microrganismos acompanharam o comércio tético. Certas plantas hoje consideradas tradicionais de Vélia chegaram de Kemet séculos antes da Concordância. O termo nativo descreve uma longa integração cultural, não necessariamente a origem evolutiva.

## NOMES POPULARES E CLASSIFICAÇÃO

Vethi Comum usa nomes como onça, capivara, lobo-guará e fenneco para animais reconhecidos por forma e hábito. Esses nomes não afirmam identidade taxonômica com categorias de outros sistemas acadêmicos. Uma mesma palavra pode abranger espécies próximas em regiões diferentes. Tratados científicos registram anatomia, reprodução e linhagem para evitar que semelhança popular substitua comparação.

A taxonomia moderna combina estrutura, desenvolvimento, reprodução e Fitas de Linhagem. A classificação continua provisória. Organismos marinhos simples trocam material hereditário; fungos formam redes entre indivíduos; simbioses tornam difícil decidir onde termina um organismo. A utilidade do nome está em permitir comunicação, não em encerrar a vida numa definição.

## PROVÍNCIAS BIOGEOGRÁFICAS

Arden pode ser dividido em grandes províncias: Boreal Tramontana, Temperada Tética, Oriental Monçônica, Equatorial Ocídua, Altimontana Ocídua, Árida Ocídua, Mediterrânea do Alvor, Desértica Alvorina, Savânica Austral, Cratônica de Yawurua, Insular Oriental, Polar e Cinérea. Seus limites seguem o clima, relevo e história, não a reinos.

Zonas de transição possuem diversidade elevada porque reúnem linhagens de duas províncias. Também são sensíveis a mudanças. O Istmo de Veth permitiu intercâmbio entre Ocíduo e Alvor; Colhara liga floresta e savana; Axum conecta montanha, monção e terras secas.

## FLORESTA EQUATORIAL DE VERDANIA

A floresta de Verdania possui camadas. Árvores emergentes ultrapassam cinquenta metros; o dossel pindórico concentra luz e folhas; abaixo, sub-bosque úmido recebe pouca radiação. Lianas, epífitas e fungos ocupam troncos. O solo contém poucos nutrientes disponíveis porque a matéria é rapidamente absorvida por raízes e micélios.

A floresta regula umidade por evapotranspiração. Água retirada do solo retorna ao ar e precipita novamente. Rios transportam sedimentos, sementes e organismos. Várzeas inundáveis sustentam espécies diferentes de terras firmes. Tepuis apresentam flora própria, incluindo plantas carnívoras e arbustos adaptados a solos pobres.

Grandes herbívoros abrem clareiras; predadores regulam populações; formigas e cupins movem solo. A diversidade de insetos e fungos supera a de vertebrados. Bioalquímica concentra-se nesses organismos menores porque produzem moléculas de defesa, digestão e comunicação.

## FLORESTAS TROPICAIS INSULARES DE XOCHIATLALPAN

As Ilhas Verdes possuem florestas mais baixas que Verdania, moldadas por vento, sal e ciclones. Encostas de barlavento são úmidas; sotaventos sustentam florestas estacionais e arbustos. Domos riolíticos criam solos ácidos; calcário recifal, solos alcalinos. A proximidade dessas bases amplia diversidade em pequena área.

A fauna terrestre é limitada pelo isolamento. Aves, répteis, morcegos e invertebrados dominam. Espécies de uma ilha podem não existir na seguinte. Manguezais, lagoas e recifes formam continuidade entre terra e mar. A farmacologia local depende mais da diversidade marinha que da floresta isoladamente.

Ciclones derrubam árvores e reiniciam sucessão. Plantas flexíveis, sementes resistentes à água salgada e crescimento rápido predominam nas costas. A introdução de mamíferos e fungos continentais já causou extinções locais.

## SAVANAS E CERRADOS

Savanas de Colhara, Mansa, Nzadi, Axum e Madzimbabwe alternam gramíneas com árvores espaçadas. A estação seca limita a floresta; fogo e herbivoria mantêm abertura. Raízes profundas armazenam água, cascas protegem contra calor e muitas plantas rebrotam após os incêndios.

Grandes herbívoros migram acompanhando a chuva. Predadores seguem rebanhos. Cupinzeiros concentram nutrientes e alteram a drenagem. Em Axum, solos vulcânicos sustentam gramíneas densas; em Yawurua, a baixa fertilidade produz uma savana mais aberta.

O fogo possui regimes. Queimas frequentes e leves diferem de incêndios tardios e intensos. Povos locais usam o calendário, vento e umidade para manejar a paisagem. Proibições externas podem aumentar combustível e produzir incêndios maiores.

## FLORESTAS TEMPERADAS

Florestas decíduas ocupam Vélia interior, Solane, Grauth meridional, Daesung, Qin e setores de Riosola. Árvores perdem folhas em estação fria ou seca, reduzindo a perda de água. A decomposição produz solos férteis. Clareiras sustentam arbustos, flores e caça.

Florestas oceânicas de Albrath e Nordhavn permanecem úmidas, com musgos e samambaias. Coníferas aparecem em altitudes e latitudes maiores. O uso humano fragmentou grande parte das planícies; bosques antigos sobrevivem em encostas, propriedades e áreas protegidas pela Eclésia.

A fauna inclui cervídeos, javalis, pequenos carnívoros, aves migratórias e insetos sazonais. A transição com campos agrícolas criou espécies adaptadas a mosaicos humanos.

## TAIGA E TUNDRA

Taiga de Myrova, Nordhavn interior e Frontier-Sud é formada por coníferas, bétulas e larícios adaptados a frio. Crescimento é lento; incêndios e insetos podem alterar áreas enormes. Solos ácidos e turfeiras armazenam matéria orgânica. Lagos sustentam aves durante o verão.

Ao norte e acima da linha de árvores surge tundra: musgos, líquens, gramíneas e arbustos rasteiros ocupam a camada ativa sobre permaglacis. Plantas crescem rente ao chão e florescem rapidamente. Animais migram, acumulam gordura ou permanecem sob a neve.

A Flor-de-Neve de Valdmere acompanha a Estela e fecha-se antes da queda brusca de temperatura, comportamento usado como indicador local. A Gramínea-do-Vento forma touceiras compactas. O Musgo Polar cresce milímetros por ano; sua remoção deixa o solo exposto por décadas.

## CAMPANHAS E ESTEPES

Riosola possui campos de gramíneas altas sobre um solo negro. A ausência de floresta resulta de fogo, vento, estação seca e herbivoria. Raízes profundas criam matéria orgânica e estabilizam o solo. Grandes rebanhos e a criação doméstica transformaram o bioma sem eliminá-lo por completo.

Estepes de Tlacua, bordas do Alvor e Yawurua são mais secas. Vegetação baixa aparece em pulsos após chuva. Sementes permanecem dormentes; arbustos armazenam água; animais percorrem longas distâncias. Crostas biológicas protegem o solo e são destruídas facilmente por tráfego repetido.

## MEDITERRÂNEO E MAQUIS

Sul de Vélia, Tyrenia, Qalat costeiro e leste de Kemet possuem verão seco e inverno úmido. Árvores pequenas, folhas duras e arbustos aromáticos resistem à perda de água. Incêndios periódicos fazem parte do ciclo. Encostas calcárias sustentam a flora diferente de vales aluviais.

Vinhas, oliveiras e cereais substituíram grande parte da vegetação original. Restos de maquis conservam polinizadores, ervas medicinais e predadores. Erosão cresce quando terra é deixada nua durante chuvas de inverno.

## DESERTOS E SEMIDESERTOS

O Grande Deserto de Veth combina dunas, planícies de cascalho, rochas nuas e salares. A vida concentra-se em oásis, leitos secos e períodos breves de chuva. Plantas reduzem folhas, armazenam água ou completam ciclo em semanas. Animais evitam calor por atividade noturna e tocas.

Tlacua possui semidesertos de altitude, mais frios. Yawurua apresenta desertos planos e savanas secas. Organismos de crosta fixam nitrogênio e estabilizam sedimentos. Fontes e cavernas sustentam comunidades isoladas.

## MONTANHAS E CAMPOS ALPINOS

Montanhas comprimem biomas em altitude. A base pode ser tropical ou temperada; acima surgem florestas de neblina, campos frios, tundras alpinas e gelo. Tahuantinsuyu possui gramíneas de altitude e plantas em roseta. Valdmere apresenta prados alpinos; Axum, matas montanas e campos vulcânicos.

Espécies de alta altitude resistem a radiação, frio e pouco oxigênio. Animais possuem sangue com maior afinidade por oxigênio ou pulmões eficientes. Isolamento entre picos produz endemismo semelhante ao de ilhas.

## RECIFES, MANGUEZAIS E ESTUÁRIOS

Recifes de Xochiatlalpan são construídos por organismos calcificadores em simbiose com microrganismos fotossintéticos. Precisam de luz, temperatura e água relativamente clara. Sedimento, calor extremo e acidificação prejudicam o crescimento. A estrutura abriga peixes, moluscos, esponjas e algas.

Manguezais ocupam costas quentes protegidas. Raízes retêm sedimentos e oferecem um berçário. Estuários misturam água doce e salgada; organismos precisam tolerar a variação. Calçada, Verdania costeira, Kitomena e Xochiatlalpan possuem sistemas extensos.

## FLORESTAS DE ALGAS E MARES FRIOS

Contigo, Nordhavn e setores austrais possuem florestas de algas presas a substratos rochosos. Crescem onde água fria e nutrientes abundam. Criam um abrigo tridimensional e sustentam peixes, moluscos e mamíferos marinhos. Tempestades arrancam faixas; mas novas algas recolonizam.

Ressurgências trazem nutrientes, mas podem trazer águas pobres em oxigênio. Florações de algas microscópicas sustentam cadeias alimentares e às vezes produzem toxinas. Pescadores acompanham cor, cheiro e comportamento de aves para evitar áreas contaminadas.

## ÁGUAS DOCES E ZONAS ÚMIDAS

Rios rápidos de montanha têm água fria e oxigenada; já planícies, água mais quente e turva. Lagos fechados acumulam sais; pântanos possuem pouco oxigênio no solo. Espécies distribuem-se segundo corrente, temperatura, sedimento e conexão com outras bacias.

Igapós de Verdania inundam florestas; turfeiras de Myrova acumulam matéria; chinampas de Huexotl criam um mosaico artificial de canais e terra. Barragens humanas bloqueiam a migração de peixes e alteram sedimentos. Algumas regiões construíram passagens; outras dependem de criação em viveiro.

## ECOSSISTEMAS ABISSAIS

O fundo do Mar de Fora recebe pouca luz e alimento. Organismos dependem de matéria que afunda ou de alquímica em fontes hidrotermais. Pressão elevada exige membranas e proteínas adaptadas. Contigo acessa águas profundas próximas à costa; Aotearoa e Yamashiro estudam fontes associadas a dorsais e arcos.

Comunidades de fonte usam compostos de enxofre e metais como base energética. Podem desaparecer quando uma chaminé cessa e surge em outra. A dispersão de larvas por correntes profundas continua pouco compreendida.

| ANOTAÇÃO MARGINAL AMOSTRAS DE CONTIGO Alguns tecidos abissais mantêm coordenação após a morte celular aparente. Explicações por pressão, redes proteicas e atividade microbiana ainda são suficientes para justificar uma pesquisa natural. Nenhuma amostra deve ser exposta a Fragmentos para “testar afinidade”; o experimento de 1.817 demonstrou apenas que imprudência produz resultado difícil de interpretar. |
| --- |

## BIODIVERSIDADE E ALTERAÇÃO HUMANA

Agricultura, caça, introdução de espécies, mineração e cidades modificaram todos os biomas habitados. A intensidade varia. Vélia e Qin possuem pouca floresta original nas planícies; Verdania conserva cobertura ampla, mas estradas e extração fragmentam bordas; Aotearoa perdeu aves incapazes de voo após introdução de predadores.

Extinção não exige desaparecimento mundial. Uma população local pode sustentar polinização, cultura e diversidade genética únicas. Bancos de sementes, reservas, manejo comunitário e jardins vivos surgiram como resposta. O conhecimento bioalquímico tornou certas espécies economicamente valiosas, protegendo algumas e aumentando a pressão sobre outras.

A conservação mais eficaz acompanha processos. Proteger um recife sem controlar os sedimentos do rio não basta. Preservar um predador sem corredor um de migração isola populações. Um mapa de áreas protegidas precisa sobrepor bacias, rotas e uso humano.

## VETH CINÉRIO

O Continente Cinzento possui clima capaz de sustentar florestas temperadas, campos e fauna. Relatos confirmam árvores, gramíneas, fungos e animais pequenos, mas descrevem distribuição incomum. Certas florestas têm baixa produção sonora; alguns padrões de crescimento parecem mais regulares do que se espera; pigmentos diferem levemente de espécies próximas.

Parte dessa impressão pode resultar de observadores sob estresse, amostras degradadas e expectativa. Parte é mensurável. Folhas de três regiões possuem orientação celular simétrica rara, e fungos coletados perto do Cerne crescem em anéis geometricamente precisos mesmo em substrato irregular. A Ordem evita chamar essas formas de “erradas”. Elas são reais, mas exigem descrição antes de significado.

Fauna grande é pouco observada. Rastros indicam herbívoros e predadores; encontros diretos são raros. Expedições não permanecem tempo suficiente para construir inventário. A ausência de insetos sonoros em certas áreas altera a polinização e decomposição de formas ainda não compreendidas.

## LOBO AUSTER E AMBIENTES SUBGLACIAIS

A vida do Auster concentra-se no mar, costas livres no verão e fendas de gelo. Algas crescem sob gelo marinho; aves e mamíferos alimentam-se em águas produtivas. Líquens e microrganismos ocupam rochas expostas. O interior possui comunidades microscópicas em neve, salmoura e talvez lagos subglaciais.

Perfuração de lagos poderia revelar linhagens isoladas por centenas de milhares de anos, mas arrisca uma contaminação irreversível. Academias propõem sondas esterilizadas; a Ordem mantém restrições adicionais em duas bacias. Nenhum argumento público explica por que essas duas diferem de outras do mesmo tipo.

PARTE IX
