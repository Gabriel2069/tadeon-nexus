---
title: "Geografia de Veth — TERRITÓRIOS DE OBSERVAÇÃO LIMITADA"
node_type: "concept"
summary: "Seção “TERRITÓRIOS DE OBSERVAÇÃO LIMITADA” de Geografia de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "globe-2"
aliases: ["TERRITÓRIOS DE OBSERVAÇÃO LIMITADA"]
tags: ["cânone","fonte-primária","geografia"]
properties: {"canon_layer":"primary_source","source_document":"O.A. IV ~ Geografia de Veth(1).docx","source_section":"TERRITÓRIOS DE OBSERVAÇÃO LIMITADA","source_order":9,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/geografia|Fonte — Geografia de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# TERRITÓRIOS DE OBSERVAÇÃO LIMITADA

Onde o mapa precisa declarar a própria incerteza

Um espaço em branco pode ser falha do cartógrafo. Também pode ser a forma mais honesta de representar o que ainda não foi observado.

## GRAUS DE CONFIANÇA GEOGRÁFICA

Orbis Ardex distingue quatro graus de levantamento. Confirmado indica observação repetida por equipes independentes. Provável reúne dados coerentes, porém incompletos. Provisório depende de uma única expedição ou método indireto. Restrito descreve informação preservada pela Ordem e ausente da edição pública.

A classificação aplica-se à localização, não necessariamente à interpretação. Uma montanha pode estar confirmada e sua origem ser provisória. Um rio pode ser bem mapeado, mas sua vazão anual depender de poucas medidas. Declarar confiança impede que o acabamento de uma carta transforme hipótese em fato.

## VETH CINÉRIO

As costas de Veth Cinério foram levantadas por navegação, triangulação e observação óptica. O interior é conhecido por corredores de expedição. Correntes irregulares atrasam a partida; neblina e relevo reduzem a visibilidade; instrumentos magnéticos sofrem desvio. A Confluência acrescenta risco que não consegue ser tratado como uma simples dificuldade logística.

O maciço central, rios radiais e o Cerne são confirmados. A continuidade de certas serras, profundidade de vales e posição de lagos permanecem provisórias. Mapas de expedições diferentes não coincidem por margens superiores ao erro normal. A Ordem arquiva versões sem fundi-las, pois uma síntese poderia eliminar a própria anomalia que precisa ser estudada.

## O CERNE

O Cerne é um platô produzido ou transformado pela Grande Contenção. Sua borda eleva-se de maneira abrupta sobre vales cinérios. Vegetação dos arredores cresce de forma irregular, metais oxidam rapidamente em zonas específicas e rochas apresentam vitrificação sem assinatura térmica suficiente. A drenagem evita alguns setores como se o solo tivesse baixa permeabilidade, embora amostras indiquem fraturas.

Não há consenso sobre quanto do relevo precede o evento. O platô pode ser formação geológica antiga alterada pela Contenção, ou parte da elevação pode ter ocorrido durante ela. A Ordem mantém uma estação rotativa nas proximidades e proíbe escavação profunda. O mapa registra a superfície; o subsolo permanece deliberadamente não sondado. Seu interior, menos ainda.

| NOTA RESTRITA LIMITES DO CERNE Os limites cartográficos do Cerne não coincidem exatamente com a área de efeitos. Alguns sinais seguem drenagem; outros, linhas de visão ou antigos marcos. A representação por contorno único é puramente administrativa. Nenhuma equipe deve assumir que cruzar a linha impressa equivale a entrar ou sair da influência. |
| --- |

## FRANJA NORTE

A Franja Norte é parcialmente observável no verão. Gelo marinho, ilhas móveis de gelo e neblina dificultam distinguir a costa permanente. Levantamentos ópticos registram montanhas e canais; sondagem revela plataformas submersas. A Placa Polar Norte continua pouco compreendida.

Relatos de ruínas sob gelo não foram confirmados. Formas retilíneas aparecem em imagens de baixa luz, mas podem ser fraturas ou morainas. A Ordem conserva dois diários de expedição cujo conteúdo não corresponde à distância percorrida. O fenômeno é registrado como alteração de memória e defasagem de navegação, sem conclusão sobre origem.

## LOBO AUSTER

O litoral norte do Auster é conhecido por segmentos. O interior depende de gravimetria, ecos sísmicos e expedições curtas. Ventos, altitude e frio limitam a permanência. Rotas mudam quando plataformas rompem ou fendas se abrem.

A Base Sul foi instalada numa região de gelo relativamente estável sobre rocha elevada. Seu colapso em 1.845 removeu registros que seriam centrais para este volume. Dados recuperados indicam atividades anômalas de dobras, distante de qualquer processo comum. A área permanece marcada como levantamento suspenso.

## MAPAS, PODER E SILÊNCIO

Mapas não são apenas registro. Definem acesso, tributação, fronteira, concessão de mineração e responsabilidade por rios. Um erro pode beneficiar um reino ou uma casa comercial. Instituições cartográficas exigem fontes, datas e métodos por essa razão.

A Ordem possui mapas que não podem circular. Alguns mostram Selos, Âncoras e rotas de manutenção; outros preservam lugares cuja divulgação atrairia exploração. O segredo cria um risco próprio: governos podem interpretar lacunas como tentativas de controle. Gartza defende que toda omissão seja registrada internamente com justificativa e prazo de revisão.

APÊNDICES
