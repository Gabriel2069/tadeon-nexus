---
title: "Ciências de Veth — MATRIZES ENERGÉTICAS"
node_type: "concept"
summary: "Seção “MATRIZES ENERGÉTICAS” de Ciências de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "microscope"
aliases: ["MATRIZES ENERGÉTICAS"]
tags: ["cânone","fonte-primária","ciencias"]
properties: {"canon_layer":"primary_source","source_document":"O.A. III ~ Ciências de Veth.docx","source_section":"MATRIZES ENERGÉTICAS","source_order":2,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/ciencias|Fonte — Ciências de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# MATRIZES ENERGÉTICAS

As diferenças naturais convertidas em trabalho

Veth conhece o fogo e continua a usá-lo em forjas, cozinhas, cerâmicas e emergências. Sua infraestrutura principal, porém, foi organizada ao redor de rios, mares, calor interno, luz, vento, gravidade, salinidade e metabolismo.

## A ARQUITETURA DA ENERGIA

Toda matriz energética de Arden pode ser descrita em quatro operações. A fonte mantém um gradiente; o conversor retira trabalho desse gradiente; o armazenamento separa produção e consumo no tempo; a distribuição leva o trabalho ao lugar onde será usado. A distinção parece simples, mas evitou uma confusão que atrasou a engenharia antiga por séculos. Um rio é fonte. A roda ou turbina é conversor. O reservatório elevado ou o ar comprimido é armazenamento. O canal, eixo ou tubulação é distribuição. Projetos que tentavam fazer um único mecanismo cumprir as quatro funções eram difíceis de regular e quase impossíveis de reparar.

As matrizes regionais foram moldadas pela geografia. O Tramontana possui rios de degelo, vales e cidades densas, o que favoreceu a hidropneumática. Os estreitos e baías de Nordhavn e Yamashiro deram valor à maré. O Alvor transformou luz e diferença térmica em infraestrutura. Verdania fez do metabolismo uma indústria. Contigo aprendeu a aproveitar pressão e frio do mar profundo. A ciência circulou depois da Concordância, mas a fonte continuou presa ao lugar. Um projeto pode ser copiado; o rio, o vulcão e o deserto não.

## MATRIZ HIDROPNEUMÁTICA

A hidropneumática é a matriz mais difundida do Tramontana. A água desce por canais ou condutos fechados, move rodas, turbinas de baixa rotação e pistões hidráulicos, e esse movimento aciona compressores. O ar comprimido segue para reservatórios e redes urbanas. A água fornece trabalho contínuo; o ar permite distribuí-lo com limpeza, flexibilidade e controle. Em cidades construídas ao longo de um único rio, as estações são espaçadas para que a mesma água realize trabalho em diferentes níveis antes de retornar ao curso principal.

Rios sazonais exigem reservatórios de regularização. Durante períodos de vazão alta, bombas elevam água para lagos artificiais e comprimem ar além da demanda imediata. Na estiagem, a água armazenada desce e os reservatórios pneumáticos assumem picos de consumo. A eficiência depende do relevo. Um vale estreito pode sustentar grande queda em pouca distância; uma planície precisa de barragens baixas, canais extensos e máquinas maiores. Grauth construiu sua rede em etapas porque nenhum projeto único conseguiria coordenar rios tão distintos sem interromper a agricultura e navegação.

## MATRIZES DE MARÉ E ONDA

A mareopneumática converte a subida e a descida do mar em compressão. Baías estreitas recebem câmaras com comportas e pistões. A maré crescente força água para dentro e comprime bolsas de ar; a vazante produz movimento inverso, capturado por válvulas unidirecionais. O ciclo é previsível e pode ser calculado com meses de antecedência. Sua limitação é temporal: a produção varia ao longo do dia e precisa de grandes acumuladores para alimentar serviços contínuos.

Yamashiro aperfeiçoou câmaras compactas escavadas na rocha vulcânica. Nordhavn prefere diques e bacias largas, capazes de continuar operando sob gelo parcial. Vélia usa marés principalmente em docas e drenagem. A matriz de ondas, chamada ondimotriz nos tratados recentes, trabalha com movimentos menos previsíveis. Boias articuladas, braços costeiros e plataformas flutuantes bombeiam ar em cada elevação. Faróis e postos insulares dependem desse sistema porque sua manutenção é simples e a força chega do próprio mar, mas instalações grandes precisam liberar o excesso durante tempestades para que a energia das ondas não destrua o conversor.

MATRIZ OSMÓTICA

Nos estuários, a água doce tende a atravessar certas membranas em direção à água salgada. Bioalquimistas de Verdania transformaram esse movimento em pressão útil. Módulos osmóticos mantêm soluções separadas por membranas semipermeáveis cultivadas sobre armações minerais. A água atravessa, pressuriza uma câmara e move uma bomba lenta. A produção é pequena por unidade de área, mas constante durante todo o ano, o que a torna adequada a purificação de água, irrigação, ventilação e serviços que não toleram interrupção.

O custo principal está na limpeza. Sedimentos, sais e organismos fecham os poros das membranas. Estações modernas alternam módulos, permitindo que enzimas dissolvam depósitos enquanto os demais continuam em operação. A salmoura concentrada não pode ser devolvida ao mesmo ponto sem alterar o estuário. Verdania exige canais de dispersão e monitoramento biológico; portos com fiscalização fraca lançam o resíduo diretamente e transformam manguezais em zonas salinas improdutivas em poucas décadas.

## MATRIZ GEOTÉRMICA

A geotermia é a matriz de maior densidade entre as fontes naturais de Arden. Água circula por fraturas profundas, retorna aquecida e entrega calor a redes urbanas, estufas, hospitais, destiladores e motores térmicos. Em sistemas de baixa temperatura, o fluido não precisa ferver. Sua expansão em câmaras fechadas, combinada a fluidos secundários de ponto de ebulição reduzido, move pistões lentamente durante todo o dia. Zonas vulcânicas permitem pressões maiores, acompanhadas por corrosão, gases tóxicos e risco sísmico.

Yamashiro utiliza o calor para banhos, secagem, fermentação e compressão. Aotearoa combina poços geotérmicos com redes de aquecimento e lapidação de minerais. Myrova usa fontes profundas onde o inverno torna outras matrizes menos confiáveis. Axum aproveita calor residual do ponto quente sob o planalto, sobretudo em secagem agrícola e processos metalúrgicos. Nenhuma dessas regiões perfura sem mapas geológicos extensos. Um poço mal localizado pode perder pressão, contaminar aquíferos ou abrir caminho para gases que permaneciam confinados há milhares de anos.

## MATRIZ HELIOTÉRMICA E HELIO-ÓPTICA

O Alvor transformou a regularidade de seu céu em infraestrutura. Campos de espelhos acompanham o movimento de Estela e concentram luz em torres revestidas por cerâmica refratária. O calor aquece sais, água e óleos minerais, sustenta destilação, esterilização, secagem, fundição de ligas leves e motores térmicos. As reservas de termolita mantêm parte desse calor depois do pôr do sol. Tempestades de areia reduzem a produção e desgastam superfícies; por isso os campos são divididos em setores que podem ser recolhidos ou cobertos separadamente.

A matriz helio-óptica destina a luz a informação e excitação cristalina. Torres coletoras alimentam amplificadores, arquivos mnêmicos, heliógrafos e calculadores. A luz estelar direta é intensa, mas incoerente e irregular. Cavidades hialinas a filtram, acumulam energia em centros luminescentes e liberam feixes controlados. A maior parte da força mecânica de uma cidade não vem desse sistema. Seu valor está em manter comunicação, cálculo e medição com pouca matéria em movimento.

## MATRIZ EÓLICA E GRAVÍTICA

A eolopneumática usa vento para comprimir ar e bombear água. Torres de múltiplas pás ajustam o ângulo conforme a direção e acionam compressores por engrenagens diferenciais. Planaltos do Alvor, costas do Mar de Fora, passagens de Valdmere e fazendas do Tramontana dependem dessa matriz. Sua produção varia mais que a de rios ou marés, mas o ar comprimido transforma rajadas breves em reserva utilizável. Em regiões sujeitas a ventos extremos, as pás recolhem-se dentro da torre e um rotor menor continua carregando serviços essenciais.

A matriz gravítica é, em essência, armazenamento por altura. Água é elevada quando há trabalho excedente e liberada quando a demanda cresce. Pesos suspensos movem relógios, elevadores, compressores lentos e mecanismos de emergência. Cidades montanhosas aproveitam desníveis naturais; cidades planas constroem torres. A perda é pequena enquanto o peso permanece parado, o que torna o sistema adequado a reservas que podem esperar meses. A quantidade de material e o risco de queda impedem seu uso universal. Um reservatório de pressão rompe com ruído; uma torre de peso mal mantida atravessa os andares abaixo.

## MATRIZ BIOALQUÍMICA

A matriz bioalquímica retira trabalho de processos vivos sem depender da queima como destino principal. Fermentações liberam gases que pressurizam membranas; colônias termogênicas produzem calor; tecidos contráteis movem bombas delicadas; membranas osmóticas transferem água; materiais em crescimento tensionam estruturas e fecham fissuras. O alimento fornecido ao organismo contém a energia alquímica. O biorreator controla velocidade, temperatura e produto.

O metano continua sendo produzido em Verdania, mas a maior parte não alimenta iluminação urbana. Serve como matéria-prima para síntese de solventes, reserva emergencial e combustível de instalações sem acesso às redes principais. A pressão da fermentação, o calor metabólico e o resíduo fertilizante são aproveitados antes que o gás seja queimado. A mudança ocorreu quando cidades perceberam que transformar todo resíduo em chama desperdiçava compostos que a bioalquimia podia converter em polímeros, ácidos e nutrientes.

## MATRIZ TERMODIFERENCIAL E MAR PROFUNDO

A matriz termodiferencial trabalha com a expansão desigual de fluidos e sólidos entre regiões quentes e frias. Desertos do Alvor usam a diferença entre dia e noite para bombear água e ventilar edifícios. Myrova combina ar exterior gelado com fontes quentes para circulação contínua. Em costas profundas, água superficial e água abissal alimentam motores de baixa potência, refrigeração e conservação. Esses sistemas raramente movem indústria pesada. Mantêm serviços lentos por longos períodos e funcionam onde o combustível seria caro ou a manutenção humana irregular.

Contigo desenvolveu equipamentos capazes de descer linhas até águas frias e pressurizadas. O objetivo inicial era obter óleo de profundidade, mas os mesmos condutos passaram a trazer água para refrigeração, laboratórios e condensadores. A pressão do mar pode mover pistões quando equilibrada contra câmaras internas, desde que as válvulas suportem sal, organismos e fadiga. A matriz é eficiente apenas perto de costas onde a profundidade aumenta rapidamente. Em plataformas rasas, o comprimento da tubulação consome mais trabalho do que o gradiente devolve.

## ARMAZENAMENTO E DISTRIBUIÇÃO

Arden armazena trabalho em formas que correspondem ao uso esperado. Ar comprimido responde rápido e atravessa tubulações. Água elevada conserva energia por meses. Pesos e molas alimentam mecanismos de emergência. Termolita guarda calor. Vidros e cristais armazenam informação e excitação luminosa. Colônias vivas guardam potencial químico que pode crescer, reparar ou produzir conforme alimentadas. Nenhuma forma é universal, e cidades resilientes combinam várias.

| Forma de armazenamento | Vantagem principal | Limitação principal |
| --- | --- | --- |
| Ar comprimido | resposta rápida e distribuição flexível | vazamento, calor de compressão e volume |
| Água elevada | baixa perda durante espera | depende de altura e grandes reservatórios |
| Pesos e molas | controle mecânico direto | densidade limitada e fadiga |
| Termolita e cerâmicas | conservação de calor | transporte difícil e perda gradual |
| Cristais excitados | sinais e informação | fragilidade e necessidade de bombeamento |
| Matéria viva | produção renovável e autorreparo | tempo, contaminação e necessidade de alimento |

A distribuição também segue a função. Força percorre ar, água, eixos e cabos tensionados; calor percorre fluidos e canais isolados; informação percorre luz; substâncias percorrem tubos, recipientes e organismos de transporte. A separação torna a infraestrutura mais complexa de construir e mais resistente a uma falha única. Uma tubulação rompida não apaga arquivos ópticos; uma torre sem luz não interrompe bombas mecânicas; uma contaminação bioalquímica pode ser isolada sem esvaziar reservatórios de pressão.

| ANOTAÇÃO MARGINAL CONTINENTE CINZENTO As instalações permanentes da Ordem em Veth Cinério usam matrizes redundantes sem depender de produção local contínua. A geotermia apresenta oscilações incompatíveis com a atividade tectônica registrada, e alguns acumuladores perdem pressão sem vazamento detectável. Os relatórios públicos atribuem o fenômeno à qualidade irregular dos materiais levados por mar. A hipótese permanece conveniente e incompleta. |
| --- |

## DISTRIBUIÇÃO REGIONAL DAS MATRIZES

O predomínio regional de uma matriz não significa exclusividade. Indica apenas qual fonte fornece a maior parcela do trabalho regular e qual infraestrutura moldou a forma das cidades. O Tramontana apoia-se em rios, reservatórios e pressão; o Ocíduo em água, organismos e estuários; o Alvor em luz, calor e diferenças térmicas; os arquipélagos orientais combinam maré, onda e geotermia. Regiões de fronteira são tecnicamente mais diversas porque precisam adaptar sistemas importados a fontes locais.

| Região | Matrizes predominantes | Características de infraestrutura |
| --- | --- | --- |
| Lobo Tramontana | hidropneumática, eólica, gravítica e geotermia setentrional | redes de pressão, aquedutos, reservatórios e linhas industriais |
| Lobo Ocíduo | bioalquímica, osmótica, fluvial e mar profundo | biorreatores, membranas, canais e materiais vivos |
| Lobo Alvor | heliotérmica, helio-óptica, termodiferencial e eólica | campos de espelhos, torres de luz, sais térmicos e bombas lentas |
| Yamashiro e Aotearoa | geotérmica, mareopneumática, ondimotriz e eólica costeira | sistemas dispersos, câmaras de maré e reservas subterrâneas |
| Veth Cinério | reservas transportadas, geotermia irregular e sistemas autônomos | redundância extrema, baixa confiança em fontes locais |

As diferenças energéticas também alteram a paisagem construída. Cidades hidropneumáticas seguem rios e exibem torres de pressão; centros heliotérmicos abrem pátios e coberturas ao sol; cidades bioalquímicas reservam espaço para estufas, canais e quarentenas; portos mareopneumáticos organizam trabalho segundo o ciclo do mar. A matriz deixa de ser visível apenas quando funciona bem por muitas gerações. Nesse ponto, torna-se parte da arquitetura e do calendário, e a população passa a tratá-la como condição natural do lugar.

PARTE III
