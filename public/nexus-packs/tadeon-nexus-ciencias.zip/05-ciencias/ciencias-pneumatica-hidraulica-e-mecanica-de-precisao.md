---
title: "Ciências de Veth — PNEUMÁTICA, HIDRÁULICA E MECÂNICA DE PRECISÃO"
node_type: "concept"
summary: "Seção “PNEUMÁTICA, HIDRÁULICA E MECÂNICA DE PRECISÃO” de Ciências de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "microscope"
aliases: ["PNEUMÁTICA, HIDRÁULICA E MECÂNICA DE PRECISÃO"]
tags: ["cânone","fonte-primária","ciencias"]
properties: {"canon_layer":"primary_source","source_document":"O.A. III ~ Ciências de Veth.docx","source_section":"PNEUMÁTICA, HIDRÁULICA E MECÂNICA DE PRECISÃO","source_order":3,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/ciencias|Fonte — Ciências de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# PNEUMÁTICA, HIDRÁULICA E MECÂNICA DE PRECISÃO

A ciência da força conduzida

O Tramontana transformou fluidos, metais e mecanismos em uma infraestrutura capaz de mover navios, cidades, oficinas e instrumentos cirúrgicos. Sua maturidade depende menos da força máxima de uma máquina do que do controle com que essa força é produzida, distribuída e interrompida.

## FUNDAMENTOS DA PNEUMÁTICA

A pneumática usa gases comprimidos para armazenar e transmitir trabalho. O ar é abundante, limpo, leve e capaz de atravessar redes complexas. Sua compressibilidade, que permite armazenamento, também reduz a precisão quando uma carga muda rapidamente. Por isso a engenharia moderna separa funções. Atuadores pneumáticos realizam movimentos rápidos, absorvem impactos e continuam seguros quando bloqueados. Sistemas hidráulicos assumem prensas, eclusas, direção de grandes máquinas e qualquer tarefa em que o deslocamento precise corresponder exatamente ao volume bombeado.

Uma estação de compressão moderna opera em estágios. Filtros retiram poeira e aerossóis; secadores removem água; pistões líquidos ou mecânicos elevam a pressão gradualmente; serpentinas transferem calor para termolita; separadores recolhem condensado; válvulas unidirecionais conduzem o gás a reservatórios. Sensores mecânicos e ópticos monitoram temperatura, pressão e vibração. O ar nunca segue diretamente do compressor para uma residência. Passa por acumuladores, reguladores distritais e linhas de serviço, cada qual projetada para uma faixa de pressão.

REGIMES DE PRESSÃO

| Regime | Faixa usual | Aplicações |
| --- | --- | --- |
| Baixa pressão | 1,2 a 3 atmosferas | mensagens, ventilação, iluminação controlada, instrumentos delicados |
| Média pressão | 3 a 12 atmosferas | elevadores, oficinas, transporte urbano, bombas e ferramentas |
| Alta pressão | 12 a 40 atmosferas | mineração, prensas, portos, propulsão de canal e indústria pesada |
| Acumulação distrital | 60 a 120 atmosferas | reserva urbana alimentando estações redutoras |
| Reserva estratégica | 150 a 300 atmosferas | serviços críticos, frotas, minas e instalações isoladas |

As faixas superiores exigem reservatórios pequenos, paredes espessas e inspeção frequente. Não percorrem ruas residenciais. Uma estação redutora transforma a pressão de reserva em regimes menores e usa a expansão para realizar trabalho secundário, como bombeamento de água ou refrigeração. Válvulas de alívio abrem mecanicamente antes que a pressão alcance o limite estrutural, independentemente de operador ou calculador. Essa independência é deliberada: nenhum sistema de controle deve possuir autoridade para impedir o próprio dispositivo que o protege de ruptura.

## MATERIAIS DA PRESSÃO

O cobre permanece material preferido em linhas de baixa e média pressão. Aceita curvas sem rachar, resiste à corrosão e permite reparo local. Aço carbono tratado domina alta pressão e reservatórios. O desempenho de ambos depende de juntas, soldas, vedações e histórico térmico. Grande parte dos acidentes atribuídos a “metal ruim” começa em uma conexão mal alinhada que concentra esforços em uma região pequena.

A Rethita é um silicato lamelar de ferro, magnésio e boro encontrado nas montanhas de Rethmark. Suas camadas formam canais microscópicos orientados. Depois de polida e condicionada com óleo, a superfície adsorve uma película molecular estável que reduz o atrito junto à parede, limita condensação e torna o fluxo menos turbulento. Revestimentos finos diminuem perdas em linhas longas; peças maciças seriam caras e frágeis em impacto. A mesma organização interna explica sua resistência à fadiga cíclica quando usada como aditivo em ligas de cobre.

O óleo de profundidade de Contigo contém ésteres cerosos ramificados que permanecem fluidos em temperaturas baixas e resistem à oxidação. Essa estabilidade o torna adequado a relógios, válvulas e fibras mecânicas. Pequenas quantidades são suficientes, mas a contaminação por água ou sal reduz seu efeito rapidamente. Oficinas de precisão testam viscosidade por queda de esfera antes de aceitar um lote. O preço elevado estimulou misturas fraudulentas, e Albrath mantém uma coleção de amostras adulteradas maior que a de alguns museus comerciais.

## METALURGIA E MICROESTRUTURA

Grauth aperfeiçoou o trabalho a frio, chamado Kaltschlagen no leste. A deformação abaixo da temperatura de recristalização aumenta a densidade de discordâncias no metal. Essas irregularidades dificultam o deslizamento posterior dos planos cristalinos, elevando dureza e resistência. O processo também reduz ductilidade e pode acumular tensões internas, por isso peças complexas recebem recozimentos intermediários. O antigo ensino de que o metal “ganhava densidade de cristal” foi abandonado depois que microscópios de Kemet mostraram que o ganho vinha da estrutura deformada, não de uma compactação geral da matéria.

As ligas de Albrath ilustram o grau de especialização alcançado. O Firmetal, latão com pequenas proporções de tântalo e tratamentos de superfície, resiste a corrosão e variação térmica. O Aço Azul retém elasticidade em frio e altitude graças à têmpera controlada. O Bronze de Precisão, com oito por cento de estanho e traços de berílio, aceita usinagem fina e mantém dentes de engrenagem por milhões de ciclos. A poeira de berílio adoece lapidadores e fundidores; oficinas modernas usam ventilação, máscaras úmidas e processos fechados, medidas que só se tornaram obrigatórias depois de décadas de mortes atribuídas a “fraqueza pulmonar de artesão”.

## MECÂNICA DE PRECISÃO

A relojoaria é a gramática material das três correntes. Escapamentos transformam movimento contínuo em pulsos; cames registram sequências; diferenciais somam e subtraem rotações; reguladores centrífugos respondem à velocidade; molas armazenam pequena quantidade de trabalho; válvulas proporcionais convertem movimento mínimo em controle de fluxo. Um mecanismo de precisão não precisa ser pequeno. As eclusas do Huang-Lin usam princípios encontrados em relógios, ampliados até peças de toneladas.

O torno de precisão albrathiano alcança tolerâncias de centésimos de milímetro em produção regular e de milésimos nas mãos de mestres. O segredo está no conjunto: fusos retificados, ferramentas estáveis, bancada isolada de vibração, medição durante o corte e calibração diária. Uma máquina excelente colocada sobre piso flexível produz peças ruins. Albrath tornou-se referência porque trata o ambiente da oficina como parte do instrumento.

O escapamento de vai-e-vem, desenvolvido em 1.140, permitiu relógios com erro de poucos segundos por dia e reguladores capazes de abrir válvulas em intervalos repetíveis. Cames intercambiáveis deram aos autômatos sequências programadas. Servomecanismos posteriores usaram pequenas diferenças de pressão ou luz para controlar válvulas muito maiores, reduzindo a força exigida do operador. A automação ardênica nasceu desse princípio: um sinal fraco não realiza o trabalho principal, apenas decide por onde a força armazenada deve passar.

## REDES, CONTROLE E SEGURANÇA

Uma rede urbana possui anéis principais, linhas secundárias e ramais locais. Válvulas unidirecionais impedem retorno; reguladores mantêm pressão; acumuladores de bairro absorvem picos; estações de isolamento fecham setores danificados. Sinais ópticos percorrem parte das mesmas galerias, mas não compartilham o fluido. Quando a pressão cai de forma incompatível com a demanda, um mecanismo fecha o trecho e envia pulso luminoso à estação. Equipes de manutenção localizam a falha pela diferença entre manômetros sucessivos.

Pequenos vazamentos podem ser tratados por vedações bioalquímicas que incham em contato com ar seco de alta velocidade. Elas não substituem reparo. Compram tempo. As tubulações mais antigas de Maravezia demonstraram o perigo de confiar demais nesse recurso: reguladores e vedações mantinham a pressão aparente enquanto microfissuras avançavam no cobre. O programa de substituição iniciado pela Casa Marevan revelou que uma rede capaz de esconder seus sintomas também pode esconder sua idade.

## PNEUMÁTICA E MECÂNICA POR REINO

VÉLIA

Síntese e adaptação

Vélia transformou a integração em especialidade. Seus engenheiros raramente inventam o primeiro exemplar de uma tecnologia; constroem a versão que conversa com sistemas vindos de outros lugares. O regulador veliano combina escapamento mecânico e válvula proporcional, abrindo e fechando o fluxo em intervalos definidos pela pressão de saída. Estações que antes exigiam vigília constante passaram a operar durante doze horas com inspeções periódicas. Modelos recentes acrescentam um mecanismo de comparação óptica que corrige lentamente a mola quando temperatura e fadiga alteram sua resposta.

Os portos de Maravezia são a expressão material dessa cultura. Sinais de Qalat orientam entrada de navios; guindastes pneumáticos usam estruturas albrathianas; balanças registram carga em vidro mnêmico de Kemet; resinas de Calçada protegem cascos; documentos recebem tratamento de Verdania. A rede urbana distribui baixa pressão a bairros, média a oficinas e alta apenas a corredores industriais. A modernização do centro histórico tornou-se disputa política porque exige substituir tubulações centenárias sob ruas densamente ocupadas e definir quem arcará com o custo de uma infraestrutura que beneficia toda a cidade, mas foi lucrativa para casas específicas durante gerações.

A medicina vêliana adaptou válvulas albrathianas a seringas pneumáticas. Os modelos cirúrgicos entregam volumes de dois microlitros, uma fração muito menor que uma gota comum, em pulsos repetíveis. Freios pneumáticos de carruagens e portos usam reservatórios locais: a perda da linha principal aplica o freio em vez de liberá-lo. Esse princípio, conhecido como segurança por falha, nasceu depois do acidente da Ponte de San Lúcio, quando uma ruptura de tubo deixou vinte vagões sem controle.

SOLANE

Mecânica cívica e de processos

A pneumática soliana desenvolveu-se ao redor da água, da alimentação e da ocupação urbana. Os Grandes Aquedutos de Mareval chegam à cidade com diferença de altura suficiente para mover rodas hidráulicas antes de entregar seu fluxo aos reservatórios públicos. Estações instaladas ao longo da descida convertem parte desse movimento em ar comprimido e abastecem anéis de média pressão distribuídos pelos bairros. A rede atende bombas, elevadores de carga, oficinas, cozinhas coletivas e fábricas de processamento alimentar. Sua capacidade industrial é menor que a de Grauth, mas a distribuição alcança atividades muito mais variadas. Uma padaria, um mercado e uma casa de banho podem receber força da mesma estação sem operar sob o mesmo regime de pressão.

A indústria gastronômica produziu uma mecânica própria, construída para dosar, misturar, prensar, aquecer e resfriar sem alterar as qualidades sensíveis dos alimentos. Cames regulam o tempo de amassamento; pistões graduados mantêm espessura constante; bombas transferem caldos e óleos sem contato com o ar; válvulas térmicas interrompem o aquecimento quando a expansão de um fluido de referência atinge o volume calibrado. Câmaras de expansão pneumática fornecem refrigeração para mercados e depósitos, enquanto o calor retirado é conduzido para secadores e tanques de lavagem. Os fabricantes solianos não buscam a tolerância extrema de Albrath. Preferem máquinas que possam ser abertas, limpas, ajustadas e reparadas por oficinas locais, porque resíduos biológicos transformam qualquer mecanismo inacessível em fonte de contaminação.

Fonds levou essa tradição para uma direção diferente. A cidade subterrânea depende de ventilação, drenagem e sincronização para permanecer habitável. Poços em alturas distintas criam tiragem natural, ampliada por exaustores pneumáticos nos bairros profundos. Reguladores alteram a abertura de comportas conforme a temperatura, a umidade e a concentração de gás carbônico indicada por reagentes ópticos. Caso uma galeria seja inundada ou contaminada por fumaça, portas de pressão isolam o setor enquanto linhas secundárias mantêm circulação nos bairros vizinhos. Os sinos pneumáticos que marcam as horas também funcionam como sistema de emergência: sequências diferentes anunciam queda de pressão, incêndio, falha de drenagem ou fechamento de passagem. A mecânica de Fonds surgiu da necessidade de fazer uma cidade respirar sem depender do vento que alcança a superfície.

GRAUTH

Escala, redundância e força

Grauth consolidou a pneumática pesada porque possuía rios, metalurgia e guildas capazes de coordenar cadeias longas de produção. O método grauthiano exige reserva calculada. Cada estação principal possui unidade secundária capaz de assumir ao menos sessenta por cento da carga; tubulações críticas têm caminhos paralelos; acumuladores sustentam minas e hospitais durante isolamento. Brenholt não sofreu perda pneumática integral em cento e trinta anos, embora bairros e distritos tenham sido desligados muitas vezes para conter danos.

A cadeia do leste liga minério da Casa Ostmark, carvão metalúrgico histórico do vale de Brenn, forjas de Ostberg e oficinas de Brenntal. O carvão deixou de alimentar a maior parte das estações de compressão depois que a queda de qualidade e o teor de enxofre aumentaram inclusões no aço. Hidropneumática e calor recuperado assumiram a produção de força; o coque permaneceu em processos metalúrgicos que ainda não encontraram substituto completo. A crise de qualidade que antes ameaçava o padrão do aço grauthiano tornou-se impulso para lavagem mineral, fornos estelares auxiliares e maior controle de atmosfera nas forjas.

A rede hidráulica do reino usa água incompressível para eclusas e prensas. Câmaras trocam pressão por volume, elevando barcaças de dezenas de toneladas com movimento lento e previsível. Nas fábricas, linhas hidráulicas executam conformação e corte, enquanto ar comprimido movimenta ferramentas e retira peças. Essa divisão reduziu oscilações que destruíam moldes nas primeiras prensas inteiramente pneumáticas.

ALBRATH

Precisão como instituição

Albrath construiu sua influência ao redor do Instituto de Filosofia Natural Aplicada, que funciona como academia, oficina de padrões, tribunal técnico e arquivo de instrumentos. Fabricantes que desejam vender peças nas classes superiores enviam amostras ao Instituto. A certificação verifica dimensão, composição, vida em fadiga e desempenho térmico. O processo é caro e frequentemente criticado por oficinas menores, mas sua aceitação permite que compradores confiem em peças sem conhecer pessoalmente o fabricante.

A miniaturização pneumática albrathiana aparece em dosadores médicos, moduladores ópticos e instrumentos de laboratório. Fluxos de décimos de milímetro cúbico por segundo controlam pressão sobre cristais e membranas. Mecanismos de armamento usam a mesma precisão em disparadores, sincronizadores e sistemas de pontaria. A distinção entre fabricar a arma e fabricar o componente que a torna precisa permanece juridicamente útil e moralmente instável, embora sucessivos governos tenham preferido discutir a classificação aduaneira em vez da responsabilidade material.

Os autômatos de Albrath são especializados. Cames e rodas de programa executam tarefas de inspeção, classificação e montagem. Não pensam nem escolhem fora da sequência preparada, mas detectam posição por alavancas, luz e pressão. Uma linha bem ajustada pode separar peças defeituosas, aplicar óleo e registrar contagem sem operador contínuo. Quando o ambiente muda além da faixa prevista, o autômato para. Os engenheiros consideram essa interrupção uma qualidade, porque uma máquina incapaz de reconhecer o próprio limite transforma seu erro em produção.

NORDHAVN

Mar, frio e corrosão

Nordhavn desenvolveu sistemas para sal, umidade, gelo e variação térmica. Suas vedações usam elastômeros derivados de resinas de coníferas, reticulados por compostos de enxofre e óleos que mantêm flexibilidade abaixo de trinta graus negativos. Peças metálicas recebem camadas sacrificiais que oxidam antes do corpo estrutural. Tubulações costeiras possuem drenos em pontos baixos para impedir que água salgada permaneça dentro do sistema durante o congelamento.

Guinchos pneumáticos movimentam carga mesmo sob gelo parcial. Canais internos injetam ar sob perfis de barcaça e reduzem o atrito superficial, técnica útil contra ventos fortes. Estações mareopneumáticas carregam reservatórios nas duas direções do ciclo da maré. Bombas de porão operam por mecanismos passivos que começam a trabalhar quando a água eleva uma boia, sem depender de tripulação ou sinal externo. A confiabilidade marítima de Nordhavn surgiu da aceitação de que todo navio acabará recebendo água; o projeto decide apenas se ela encontrará caminho de saída antes de comprometer a embarcação.

VALDMERE

Pressão em altitude

A rarefação do ar reduz a massa admitida por cada curso de uma bomba. Cantões elevados usam compressão em dois ou três estágios, com resfriamento intermediário e volumes maiores na entrada. Reservatórios são instalados abaixo dos pontos de consumo sempre que o relevo permite, combinando pressão do gás e diferença de altura. Linhas externas recebem juntas capazes de acompanhar expansão térmica e movimento de encostas.

Cada Casa de Guarda mantém estação própria, comunicação óptica e peças suficientes para meses de isolamento. Avalanches podem cortar rotas sem destruir a infraestrutura interna, por isso a autonomia local é planejada como parte do sistema cantonal. A reserva não é uniforme. Hospitais, aquecimento e comunicação recebem prioridade; oficinas reduzem atividade; elevadores públicos podem ser suspensos. Valdmere foi o primeiro reino a publicar tabelas de racionamento técnico antes de uma crise, prática que outros governos ainda evitam por receio de admitir vulnerabilidade.

MYROVA

Calor e pressão no frio extremo

A umidade residual do ar comprimido congela em válvulas e filtros. Myrova responde com secagem profunda, linhas aquecidas e, em trechos industriais, vapor seco superaquecido. O vapor circula acima da temperatura de condensação dentro de tubos isolados por Fibras de Inverno. Estações de retorno recuperam água e parte do calor. O sistema exige inspeção porque uma perda de isolamento pode produzir gelo externo, condensação interna e choque térmico no metal.

As Cortinas de Pressão, chamadas Davleniye Zanavas, lançam ar aquecido por entradas de estábulos, oficinas e hospitais. O fluxo reduz a entrada de ar frio sem bloquear passagem. Redes urbanas combinam calor geotérmico, termolita e circulação pneumática sob ruas. Myrgrad mantém setores que podem ser isolados caso uma tubulação se rompa, pois água quente lançada em solo congelado cria cavidades e afundamentos mais perigosos que a perda imediata de aquecimento.

RETHMARK

A Rethita

Rethmark fornece o mineral que tornou economicamente possíveis muitas redes longas. Revestimentos de Rethita reduzem perdas, atrasam condensação e resistem à fadiga em válvulas. A mineração precisa preservar orientação das camadas; blocos quebrados transversalmente perdem parte do desempenho. As melhores minas vendem placas marcadas com o eixo cristalino, e oficinas sem treinamento desperdiçam material ao polir a face errada.

| ANOTAÇÃO MARGINAL AQUISIÇÃO VELADA A afinidade da Rethita com Selos permanece classificada. Componentes orientados ampliam a estabilidade de estruturas de Significância e reduzem a degradação de bordas sob pressão contínua. A Ordem compra o material por intermediários independentes para impedir que uma casa mineira identifique a escala do consumo. O efeito não substitui os quatro Fatores do Conhecimento e não transforma Rethita em fonte de Canalização. Ela funciona como substrato ordenado para uma costura que já foi construída corretamente. |
| --- |

QIN

Padronização em escala imperial

Qin escolheu consistência média em lugar de excelência restrita. O Gabinete dos Mecanismos Imperiais certifica componentes para que milhares de oficinas consigam produzir peças compatíveis. Os padrões admitem tolerâncias maiores que Albrath, mas exigem documentação, marca de lote e composição declarada. Isso permite substituir válvulas e engrenagens ao longo dos três mil e duzentos quilômetros navegáveis do Huang-Lin sem depender do fabricante original.

As quarenta e sete eclusas do rio usam um projeto comum revisado uma única vez desde 1.620. Equipes treinadas em uma delas reconhecem todas as demais. Partes da Grande Muralha conservam tubulações acústicas que transmitiam sinais por pulsos de pressão. A rede foi desativada com a expansão dos heliógrafos, mas permanece como sistema emergencial em trechos onde tempestades de areia impedem comunicação óptica. Qin não remove infraestrutura antiga enquanto ela continuar oferecendo função verificável.

DAESUNG

Ciência da falha

Daesung concentra pesquisa em diagnóstico, documentação e comparação. O Arquivo de Falhas não se limita a descrever rupturas. Registra idade da peça, manutenção, pressão, temperatura, fabricante, composição e sequência de eventos. Modelos estatísticos calculam quais combinações precedem um acidente. Oficinas de outros reinos enviam relatórios porque a análise daesungiana frequentemente revela causas que não seriam visíveis localmente.

A pneumática acadêmica também produziu bancadas automatizadas que repetem ciclos durante meses. Uma válvula pode abrir e fechar centenas de milhares de vezes enquanto sensores ópticos registram deformação. Esses ensaios reduziram acidentes por fadiga e alteraram contratos: fabricantes agora garantem número de ciclos sob condições definidas, não apenas anos de uso. Um mecanismo instalado em mina trabalha de forma diferente do mesmo mecanismo guardado em laboratório, e os documentos modernos tratam a aplicação como parte da especificação.

YAMASHIRO

Miniaturização e maré

Os karakuri de Yamashiro comprimem sequências longas em mecanismos pequenos. Um autômato de chá executa vinte e dois movimentos com uma mola, cames sobrepostos e contrapesos que usam o próprio deslocamento da bandeja como sinal. A qualidade não vem de uma peça impossível, mas da coordenação de muitas peças simples dentro de espaço limitado. Engenheiros albrathianos reproduzem o princípio e ainda encontram dificuldade em alcançar a mesma suavidade porque Yamashiro desenvolveu ligas, lubrificantes e métodos de montagem específicos para mecanismos compactos.

A pneumática de ilha nasceu das enseadas. Câmaras de maré comprimem ar quando o nível sobe e recuperam trabalho na vazante. Reservatórios subterrâneos protegem a pressão de tufões e erupções. Fontes geotérmicas aquecem oficinas e secam o ar antes da compressão. Yamashiro combina três matrizes locais em instalações pequenas, cada qual capaz de manter apenas parte do serviço. A dispersão reduz a eficiência de escala, mas permite que uma ilha continue operando quando outra perde porto ou estação.

PARTE IV
