---
title: "Ciências de Veth — BIOALQUIMIA"
node_type: "concept"
summary: "Seção “BIOALQUIMIA” de Ciências de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "microscope"
aliases: ["BIOALQUIMIA"]
tags: ["cânone","fonte-primária","ciencias"]
properties: {"canon_layer":"primary_source","source_document":"O.A. III ~ Ciências de Veth.docx","source_section":"BIOALQUIMIA","source_order":4,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/ciencias|Fonte — Ciências de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# BIOALQUIMIA

A ciência dos processos vivos

A bioalquimia tornou organismos, enzimas e tecidos em instrumentos de produção. Seu avanço não veio da coleta infinita de espécies raras, mas da capacidade de isolar processos, estabilizar linhagens e cultivar em escala o que antes dependia do acaso da floresta.

## FUNDAMENTOS DA BIOALQUIMIA

Bioalquimia é o controle sistemático de processos vivos para produzir materiais, substâncias, energia alquímica e alterações fisiológicas. Fermentação, crescimento de fungos, síntese enzimática e adaptação celular existiam antes do primeiro laboratório. A ciência começou quando curadores e cultivadores passaram a separar organismos, registrar condições e selecionar descendentes segundo uma propriedade desejada. Uma linhagem industrial não é apenas uma espécie. É uma população preservada porque produz o mesmo resultado dentro de limites conhecidos.

Os laboratórios modernos mantêm culturas-mãe em condições estáveis e distribuem amostras identificadas. Cada lote recebe data, substrato, temperatura, origem e número de gerações desde a cultura original. Quanto mais uma linhagem se multiplica, maior a chance de acumular variações. Produções críticas retornam periodicamente à cultura-mãe. Essa prática tornou possível fabricar antibióticos, enzimas, polímeros e pigmentos em reinos distantes sem depender da presença contínua do organismo selvagem que originou a descoberta.

## CÉLULA, HEREDITARIEDADE E FITAS DE LINHAGEM

A teoria celular ardênica afirma que todo organismo é formado por unidades vivas capazes de manter metabolismo, responder ao ambiente e produzir novas células. Microscópios de Kemet e corantes de Verdania revelaram estruturas internas distintas. Entre elas, filamentos que se condensam antes da divisão e reaparecem em cada célula filha. Os bioalquimistas chamaram esses filamentos de Fitas de Linhagem porque alterações neles acompanhavam mudanças hereditárias.

As Fitas são moléculas longas compostas por unidades que se pareiam segundo afinidades específicas. Sua ordem orienta a produção de proteínas por intermediários celulares. Laboratórios não leem uma fita inteira como se fosse texto visível. Cortam-na com enzimas, separam fragmentos por tamanho, usam sondas complementares e comparam padrões. A técnica identifica parentesco, contaminação e regiões associadas a propriedades conhecidas. Mapas de linhagem de organismos industriais ocupam volumes inteiros e continuam incompletos.

As Tesselas são complexos enzimáticos derivados de vírus que infectam bactérias de Verdania. Uma pequena fita-guia conduz o complexo até uma sequência complementar, onde ele corta a molécula. Outras enzimas removem, inserem ou substituem trechos durante o reparo celular. A edição funciona melhor em microorganismos e tecidos cultivados. Em organismos completos, células diferentes podem receber alterações distintas, e respostas imunológicas podem destruir o tecido modificado. Por isso, grande parte da bioengenharia ardênica ocorre fora do corpo e retorna como enzima, material ou enxerto, não como transformação integral de uma pessoa adulta.

## OS DOMÍNIOS DA BIOALQUIMIA

| Domínio | Objeto principal | Produtos comuns |
| --- | --- | --- |
| Fermentação estrutural | crescimento orientado e polímeros | compósitos, fibras, resinas, pigmentos |
| Enzimologia aplicada | reações seletivas em condições brandas | curtimento, digestão, síntese, limpeza |
| Bioenergia e metabolismo | pressão, calor e gradientes químicos | gases, membranas, bombas, fertilizantes |
| Medicina e compostos bioativos | fisiologia e microrganismos | anestésicos, antibióticos, hormônios, enxertos |
| Biofotônica | luz produzida ou absorvida por organismos | sensores, catálise, iluminação, registro |

FERMENTAÇÃO E BIORREATORES

Um biorreator controla temperatura, acidez, alimento, oxigênio e retirada de produto. O recipiente pode ser cerâmico, metálico ou cultivado. Agitadores pneumáticos mantêm a mistura; fibras ópticas medem turbidez e cor; válvulas retiram gás; filtros impedem que a cultura saia com o produto. A esterilidade absoluta é rara em escala urbana, mas processos industriais usam ecossistemas controlados nos quais a linhagem desejada ocupa recursos antes dos invasores. Quando a contaminação altera cheiro, pressão ou espectro óptico, o lote é isolado.

Biofábricas produzem antibióticos, hormônios, proteínas estruturais, solventes, ácidos, pigmentos e alimentos. O organismo fornece uma sequência de reações que seria difícil reproduzir em vidro. O preço é a lentidão e a sensibilidade. Uma fábrica metalúrgica pode ser desligada e reiniciada; uma cultura abandonada morre, deriva ou é substituída por contaminantes. A manutenção inclui alimentar, selecionar e às vezes sacrificar organismos que permaneceram produtivos por décadas.

## MATERIAIS CULTIVADOS

O Solidus mycetes de Verdania foi selecionado durante séculos para formar redes de hifas densas. Esporos colonizam palha e resíduos de madeira dentro de moldes. As hifas funcionam como fibras; partículas minerais e vegetais formam a matriz; proteínas adesivas unem as interfaces. Compressão durante o crescimento orienta a estrutura. Depois de sete a doze dias, aquecimento moderado encerra a atividade e estabiliza a peça. O Fungo-Pedra resultante é leve, isolante e moldável. Sua resistência à água depende do tratamento superficial; exemplares mal curados incham e perdem forma.

A Verdacelina é um polímero bacteriano produzido em folhas, fios ou espumas. Sua cadeia possui grupos que podem ser reticulados por enzimas depois da moldagem. Fibras vegetais aumentam resistência; pós minerais conferem dureza; pigmentos são incorporados durante o crescimento. O material pode ser reparado aplicando cultura e solução nutritiva à fissura antes de novo tratamento. Não substitui aço em altas temperaturas nem pedra sob compressão contínua, mas supera madeira comum em ambientes úmidos e reduz o peso de veículos, próteses e painéis.

Fibras de Inverno imitam hifas boreais que aprisionam ar em poros microscópicos. Resinas de Casco penetram madeira, reduzem absorção de água e impedem organismos marinhos de se fixar. Mucilagens formam curativos úmidos; proteínas adesivas unem tecidos; biocerâmicas cultivadas reconstroem pequenas partes de osso. O traço comum é a arquitetura em várias escalas. A propriedade não pertence apenas à molécula, mas à forma como fibras, poros e minerais são organizados.

## MEDICINA BIOALQUÍMICA

A medicina de Veth combina anatomia, cirurgia, óptica, pneumática e bioalquimia. Antibióticos são cultivados a partir de fungos e bactérias que competem entre si. Anestésicos bloqueiam canais nervosos; anticoagulantes e coagulantes regulam proteínas do sangue; hormônios purificados alteram metabolismo; enxertos fornecem suporte para que células do paciente reconstruam tecido. O avanço mais importante foi a padronização de dose. Extratos tradicionais variavam conforme estação e organismo. Preparações modernas medem concentração por resposta óptica e passam por ensaios em tecidos antes de uso clínico.

A regeneração possui limites claros. Pele, mucosa, vasos pequenos e cartilagem podem ser cultivados com bons resultados. Nervos periféricos crescem lentamente sobre guias biológicos. Órgãos inteiros exigem redes vasculares que os laboratórios ainda não reproduzem com confiabilidade. Transplantes dependem de compatibilidade e supressão temporária da resposta imune. Compostos crioprotetores prolongam transporte, mas não tornam tecidos indiferentes ao tempo.

O veneno do Cone de Fogo das Ilhas Verdes produz anestesia localizada em doses mínimas. A mucilagem da Medusa-Sol estimula fibroblastos e protege queimaduras. Tahuantinsuyu usa proteínas anticongelantes de musgos para impedir cristais de gelo em alimentos e amostras. A Frontier-Sud extrai crioprotetores de Cryobacillus polarensis, permitindo resfriar tecidos a vinte graus negativos e reaquecê-los com viabilidade suficiente para transporte médico. O processo requer curvas lentas de temperatura; congelar mais rápido continua destruindo membranas.

## BIOFOTÔNICA E FOTOCATÁLISE

Organismos bioluminescentes transformam energia alquímica em fótons com pouco calor. Tintas vivas usam proteínas que respondem a temperatura, acidez ou substâncias específicas. Sensores de estrada brilham quando o frio aumenta; indicadores hospitalares mudam de cor diante de contaminação; marcas espectrais aparecem apenas sob determinada frequência. A vida fornece o reagente, mas a leitura depende da óptica.

A fotocatálise de Ínsula Verde usa o Cristal Azul para conduzir ultravioleta e fotossensibilizadores para definir a reação. A luz por si só não escolhe uma ligação molecular. Cromóforos e enzimas absorvem frequências específicas, entram em estado excitado e transferem energia ao ponto onde a transformação deve ocorrer. Isso permite síntese em temperatura baixa, preservando compostos que seriam destruídos por calor. A precisão depende da pureza do reagente e da posição do sensibilizador, não apenas do foco do feixe.

## BIOALQUIMIA POR REGIÃO

VERDANIA

A floresta como arquivo vivo

Verdania reúne diversidade biológica e instituições capazes de registrá-la. A floresta fornece modelos; os laboratórios transformam esses modelos em linhagens estáveis. Solidus mycetes, Verdacelina, tintas bioativas e membranas osmóticas nasceram de espécies distintas e passaram por séculos de seleção. O Instituto Viridário de Saúde Natural coordena parte da medicina pública, mantém bancos de culturas e trata doenças tropicais que outros reinos enviam para estudo.

Biorreatores urbanos recebem resíduos orgânicos e separam produtos antes do descarte. Gases carregam reservatórios de baixa pressão; ácidos e solventes seguem para indústria; material digerido retorna como fertilizante. O ciclo não é fechado. Nutrientes entram com alimentos e saem em exportações, e contaminações podem atravessar a rede. Cidades verdanianas mantêm laboratórios de bairro que analisam água e culturas porque um único tanque infectado pode distribuir esporos por tubulações compartilhadas.

| ANOTAÇÃO MARGINAL USO INTERNO As tintas bioativas de Verdania ganharam uso velado pela Ordem. Indicadores de pH e temperatura são públicos. Algumas formulações respondem a alterações alquímicas que acompanham certos Furos e Fragmentos, embora o mecanismo não seja universal. A versão acadêmica descreve essas tintas como detectores ambientais de espectro amplo. O termo é correto e cuidadosamente incompleto. |
| --- |

HUEXOTL

Ecologia lacustre e agricultura recirculante

A bioalquimia de Huexotl não nasceu em recipientes de laboratório. Desenvolveu-se no Lago Texcoco Central, nos canais e nas chinampas que sustentam Tenōchtlan. Cada chinampa funciona como um sistema de circulação de matéria: sedimentos ricos em nutrientes são retirados dos canais e aplicados ao solo; resíduos vegetais retornam em compostagem; peixes e aves acrescentam compostos nitrogenados; raízes e comunidades microbianas impedem que esses nutrientes sejam perdidos imediatamente para a água. Bactérias fixadoras de nitrogênio, fungos micorrízicos e algas de superfície são cultivados como parte da lavoura. O solo não é tratado como substrato inerte, mas como uma comunidade cuja composição determina o que poderá crescer na estação seguinte.

Os calpullis responsáveis pelo sistema hídrico mantêm culturas microbianas próprias para salinidade, fertilidade e controle de doenças. Canais próximos às entradas do lago recebem plantas filtrantes e tapetes bacterianos capazes de reter metais e consumir excesso de matéria orgânica. Nas chinampas, fungos entomopatogênicos e insetos predadores reduzem pragas antes que seja necessário aplicar toxinas de amplo efeito. As sete colheitas anuais atribuídas às áreas mais produtivas não resultam de uma planta excepcional, mas da coordenação entre irrigação, sedimento, rotação, temperatura da água e sucessão de culturas. Um erro num desses componentes pode permanecer invisível por meses e surgir como queda de produtividade em outra parte da bacia.

Huexotl também preserva um dos maiores arquivos agrícolas vivos de Arden. Sementes, tubérculos, micélios e culturas bacterianas são mantidos em jardins distribuídos ao redor do lago, cada um sob responsabilidade de um calpulli diferente. Linhagens semelhantes são conservadas em locais separados para que inundação, doença ou conflito não eliminem uma variedade inteira. O sistema antecede a teoria moderna das Fitas de Linhagem, mas passou a ser estudado por bioalquimistas porque contém séculos de seleção dirigida registrados na própria diversidade das plantas. A maior realização huexotliana não é um composto isolado. É a manutenção deliberada de um ecossistema agrícola capaz de sustentar uma cidade sobre uma bacia que originalmente não poderia alimentá-la.

TLACUA

Fisiologia da escassez

A bioalquimia de Tlacua concentra-se na sobrevivência à perda de água. Plantas do território acumulam açúcares protetores, betaínas e mucilagens que estabilizam proteínas e membranas durante a desidratação. Comunidades microbianas formam crostas sobre o solo, prendendo partículas, reduzindo erosão e absorvendo umidade breve antes que ela evapore. Os clãs aprenderam a cultivar essas crostas nas proximidades de pontos de água e a transferir pequenas porções para áreas degradadas. A recuperação leva anos, mas transforma um solo solto em uma superfície capaz de reter sementes e infiltrar a chuva.

Extratos de plantas suculentas são usados em revestimentos que reduzem a evaporação de cisternas e em géis que mantêm raízes úmidas durante o transporte. Culturas de leveduras e bactérias são secas junto a açúcares protetores, permanecendo dormentes por meses até serem reidratadas. Isso permite produzir alimentos fermentados, medicamentos simples e culturas digestivas durante deslocamentos longos. Os recipientes são pequenos porque uma sociedade móvel não pode transportar biorreatores de pedra; a ciência de Tlacua precisou caber em bolsas, odres e caixas de sela.

A criação animal combina seleção hereditária e manejo de microbioma. Rebanhos adaptados ao território possuem rins capazes de concentrar urina, maior tolerância térmica e metabolismo que reduz perda de água durante repouso. Antes de uma mudança de pastagem, animais jovens recebem culturas digestivas retiradas de adultos habituados às plantas da rota seguinte. A prática facilita a transição entre forragens de composição diferente e reduz mortes por intoxicação ou incapacidade de fermentação. Como as linhagens pertencem aos clãs, registros de cruzamento e culturas intestinais acompanham os mesmos acordos que regulam rotas e pontos de água. Em Tlacua, conservar um rebanho também significa conservar o conjunto invisível de organismos que o torna capaz de sobreviver.

CONTIGO

Bioalquímica de profundidade

A costa de Contigo oferece acesso a águas frias que sobem rapidamente das profundezas. Os organismos recolhidos nessas correntes vivem sob pressão elevada, pouca luz e temperaturas que interromperiam a maioria das reações biológicas de superfície. Suas células usam membranas ricas em lipídios flexíveis, proteínas com estruturas compactas e pequenas moléculas estabilizadoras conhecidas como piezólitos. Esses compostos impedem que a pressão desloque a água ligada às proteínas e altere sua forma. Quando retirado do fundo sem contenção, parte desse material se degrada antes de alcançar o laboratório; por isso as embarcações científicas usam câmaras que mantêm pressão durante a subida e permitem observar a amostra sem expô-la imediatamente ao ar superficial.

Enzimas de profundidade realizam reações em temperaturas baixas e são usadas no processamento de alimentos, na limpeza de instrumentos e na síntese de compostos que o calor destruiria. Proteínas anticongelantes retardam a formação de cristais em tecidos e soluções. Piezólitos purificados estabilizam vacinas, enzimas e amostras durante transporte marítimo. O óleo de profundidade deriva da mesma adaptação: seus ésteres cerosos ramificados permanecem fluidos no frio e resistem à oxidação, propriedade que o tornou indispensável à mecânica de precisão. Bioalquimistas contiguenses estudam agora formas de produzir esses ésteres em culturas microbianas, pois a coleta em peixes abissais cresce mais rápido que a capacidade natural de reposição.

Os portos mantêm culturas de bactérias que consomem resíduos de pescado, produzem fertilizantes e sintetizam películas contra incrustação marinha. Algumas aderem a metal e madeira, formando superfícies que dificultam a fixação de cracas sem liberar veneno persistente na água. A proteção precisa ser renovada e pode falhar quando embarcações cruzam mares com temperatura ou salinidade diferentes. Contigo aprendeu a tratar o oceano como ambiente químico variável e não como uma única massa de água. Cada corrente traz comunidades, sais e pressões próprias; um processo criado para um porto pode funcionar mal algumas centenas de quilômetros ao sul.

| ANOTAÇÃO MARGINAL ORGANISMOS DE INTERESSE A Ordem mantém interesse especial nos organismos recolhidos abaixo da faixa alcançada pela luz. Algumas amostras apresentam padrões celulares que permanecem coordenados depois da morte do tecido, como se a organização não dependesse inteiramente das estruturas biológicas observáveis. Os laboratórios públicos classificam o fenômeno como persistência alquímica sob pressão. Os registros internos usam uma linguagem mais cautelosa. Até o momento, nenhuma cultura permaneceu estável por muitas gerações fora de sua câmara de origem, o que tem sido tratado como limitação experimental e, por alguns Custódios, como forma de contenção que não deve ser superada. |
| --- |

COLHARA

Câmaras, fungos e fermentação precisa

Palenque-Nova usa fungos higroscópicos para estabilizar umidade em galerias. As colônias absorvem vapor quando o ar está úmido e o liberam quando seca, dentro de limites biológicos. Ventilação e pedra calcária completam o sistema. Os Arquivos de Pedra preservam documentos, culturas e amostras por séculos porque temperatura, luz e umidade mudam lentamente. A manutenção exige substituir colônias envelhecidas antes que percam resposta.

A chicha bioativa tornou-se plataforma de fermentação. Linhagens diferentes produzem analgésicos, relaxantes musculares, coagulantes e estimulantes de curta duração a partir de substratos semelhantes. O processo é identificado por aroma, espectro e pressão, e não pela tradição ritual que lhe deu origem. Examinadores de Daesung compram estimulantes em quantidades suficientes para que médicos colharenses publiquem advertências periódicas sobre dependência, insônia e perda de julgamento.

RIOSOLA

Preservação e logística

Os Alimentos Vivos de Riosola combinam tratamento enzimático e colonização por bactérias benevolentes. Enzimas tornam nutrientes menos acessíveis a organismos de deterioração; a cultura protetora ocupa superfície e produz ácidos suaves. Carnes e laticínios permanecem estáveis por meses sem refrigeração completa. O produto continua biologicamente ativo e precisa respirar por embalagens permeáveis. Recipientes herméticos podem favorecer toxinas, razão pela qual cada lote traz instruções de ventilação que comerciantes estrangeiros nem sempre respeitam.

A preservação riosolana alterou campanhas, navegação e abastecimento urbano. Qin comprou grandes quantidades para expedições. Hospitais mantêm dietas estáveis durante inverno. A vantagem logística criou dependência de culturas específicas, e Riosola conserva bancos em três cidades separadas. A destruição de uma cultura-mãe não eliminaria a técnica, mas poderia reduzir qualidade por anos.

CALÇADA

Materiais do mar

Resinas de Casco derivam de cnidários calcários e equinodermos de estuário. Proteínas e polímeros penetram madeira, ligam-se a fibras e mantêm elasticidade depois da cura. A superfície dificulta fixação de cracas, algas e moluscos. Embarcações tratadas exigem carena em intervalos maiores e mantêm velocidade por mais tempo. O processo não torna madeira invulnerável. Danos profundos expõem fibras não tratadas e precisam de reparo antes que a água se espalhe por capilaridade.

Calçada também cultiva membranas para dessalinização, adesivos cirúrgicos e biocerâmicas. Sua bioalquimia depende de estuários saudáveis, o que colocou casas navais contra indústrias que descartavam salmoura e metais. A legislação costeira atual nasceu menos de ideal ecológico que da percepção de que poluir o estuário destruía o próprio material de que os estaleiros dependiam.

TAHUANTINSUYU

Altitude como seleção

A altitude preservou organismos com proteínas anticongelantes, pigmentos resistentes a ultravioleta e metabolismo eficiente em pouco oxigênio. Compostos de raízes estimulam produção de hemoglobina de alta afinidade; alcalóides processados dilatam capilares. A aclimatação acelerada reduz semanas a poucos dias, mas não elimina risco de edema ou esforço excessivo. Médicos ajustam dose conforme origem do paciente, porque habitantes de altitude respondem de maneira diferente de visitantes.

Musgos fornecem crioprotetores para alimentos e amostras. Terraços experimentais cultivam linhagens em faixas de altitude diferentes para medir a resposta. Tahuantinsuyu contribuiu para a ciência ao tratar a montanha como um laboratório vertical: a mesma espécie pode ser observada sob temperatura, radiação e pressão distintas em poucos quilômetros.

FRONTIER-SUD

Conservação no frio

Cryobacillus polarensis permanece metabolicamente ativo em temperaturas que interrompem a maioria das bactérias. Seus lipídios mantêm membranas flexíveis e suas proteínas impedem cristais de gelo de crescer. Compostos purificados protegem tecidos durante resfriamento controlado. Corações, enxertos e amostras nervosas podem atravessar um dia de viagem antes do transplante ou estudo. O reaquecimento é tão importante quanto o congelamento, e hospitais mantêm curvas específicas para cada tecido.

Fibras de Inverno incorporam estruturas microporosas inspiradas em fungos boreais. Tecidos retêm ar sem acumular tanta umidade quanto lã comum. Myrova compra grandes volumes para isolar tubulações de vapor; expedições usam versões leves. O material perde desempenho quando comprimido por longos períodos, por isso roupas e mantas precisam ser suspensas e recondicionadas.

ILHAS VERDES

Farmacologia marinha

Os recifes das Ilhas Verdes possuem três séculos de documentação farmacológica. O Cone de Fogo fornece peptídeos que bloqueiam a transmissão nervosa em regiões específicas. A Medusa-Sol produz mucilagem que mantém feridas úmidas e estimula fibroblastos. Outros organismos oferecem anticoagulantes, pigmentos, adesivos e toxinas. A dificuldade está em separar compostos parecidos que produzem efeitos opostos em doses pequenas.

A coleta selvagem foi reduzida depois que algumas populações diminuíram. Laboratórios agora cultivam tecidos ou transferem Fitas de Linhagem para microorganismos de produção. Essa mudança preserva os recifes e estabiliza a dose. Também concentra conhecimento em poucas casas capazes de manter biorreatores marinhos, problema que os conselhos insulares tentam limitar por licenças e bancos públicos de linhagens.

ÍNSULA VERDE

Fotobioalquimia

O Cristal Azul conduz ultravioleta com perda menor que outros minerais. Roseline Andriantsoa descobriu em 1.841 que um composto experimental, ligado a um fotossensibilizador específico, alterava sua estrutura sob luz conduzida e adquiria capacidade incomum de reforçar padrões de Significância. A pesquisa pública descreve aplicações em catálise, esterilização e síntese de fármacos.

| ANOTAÇÃO MARGINAL PESQUISA DE ANDRIANTSOA A Ordem recolheu o material em 1.843, manteve Andriantsoa formalmente em seu cargo e restringiu apenas a reprodução do composto. Ensaios com Selos pequenos produziram durações maiores e falhas menos previsíveis. A combinação de vantagem e imprevisibilidade mantém a pesquisa suspensa. Andriantsoa permanece viva, cooperativa e corretamente desconfiada da justificativa oficial para o confisco. |
| --- |

## ÉTICA, CONSENTIMENTO E CONTENÇÃO BIOLÓGICA

A bioalquimia trabalha com sistemas capazes de reproduzir-se, variar e atravessar fronteiras. Por isso seus erros raramente permanecem apenas dentro do instrumento. Verdania exige quarentena para linhagens novas, esterilização de resíduos e registro de transferência entre laboratórios. Ensaios em pessoas dependem de consentimento documentado, embora a prática varie entre reinos e se torne especialmente frágil em hospitais militares, prisões e comunidades pobres que recebem tratamento em troca de participação.

A edição de Fitas de Linhagem levantou uma disputa que ainda não encontrou solução comum. Alterações feitas para produzir medicamentos em bactérias são amplamente aceitas. Modificações em tecidos cultivados para enxerto recebem supervisão. Mudanças hereditárias em pessoas e animais reprodutores são proibidas por muitos reinos e toleradas em segredo por alguns. A razão não é apenas moral. Uma alteração que parece útil em uma geração pode interagir com outras sequências de forma imprevisível nas seguintes, espalhando um erro por uma população antes que a ciência reconheça sua origem.

| ANOTAÇÃO MARGINAL PROTOCOLO DA ORDEM A Ordem mantém protocolos próprios para organismos expostos a Fragmentos e Furos. O contato não transforma toda amostra em perigo metafísico, mas pode produzir padrões que persistem depois da remoção do tecido original. Culturas suspeitas são mantidas em recipientes sem linhagem reprodutiva, observadas por ciclos completos e destruídas por métodos independentes. O maior risco não é um organismo monstruoso escapando do laboratório. É uma propriedade útil demais para ser abandonada e incompreendida demais para ser usada com segurança. |
| --- |

PARTE V
