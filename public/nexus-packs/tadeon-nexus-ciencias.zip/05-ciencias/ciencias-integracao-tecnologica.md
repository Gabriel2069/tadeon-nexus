---
title: "Ciências de Veth — INTEGRAÇÃO TECNOLÓGICA"
node_type: "concept"
summary: "Seção “INTEGRAÇÃO TECNOLÓGICA” de Ciências de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "microscope"
aliases: ["INTEGRAÇÃO TECNOLÓGICA"]
tags: ["cânone","fonte-primária","ciencias"]
properties: {"canon_layer":"primary_source","source_document":"O.A. III ~ Ciências de Veth.docx","source_section":"INTEGRAÇÃO TECNOLÓGICA","source_order":6,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/ciencias|Fonte — Ciências de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# INTEGRAÇÃO TECNOLÓGICA

A cidade como sistema de sistemas

A maturidade científica de Arden aparece na integração. Uma tecnologia isolada pode impressionar; uma cidade revela se energia, controle, matéria, manutenção e instituições conseguem funcionar juntas durante décadas.

## CIDADES QUE RESPIRAM, VEEM E CRESCEM

Uma cidade hidropneumática recebe trabalho de rios, marés, vento e reservas gravíticas. Compressores carregam acumuladores; tubulações distribuem força; redes hidráulicas movem água e cargas pesadas; fibras ópticas transmitem comandos; reguladores mecânicos mantêm funções quando o cálculo falha; materiais bioalquímicos vedam, isolam e filtram. A infraestrutura possui ritmos. Reservatórios carregam durante a madrugada, oficinas consomem durante o dia, marés renovam portos em ciclos, estufas e culturas seguem tempos mais lentos.

O controle não está concentrado em uma sala única. Estações locais conhecem cada pressão, nível e temperatura de seu setor. Calculadores centrais otimizam a distribuição, mas válvulas passivas impedem a sobrepressão mesmo sem sinal. Esse arranjo limita a eficiência máxima e aumenta a sobrevivência. Uma cidade pode perder comunicação e continuar bombeando água. Pode perder uma estação e racionar bairros. Pode perder um porto e manter hospitais. O colapso integral exige falhas múltiplas ou destruição deliberada de pontos cuja importância costuma ser protegida por redundâncias e segredos.

## HOSPITAIS

Hospitais avançados reúnem todas as correntes. Geotermia ou hidropneumática fornece calor e pressão. Instrumentos pneumáticos dosam fármacos e movem a ventilação. Microscópios ópticos ampliam cirurgias e diagnósticos. Vidro Mnêmico guarda prontuários. Bioalquimia produz anestésicos, antibióticos, tecidos e curativos. Reservatórios locais mantêm operações durante interrupções. Salas críticas usam reguladores mecânicos e iluminação biofotônica para que a falha de uma torre óptica não interrompa os procedimentos.

A medicina continua desigual. Capitais possuem microscopia, enxertos e bancos de tecidos; aldeias dependem de curadores, instrumentos simples e transporte. A tecnologia reduz os limites naturais, mas não elimina distância, custo e formação. Verdania exporta compostos que poucos hospitais sabem usar corretamente. Albrath produz dosadores que se tornam perigosos sem a calibração correta. A ciência só chega a um paciente quando as instituições conseguem levar material, conhecimento e manutenção ao lugar.

## TRANSPORTE E LOGÍSTICA

Trilhos pneumáticos e hidráulicos dominam corredores densos. Carruagens usam pressão da linha para aceleração e reservatórios próprios para frenagem. Eclusas ligam níveis de rios. Portos empregam guindastes, docas mareopneumáticas e registros ópticos. Navios oceânicos combinam velas, mecanismos de carga, bombas e instrumentos de navegação. A ausência de motores compactos de combustão favoreceu transporte coletivo e infraestrutura fixa. Viagens fora dessas redes continuam lentas, dependentes de animais, vento e rios.

A logística avançou por conservação e informação. Alimentos Vivos prolongam campanhas e expedições; heliógrafos antecipam demanda; calculadores planejam irrigação e carga; peças padronizadas permitem manutenção longe da oficina original. O sistema é eficiente onde as rotas são conhecidas e as instituições cooperam. Fronteiras, guerras e sabotagem aumentam os custos rapidamente, porque cada corrente depende de materiais vindos de regiões diferentes.

## AGRICULTURA E ÁGUA

A agricultura usa bombas e eclusas para irrigação, sensores ópticos para umidade, culturas bioalquímicas para solo e preservação, e calculadores para distribuir água. Kemet administra o Netjer por modelos que incorporam níveis, canais e safras. Verdania usa membranas e ciclos orgânicos. Grauth regula rios para navegação e grãos. A produtividade vem da coordenação entre a ciência e o direito, pois um canal tecnicamente perfeito ainda assim falha quando comunidades recusam a distribuição que ele impõe.

## INDÚSTRIA E AUTOMAÇÃO

Fábricas ardênicas são redes de máquinas especializadas. Eixos hidráulicos fornecem movimento contínuo; ar comprimido aciona ferramentas; cames definem sequências; sensores ópticos verificam posições; autômatos retiram peças defeituosas; materiais cultivados chegam de biorreatores. A produção em massa existe, mas não depende de uma máquina universal. Linhas são reconfiguradas trocando cames, placas ópticas, moldes e ferramentas. Produtos muito diferentes exigem dias de preparação, o que favorece séries longas e oficinas dedicadas.

A automação deslocou o trabalho sem eliminá-lo. Operadores passaram de força direta para manutenção, inspeção e ajuste. Guildas controlam a formação, porque uma falha de calibração pode inutilizar milhares de peças. Conflitos trabalhistas surgem quando casas usam autômatos para reduzir equipes sem financiar treinamento. A tecnologia ainda altera a distribuição de poder antes de alterar a quantidade total de trabalho, e cada reino responde segundo suas instituições.

## COMUNICAÇÃO E CONHECIMENTO

Fibras e heliógrafos permitem que a informação atravesse Veth em horas. Arquivos ópticos armazenam volumes que bibliotecas inteiras não conseguiriam copiar rapidamente. A velocidade não garante a verdade. Redes transmitem erros com a mesma eficiência que fatos, e governos que controlam estações. A Concordância estabeleceu protocolos de autenticação por sequências luminosas e marcas de origem. Casas mercantis acrescentam cifras. A Ordem mantém canais próprios, frequentemente escondidos dentro da infraestrutura eclesiástica.

A ciência depende dessa circulação. Um surto em Verdania pode ser descrito a Daesung antes de suas amostras chegarem. Um defeito de válvula identificado em Albrath pode suspender lotes em Grauth. A rede também concentra vulnerabilidades informacionais: quem controla padrões, arquivos e repetidores decide quais descobertas se tornam comuns. O ideal de “conhecimento aberto” convive com patentes, segredos de guilda e censura estatal.

## LIMITES E ASSIMETRIAS

A tecnologia de Arden não é uniforme. Calculadores ópticos superam equipes humanas em tarefas paralelas e previsíveis, mas ocupam espaço e exigem preparação. Pneumática distribui força com limpeza, porém não oferece a densidade de um combustível portátil. Bioalquimia produz materiais e fármacos refinados, mas trabalha no tempo da vida e enfrenta contaminação. Mecânica de precisão mantém sistemas por décadas, desde que receba inspeção e peças. Essas limitações moldaram uma civilização de infraestrutura compartilhada, transporte coletivo e oficinas especializadas.

A menor dependência de combustão reduziu fumaça e certas formas de poluição. Criou outros riscos. Reservatórios explodem; salmouras destroem estuários; culturas escapam; amplificadores aquecem; cristais ultravioletas ferem trabalhadores; resíduos metálicos contaminam rios; redes extensas podem tornar cidades dependentes de materiais distantes. A ciência não retirou o custo do mundo. Tornou o custo mensurável e, em muitos casos, negociável.

## A ORDEM E AS CIÊNCIAS PÚBLICAS

A Ordem do Véu depende das mesmas academias que oculta de si. Bordadores usam metrologia, mineralogia e óptica. Curadores usam bioalquimia. Cartógrafos do Véu dependem de redes de comunicação. Ao mesmo tempo, a Ordem retém descobertas cuja divulgação permitiria manipular Fragmentos, reconhecer Selos ou explorar Furos. Essa política preservou vidas e atrasou pesquisas legítimas. Zabreion Taveus Gartza escreveu a edição pública deste livro defendendo que o segredo deveria recair sobre aplicações perigosas, não sobre princípios naturais capazes de fortalecer toda a sociedade.

As anotações desta cópia mostram que a fronteira raramente é nítida. Rethita possui uso industrial e afinidade com Selos. Tintas ambientais podem indicar uma dobra. O Pounamu responde a pressão física e participa de instrumentos de Canalização. Nenhuma dessas propriedades torna a ciência pública uma fachada. A matéria continua obedecendo a regularidades, e compreendê-las é a condição para distinguir fenômeno natural de manifestação. A Ordem comete seus erros mais graves quando decide primeiro que algo pertence ao Além-Véu e procura depois uma explicação que confirme a decisão.

| ANOTAÇÃO FINAL ARQUIVO DE GARTZA A versão entregue às academias encerra-se com um catálogo de aplicações. Esta cópia preserva a advertência retirada pelo Conclave: nenhuma instituição deve tornar-se a única guardiã de uma ciência da qual toda Veth depende. A redundância que protege uma cidade também deve proteger o conhecimento. Padrões precisam de cópias, culturas precisam de bancos separados, rotas precisam de alternativas e arquivos precisam sobreviver a seus próprios custódios. A Ordem não está isenta dessa regra. |
| --- |

## CONCLUSÃO

A ciência ardênica adquiriu sua forma pela divisão de funções. Matrizes naturais captam trabalho. Pneumática e hidráulica conduzem força. Óptica conduz informação e realiza cálculos. Bioalquimia transforma matéria viva. Mecânica e metalurgia convertem todos esses processos em instrumentos duráveis. Metrologia, registro e confiabilidade mantêm as partes compatíveis. A complexidade do conjunto não resulta de uma descoberta única, mas de séculos em que reinos diferentes resolveram problemas locais e depois aceitaram ligar suas soluções.

Essa integração explica por que uma cidade de Veth pode ser ao mesmo tempo antiga e tecnicamente avançada. Aquedutos recebem sensores ópticos; mosteiros mantêm bancos de culturas; palácios usam reservatórios de pressão; portos combinam maré e cálculo; hospitais cultivam tecido sob luz coerente. A aparência conserva pedra, cobre, vidro, madeira e organismos vivos porque esses materiais nunca foram substituídos por uma única substância universal. Foram compreendidos em maior profundidade e reunidos em sistemas que aproveitam suas diferenças.

A tecnologia de Arden não promete independência do mundo físico. Sua força vem do contrário: cada região aprendeu a ler os gradientes que a geografia oferecia e a transformá-los em infraestrutura. O rio torna-se pressão, a maré torna-se doca, o vulcão torna-se hospital, o deserto torna-se lente, a floresta torna-se fábrica e o arquivo torna-se memória de uma civilização inteira. A ciência começa quando essa transformação pode ser explicada. Torna-se cultura quando pode ser preservada.

FIM DO LIVRO III

CIÊNCIAS DE VETH

━━━━━━━━━━━━━━  ◇  ━━━━━━━━━━━━━━

PRÓXIMO VOLUME

LIVRO IV

GEOGRAFIA DE VETH

Geomorfologia, hidrografia, climatologia e formas vivas que fornecem a base material das ciências apresentadas neste volume.
