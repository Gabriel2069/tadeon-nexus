---
title: "Ciências de Veth — FUNDAMENTOS DA CIÊNCIA ARDÊNICA"
node_type: "concept"
summary: "Seção “FUNDAMENTOS DA CIÊNCIA ARDÊNICA” de Ciências de Veth, preservada como fonte canônica rastreável."
status: "canonical"
visibility: "workspace"
icon: "microscope"
aliases: ["FUNDAMENTOS DA CIÊNCIA ARDÊNICA"]
tags: ["cânone","fonte-primária","ciencias"]
properties: {"canon_layer":"primary_source","source_document":"O.A. III ~ Ciências de Veth.docx","source_section":"FUNDAMENTOS DA CIÊNCIA ARDÊNICA","source_order":1,"verbatim_transcription":true}
---
> Fonte canônica: [[../00-fontes/ciencias|Fonte — Ciências de Veth]]. O conteúdo abaixo preserva a redação da seção de origem.

# FUNDAMENTOS DA CIÊNCIA ARDÊNICA

Medida, conservação, materiais e confiança

A capacidade técnica de Veth nasceu da repetição. Descobertas isoladas tornaram-se ciência quando puderam ser medidas, verificadas, transmitidas e incorporadas a sistemas que continuavam funcionando depois da morte de seus inventores.

## A CONCORDÂNCIA DAS MEDIDAS

A Concordância é lembrada sobretudo por seus tratados políticos, mas sua consequência material mais duradoura foi a padronização das medidas. Antes do ano zero, cada porto possuía seu próprio peso comercial, cada reino definia a extensão de uma milha segundo tradições locais e cada oficina de metalurgia preservava padrões físicos que se alteravam lentamente com o desgaste. Essa diversidade era tolerável enquanto uma máquina inteira era construída pela mesma oficina. Tornou-se um obstáculo quando Vélia passou a reunir mecanismos produzidos em três continentes e descobriu que uma rosca descrita como “um quarto de dedo” em Albrath não recebia uma válvula de mesma medida fabricada em Grauth.

O primeiro Padrão da Concordância foi uma coleção de barras, massas, recipientes e relógios selados em uma câmara de Maravezia. As cópias oficiais seguiram para os principais reinos, acompanhadas por instruções de reprodução e comparação. O sistema atual é mais rigoroso. Comprimento é aferido por padrões ópticos gravados em vidro de Kemet; massa usa ligas estáveis de Albrath; tempo civil é ajustado pelos observatórios de Qalat, Colhara e Daesung; pressão é definida pela coluna de um fluido de densidade conhecida mantida sob temperatura controlada; temperatura usa pontos de transformação de sais purificados. Nenhum padrão depende de um único objeto. Cada unidade pode ser reconstruída a partir de procedimentos documentados, e os institutos de calibração comparam suas cópias em ciclos regulares.

A metrologia alterou a organização do trabalho. Oficinas deixaram de produzir mecanismos completos e passaram a fabricar famílias de peças intercambiáveis. Uma engrenagem quebrada em Nordhavn pode ser substituída por uma peça produzida em Albrath sem que o eixo inteiro precise ser refeito. Hospitais compram agulhas, válvulas e reservatórios de fornecedores distintos porque todos declaram tolerâncias no mesmo sistema. A uniformidade nunca é perfeita. Ela é administrada por classes de precisão: infraestrutura comum aceita desvios maiores; instrumentos cirúrgicos, calculadores ópticos e reguladores de alta pressão exigem certificação mais estreita. O custo cresce com cada casa decimal, e a ciência de produção consiste em escolher a precisão necessária sem desperdiçar trabalho tentando superar um limite que a aplicação não aproveita.

| Classe de fabricação | Desvio admitido | Aplicações comuns |
| --- | --- | --- |
| Comum | até 0,5 mm | estruturas, canais, mobiliário, tubulação de baixa pressão |
| Industrial | até 0,1 mm | válvulas urbanas, bombas, eclusas, mecanismos de transporte |
| Precisa | até 0,01 mm | relojoaria, instrumentos médicos, moduladores ópticos |
| Magistral | até 0,001 mm | lentes de interferência, cavidades ópticas, padrões de calibração |

MÉTODO, REGISTRO E REPRODUÇÃO

O método ardênico moderno se formou em instituições que possuíam razões práticas para desconfiar da memória individual. Navegadores precisavam registrar correntes que mudavam com a estação; curadores precisavam distinguir uma cura real da recuperação espontânea; engenheiros de pressão precisavam saber se uma ruptura resultara de material ruim, instalação incorreta ou fadiga acumulada. O procedimento consolidado pela Conferência de Brenholt exige descrição do material, instrumento, temperatura, pressão, duração e resultado. Experimentos relevantes devem ser repetidos por outra oficina ou academia antes que ingressem em manuais públicos. O prestígio de uma descoberta continua ligado a seu autor, mas sua aceitação depende da possibilidade de sobreviver a ele.

Daesung deu ao registro de falhas o mesmo estatuto que outros reinos davam às invenções. Seu Arquivo Real recebe relatórios de acidentes pneumáticos, contaminações bioalquímicas, distorções ópticas e falhas estruturais. Cada caso é preservado com amostras, desenhos e depoimentos. O Relatório de Modos de Falha Pneumáticos de 1.810 surgiu da comparação de centenas de acidentes que, tomados isoladamente, pareciam distintos. Treze padrões recorrentes foram identificados, desde corrosão sob vedação até oscilação de reguladores em redes mal segmentadas. A consequência mais importante do relatório não foi uma máquina nova, foi a percepção de que falhas também possuem famílias e podem ser previstas antes de acontecer.

## TRABALHO, CONSERVAÇÃO E GRADIENTES

A filosofia de Veth define trabalho como transferência ordenada de movimento capaz de alterar um sistema, comumente atribuído como a própria natureza. O conceito unificou práticas que antes pertenciam a ofícios separados. A água descendo um vale, o ar expandindo dentro de um cilindro, uma massa suspensa perdendo altura e um organismo transformando alimento realizam trabalho por mecanismos diferentes, mas obedecem à mesma contabilidade: a capacidade de produzir mudança diminui em uma parte do sistema e aparece em outra, acompanhada por perdas em calor, atrito, deformação e ruído.

Os tratados modernos usam o termo gradiente para qualquer diferença que possa ser conduzida. Há gradientes de altura, pressão, temperatura, concentração, salinidade, luminosidade e potencial químico. Uma matriz energética é uma infraestrutura construída ao redor de um gradiente suficientemente persistente. O rio oferece diferença de altura; a maré oferece variação periódica de nível; uma fonte geotérmica oferece diferença térmica; um estuário oferece diferença de salinidade; uma cultura viva oferece diferença alquímica entre alimento e produto. O projeto técnico começa pela duração do gradiente, não por sua intensidade momentânea. Uma força pequena e contínua sustenta serviços que uma força violenta e irregular não consegue alimentar sem grande armazenamento.

A conservação de trabalho tornou-se o princípio de ensino depois que os primeiros inventores pneumáticos prometeram mecanismos que manteriam a própria pressão indefinidamente. Nenhum deles funcionou. Válvulas vazavam, superfícies aqueciam, molas perdiam tensão e o ar expandido já não retornava ao reservatório sem compressão externa. A partir dessas falhas, os físicos passaram a tratar toda máquina como um percurso de perdas mensuráveis. Eficiência deixou de significar uma qualidade geral e passou a indicar a fração de trabalho que chega ao uso final. Essa mudança permitiu comparar uma roda hidráulica, um acumulador pneumático e um sistema de pesos sem fingir que eram a mesma máquina.

CALOR E TRANSFORMAÇÃO

A compressão aquece gases; a expansão os resfria. O fenômeno era conhecido por ferreiros e mineiros muito antes de receber explicação quantitativa, mas só se tornou ferramenta de engenharia quando os laboratórios de Grauth e Myrova passaram a medir pressão e temperatura durante ciclos completos. Uma estação que comprime ar rapidamente e deixa o calor escapar perde parte do trabalho investido. Quando o mesmo ar se expande, resfria e pode formar gelo nas válvulas. A solução moderna combina compressão em estágios, troca térmica e armazenamento de calor, aproximando o processo de uma transformação lenta e quase isotérmica.

A termolita tornou esse sistema economicamente viável. O nome reúne uma família de sais de cálcio, sódio e metais alcalinos encontrados em depósitos do Alvor e purificados em Kemet. Cada composição possui uma temperatura de transição na qual absorve grande quantidade de calor enquanto reorganiza sua estrutura cristalina. Durante a compressão, serpentinas transferem calor para leitos de termolita. Durante a expansão, o fluxo é reaquecido pelo mesmo material. A termolita não produz trabalho e não impede todas as perdas. Ela conserva uma parcela que antes era lançada ao ambiente, reduz o congelamento e permite que reservatórios distritais entreguem pressão por mais tempo com menor queda térmica.

## CIÊNCIA DOS MATERIAIS

As três correntes tecnológicas dependem de uma ciência dos materiais comum. A composição alquímica informa apenas parte do comportamento de uma peça. O mesmo aço pode tornar-se dúctil, frágil, elástico ou resistente ao desgaste conforme a velocidade de resfriamento, a direção do trabalho mecânico e a quantidade de impurezas. Cristais de mesma composição conduzem luz de maneiras diferentes quando cortados em eixos distintos. Fibras biológicas ganham diferentes forças quando orientadas durante o crescimento. Os tratados modernos descrevem material por composição, microestrutura, tratamento e histórico de carga.

A microscopia óptica de Kemet permitiu observar grãos metálicos, fibras vegetais, colônias celulares e inclusões cristalinas. Ensaios de fadiga repetem milhares de ciclos até que uma peça falhe. Câmaras climáticas de Myrova e Qalat submetem amostras a frio, calor, umidade e areia. Os resultados são registrados como curvas de vida útil, não como promessas de permanência. Uma válvula certificada para um milhão de ciclos pode durar mais, mas deve ser substituída antes que a probabilidade de ruptura cresça além do limite aceito. Essa disciplina explica por que sistemas ardênicos parecem conservadores: muitas peças são retiradas enquanto ainda funcionam, porque sua história de esforço já se tornou suficiente para desconfiar delas.

## CONFIABILIDADE E FALHA GRADUAL

As grandes infraestruturas de Veth foram construídas para perder capacidade sem perder a função inteira. A doutrina recebe o nome de falha gradual. Redes pneumáticas são divididas por válvulas de isolamento; reservatórios locais sustentam hospitais e bombas de água depois que uma linha principal se rompe; calculadores ópticos possuem caminhos alternativos para sinais essenciais; mecanismos mecânicos assumem funções simples quando o controle óptico deixa de operar; cidades costeiras combinam maré, vento e reservatórios elevados para que a ausência de uma fonte não interrompa todos os serviços.

A redundância não significa duplicar tudo. O custo tornaria qualquer cidade impraticável. Engenheiros classificam funções segundo a consequência de sua perda. Iluminação decorativa pode esperar; ventilação de mina, bombeamento de hospital e comportas de inundação recebem rotas independentes. Uma rede é avaliada por quantas falhas simultâneas suporta, quanto tempo mantém serviços essenciais e quão rapidamente revela o ponto danificado. O sistema mais seguro não é aquele que nunca falha. É aquele cuja falha permanece localizada, compreensível e reparável.

| Princípio | Aplicação | Efeito |
| --- | --- | --- |
| Segmentação | válvulas e comportas entre setores | impede propagação da perda |
| Reserva local | tanques, pesos e calor armazenado | mantém funções durante interrupções |
| Diversidade de fontes | rio, maré, vento, calor e osmose | reduz dependência de um único regime |
| Controle passivo | reguladores mecânicos e válvulas de alívio | funciona sem cálculo central |
| Diagnóstico | manômetros, tintas indicadoras e leitura óptica | localiza desgastes antes de romperem |
| Intercambialidade | peças padronizadas | reduz tempo de reparo |

| ANOTAÇÃO MARGINAL CIRCULAÇÃO INTERNA Alguns Selos antigos demonstram a mesma arquitetura de falha gradual. Em vez de depender de uma única linha, distribuem a contenção entre símbolos, materiais e vínculos humanos. A semelhança não prova origem comum, mas orientou os Bordadores da Ordem na reforma de Selos territoriais depois da Quebra. A documentação pública atribui essas práticas exclusivamente à engenharia civil. |
| --- |

PARTE II
