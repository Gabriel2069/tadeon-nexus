---
title: "Livro de Regras TdV II v2.0"
node_type: "rule"
summary: "Fonte normativa atual para fichas, motor, condução, Ameaças e expressões."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "canon_layer": "primary_source_index"}
---

Fonte fornecida por Tadeu: `02_Livro_de_Regras(3).docx`. SHA-256: `8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f`. Extração textual do corpo e das tabelas; ilustrações e paginação do DOCX não são reproduzidas. Os procedimentos e casos-limite deste arquivo prevalecem sobre os registros históricos da primeira edição.

- [[tdv-ii/00-apresentacao-e-precedencia|TdV II · Apresentação e precedência]]
- [[tdv-ii/01-arquitetura|TdV II · Arquitetura]]
- [[tdv-ii/02-pessoa|TdV II · Pessoa]]
- [[tdv-ii/03-acao|TdV II · Ação]]
- [[tdv-ii/04-relacao|TdV II · Relação]]
- [[tdv-ii/05-situacao|TdV II · Situação]]
- [[tdv-ii/06-transformacao|TdV II · Transformação]]
- [[tdv-ii/07-expressao|TdV II · Expressão]]
- [[tdv-ii/08-aplicacao-derivada|TdV II · Aplicação derivada]]
- [[tdv-ii/09-mundo|TdV II · Mundo]]
- [[tdv-ii/10-referencia|TdV II · Referência]]
- [[tdv-ii/11-integridade-do-canone|TdV II · Integridade do cânone]]
- [[tdv-ii/12-calibracao-matematica-verificada|TdV II · Calibração matemática verificada]]
- [[tdv-ii/13-consulta-rapida-de-mesa|TdV II · Consulta rápida de mesa]]
- [[tdv-ii/14-integridade-editorial-precedencia-e-glossario|TdV II · Integridade editorial, precedência e glossário]]
- [[tdv-ii/15-autoria-auditoria-e-direcao-editorial|TdV II · Autoria, auditoria e direção editorial]]