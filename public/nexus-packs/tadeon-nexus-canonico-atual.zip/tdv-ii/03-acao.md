---
title: "TdV II · Ação"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "AÇÃO", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# AÇÃO

INTENÇÃO, INTERVENÇÃO E MOTOR

Dois Fios encontram uma situação. O resultado conserva o encontro.

Como uma intenção ganha forma e encontra a situação através do Motor.

## SEÇÃO 01PRINCÍPIO DO MOTOR

TdV II resolve uma ação pela relação entre duas coisas que nunca são a mesma:

o que existe na pessoa e o modo como ela encontra uma abertura na situação.

A primeira dimensão é a Matriz; a segunda é o Alinhavo. Seus dados formam dois Fios distintos. Os Fios são lidos primeiro individualmente e depois em conjunto.

A sequência universal é:

Matriz + Alinhavo → Fio de Prumo + Fio de Tento → Ascendente + Retorno → Enlace → Desvio → Consonância → consequência

O dado nunca existe apenas para dizer "passou" ou "falhou". O resultado deve informar a capacidade alcançada, a sustentação da tentativa e a forma como a situação respondeu.

## SEÇÃO 02OS DOIS FIOS

### Fio de Prumo

É o dado produzido pela Matriz.

Representa a capacidade disponível na pessoa: força, coordenação, compreensão ou presença, conforme a Matriz escolhida.

Prumo pergunta: "Quanto existe em mim para sustentar esta ação?"

### Fio de Tento

É o dado produzido pelo Alinhavo.

Representa método, prática e capacidade de reconhecer uma abertura e aproveitá-la.

Tento pergunta: "Quanto consigo fazer esta situação trabalhar a meu favor?"

Os nomes fazem referência à linguagem material da Urdidura: o Fio possui direção e dependência; o sistema usa duas linhas diferentes porque uma ação humana nunca é apenas potência nem apenas técnica.

## SEÇÃO 03ESCADA DOS DADOS

### Matrizes

Matrizes possuem seis posições: 0 é uma limitação funcional; 1 a 5 formam cinco categorias de crescimento.

[0408 TABLE]

Valor | Estado | Dado

0 | Limitado | d4

1 | I | d6

2 | II | d8

3 | III | d10

4 | IV | d12

5 | V — transcendente | d20

d16 não pertence à escala ordinária.

#### Matriz 0

Matriz 0 ainda rola. Ela não significa incapacidade absoluta; significa que a ação depende de uma capacidade na qual a pessoa possui uma limitação real.

### Alinhavos

Alinhavos possuem cinco categorias, de 0 a 4. O 0 é a experiência comum e não uma deficiência.

[0414 TABLE]

Grau | Estado | Dado

0 | Comum | d4

1 | Iniciado | d6

2 | Praticado | d8

3 | Profissional | d10

4 | Especialista | d12

O d20 de um Alinhavo não faz parte da progressão ordinária; só aparece por efeito extraordinário, Lavor, equipamento, condição ou outra regra explícita.

#### O d20 de Matriz

O d20 ocupa deliberadamente o topo da escada e não representa apenas excelência humana. A passagem de uma Matriz para d20 é reservada a capacidades sobrenaturais, transcendentes ou equivalentes em escala. Mesmo uma personagem excepcionalmente experiente não alcança d20 em uma Matriz apenas por prática ordinária. O d20 deve parecer raro na ficção e raro na ficha.

## SEÇÃO 04FORMAÇÃO DO TESTE

1.  O Jogador declara intenção.

2.  Define abordagem: de que maneira pretende alcançar a intenção.

3.  O Narrador determina a Matriz e o Alinhavo coerentes com essa abordagem.

4.  Role os dois dados:

•  Fio de Prumo = dado da Matriz;

•  Fio de Tento = dado do Alinhavo.

5.  Registre os dois resultados antes de somá-los.

6.  Determine Ascendente e Retorno.

7.  Calcule o Enlace.

8.  Compare o Enlace com a DT ou, em oposição, com o Enlace da outra parte.

9.  Leia o Desvio.

10.  Verifique Consonância.

11.  Aplique a consequência correspondente.

A abordagem é parte da regra. Trocar a Matriz sem mudar a ficção não é permitido apenas para buscar o maior dado.

## SEÇÃO 05ASCENDENTE E RETORNO

Os dois resultados individuais não são descartados após a soma.

### Ascendente

É o maior dos dois resultados.

Representa o quanto a tentativa conseguiu se elevar acima da parte mais frágil de sua própria composição.

Ascendente é a leitura predominantemente favorável do teste.

Ele serve para:

•  qualificar sucessos

•  medir extensão, domínio ou oportunidade quando o Enlace alcança a DT

•  sustentar avanço residual quando o Enlace não alcança a DT

•  alimentar efeitos que dependam explicitamente da força da execução.

#### Retorno

É o menor dos dois resultados.

Representa a parte da tentativa que não acompanhou sua melhor expressão e que, portanto, pode retornar como pressão, custo ou instabilidade.

Retorno é a leitura predominantemente desfavorável do teste.

Ele serve para:

•  revelar quanto da ação permaneceu pouco sustentado

•  determinar ou agravar consequências quando o resultado pede preço

•  medir vulnerabilidade da execução

•  alimentar efeitos que expressem repercussão, desgaste ou retorno.

Ascendente pergunta "até onde a ação conseguiu subir?"

Retorno pergunta "o que dessa tentativa ainda ficou sem sustentação?"

Importante: Retorno não é um segundo teste de fracasso. O Enlace continua sendo o único determinante de alcance da intenção.

## SEÇÃO 06ENLACE

Enlace = Fio de Prumo + Fio de Tento.

O Enlace é o resultado composto dos dois Fios.

É ele que decide se a intenção pode ser alcançada.

### Contra uma DT

Enlace ≥ DT: a intenção principal é alcançada.

Enlace < DT: a intenção principal não é alcançada como pretendida, mas o resultado ainda pode produzir avanço, informação ou mudança conforme Ascendente, Retorno e Desvio.

#### Em disputa

Cada participante forma seu próprio Enlace.

O maior Enlace prevalece. Empates preservam a condição anterior, salvo regra específica da situação.

O mesmo motor serve para combate, perseguição, negociação, investigação, infiltração, Canalização e qualquer outro Conflito.

## SEÇÃO 07DESVIO

Desvio registra a distância entre os dois Fios e sua direção.

Desvio = Fio de Prumo − Fio de Tento.

O valor pode ser:

•  positivo: Prumo prevaleceu

•  zero: os Fios coincidiram

•  negativo: Tento prevaleceu.

A magnitude do Desvio é a distância absoluta entre os Fios.

### Direção do Desvio

#### Prumo prevalece

A pessoa conseguiu porque havia capacidade suficiente, mas não necessariamente método suficiente.

Consequências típicas:

•  força excessiva

•  gasto de recurso

•  dano colateral

•  solução pouco elegante

•  exposição

•  necessidade de controlar o que foi produzido.

##### Tento prevalece

A pessoa encontrou um caminho melhor do que sua capacidade bruta sugeriria.

Consequências típicas:

•  depender do contexto

•  abrir uma oportunidade frágil

•  precisar preservar posição

•  deixar-se vulnerável depois da ação

•  criar uma solução que funciona enquanto determinada condição permanecer.

##### Desvio pequeno

Capacidade e método estão próximos. A execução é coerente e tende a produzir menos repercussão própria.

##### Desvio grande

A execução depende fortemente de um dos dois lados. Mesmo em sucesso, o Narrador pode usar essa assimetria para definir a forma da consequência.

Desvio não muda automaticamente o alcance da intenção. Ele explica a natureza do resultado.

## SEÇÃO 08CONSONÂNCIA

Consonância é o terceiro elemento emergente dos dois Fios.

### Regra-base

Consonância ocorre quando os dois Fios apresentam o mesmo resultado.

Quando isso acontece:

•  Ascendente e Retorno possuem o mesmo valor

•  Desvio é 0

•  a tentativa encontrou uma forma em que capacidade e aplicação se sustentam mutuamente.

#### Consonância em sucesso

Se o Enlace alcança a DT e existe Consonância, ocorre sucesso crítico, exceto na dupla unidade (1,1), que é Falha Crítica e prevalece sobre essa leitura.

O efeito principal ocorre e recebe uma expressão extraordinária apropriada à ação: mais alcance, economia, precisão, informação adicional, posição favorável, duração adequada ou outro benefício coerente.

Consonância nunca cria meios que a ficção não ofereça.

#### Consonância em falha

Se os Fios são iguais, mas o Enlace não alcança a DT, não existe sucesso crítico. Há Consonância sem alcance: a tentativa estava perfeitamente coerente em si mesma, mas a situação era superior àquilo que os recursos disponíveis podiam alcançar.

Isso evita que Consonância vire automaticamente "20 natural". Ela representa coerência, não poder bruto.

## SEÇÃO 09RESULTADOS

O Motor produz uma leitura integrada de resultado: Alcance pelo Enlace; Movimento por Ascendente e Retorno; Direção pelo Desvio; Encontro pela Consonância; e Resto pelo que permanece disponível depois da resolução.

### Alcance

#### Êxito

Enlace alcança a DT.

#### Não alcançado

Enlace fica abaixo da DT.

O segundo resultado não substitui o primeiro: a diferença entre eles define como a situação continua.

### Qualidade do Êxito

Em vez de criar um novo tipo de rolagem, o jogo lê a margem do Enlace:

•  Êxito: +0 a +3;

•  Êxito elevado: +4 a +7;

•  Êxito excepcional: +8 ou mais.

O Ascendente qualifica a abertura produzida pelo resultado; não cria uma segunda escala de sucesso.

### Qualidade da Falha

Abaixo da DT, a falha é lida pela margem:

•  Quase: −1 a −2;

•  Falha com consequência: −3 a −5;

•  Falha severa: −6 ou menos.

Falha severa não significa Ruptura automaticamente. O Retorno e o Desvio decidem qual consequência é coerente e quão sustentada ela está.

## SEÇÃO 10MOVIMENTOS DO RESULTADO ~ ABERTURA, FRESTA, RASTRO E RESTO

Os nomes da árvore de Resultados deixam de ser apenas etiquetas e recebem o seguinte procedimento universal. Nenhum desses elementos altera o Enlace ou cria um dado adicional. A leitura curta só os invoca quando relevante.

Abertura é a oportunidade produzida pelo Ascendente quando o Enlace alcança a DT. Pode tornar uma abordagem possível, melhorar Posição, revelar relação, preservar algo ameaçado, criar acesso ou preparar uma mudança subsequente. Não é uma ação gratuita e não concede Proveito automaticamente: o Proveito só nasce quando a Abertura passou a favorecer de fato um Fio posterior.

Fresta é o avanço residual produzido pelo Ascendente quando o Enlace não alcança a DT. Mostra uma vulnerabilidade, explica por que a ação falhou, conserva uma pista ou torna a próxima abordagem mais específica. Não transforma a intenção original em sucesso retroativo.

Rastro é o vestígio que uma ação deixa disponível na cena: assinatura, testemunha, obrigação, ferramenta consumida, situação modificada ou informação tornada pública. Pode acompanhar êxito ou falha e não constitui uma taxa automática por agir. Quando o vestígio nasce da parte pouco sustentada da execução, sua leitura se liga ao Retorno; o Rastro cosmológico, definido na Urdidura, é mais amplo que esse uso do Motor.

Devolução é a consequência que retorna sobre quem agiu, a Posição, os recursos ou as relações envolvidas. Pode acompanhar uma falha ou um sucesso arriscado, desde que a ação e a situação sustentem esse retorno. Retorno baixo identifica menor sustentação, mas não impõe custo automático; o Narrador não inventa punições porque um Fio mostrou um número menor.

Resto é o registro objetivo da modificação que ainda importa depois de narrar a intenção: Abertura, Fresta, Rastro, Devolução, Posição, Pressão, Condição ou mudança de Vínculo. Quando atravessa a cena, transforma-se em Permanência; se integrar a pessoa, torna-se Incorporação. Memória da Trama é o registro duradouro desses Restos, não um bônus ou recurso.

Redobra permite reorientar um Resto já produzido, sem refazer a rolagem, apagar o custo ou transformar a falha original em sucesso. Só é possível quando existe outra continuidade plausível que possa suportá-lo; o Narrador explica qual relação mudou e pode recusá-la quando nenhuma existir.

Contrapartida é a continuidade que uma mudança efetivamente deslocou. Não é gasto universal nem punição do Narrador: só existe quando a intervenção alterou algo que precisava ser sustentado e o efeito não possuía preço pré-escrito.

Ponto em Jogo pode ser declarado antes da rolagem para identificar a pessoa, relação, informação, recurso, promessa ou Posição que o jogador quer preservar. Não aumenta dados nem torna esse elemento invulnerável; orienta a interpretação da consequência.

Virada de Posição é a transferência efetiva do controle de uma frente ou passagem. Não é estado numerado novo nem bônus independente, e nasce de Abertura, Cooperação, Redobra ou outra intervenção relevante.

Preparo é uma condição favorável concretamente criada antes de ser utilizada. Deve declarar o que foi preparado, para qual situação e como sua continuidade será consumida ou alterada ao surgir o gatilho. Não autoriza retrospectivas ilimitadas.

A escala de Ascendente e Retorno nunca impõe efeitos automáticos por números isolados. A margem de Enlace continua sendo a graduação objetiva de êxito ou falha; os Fios individuais definem abertura, peso e direção, sempre dentro do que a ficção realmente permite.

## SEÇÃO 11PROVEITO E DESPROVEITO

Proveito e Desproveito substituem Vantagem e Desvantagem.

Eles não acrescentam dados.

Cada aplicação desloca um Fio em uma categoria de dado, para cima ou para baixo.

Exemplo:

d8 → d10 com Proveito.

d8 → d6 com Desproveito.

### Distribuição

A fonte do efeito determina qual Fio é alterado.

•  equipamento ou método adequado tende a afetar o Tento;

•  condição física ou circunstância corporal tende a afetar o Prumo;

•  Lavores, Vínculos, Tramas e situações especiais especificam seu próprio Fio quando necessário.

Proveito e Desproveito acumulam-se apenas até os limites da escada de dados e se cancelam um pelo outro quando representam modificações opostas sobre o mesmo Fio.

Cada Fio recebe no máximo um deslocamento líquido de Proveito ou Desproveito por teste. Fontes múltiplas no mesmo Fio não acumulam além desse limite; efeitos opostos se cancelam antes da aplicação. Proveito pode coexistir em Prumo e Tento, pois afeta Fios distintos. Proveito ordinário não cria d20; d12→d20 exige autorização extraordinária.

## SEÇÃO 12FORÇAR

Forçar é uma decisão consciente de ultrapassar o limite atual.

Antes de rolar, o jogador pode declarar Forçar para elevar um único Fio em uma categoria. Só pode ocorrer uma vez por teste. O custo é 1 PE para d4→d6, d6→d8, d8→d10 ou d10→d12; d12→d20 custa 2 PE, mas só é permitido mediante autorização transcendente expressa. Um Fio em d20 não pode ser Forçado. Com PE em 0, a personagem pode Forçar uma vez por cena aceitando uma consequência ficcional equivalente em vez do gasto; PE permanece em 0.

A elevação não é Proveito: ela representa capacidade temporariamente puxada além da continuidade normal.

Forçar nunca remove uma consequência por si só.

Na Canalização, Forçar se integra a Puxagem e Refluxo; fora dela, permanece governado pelo custo universal acima. A consequência adicional só existe quando a ficção justificar uma contrapartida excepcional. A passagem d12 → d20 requer permissão transcendente explícita, mesmo quando seu custo em PE é pago.

## Protocolo de precedência ~ modificadores e casos-limite

Para impedir decisões divergentes entre mesas, cada rolagem segue esta ordem, mantendo o Motor inalterado:

1.  Declare Intenção e Abordagem; escolha a Matriz e o Alinhavo coerentes.

2.  Determine permissão ficcional, Posição, DT ou oposição e os Fios-base.

3.  Identifique todas as fontes válidas de Proveito e Desproveito, por Fio; cancele fontes opostas uma a uma. O resultado líquido altera cada Fio em no máximo uma categoria, embora possam existir fontes adicionais.

4.  O jogador decide se vai Forçar um único Fio, antes da rolagem. Forçar é distinto de Proveito: se ambos forem válidos, aplicam-se sucessivamente à mesma escada, respeitando o limite do d12 ordinário. É permitido Forçar um Fio já beneficiado, desde que o gasto seja pago e a ficção justifique o esforço. Nenhum deles, isoladamente, autoriza d20.

5.  Pague PE e custos pré-declarados; role os dados resultantes uma só vez.

6.  Identifique a dupla unidade (1,1) dos dois Fios finais. Ela produz Falha Crítica e prevalece sobre Consonância e sobre qualquer eventual DT de 2; a Matriz usada fica Abalada até o término da cena.

7.  Se não houver dupla unidade, calcule Enlace, compare ao limiar, confira Consonância, margem, Ascendente, Retorno e Desvio conforme a leitura necessária.

8.  Aplique a consequência principal e os efeitos adicionais expressamente autorizados; registre o Resto, a nova Posição e as relações que permanecem.

Proveito não é ação extra; Forçar não é Proveito; Consonância não ignora um limiar não alcançado. Condições com efeitos sobre o mesmo Fio respeitam as mesmas regras de cancelamento e limite, exceto uma especialização que declare claramente o contrário.

Forçar a 0 PE: no máximo uma vez por cena, sem tornar PE negativo; antes de rolar, escolha com o Narrador uma contrapartida verificável, tipicamente Condição Grave relacionada ao esforço ou aumento de 1 na Frente de Pressão apropriada. Não se pode escolher uma contrapartida irrelevante. A contrapartida ocorre mesmo que a rolagem tenha êxito, e não concede passagem transcendente por si só.

Sem rolagens tautológicas: se não há oposição, incerteza relevante nem consequência de falha, a ação é resolvida diretamente. A dupla unidade e os efeitos de falha não podem ser provocados exigindo testes desnecessários.

## O encontro de dois Fios ~ como ler sem burocracia

O Fio de Prumo não indica que a personagem age sozinha, nem o Fio de Tento declara que a situação coopera. A diferença nomeia duas dimensões de uma única intervenção: potência de realização e capacidade de aplicá-la. Os dados são lidos em conjunto para responder ao alcance e separadamente apenas quando a consequência precisa de textura.

### Ficha de decisão do Motor

[0583 TABLE]

Antes de rolar | Durante a rolagem | Depois de rolar

Intenção e abordagem; acesso real; DT ou Defesa | Prumo, Tento, Enlace, dupla unidade | Alcance, Consonância e, se necessário, margem

Qual Fio recebe Proveito ou Desproveito | Ascendente e Retorno já existem nos dados mostrados | Desvio, Abertura/Fresta, Rastro/Devolução quando importarem

Custo de Forçar e consequência declarada | Sem terceiro dado e sem rerrolagem oculta | Uma consequência principal e Restos relevantes

Exemplo — análise do registro. Iria possui Nexo 3 (d10) e Investigação 2 (d8). Ela procura correções num livro de entrada de navios. A DT 10 foi definida antes do teste porque há pressão de tempo e adulteração deliberada. Obtém Prumo 7 e Tento 3: Enlace 10. Ela alcança a intenção, com Ascendente 7, Retorno 3 e Desvio +4. A leitura completa pode sugerir que reconhece a falsificação graças à compreensão ampla, mas seu método deixa um rastro de consulta detectável. O sucesso não exige esse custo: ele só será aplicado se o procedimento de segurança do arquivo e o contexto o justificarem.

Se Iria tivesse rolado 4 e 4, teria Enlace 8: Consonância sem alcance; os dados coincidentes não lhe dariam êxito automático. Se tivesse rolado 5 e 5, Enlace 10 e Consonância produziriam crítico. Se tivesse rolado 1 e 1, a Falha Crítica prevaleceria sobre qualquer DT alcançável e abalaria a Matriz usada, conforme o protocolo específico.

### Nada se soma duas vezes

Uma Abertura pode tornar uma ação posterior plausível, mas não concede automaticamente outro Proveito. Uma resposta defensiva não constitui segunda camada de proteção gratuita. Um Vínculo que permite acessar o arquivo não concede, pelo simples fato de existir, bônus em Investigação. Essas decisões são manifestações da mesma regra de suficiência: a relação permite uma coisa concreta; não cria todas as vantagens imagináveis relacionadas ao seu nome.

## SEÇÃO 13TESTE CONTESTADO

Cada lado forma seu Enlace usando seus próprios dois Fios.

Maior Enlace vence.

Empate preserva a situação anterior, a menos que uma regra específica estabeleça outra resolução.

Depois da comparação, Ascendente, Retorno e Desvio de cada lado podem determinar a forma da vitória, do recuo ou da consequência.

### Consonância e dupla unidade em disputa

Primeiro aplique a Falha Crítica de cada participante. Quem obtém (1,1) não alcança sua intenção, e sua Matriz fica Abalada. Se ambos obtêm (1,1), nenhum vence e a condição anterior permanece, além das consequências críticas de cada lado. Se apenas um obtém (1,1), o outro prevalece quando sua abordagem possui os meios ficcionais necessários.

Fora desse caso, compare os Enlaces. Uma Consonância só concede expressão crítica quando o participante vence a disputa; Consonância em um Enlace menor não derrota o vencedor. Em empate, mantém-se a condição anterior, mesmo que um lado tenha Consonância. A margem de quem prevalece é a diferença entre os Enlaces; ela qualifica a vitória pela escala comum, sem gerar um segundo desempate.

## SEÇÃO 14TESTES PROLONGADOS

Testes prolongados continuam usando o mesmo motor.

A operação possui dois registros:

Progresso ~ aproximação do objetivo.

Pressão ~ custo acumulado de continuar.

Um Enlace que alcança a DT concede Progresso.

A qualidade do resultado, Ascendente/Retorno e Desvio determinam se o progresso é limpo, produz custo ou aumenta Pressão.

Quando a Pressão alcança seu limite, ocorre uma mudança estrutural na operação.

A operação não pede a mesma rolagem repetidamente: cada teste deve alterar uma frente diferente ou responder a uma consequência nova.

### Progresso em operações prolongadas ~ padrão de execução

Quando a operação exigir mais de um êxito, o Narrador anuncia objetivo, número de etapas e Frente de Pressão antes do primeiro teste. Na ausência de escala ficcional mais apropriada, use três etapas distintas de Progresso como referência: acesso, intervenção e estabilização. Cada etapa alcançada concede um avanço verificável; êxito elevado pode resolver uma etapa adicional somente se a ação realmente tiver abrangido as duas. Uma falha não apaga Progresso previamente conquistado.

A Pressão 0–4 continua sendo o único relógio genérico de deterioração. Cada aumento exige evento ficcional; alcançar 4 produz Ruptura previamente descrita. Progresso e Pressão podem coexistir e não são subtraídos um do outro. Repetir idêntica rolagem sem novo elemento situacional não concede novo Progresso.

## SEÇÃO 15CRÍTICO E DESASTRE

O motor não utiliza 20 natural como regra universal de crítico.

Consonância + Enlace bem-sucedido = crítico, exceto a dupla unidade (1 e 1), que constitui Falha Crítica.

Além disso, a v2.0 possui Falha Crítica: quando os dois dados efetivamente rolados, Prumo e Tento, mostram 1, a ação falha e a Matriz usada fica Abalada até o fim da cena. Essa condição acrescenta Desproveito ao Prumo da Matriz afetada; apoio ordinário não apaga o estado Abalado.

A Falha Crítica é verificada imediatamente após a rolagem e pode coexistir com a consequência normal da margem de Enlace. Ela não transforma automaticamente toda falha severa em desastre nem determina morte por si só.

## SEÇÃO 16LEITURA RÁPIDA DO MOTOR

A leitura do Motor possui dois níveis. Em uma ação simples, a mesa não precisa calcular toda a arquitetura a cada rolagem. A resolução básica é:

1. Escolha Matriz + Alinhavo.

2. Role Prumo + Tento.

3. Some para formar o Enlace e compare com a DT.

4. Verifique Consonância e, quando cabível, Falha Crítica.

5. Narre o resultado e leia o Retorno para saber o que a situação devolveu, preservou ou deixou exposto.

A leitura completa é necessária quando o resultado tiver complexidade, consequência relevante ou múltiplas continuidades em jogo. Em cenas simples, a soma, a Consonância e o Retorno normalmente bastam:

Enlace → Ascendente → Retorno → Desvio → Consonância → Resto.

Nesse nível, Ascendente detalha o que avançou ou abriu; Retorno detalha o que voltou; Desvio mostra por qual Fio a repercussão se inclinou; Consonância identifica encontro exato entre os Fios; e o Resto registra o que ficou disponível para persistir.

O Narrador não deve preencher toda a leitura por obrigação. Se uma ação simples só precisa de Enlace e Retorno para ser compreendida, é só isso que a mesa precisa ler.

## SEÇÃO 17EXEMPLO COMPLETO

Uma personagem tenta atravessar um mecanismo industrial em funcionamento usando Cadência + Engenharia.

Seu Fio de Prumo é d12. Seu Fio de Tento é d10.

Resultados:

Prumo 9

Tento 6

Ascendente 9

Retorno 6

Enlace 15

Desvio +3

Contra uma DT 14, a personagem alcança a intenção.

O sucesso é predominantemente sustentado pelo Prumo: há capacidade de execução maior que o domínio do procedimento.

O Narrador não aplica penalidade automática. Em vez disso, escolhe uma consequência coerente caso a cena peça repercussão: o mecanismo é atravessado, mas parte da proteção é deformada; o acesso foi obtido com força e agora o sistema acusa a intervenção.

O resultado não é "9 no dado". É:

Enlace 15 ~ alcançou. Ascendente 9 ~ execução forte. Retorno 6 ~ sustentação razoável. Desvio +3 ~ capacidade física prevaleceu sobre método.

## SEÇÃO 18POSIÇÃO DO MOTOR NA ARQUITETURA DO TDV II

O motor é universal.

Ele alimenta:

Conflitos físicos; Conflitos sociais; Investigação; perseguições; infiltração; Selagem; Canalização; situações ambientais; testes individuais; testes Contestados; testes Conjuntos; operações Prolongadas..

Cada subsistema pode acrescentar interpretação própria, mas não inventa outro método de rolagem sem necessidade.

## SEÇÃO 19RELAÇÃO COM A URDIDURA

O vocabulário do motor deve respeitar a cosmologia existente.

A Urdidura define:

•  Fio como dependência mínima ainda perceptível;

•  Malha como conjunto de Fios que sustenta uma forma;

•  Urdidura como organização profunda que oferece direção e continuidade;

•  Assinatura como padrão particular de organização dos Fios.

A resolução utiliza essas imagens porque cada ação também é uma relação entre capacidade, método e situação. Ela não redefine Fio, Urdidura ou Malha dentro da cosmologia.

### Hierarquia definitiva do Motor

O Motor pode ser lido em sete perguntas:

Fios → como a capacidade encontra a tarefa?Enlace → alcançou?Ascendente → o que avançou?Retorno → o que voltou?Desvio → por onde se inclinou?Consonância → os Fios se encontraram?Resto → o que ficou?Leitura curta usa Enlace + Consonância + Retorno. A leitura completaacrescenta Ascendente, Desvio e Resto quando a situação exigir.

Abertura e Fresta são expressões daquilo que avançou, lidas pelo Ascendente conforme houve ou não alcance. Devolução e Rastros ligados à sustentação da ação podem ser lidos pelo Retorno. Nenhum desses nomes cria um segundo teste nem obriga toda rolagem a produzir todos os movimentos.

PARTE III
