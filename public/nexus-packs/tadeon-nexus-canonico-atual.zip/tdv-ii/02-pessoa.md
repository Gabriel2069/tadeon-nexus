---
title: "TdV II · Pessoa"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "PESSOA", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# PESSOA

FEIÇÃO E CONSTITUIÇÃO

Antes de agir, alguém precisa existir o bastante para ser transformado.

Quem existe na Tessitura, quais continuidades pessoais traz e o que consegue sustentar.

## SEÇÃO 01FEIÇÃO, ÂNCORA, VÍNCULOS E MARCA

A criação não começa por números. Começa pela Feição.

A Feição responde quem esta pessoa é, mas no TdV II seus elementos também precisam funcionar como matéria de jogo. Origem, Ofício, Convicção, Limite, Marca e Vínculos continuam sendo os seis pilares; nenhum deles é reduzido a um simples campo descritivo.

A lógica mecânica da Feição fica dividida em três funções:

•  Âncora preserva continuidade quando a pessoa é ameaçada de deixar de ser quem é;

•  Vínculo cria reciprocidade, acesso, obrigação e pressão através de relações reais;

•  Marca registra uma transformação permanente e faz essa transformação voltar a agir sobre a pessoa.

Essas funções se conectam, mas não se substituem.

### Origem

É o lugar, contexto ou história de onde a pessoa vem. Origem estabelece permissões ficcionais, conhecimentos plausíveis, referências e formas de pertencimento.

Origem não fornece bônus automático. Ela responde principalmente à pergunta: "Que coisas esta pessoa reconhece, entende ou consegue acessar por já ter vindo de onde veio?"

### Ofício

É aquilo que a pessoa aprendeu a fazer de forma recorrente e socialmente reconhecível.

Ofício pode justificar abordagens, permissões e uso de Alinhavos, mas não substitui o dado quando existe risco real.

### Convicção

É aquilo que o personagem preserva mesmo quando a situação pressiona outras partes de sua Feição.

Uma Convicção pode orientar escolhas, estabelecer o que conta como consequência significativa e criar condições para Ancorar. Ela não funciona como uma Defesa mental genérica.

### Limite

É a fronteira que define algo que não pode ser atravessado sem transformação.

O Limite não é uma fraqueza numérica. Ele estabelece uma consequência qualitativa quando a pessoa age contra aquilo que declarou não poder atravessar.

### Marca

A Marca é uma transformação fundamental que passa a integrar a Feição. Pode nascer de uma ruptura, de contato anormal com a realidade ou de um acontecimento decisivo da vida comum, quando deixa Gatilho, Manifestação e Resíduo identificáveis. Não é necessário ter encontrado o Além-Véu para possuir uma Marca.

A Marca é permanente, mas não precisa estar sempre ativa. Ela possui uma forma de entrada (Gatilho), uma forma visível ou funcional (Manifestação) e uma permanência que continua existindo mesmo depois que a manifestação passa (Resíduo).

A Marca deve sempre responder:

1.  O que acende isto? ~ Gatilho;

2.  O que acontece quando acende? ~ Manifestação;

3.  O que fica depois? ~ Resíduo.

#### Funcionamento mecânico da Marca

Quando o Gatilho acontece, a Marca entra em Manifestação. A Manifestação não é um modificador universal: ela altera uma decisão, uma consequência, uma relação, um procedimento ou um elemento da ficção especificado na própria Marca.

Enquanto estiver Manifestada, ela pode:

•  impor Desproveito ao Fio pertinente quando a ação enfrenta uma limitação expressamente descrita pela Marca; produzir uma consequência própria no seu Gatilho; ou abrir uma abordagem específica. Cada efeito deve estar delimitado na descrição da Marca.

•  transformar uma consequência em algo específico da Marca.

O jogador pode acolher a Marca em uma ação diretamente relacionada a ela. Quando isso fizer sentido ficcional, a Manifestação pode justificar Proveito na abordagem em vez de apenas funcionar como obstáculo. O ganho não apaga o Gatilho nem o Resíduo.

Isso faz da Marca uma transformação jogável: ela pode ferir, revelar, abrir caminho e cobrar preço.

#### Resíduo

O Resíduo permanece depois que a Manifestação cessa. Ele não é um ponto ou contador. É uma alteração duradoura da Feição, do corpo, da percepção, de uma relação ou da forma como o mundo responde ao personagem.

Um Resíduo relevante pode ser usado pelo Narrador para criar novas situações, e pelo jogador para justificar abordagens que não existiriam antes da Marca.

Marca da Morte e Marca da Loucura são casos específicos e não substituem a Marca comum. Suas regras próprias são apresentadas na seção Morte e Colapso deste livro.

### Vínculos

São relações ativas, com história, reciprocidade e estado. O Vínculo nunca é simplesmente uma barra de afeição nem um bônus social genérico.

Cada Vínculo relevante possui:

•  Nó ~ quem ou o que está envolvido;

•  Natureza ~ confiança, proteção, dependência, rivalidade, respeito, dívida, admiração, obrigação etc.;

•  Estado ~ Presente, Tensionado, Ferido, Rompido ou Costurado;

•  Oferta ~ o que esta relação torna possível para o personagem;

•  Cobrança ~ o que esta relação pode legitimamente exigir do personagem;

•  Condição de tensão ~ aquilo que costuma pressionar ou ameaçar o Vínculo.

Vínculo não possui "nível" universal. O estado e o conteúdo importam mais do que um número.

### Âncora

A Âncora não é um sétimo elemento da Feição. É um dos seis elementos já existentes, escolhido pelo jogador, que representa aquilo ao qual a pessoa consegue retornar quando sua continuidade está em risco.

A ficha marca apenas um elemento como Âncora, salvo uma regra extraordinária que diga o contrário.

Uma Âncora pode ser Origem, Ofício, Convicção, Limite, Marca ou Vínculo.

A pergunta da Âncora é:

"Quando algo ameaça me desfazer, a que parte de mim eu consigo voltar?"

A escolha precisa produzir conteúdo concreto. "Minha personalidade" é amplo demais; "a promessa que fiz à minha irmã", "o ofício que aprendi com meu avô" ou "a Marca que carrego" são Âncoras jogáveis.

## SEÇÃO 02MECÂNICAS DE VÍNCULO E ANCORAR

### Uso ativo de Vínculos

Todo Vínculo pode agir no jogo por três vias distintas. Elas não são poderes separados nem exigem novos recursos.

#### Abrir

O personagem usa a existência do Vínculo para obter acesso, permissão, informação ou oportunidade que a relação realmente poderia fornecer.

Quando a relação por si só resolve a barreira, nenhum teste é necessário. Quando existe risco, oposição ou pressão, a relação apenas torna a abordagem possível e o teste segue o motor normal.

#### Sustentar

Quando um Vínculo participa diretamente da ação ~ alguém ajuda, protege, fornece contexto, assume risco ou oferece uma vantagem real ~ o jogador pode aplicar Proveito ao Fio que efetivamente recebeu essa sustentação.

Não existe "bônus de amizade". O Proveito nasce de uma participação concreta do Vínculo na situação.

#### Cobrar

O personagem pode exigir do Vínculo algo que a relação dê motivo legítimo para exigir. Cobrar nunca é gratuito: o atendimento fortalece a expectativa de reciprocidade, enquanto a recusa, atraso ou abuso pode alterar o Estado do Vínculo.

Cobrar não é um encantamento. O resultado depende do que existe na relação e do que foi colocado em jogo.

### Estado dos Vínculos

O Estado representa a condição atual da relação:

Presente → a relação funciona normalmente.

Tensionado → existe atrito, dúvida ou custo que ainda não rompeu a relação.

Ferido → algo importante foi quebrado; a relação ainda existe, mas não pode ser usada como se nada tivesse acontecido.

Rompido → a relação deixou de oferecer o funcionamento normal e passa a agir principalmente como fonte de ausência, oposição, dívida ou consequência.

Costurado → uma relação rompida encontrou uma nova forma de continuidade. Costurado não significa "voltou ao normal": significa que existe uma nova configuração consciente da relação.

Mudanças de Estado devem ser consequências da ficção. O Narrador não deve mover um Vínculo apenas para punir uma falha de rolagem; a cena precisa explicar o que mudou entre os envolvidos.

### Ancorar

Ancorar é a resposta pela qual o personagem impede que uma consequência destrua imediatamente a continuidade de sua Feição.

Ancorar só pode ser usado quando:

1.  uma consequência atingiria de maneira relevante a Feição, a continuidade física/mental ou uma relação essencial;

2.  a Âncora escolhida realmente poderia responder àquela ameaça;

3.  o jogador consegue dizer como aquela parte da Feição sustenta seu retorno.

Ao Ancorar, o jogador não apaga a consequência. Ele muda a forma como ela atravessa a pessoa.

Escolha uma das duas formas:

#### Sustentar

A consequência é reduzida para uma forma menor, porém permanece na cena.

Exemplos:

•  uma perda total de Ponto de Inteireza vira abalo significativo

•  uma consequência que romperia um Vínculo passa a Tensioná-lo

•  uma perda de posição vira exposição ou deslocamento menor

•  uma consequência física incapacitante vira desgaste grave, sem eliminar o restante da ficção.

A redução deve preservar o sentido do que aconteceu.

#### Redirecionar

A consequência deixa de atingir o alvo inicialmente ameaçado e passa a atingir outro alvo plausível, escolhido em conjunto com o Narrador, que tenha relação direta com a Âncora.

Exemplos:

•  uma consequência que atingiria a identidade passa a atingir a relação que a sustenta

•  uma consequência que atingiria um Vínculo passa a atingir posição, equipamento ou Ponto de Esforço

•  uma consequência que atingiria o corpo passa a gerar exposição, dívida ou perda de oportunidade, quando a ficção permitir.

Redirecionar nunca pode produzir uma consequência menor simplesmente por conveniência. A nova forma precisa continuar tendo peso narrativo comparável.

### Estado da Âncora

Depois de Ancorar, a Âncora fica Abalada.

Uma Âncora Abalada continua existindo na Feição, mas não pode ser usada novamente para Ancorar até ser Reassentada pela ficção.

Reassentar exige uma ação significativa coerente com a própria Âncora, como:

•  cumprir ou reafirmar uma Convicção

•  retornar à Origem

•  retomar um Ofício ou prática fundamental

•  confrontar o próprio Limite

•  integrar a própria Marca

•  restaurar, redefinir ou assumir um Vínculo.

Reassentar não exige um ritual universal nem um teste automático. O momento em que a história realmente demonstra retorno é o que reativa a Âncora.

Isso substitui a função dos antigos PA sem criar um novo recurso numérico.

### Âncora e Vínculo

Quando o elemento escolhido como Âncora é um Vínculo, Ancorar coloca a relação diretamente no centro da consequência. A relação pode ser preservada, mas também pode ser Tensionada, Ferida ou até assumir uma nova forma de continuidade.

Quando a Âncora é outra parte da Feição, Vínculos podem ser usados para sustentá-la ou sofrer o preço do Redirecionar.

Assim, Ancorar não protege relacionamentos automaticamente; ele obriga a ficção a mostrar o que a pessoa está fazendo para continuar sendo quem é.

### Relação entre os três mecanismos

A tríade de Feição fica:

Vínculo cria continuidade com o outro.

Âncora preserva continuidade consigo.

Marca registra a transformação que a continuidade sofreu.

Um mesmo acontecimento pode atravessar os três sem criar regras duplicadas:

ação → consequência → Vínculo é pressionado → Ancorar preserva algo essencial → Marca ou Resíduo registra o que mudou.

## SEÇÃO 03CONSTITUIÇÃO ~ RECURSOS E DEFESAS

A Constituição responde: "Do que esta pessoa é capaz de sustentar, suportar e fazer quando a situação aperta?"

Ela contém Matrizes, Alinhavos, Recursos, Defesas e Guarda. Cada camada responde a uma pergunta diferente:

•  Matrizes medem capacidade ampla;

•  Alinhavos medem prática aplicável;

•  Recursos medem continuidade disponível;

•  Defesas medem o quanto é difícil deslocar o personagem de um estado para outro;

•  Guarda mede a proteção imediata contra agressão física.

Nenhuma dessas camadas deve duplicar a função de outra.

### Matrizes ~ função e limite

As quatro Matrizes estão consolidadas: Ímpeto, Cadência, Nexo e Lastro.

Cada Matriz possui uma região de competência principal e um limite ficcional. O valor alto não concede autorização para qualquer abordagem; ele apenas indica capacidade potencial.

#### Ímpeto

Força aplicada, resistência corporal, sustentação de esforço, impacto e imposição física.

Ímpeto responde: "Quanto meu corpo consegue sustentar, mover ou impor?"

Limite: não substitui técnica. Um personagem pode ter Ímpeto alto e falhar em Luta, Atletismo ou qualquer aplicação que dependa de prática.

#### Cadência

Coordenação, velocidade, reflexo, precisão, equilíbrio e adaptação motora.

Cadência responde: "Com que precisão e velocidade consigo acompanhar a mudança?"

Limite: não cria conhecimento, treinamento social nem percepção sobrenatural por si só.

#### Nexo

Percepção, memória, raciocínio, leitura de padrões, julgamento e compreensão.

Nexo responde: "Quanto consigo perceber, relacionar e compreender?"

Limite: não substitui informação ausente nem garante competência prática. Saber o que deve ser feito e conseguir executar são coisas diferentes.

#### Lastro

Vontade, identidade, presença, influência, firmeza relacional e capacidade de sustentar a própria posição diante de outras pessoas ou pressões.

Lastro responde: "Quanto de mim continua presente quando algo tenta me deslocar?"

Limite: não torna o personagem automaticamente imune a medo, manipulação ou conflito social; ele define capacidade de sustentar-se neles.

#### Regra de interpretação

Quando duas Matrizes poderiam parecer válidas, escolhe-se a que representa o centro da ação, não a que possui o maior dado. A abordagem declarada pelo jogador vem antes da otimização mecânica.

Uma mesma ficção pode usar Matrizes diferentes conforme a intenção mude. Isso não é incoerência: é mudança real de abordagem.

### Alinhavos ~ lista e redundâncias

Alinhavos são competências aplicáveis. Permanecem como uma única lista, sem famílias mecânicas, bônus por grupo ou identidade de classe.

Lista consolidada (colunas apenas para consulta):

[0289 TABLE]

Alinhavo | Alinhavo

Atletismo | Luta

Pontaria | Furtividade

Engenharia | Ciências

Medicina | Ofício

Percepção | Sobrevivência

Investigação | Condução

Diplomacia | Persuasão

Intimidação | Encenação

Sociedade | Tática

Iniciativa | Canalização

Selagem | 

#### Ofício da Feição × Ofício do Alinhavo

Os dois usos da palavra Ofício não são a mesma coisa:

•  Ofício (Feição) é identidade profissional, origem social e relação com aquilo que a pessoa faz;

•  Ofício (Alinhavo) é competência operacional para produzir, reparar, adaptar ou operar um trabalho especializado.

O primeiro gera principalmente permissão ficcional e contexto; o segundo resolve risco de execução.

#### Perícias defensivas removidas como Alinhavos

Os antigos campos Fortitude, Reflexo, Temperança e Concentração não retornam como Alinhavos separados. Suas funções ficam distribuídas:

[0297 TABLE]

Antiga competência | Destino no TdV II

Fortitude | Ímpeto + Vitalidade + Defesas físicas

Reflexo | Cadência + Guarda + Posição

Temperança | Lastro + Ponto de Inteireza

Concentração | Nexo/Lastro + Ponto de Inteireza + situação

Iniciativa é a exceção deliberada. Ela retorna como Alinhavo porque sua função não é uma Defesa nem uma capacidade passiva: ela representa a competência de perceber, assumir ou explorar a prioridade de agir quando a ordem não está definida pela ficção.

#### Regra de competência

Alinhavo 0 significa experiência comum, não incompetência. Quando uma ação exige conhecimento ou prática que o personagem não possui, a ficção pode negar uma abordagem, exigir ajuda, equipamento ou aprendizado. O d4 não transforma desconhecimento em competência fictícia.

### Recursos

Os recursos representam continuidade disponível, não "poder mágico genérico".

#### Ponto de Vitalidade

Ponto de Vitalidade mede quanto de continuidade física imediata o corpo ainda consegue sustentar. Ele não mede qualidade de vida, dor ou importância narrativa isoladamente.

Base consolidada:

Ponto de Vitalidade máximo = 6 + (Ímpeto × 2)

Equipamentos, efeitos extraordinários e regras específicas podem alterar esse valor; não existe bônus genérico por possuir determinada profissão.

A perda de Ponto de Vitalidade deve produzir consequências ficcionais coerentes. Dano não é automaticamente "perda de pontos e nada mais": quando o golpe muda posição, causa sangramento, quebra equipamento ou cria exposição, essa consequência pode aparecer junto.

#### Ponto de Inteireza

Ponto de Inteireza mede a capacidade de manter uma percepção, memória, corpo e identidade suficientemente coerentes para continuar funcionando como a mesma pessoa.

Base consolidada:

Ponto de Inteireza máximo = 6 + Nexo + Lastro

Ponto de Inteireza não é simplesmente "sanidade mental". Ele também pode ser pressionado por contradição de memória, contato paranormal, ruptura identitária, manipulação, excesso de tensão ou situações em que a pessoa deixa de reconhecer a própria continuidade.

Quando o Ponto de Inteireza chega ao limite crítico definido pelo conflito, aplica-se a regra de Colapso; a consequência permanente deve atravessar a Feição e pode criar ou alterar uma Marca.

#### Ponto de Esforço

Ponto de Esforço mede o esforço que a pessoa ainda consegue converter em ação extraordinária: Canalização, Lavores exigentes, Forçar e outras práticas que ultrapassam a execução ordinária.

Base consolidada:

Ponto de Esforço máximo = 5 + Nexo + Lastro

Ponto de Esforço não é "combustível para toda ação". A ação comum deve continuar existindo sem gastar Ponto de Esforço. Ela é usada quando o personagem força a própria capacidade, sustenta algo extraordinário ou utiliza uma regra que explicitamente a consome.

#### Recuperação de recursos

A recuperação é uma transformação da capacidade de sustentação e depende do tempo, segurança, cuidado e continuidade disponíveis.

•  Pausa breve: PE +2, PI +1 e PV +0. Com cuidado corporal adequado, PV também recupera +2.

•  Repouso profundo: PE retorna ao máximo; PI recupera +3; PV recupera +5 com cuidado ou +2 sem cuidado especializado.

•  Recuperação plena: PE e PV retornam ao máximo. PI só retorna ao máximo quando houve reconstrução real da continuidade comprometida.

Esses valores são canônicos. A ficção determina se as condições necessárias para cada profundidade realmente existem.

### Janela de recuperação e prevenção de exploração

Pausa breve exige uma interrupção real da pressão imediata, normalmente alguns minutos de segurança, água, cuidado ou recomposição. Repouso profundo exige um ciclo de descanso protegido, normalmente uma noite, e não pode ser repetido indefinidamente dentro da mesma continuidade de cena. Recuperação plena exige condições prolongadas de restabelecimento e, para PI, a reconstrução ficcional da continuidade atingida.

Uma nova Pausa breve só produz novamente os valores previstos quando o grupo percorreu outra sequência significativa de risco ou esforço. Ficar repetindo o mesmo intervalo sem novos acontecimentos não multiplica PV, PI ou PE. Nenhuma recuperação ultrapassa o máximo; nenhum repouso apaga uma Marca, Âncora Abalada ou Condição sem enfrentar sua causa.

### Defesas

Defesas são limiares estáticos que representam a dificuldade de deslocar o personagem de seu estado atual. Elas não substituem os dois Fios; elas são um alvo para o Enlace adversário.

A função das Defesas é eliminar testes redundantes de reação sem apagar a capacidade de escolher respostas.

#### Quatro Defesas derivadas

Resistência ~ capacidade de suportar força, impacto, dor, exaustão e agressão corporal que não dependa de Guarda. Derivação: 6 + (Ímpeto × 2).

Evasão ~ capacidade de sair da linha de efeito, acompanhar ameaças e evitar ser alcançado quando não está protegido por Guarda. Derivação: 6 + (Cadência × 2).

Lucidez ~ capacidade de perceber, interpretar e manter continuidade cognitiva diante de confusão, influência e fenômenos anômalos. Derivação: 6 + Nexo + Lastro.

Firmeza ~ capacidade de sustentar posição, vontade, identidade e relações diante de pressão social ou emocional. Derivação: 6 + Lastro + Nexo.

As fórmulas desta seção são as referências normativas da v2.0. Sua coerência aritmética é verificável; seu desempenho em campanhas depende de testes de mesa. Uma errata deve explicitar a evidência, o valor alterado e os efeitos esperados, preservando as funções distintas das Defesas.

#### Como uma Defesa é usada

Quando uma ameaça já tem um alvo defensivo claro, o atacante realiza seu teste normal e compara o Enlace à Defesa pertinente.

•  Enlace abaixo da Defesa: a ameaça não desloca o estado protegido;

•  Enlace igual ou acima: a ameaça alcança a camada protegida e produz sua consequência.

Ascendente, Retorno e Desvio continuam qualificando como isso acontece. Uma Defesa alta não elimina consequências ficcionais de uma falha do atacante nem impede que uma abordagem inadequada tenha outro custo.

### Guarda

Guarda permanece separada das demais Defesas porque representa uma situação concreta de proteção imediata: postura, cobertura, distância, escudo, abrigo, prontidão ou posição corporal.

Guarda não é "mais uma defesa de atributo". É um estado de proteção que pode mudar dentro da cena.

Base consolidada:

Guarda = 6 + (Cadência × 2)

Ela recebe modificações da situação:

•  cobertura e abrigo podem elevar Guarda;

•  exposição, desequilíbrio ou perda de posição podem reduzir Guarda;

•  equipamento defensivo pode criar uma alteração específica;

•  algumas armas ou efeitos atacam Guarda antes de Vitalidade.

A Guarda pode ser alterada, quebrada, recuperada ou transferida durante um Conflito. Isso faz dela uma peça de posição, não apenas um número de ficha.

#### Guarda quebrada

Quando uma ação atinge ou supera Guarda com consequência suficiente para deslocar a proteção, a Guarda pode ser reduzida, rompida ou removida temporariamente. A decisão depende da abordagem e da consequência, não de um crítico automático.

Quando a proteção deixa de existir, o próximo ataque pode atingir diretamente a Defesa ou recurso pertinente.

### Constituição em uma frase

Matrizes dizem do que você é capaz; Alinhavos dizem o que você sabe fazer; Recursos dizem quanto de você ainda sustenta isso; Defesas dizem quão difícil é deslocá-lo; Guarda diz quão protegido você está agora.

## O que torna a Feição jogável

A Feição não deve servir de formulário extenso preenchido e esquecido. Cada pilar precisa ter pelo menos uma possibilidade de participação na campanha, sem prometer bônus automáticos. Ao concluir a criação, o jogador pode escrever uma frase começando por “por causa disso, eu consigo…” e outra começando por “se isto for pressionado, posso perder…”. As respostas servem ao Narrador na preparação de cenas e ao jogador na escolha de abordagens.

Exemplo — Iria. Origem: cresceu perto dos armazéns. Ofício: registradora. Convicção: não permite que uma história seja apagada para proteger uma autoridade. Limite: não entregará uma testemunha inocente. Marca: escuta a repetição de uma frase em lugares onde registros foram alterados. Vínculo: Elen, a pessoa que ainda acredita em sua investigação. A Âncora escolhida é a Convicção, concretizada no compromisso de preservar o testemunho dos ausentes.

Esse conjunto tem consequências operacionais claras. A Origem torna plausível reconhecer rotinas de cais; o Ofício permite acesso a documentos e interpretações; o Limite estabelece um preço se ela decidir comprometer uma testemunha; a Marca pode alterar a abordagem quando seu Gatilho estiver presente; o Vínculo cria apoio e cobrança; a Âncora permite transformar uma consequência realmente identitária, mas pode ficar Abalada. Nada disso substitui sua Matriz ou Alinhavo quando a ação exigir rolagem.

### Ficha de Feição ~ perguntas de uso imediato

[0364 TABLE]

Pilar | Pergunta à pessoa | Pergunta ao Narrador

Origem | O que aprendi a reconhecer antes de ser capaz de explicar? | Que acesso ou contexto é plausível?

Ofício | O que meus gestos sabem fazer por repetição? | Que prática exige Alinhavo?

Convicção | Que ideia continuo protegendo quando custa algo? | Que consequência é significativa?

Limite | Qual passagem mudaria quem sou se eu a atravessasse? | Que preço seria coerente?

Marca | Que gatilho a desperta, o que altera e o que sobra? | Qual relação particular ela toca?

Vínculo | Quem também é afetado pelo que eu decido? | O que essa relação abre, sustenta ou cobra?

Exemplo de Ancorar. Se Iria for obrigada a negar o que descobriu, sua Âncora pode Sustentar sua identidade, convertendo uma ruptura pessoal em abalo com custo real; ou Redirecionar parte do preço ao vínculo com Elen, quando a ficção justificar essa transferência. Em ambos os casos, sua Âncora ficará Abalada. A cena não autoriza ignorar uma perda apenas porque a promessa parece importante.

## Criação completa de personagem ~ procedimento oficial

Uma personagem inicial nasce do seguinte procedimento, nesta ordem. Esta normalização preserva a distribuição e os valores de referência da v2.0, mas permite escolhas reais entre perfis.

1.  Feição: registre Origem, Ofício, Convicção, Limite e pelo menos um Vínculo relevante. Descreva a Marca por Gatilho, Manifestação e Resíduo quando já existir uma transformação que a justifique. Uma personagem ainda sem Marca registra “não manifestada”; esse pilar permanece disponível, sem efeito, passado sobrenatural presumido ou benefício latente. A primeira transformação adequada poderá preenchê-lo durante a campanha. Escolha um dos pilares concretamente estabelecidos como Âncora e explique sua forma de retorno.

2.  Matrizes: distribua os valores 3, 3, 2 e 2 entre Ímpeto, Cadência, Nexo e Lastro. A distribuição de referência do relatório é Ímpeto 2, Cadência 3, Nexo 3 e Lastro 2; ela é um exemplo, não um molde obrigatório.

3.  Alinhavos: escolha dois para começar em grau 2 (d8) e quatro em grau 1 (d6). Os demais começam em grau 0 (d4). A indicação histórica de “quatro Alinhavos d4” não cria uma faixa distinta: todos os Alinhavos não selecionados já começam em grau 0 (d4). O jogador pode, se desejar, destacar até quatro como familiaridades de Feição sem qualquer efeito mecânico; isso serve apenas ao retrato da formação da personagem.

4.  Recursos: calcule PV = 6 + 2 × Ímpeto; PI = 6 + Nexo + Lastro; PE = 5 + Nexo + Lastro.

5.  Limiar de defesa: Resistência = 6 + 2 × Ímpeto; Evasão e Guarda-base = 6 + 2 × Cadência; Lucidez e Firmeza = 6 + Nexo + Lastro.

6.  Equipamento e Lavores: a equipe define o equipamento plausível pela Origem, Ofício e premissa da campanha. Os Lavores iniciais não são presumidos gratuitos pela matemática do pacote; qualquer concessão inicial de Lavor deve ser declarada pelo cenário e igualmente oferecida ao grupo, sem consumir retroativamente os 40 PU de Desenvolvimento.

7.  Vínculos de grupo: estabeleça pelo menos uma razão concreta para a personagem se implicar na primeira situação, mesmo que não conheça os demais personagens.

8.  Revisão de capacidade: confira as permissões ficcionais, as Condições iniciais, os recursos no máximo e uma hipótese de como cada Pilar poderá entrar em jogo.

Criação rápida de exemplo: Ímpeto 2 (d8), Cadência 3 (d10), Nexo 3 (d10), Lastro 2 (d8); Engenharia e Investigação d8; Atletismo, Percepção, Sociedade e Iniciativa d6; todos os demais d4. PV 10, PI 11, PE 10; Resistência 10, Evasão 12, Guarda-base 12, Lucidez 11 e Firmeza 11.

Escolha versus equipamento: possuir uma arma ou ferramenta não substitui sua competência; equipamento torna a abordagem plausível ou manifesta propriedade própria. O Narrador não exige um teste onde a capacidade, o acesso e o tempo já bastem.

Distribuição personalizada: valores além do pacote 3, 3, 2, 2 pertencem a uma premissa especial explicitada na preparação e não são tratados como regra-padrão da criação.

PARTE II
