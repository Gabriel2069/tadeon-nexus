---
title: "TdV II · Mundo"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "MUNDO", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# MUNDO

NPCs, AMEAÇAS E BALANCEAMENTO

A oposição possui uma continuidade que pode ser enfrentada.

Como dar estrutura ao que participa da Tessitura sem criar um sistema separado.

## SEÇÃO 01NPCs E AMEAÇAS

O mundo usa a mesma linguagem do personagem, mas não precisa reproduzir sua ficha inteira. A regra central é:

Quanto menos uma presença importa para as decisões da mesa, menos estado precisa ser registrado. Quanto mais ela altera o Conflito, mais estrutura recebe.

Isso produz três escalas de presença: Figurante, Adversário e Ameaça. Elas não são classes de criatura nem categorias de poder. São diferentes quantidades de estado que o Narrador precisa acompanhar.

### Figurante

Um Figurante existe para cumprir uma função imediata na ficção. Ele não precisa de ficha completa.

Registre apenas:

•  Intenção ~ o que procura fazer agora;

•  Capacidade relevante ~ aquilo em que consegue interferir de modo significativo;

•  Consequência típica ~ o que muda se sua intervenção alcançar o objetivo.

O Figurante não recebe valores que a cena não utilizará. Quando uma ação sua não disputa algo relevante, ela é resolvida diretamente pela ficção. Quando passa a disputar uma consequência importante, usa o motor de dois Fios com os dados que sua capacidade realmente sustenta.

Um Figurante pode tornar-se Adversário se começar a retornar, disputar decisões recorrentes ou acumular estado próprio.

### Adversário

Adversário é uma presença individual ou coletiva que pode ser enfrentada repetidamente, mas ainda não precisa de uma arquitetura própria de cena.

Sua ficha compacta registra somente:

•  Identidade;

•  Matriz(es) dominante(s) necessárias às suas intervenções;

•  Alinhavo(s) relevante(s) ou capacidade equivalente;

•  Defesas relevantes;

•  Guarda, quando existir proteção imediata;

•  Recursos, apenas quando o desgaste deles for importante;

•  Modo de agir;

•  Consequências características;

•  Lavor(es), quando houver capacidade excepcional;

•  Costura(s), quando combinações produzirem expressões próprias.

O Adversário continua sendo executado pelo mesmo motor dos personagens. O Narrador não precisa preencher as quatro Matrizes, todos os Alinhavos ou todos os Recursos se eles não entrarem em jogo.

#### Estado mínimo do Adversário

Um Adversário só precisa manter estado quando esse estado muda o que pode acontecer. O estado relevante pode ser:

•  Posição;

•  Guarda;

•  Condição;

•  Recurso;

•  Vínculo ou relação com alguém da cena;

•  Pressão que esteja produzindo ou sofrendo;

•  equipamento ou suporte significativo.

Se nada disso importa para a cena, não há motivo para registrar.

### Ameaça

Ameaça é uma presença cuja atuação pode alterar a estrutura do Conflito, e não apenas vencer uma troca individual.

Pode ser:

•  criatura;

•  fenômeno;

•  instituição;

•  grupo organizado;

•  ambiente;

•  antagonista central;

•  manifestação paranormal;

•  lugar que age como força ativa;

•  sistema, desastre ou processo que continua produzindo consequências.

A Ameaça não precisa ser "mais forte" que um personagem em todos os sentidos. Sua característica é possuir alcance estrutural: se ignorada, ela modifica objetivos, Posição, Pressão, relações ou condições de encerramento do Conflito.

### Ficha compacta de Ameaça

Toda Ameaça relevante pode ser descrita por sete elementos centrais:

1.  Identidade ~ o que ela é e o que a distingue;

2.  Magnitude ~ a escala de presença que consegue exercer;

3.  Intenção ~ o que tenta produzir;

4.  Ação característica ~ como altera a situação;

5.  Defesa ~ que limiar precisa ser superado para deslocá-la;

6.  Consequência ~ o que acontece quando alcança sua intenção;

7.  Dependência/vulnerabilidade ~ o que permite à presença continuar agindo e como pode ser alterado. Registre separadamente uma Costura de capacidades quando houver combinação funcional relevante.

Podem ser acrescentados, quando realmente utilizados:

•  Ponto de Vitalidade;

•  Ponto de Inteireza;

•  Ponto de Esforço;

•  Guarda;

•  Posição;

•  Pressão;

•  Condições;

•  Lavor(es);

•  Fragmentos;

•  equipamentos;

•  Vínculos;

•  Reputações;

•  vulnerabilidades específicas.

A ficha não é uma lista obrigatória. Ela é um recorte do estado que a mesa precisa lembrar.

### Magnitude

Magnitude mede quanto uma presença consegue alterar da estrutura da situação. Ela não é nível, bônus universal, quantidade de dados ou sinônimo de dano.

[2170 TABLE]

Magnitude | Escala | Pergunta de preparação

0 | Local | O que a presença altera diretamente numa pessoa, objeto ou pequena situação?

1 | Confronto | Como disputa uma intervenção individual?

2 | Frente | Que frente inteira de Conflito consegue sustentar ou pressionar?

3 | Cena | Como sua presença reorganiza uma cena inteira?

4 | Estrutural | Que parte do próprio Conflito ou da região consegue transformar?

Magnitude responde escala de consequência, não "quem ganha a rolagem".

#### Magnitude não é um bônus

Uma Ameaça de Magnitude 4 não recebe automaticamente +4 no Enlace. Um personagem pode superar uma intervenção específica de uma Ameaça de Magnitude maior quando sua abordagem, Posição e ficção permitem.

O que permanece maior é a escala daquilo que precisa ser resolvido.

Exemplo: uma personagem pode impedir que uma Ameaça de Magnitude 4 atravesse uma porta nesta intervenção. Isso não significa que ela eliminou o fenômeno que continua afetando toda a região.

#### Magnitude e estado

Quanto maior a Magnitude, maior tende a ser a quantidade de situação que precisa ser alterada antes que a Ameaça possa ser considerada realmente contida. Isso não exige uma barra universal.

Uma Ameaça de Magnitude 3 pode ser vencida por:

•  remover sua fonte;

•  cortar sua frente de atuação;

•  selar um Ponto de Costura essencial;

•  atingir seu objetivo antes que ela o faça;

•  mudar a estrutura do Conflito;

•  ou produzir uma transformação equivalente.

A Magnitude indica a escala do problema; o Objetivo do Conflito determina o que significa vencê-lo.

### Ameaça e motor de dois Fios

Ameaças relevantes usam o mesmo motor:

Fio de Prumo + Fio de Tento → Ascendente + Retorno → Enlace → Desvio → Consonância.

O Prumo representa a capacidade que sustenta a intervenção. O Tento representa o modo pelo qual a Ameaça aplica essa capacidade.

O Narrador pode registrar os dados apenas para as intervenções relevantes. Uma criatura que atua por emboscada, por exemplo, pode ter uma combinação para esse comportamento sem precisar de uma ficha humana completa.

Quando uma capacidade não cabe adequadamente em um Alinhavo, ela pode ser registrada como Lavor. O Lavor continua obedecendo à mesma filosofia dos personagens: cria uma possibilidade específica em vez de apenas acrescentar um número.

### Modo de agir

O Modo de agir é a inteligência operacional da Ameaça. Ele evita que o Narrador precise decorar uma lista de "ataques".

Deve responder:

1.  Prioridade ~ o que ela tenta alterar primeiro;

2.  Resistência ~ o que faz quando sua primeira abordagem encontra oposição;

3.  Posição desejada ~ onde quer estar em relação ao objetivo e aos participantes;

4.  Pressão produzida ~ qual deterioração tende a provocar;

5.  Consequência preferida ~ que tipo de mudança procura deixar;

6.  Recuo ou mudança ~ quando troca de frente, abandona uma abordagem ou muda de objetivo.

A Ameaça, portanto, não precisa agir de maneira ótima. Ela precisa agir de maneira coerente com o que é.

### Consequências características

Cada Ameaça deve possuir um repertório curto de consequências que expressem sua natureza.

Elas podem atingir:

•  Ponto de Vitalidade;

•  Ponto de Inteireza;

•  Ponto de Esforço;

•  Guarda;

•  Posição;

•  Condições;

•  Vínculos;

•  Reputação;

•  equipamento;

•  informação;

•  Pressão;

•  Compasso de Urgência;

•  objetivo;

•  ou a própria estrutura do Conflito.

A consequência não precisa ser um valor fixo. Ela responde:

"Se esta presença conseguir o que quer, o que ficará diferente?"

Duas Ameaças que causam a mesma perda de Vitalidade podem produzir experiências completamente diferentes se uma desloca, outra contamina, outra expõe e outra rompe relações.

### Costura

Costura é a combinação funcional entre duas ou mais capacidades que produz uma expressão nova.

Ela é diferente de simplesmente possuir duas habilidades.

Uma Costura existe quando:

•  há componentes distintos;

•  uma condição ou gatilho faz a relação entre eles importar;

•  surge uma expressão que não seria obtida por apenas um componente;

•  existe preço, limite ou risco, quando necessário.

#### Estrutura

1.  Componentes ~ o que está sendo combinado;

2.  Gatilho/condição ~ quando a relação se ativa;

3.  Expressão ~ o que passa a ser possível;

4.  Preço/limite/risco ~ o que impede a Costura de ser uma solução universal.

#### Exemplo

Uma criatura consegue atravessar superfícies e uma manifestação consegue apagar fontes de luz. Separadamente, são duas capacidades. A Costura determina que, quando a luz cai, o deslocamento da criatura também altera a Posição de todos que dependem daquela iluminação.

A Costura não dá "+2". Ela cria uma nova situação.

### Costura e Malha

A palavra Costura conserva o mesmo princípio de combinação funcional em duas aplicações:

•  na Malha, Costura é a combinação de práticas de um personagem;

•  em uma Ameaça, Costura é a combinação de capacidades que define uma expressão própria.

Em ambos os casos, o princípio é o mesmo: a relação entre componentes cria algo que não estava contido isoladamente em nenhum deles.

Nenhuma das duas Costuras fornece bônus numérico automático.

### Ameaças compostas

Várias entidades podem ser tratadas como uma única Ameaça quando funcionam como uma presença coletiva real.

Isso é apropriado quando:

•  compartilham uma intenção;

•  dependem umas das outras;

•  suas consequências são coordenadas;

•  separar indivíduos não muda as decisões relevantes dos jogadores.

Devem permanecer separadas quando cada componente possui:

•  objetivo próprio;

•  Posição própria;

•  vulnerabilidade própria;

•  Vínculos relevantes diferentes;

•  ou possibilidade de ser tratado de maneira diferente pelos jogadores.

A composição é uma decisão de representação, não uma forma de esconder quantidade.

### Quantidade, grupos e Magnitude

Quantidade não é Magnitude.

Dez Figurantes não se tornam automaticamente uma Ameaça de Magnitude 3.

Quando a quantidade for relevante, o Narrador deve perguntar qual efeito ela realmente produz:

•  bloqueia passagem?

•  aumenta Pressão?

•  reduz Posição?

•  cria múltiplas frentes?

•  dificulta proteção?

•  ameaça objetivos diferentes?

•  consome tempo?

Se o número apenas muda o volume de uma consequência já existente, pode ser melhor representá-lo diretamente na ficção. Se o grupo passa a agir como uma unidade estrutural, pode ser convertido em uma Ameaça composta.

### Ameaça como Frente de Pressão

Uma Ameaça pode ser a Fonte de uma Frente de Pressão.

Usa-se a estrutura já fechada:

Fonte → Objeto → Escalada → Ruptura.

Não se cria um segundo contador de ameaça.

A Fonte pode ser a própria entidade, sua organização, seu fenômeno ou a situação que ela mantém ativa. O Objeto é aquilo que está sendo deteriorado. A Escalada descreve como a ameaça se aproxima da Ruptura.

Uma Ameaça pode, portanto, continuar perigosa mesmo quando não está atacando diretamente um personagem.

### Ameaça dentro de um Conflito

Quando uma Ameaça participa de um Conflito, a pergunta operacional do Narrador é:

"Qual frente esta Ameaça está tentando alterar agora?"

A resposta determina a ação relevante.

Uma intervenção de Ameaça pode:

•  alcançar um personagem;

•  alterar Posição;

•  aumentar ou reduzir Pressão;

•  quebrar Guarda;

•  proteger uma Costura;

•  avançar seu próprio objetivo;

•  impedir acesso;

•  criar uma nova condição;

•  deslocar o foco para outra frente;

•  preparar uma consequência futura.

Ela não precisa atacar em todas as rodadas.

### Recursos de Ameaças

Ameaças usam Recursos somente quando seu desgaste for parte da experiência desejada.

•  Ponto de Vitalidade ~ quando o desgaste corporal importa;

•  Ponto de Inteireza ~ quando coerência, identidade, percepção ou estabilidade podem ser pressionadas;

•  Ponto de Esforço ~ quando capacidades extraordinárias possuem limite de uso ou sustentação.

Uma Ameaça não recebe todos os Recursos apenas para parecer simétrica a uma personagem.

Quando um recurso chega a um limite relevante, o Narrador olha para o objetivo do Conflito antes de decidir a consequência.

### Queda, contenção e derrota

Reduzir um recurso a zero não determina sozinho o destino da Ameaça.

Uma Ameaça pode ser:

•  destruída;

•  incapacitada;

•  expulsa;

•  contida;

•  convencida;

•  desfeita;

•  selada;

•  transformada;

•  fragmentada;

•  ou reduzida a uma forma menor de presença.

A resolução depende do que estava em disputa.

Se o objetivo era escapar, derrotar fisicamente a Ameaça pode ser desnecessário. Se o objetivo era selá-la, causar dano pode ser irrelevante. Se o objetivo era descobrir sua Costura, a vitória pode ser uma mudança de compreensão que abre outra intervenção.

Isso impede que todo Conflito do mundo seja convertido em "zerar pontos".

### Vulnerabilidades

Uma vulnerabilidade não é simplesmente "o ponto fraco que dá bônus". Ela é uma relação cuja alteração muda o que a Ameaça consegue sustentar.

Uma vulnerabilidade pode ser:

•  um Ponto de Costura ou dependência essencial;

•  uma dependência ambiental;

•  um Vínculo;

•  uma rotina;

•  um Fragmento;

•  uma condição de manifestação;

•  uma fonte de Pressão;

•  uma necessidade de posição;

•  uma contradição interna;

•  uma relação social ou institucional.

Descobrir uma vulnerabilidade por Investigação não a transforma automaticamente em dano extra. Ela cria uma abordagem que antes não existia ou altera a forma como uma consequência pode alcançar a Ameaça.

### Encontros

Um encontro não é definido pelo número de inimigos. Ele é definido pela estrutura de oposição que precisa ser resolvida.

Antes de construir um encontro, o Narrador deve registrar:

1.  Objetivo dos personagens;

2.  Objetivo da oposição;

3.  Condição de encerramento;

4.  Posição inicial;

5.  Frentes de Pressão, se houver;

6.  Ameaças ou Adversários necessários;

7.  Consequências que podem permanecer;

8.  Rotas de mudança ~ fuga, contenção, acordo, transformação, acesso, destruição etc.

Se esses elementos não estiverem presentes, acrescentar inimigos raramente melhora o encontro.

### Balanceamento estrutural

O balanceamento de encontros ocorre em três eixos:

#### Eixo 1 ~ Capacidade de oposição

Pergunta:

A oposição consegue realmente disputar as abordagens que os personagens pretendem usar?

Uma ameaça precisa possuir meios plausíveis de interferir, mas não precisa cobrir todas as abordagens. Vulnerabilidades e lacunas devem existir.

#### Eixo 2 ~ Pressão de continuidade

Pergunta:

Quanto da continuidade dos personagens o encontro exige que seja comprometida antes de terminar?

O encontro pode pressionar:

•  Vitalidade;

•  Inteireza;

•  Esforço;

•  Guarda;

•  Posição;

•  Vínculos;

•  Reputação;

•  equipamento;

•  tempo;

•  informação;

•  ou outras continuidades relevantes.

Um encontro equilibrado não precisa consumir o mesmo recurso de todos. Ele deve oferecer caminhos diferentes para responder à pressão.

#### Eixo 3 ~ Complexidade de resolução

Pergunta:

Quantas frentes precisam ser acompanhadas ao mesmo tempo para que a oposição seja compreendida e enfrentada?

Um encontro pode ser difícil porque:

•  uma Ameaça é resistente;

•  várias frentes avançam simultaneamente;

•  a Posição muda rapidamente;

•  a Pressão sobe enquanto o grupo age;

•  o objetivo exige mais de uma etapa;

•  a oposição possui Costuras que precisam ser compreendidas;

•  ou as consequências se acumulam.

A dificuldade não deve ser produzida apenas aumentando Defesas ou recursos.

### Perfis de encontro

Para construir encontros sem transformar o balanceamento em uma tabela de "nível do inimigo", o Narrador pode escolher um perfil predominante:

[2378 TABLE]

Perfil do encontro | Foco predominante

Choque | Capacidade de permanecer diante de oposição direta

Desgaste | Gestão dos recursos e das consequências ao longo do tempo

Posição | Controle de espaço, acesso, cobertura, autoridade ou oportunidade

Pressão | Impedir que uma Frente alcance Ruptura

Caçada | Posição, acesso e continuidade em movimento

Enigma | Costuras, hipóteses e vulnerabilidades

Transformação | Mudança do objetivo ou da estrutura do Conflito

Um encontro pode misturar perfis, mas um deles deve ser claramente dominante.

### Sinais de encontro mal calibrado

O Narrador deve revisar o encontro quando:

•  a única resposta plausível é atacar até o recurso chegar a zero;

•  a oposição cobre todas as abordagens possíveis;

•  o grupo não consegue identificar o que pode mudar;

•  a Ameaça possui muitas capacidades que nunca entram em jogo;

•  a dificuldade vem apenas de Defesas excessivamente altas;

•  o encontro exige rolagens repetidas sem mudança de situação;

•  a consequência de uma falha não altera nada;

•  a Ameaça pode perder sem que seu objetivo seja afetado;

•  ou a vitória depende de descobrir uma informação que a própria estrutura da cena não permite obter.

Esses são sinais de problema estrutural, não apenas de números.

### Escala de encontro e grupos de personagens

A mesma Ameaça pode produzir encontros muito diferentes conforme o número de personagens e seus repertórios.

Por isso, não existe uma equivalência universal do tipo "Magnitude 2 = quatro personagens".

O Narrador deve comparar:

•  quantidade de personagens capazes de agir sobre a frente;

•  variedade de abordagens disponíveis;

•  capacidade da Ameaça de mudar Posição;

•  capacidade de produzir Pressão;

•  quantidade de frentes simultâneas;

•  possibilidade de recuperação ou preparação;

•  condição de encerramento.

Ajustar um encontro pode significar:

•  retirar uma frente;

•  reduzir a frequência de uma consequência;

•  abrir uma vulnerabilidade;

•  alterar o objetivo da oposição;

•  oferecer uma rota de fuga;

•  reduzir a escala da Ameaça;

•  ou permitir que o grupo obtenha preparação.

Ajustar números é apenas uma das ferramentas. Na v2.0, os valores canônicos do núcleo já estão definidos; ajuste de encontro deve priorizar estrutura, Posição, Pressão, Urgência, vulnerabilidades e condições de encerramento. Futura errata não cria nova camada de regras.

### Construção de um encontro

A base atual permanece suficiente para o Mestre. Os critérios de construção de oposição, escala, objetivo, Pressão, duração, vulnerabilidades e condições de término devem ser lidos em conjunto com os princípios desta seção; eles organizam a decisão do Mestre sem criar uma nova camada de regras.

Procedimento fechado:

1. Defina o que está em disputa.

Escreva o objetivo dos personagens e o da oposição.

2. Defina como o encontro pode terminar.

Escolha entre Ruptura, Contenção, Fuga, Acordo, Objetivo alcançado ou Transformação, conforme a ficção.

3. Escolha o perfil predominante.

Choque, Desgaste, Posição, Pressão, Caçada ou Enigma.

4. Determine a presença necessária.

Use Figurantes, Adversários e Ameaças somente na quantidade de estado que a cena precisa.

5. Determine a Magnitude quando houver Ameaça.

A Magnitude deve refletir a escala que a presença consegue alterar, não sua "força de combate".

6. Defina Modo de agir e Consequências.

O Narrador precisa saber como a oposição pensa e o que muda quando consegue agir.

7. Defina Costuras e vulnerabilidades.

Registre apenas as relações que realmente criam possibilidades diferentes.

8. Monte as Frentes de Pressão.

Só quando a situação realmente possuir deterioração progressiva.

9. Verifique as rotas de resposta.

O grupo deve possuir mais de uma maneira plausível de alterar a situação, mesmo que algumas exijam preparação.

10. Só então considere números.

Defesas, Recursos, dados e custos são calibrados depois, sem usar números para esconder uma estrutura ruim.

### Balanceamento sem simetria

Um encontro equilibrado não precisa ser simétrico.

Uma Ameaça pode possuir enorme escala, mas uma vulnerabilidade clara. Um grupo pode ter mais ações disponíveis, mas precisar proteger um objetivo. Uma instituição pode ser difícil de enfrentar diretamente, mas vulnerável à reputação ou à investigação. Um fenômeno pode ser impossível de ferir, mas possível de conter.

O equilíbrio desejado é:

cada lado possui meios plausíveis de alterar a situação, e nenhum lado possui uma solução universal que torne as demais decisões irrelevantes.

### Preparação como parte do balanceamento

Investigação, Selagem, Vínculos, Reputação, equipamento, Lavores, Fragmentos e preparação podem alterar a estrutura de um encontro antes que ele comece.

Isso é deliberado.

Um encontro que parece impossível sem preparação pode tornar-se viável depois que o grupo:

•  descobre uma dependência essencial ou Ponto de Costura;

•  obtém acesso;

•  recupera um Fragmento;

•  prepara um Selo;

•  estabelece um Vínculo;

•  muda sua Posição;

•  obtém uma rota de fuga;

•  ou transforma seu objetivo.

O balanceamento deve considerar o estado esperado da campanha, não apenas personagens entrando em uma sala sem contexto.

### Regra de economia de estado

O Narrador deve registrar apenas aquilo que pode mudar uma decisão.

Se uma capacidade, recurso, Condição, equipamento, Costura ou regra não produz nenhuma decisão possível na cena atual, ela pode permanecer apenas na descrição.

Isso vale especialmente para Ameaças de alta Magnitude: uma ficha grande não é sinal de profundidade. Profundidade vem da quantidade de relações que a presença realmente altera.

### Abreviações legadas

CP (Cômputo de Pressão), VT (Vetor de Tensão) e PP (Pontos de Permanência) possuíam definições e procedimentos na edição anterior. Foram retirados porque suas funções passaram a ser representadas pela arquitetura do TdV II, e não por ausência de definição histórica.

Elas não retornam como números paralelos nesta arquitetura.

Qualquer função que esses campos precisassem cumprir deve ser absorvida por elementos já fechados:

•  Magnitude;

•  Ponto de Vitalidade;

•  Ponto de Inteireza;

•  Ponto de Esforço;

•  Defesa;

•  Guarda;

•  Posição;

•  Pressão;

•  Consequência;

•  Costura.

Ao consultar material antigo, traduza sua função para a estrutura atual; não converta automaticamente valores entre escalas incompatíveis. Uma regra nova só recupera um campo histórico se demonstrar necessidade, função e relação que não estejam atendidas pelo núcleo.

### Regra de fechamento de Ameaça

Antes de colocar uma Ameaça em jogo, o Narrador deve conseguir responder:

1.  O que ela quer?

2.  O que ela consegue alterar?

3.  Como ela procura fazer isso?

4.  O que acontece quando consegue?

5.  Que relação sustenta sua expressão?

6.  Que dependência ou vulnerabilidade os personagens podem alterar para enfrentá-la?

7.  Como o Conflito pode terminar sem depender obrigatoriamente de zerar uma barra?

Se essas respostas existirem, a Ameaça possui estrutura suficiente para entrar em cena.

NPCs, Ameaças, Magnitude e Costura utilizam a arquitetura comum; suas referências de encontro exigem avaliação da situação e do grupo.

### Economia de estado

FIGURANTE → presença mínimaADVERSÁRIO → presença opositoraAMEAÇA → oposição estruturalAMEAÇA + FRENTE → Pressão persistente

Ameaças e NPCs usam o Motor, as Intervenções, as relações, as consequências e as Permanências do sistema comum.

## Ameaças são continuidades sob conflito

Uma Ameaça importa porque há uma organização que sustenta sua presença, produz respostas e resiste à interferência. Sua ficha distingue a dependência que permite continuar agindo da Costura que combina capacidades. Em uma manifestação, uma dependência decisiva pode constituir Ponto de Costura; em outras presenças, pode ser alimentação, financiamento, reconhecimento ou suporte material.

Uma criatura corpórea pode depender de um ninho, de alimento ou de um padrão de migração; uma instituição pode depender de arquivo, financiamento e reconhecimento; uma manifestação de Além-Véu pode depender de um Ponto de Costura local. Desatar uma dessas relações não significa sempre matar, destruir ou purificar. Às vezes é suficiente reduzir alcance, interromper expansão, alterar a Condição ou produzir trégua.

### Construção de encontro em sete perguntas

1.  Continuidade: o que a Ameaça consegue preservar, e por quê?

2.  Intenção: o que ela faz quando ninguém intervém?

3.  Fios operacionais: quais dados, Defesas e recursos realmente precisam estar na ficha?

4.  Posição e Pressão: quais vantagens existem agora e qual frente evolui?

5.  Dependência e Costura: qual relação permite conter a presença, e quais capacidades combinadas produzem sua expressão?

6.  Consequência: o que cada expressão ameaça alterar?

7.  Resto: o que continuará verdadeiro após derrota, acordo, fuga ou transformação?

Exemplo — o arquivista que protege um segredo. Ele pode ser um adversário social com Enlace relevante em Persuasão e Sociedade, acesso institucional e Vínculo com guardiões. Sua dependência pode ser o reconhecimento de autoridade por parte dos funcionários. Apresentar prova incontestável de abuso pode alterar essa dependência, mesmo sem reduzir PV. Sua Magnitude não é determinada pelo número de pessoas que admiram seu título, mas pela escala de presença e pressão que consegue sustentar em jogo.

## Exemplo de jogo ~ do enunciado ao Resto

Uma personagem quer retirar uma placa de registro de uma máquina sob pressão, antes que a sala seja evacuada. Sua Intenção é conservar o registro; sua Abordagem é manusear a fixação sem romper o tubo. Usa Cadência 3 (d10) + Engenharia 2 (d8). A situação estabelece DT 12 e uma Frente de Pressão de 1, que aumentará se a máquina continuar vibrando.

Ela obtém Prumo 7 e Tento 5. O Enlace 12 alcança a DT; o Ascendente 7 revela espaço para retirar o registro, o Retorno 5 informa que o gesto não foi inteiramente estável, e o Desvio +2 indica que a coordenação sustentou mais a ação do que o método. Não há Consonância. Resultado: a placa é retirada sem quebra. Resto: a fixação fica frouxa e exigirá cuidado na próxima tentativa; a Posição da personagem muda para Exposta caso a máquina entre em falha. Não se cobra PV ou aumenta Pressão arbitrariamente só porque o Retorno existe: qualquer custo deve decorrer da situação e da leitura anunciada.

Se a rolagem fosse 6 + 6, haveria Consonância e Enlace 12; o êxito crítico poderia preservar também o mecanismo ou revelar informação adicional contida na placa, conforme a cena. Se fosse 1 + 1, ocorreria Falha Crítica independentemente da coerência dos dados; a Matriz Cadência ficaria Abalada até o fim da cena e o mecanismo poderia reagir segundo a situação.

## Travessia de exemplo ~ a mesma Malha por diferentes capítulos

A sequência abaixo não apresenta um conjunto obrigatório de cenas. É um estudo editorial do funcionamento integrado de TdV. Os participantes, suas ações e os custos são exemplos, não eventos canônicos de Castelvarco.

### Movimento I ~ a pista

Iria procura o documento alterado. A permissão inicial vem de sua Origem e do conhecimento dos procedimentos do arquivo; a incerteza surge ao reconstruir a data de adulteração sob pressão. Nexo + Investigação forma Prumo e Tento. A soma decide se alcança o limiar. Se o registro torna provável a presença de uma pessoa específica, essa hipótese passa a orientar abordagens futuras — não é uma nova habilidade, apenas informação incorporada à situação.

### Movimento II ~ o vínculo

Elen conhece uma guardiã. Seu Vínculo oferece acesso, não influência ilimitada. Se a guardiã aceitar ajudá-la contra uma ordem superior, a relação poderá ficar Tensionada. Mesmo que o grupo consiga o documento, o Resto da escolha pode ser a cobrança que Elen aceitou sem perceber. A cena altera uma Malha social.

### Movimento III ~ a estrutura

Tomas percebe uma escora cedendo. Engenharia torna plausível a intervenção; Cadência pode ser escolhida se sua abordagem privilegiar encaixe rápido, enquanto Ímpeto seria coerente se precisasse sustentar peso diretamente. A escolha da Matriz acontece depois da intenção declarada. Uma Resposta defensiva pode alterar a Posição antes do limiar, mas não transforma o mesmo acontecimento em duas defesas gratuitas.

### Movimento IV ~ o Selo

A porta protege um lugar no qual uma manifestação parece estar contida. Uma Selagem exige diagnosticar o fenômeno, reconhecer a dependência que o mantém e criar acesso ao Ponto de Costura. Iria pode contribuir com conhecimento de arquivo, Elen com o Vínculo institucional e Tomas com o mecanismo; suas ações anteriores convergem. Se atuarem simultaneamente para tecer o mesmo procedimento, pode haver Costura, conforme a regra da operação. A distinção importa mais que a palavra escolhida pelo grupo.

### Movimento V ~ o Resto

Se a Selagem funcionar, a manifestação pode ser contida sem que seu passado desapareça. Uma escora quebrada, uma autoridade desafiada e um compromisso assumido continuam tendo consequências. Iria pode compreender algo novo sobre sua Marca, mas não aprende um Lavor automaticamente: isso exigirá o mecanismo de Desenvolvimento correspondente. A nova situação não é o ponto final — é a Malha respondendo à passagem dos personagens.

### Consulta rápida do exemplo

[2515 TABLE]

Momento | Raiz focal | Operação | Resultado observável | Resto possível

Pista | Ação | Reconhecer | Informação obtida | Hipótese e rastro de consulta

Vínculo | Relação transversal | Aproximar | Acesso | Obrigação entre pessoas

Escora | Situação | Tensionar / Sustentar | Estrutura estabilizada | Equipamento danificado

Selo | Expressão | Entrelaçar / Fixar | Contenção | Manutenção e pressão residual

Depois | Transformação | Incorporar quando permitido | Nova possibilidade | Mudança de Feição ou desenvolvimento futuro

Regra de coerência: nem a Costura, nem a Incorporação, nem a Permanência precisam aparecer todas na mesma sessão. Sua ausência não torna uma cena incompleta. O jogo oferece profundidade quando ela importa; a leitura curta continua suficiente para ações ordinárias.

PARTE IX
