---
title: "TdV II · Arquitetura"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "ARQUITETURA", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# ARQUITETURA

A ÁRVORE DA TESSITURA

Uma intenção encontra o mundo. A mudança revela aquilo que a sustentava.

## Princípio fundador

A personagem entra na Tessitura com aquilo que é. Ela age para mudar alguma coisa. A mudança encontra uma situação e as relações que a sustentam ou impedem. O Motor resolve o encontro quando há incerteza relevante. O resultado altera a situação. O que sobra permanece e modifica o próximo encontro.

Forma mínima:

Você age. A Tessitura responde. Algo permanece.

Axioma mecânico:

Toda ação encontra uma continuidade, e aquilo que modifica pode permanecer.

## As quatro raízes

A arquitetura canônica possui quatro raízes funcionais. Relação é o princípio transversal que conecta as raízes, não uma quinta gaveta.

TESSITURA│├── PESSOA│   ├── Feição│   └── Constituição│├── AÇÃO│   ├── Intenção│   ├── Intervenção│   ├── Expressão│   └── Motor│├── SITUAÇÃO│   └── Cena│       ├── Posição│       ├── Pressão│       ├── Urgência│       ├── Impulsos│       └── Respostas│└── TRANSFORMAÇÃO    ├── Resultado    ├── Consequência    ├── Resto    ├── Permanência    ├── Memória da Trama    ├── Incorporação    └── DesenvolvimentoRELAÇÃO atravessa tudo:Vínculo · Costura · Convergência · Reconhecimento · Desatar

## O que cada raiz responde

[0066 TABLE]

Raiz | Pergunta | Conteúdo

Pessoa | Quem entra na situação e do que é capaz? | Feição, Constituição

Ação | O que está sendo tentado e como? | Intenção, Intervenção, Expressão, Motor

Situação | O que está sendo sustentado, disputado ou pressionado? | Cena, Posição, Pressão, Urgência, Impulsos, Respostas

Transformação | O que mudou e quanto disso permaneceu? | Resultado, Consequência, Resto, Permanência, Memória, Incorporação, Desenvolvimento

## A cadeia fundamental

PESSOA  ↓INTENÇÃO  ↓AÇÃO  ↓INTERVENÇÃO  ↓EXPRESSÃO  ↓SITUAÇÃO  ↓RELAÇÕES EM JOGO  ↓[Fios → Motor, quando houver incerteza relevante]  ↓RESULTADO  ↓TRANSFORMAÇÃO  ↓NOVA SITUAÇÃO  ↓NOVA AÇÃO

Ela é uma cadeia funcional, não uma lista obrigatória de etapas. Resolução sem teste pode ir diretamente de Ação a Transformação.

## Relação como gramática transversal

•  Vínculo: continuidade persistente entre partes identificáveis.

•  Costura: participação funcional de partes diferentes numa mesma operação.

•  Convergência: resultados diferentes que passam a sustentar a mesma mudança.

•  Desatar: ruptura de uma relação existente.

•  Reconhecimento: resposta de uma rede à trajetória de alguém.

•  Posição: relação atual entre participante, objetivo e forças contrárias.

•  Memória da Trama: relação do presente com uma mudança que continua verdadeira.

Pergunta arquitetural: que relação está fazendo esta regra funcionar?

## Tipos de regra

Estrutura existe. Processo acontece. Relação conecta. Resultado é produzido. Persistência continua. Expressão dá forma concreta.

Uma regra não deve misturar esses papéis sem declarar sua dependência.

## Hierarquias consolidadas

### Resultado

RESULTADO├── ALCANCE → Enlace├── MOVIMENTO│   ├── Ascendente│   │   ├── Abertura│   │   └── Fresta│   └── Retorno│       ├── Rastro│       └── Devolução├── DIREÇÃO → Desvio├── ENCONTRO → Consonância└── RESTO

### Costura

COSTURA├── Auxílio├── Cooperação└── Costura de MalhaConvergência = relação posterior entre resultados.Desatar = ruptura de relação.

### Persistência

RESULTADO → CONSEQUÊNCIA → RESTO → PERMANÊNCIA                                      ├── Memória da Trama                                      └── Incorporação → Desenvolvimento

Essas setas representam possibilidades de continuidade, não uma obrigação de cada resultado gerar todos os estágios.

## A Malha como gramática comum

A arquitetura do jogo pode ser lida sem supor que tudo possui a mesma natureza. Um corpo não é um tratado político; um sentimento não se confunde com uma válvula; uma Trama não é uma arma comum. O que essas coisas partilham é uma estrutura relacional: dependem de condições, oferecem continuidade, podem ser pressionadas e respondem a mudanças. Essa semelhança não apaga suas diferenças. Explica por que o mesmo Motor é capaz de mediar intervenções tão diversas.

Uma forma útil de compreender as quatro raízes é reuni-las em dois pares: Pessoa e Situação descrevem continuidades em jogo; Ação e Transformação descrevem sua alteração. A Relação atravessa as quatro, pois cada uma existe vinculada às demais. Não é uma quinta raiz.

### A recursividade da Tessitura

Ação não é o fim de uma cadeia de comandos. Uma ação modifica a situação. Algumas consequências passam para a cena seguinte. Outras alcançam um Vínculo ou a própria Feição. A pessoa transformada entra em situações futuras com uma continuidade diferente. Por isso o ciclo se repete sem reconstruir o sistema:

Nem toda ação produz um Resto que mereça anotação. Toda ação encontra uma continuidade; apenas mudanças relevantes exigem memória de mesa. O Narrador registra uma Permanência quando ela realmente pode modificar escolhas posteriores. O axioma descreve a possibilidade de consequência, não uma obrigação de preencher fichas a cada rolagem.

### Três escalas de Fio e Malha

[0099 TABLE]

Escala | Fio | Malha | Consequência para a leitura

Cosmológica | Relação que sustenta a possibilidade de existência e transformação | Organização de relações no Reflexo e na Tessitura | A Urdidura fundamenta, sem ser reduzida aos dados

Mecânica | Prumo e Tento representam capacidade e aplicação durante uma intervenção | O resultado é lido segundo as relações da Cena | Dois dados simulam dimensões de ação; não são dois fios primordiais literais

Prática pessoal | Capacidades, Lavores, Vertentes, Vínculos e expressões podem se relacionar | Malha de práticas organiza repertório e Costura | A mesma lógica permite combinar meios, sem conceder bônus por metáfora

Regra de interpretação: uma semelhança poética entre duas coisas não cria efeito mecânico. É necessário identificar que relação concreta permite o efeito, qual sua condição, o limiar ou oposição e qual consequência ele deixa.

## Gramática das intervenções ~ sete verbos, nenhum dado novo

O TdV não acrescenta sete novas fases obrigatórias. Reconhecer, Aproximar, Tensionar, Entrelaçar, Desviar, Desatar e Fixar nomeiam tipos de mudança que os procedimentos já resolvem. São um mapa para o Narrador, para autores de Lavores e para quem deseja compreender por que uma solução pertence a este jogo.

[0104 TABLE]

Operação | Relação em jogo | Exemplos | O que não significa

Reconhecer | Tornar perceptível uma dependência | Investigar, observar uma Costura, examinar uma Marca | Receber informação sem evidência ou acesso

Aproximar | Criar condições de intervenção | Abrir um contato, alcançar uma âncora, preparar ferramenta | Gerar movimento sem limite de Posição

Tensionar | Exigir de uma continuidade mais do que ela sustenta facilmente | Forçar, ampliar uma operação, pressionar vínculo | Receber bônus gratuito ou custo obrigatório em toda ação

Entrelaçar | Fazer participações diferentes sustentarem um efeito | Cooperação, Costura de Malha, Selagem coletiva | Somar arbitrariamente Enlaces

Desviar | Reorientar efeito, risco ou trajetória | Redobra, Ancorar, mudar Posição | Apagar a origem da consequência

Desatar | Romper uma dependência | Encerrar disputa, desfazer um pacto, enfraquecer Costura | Destruir automaticamente tudo que estava ligado

Fixar | Preservar a mudança por condições identificáveis | Selo, Reassentamento, Incorporação | Garantir permanência infinita

### A Matriz de Derivação de Regras

Quando uma Trama ou Ameaça precisar de uma regra particular, seu autor deve responder, nessa ordem: estrutura, relação, intervenção, expressão, limite, consequência e Resto. Isso é uma lista de revisão editorial, não sete campos obrigatórios em toda ficha. Um Lavor pode precisar apenas de três linhas; uma Ameaça complexa pode exigir uma página.

Exemplo de derivação — porta sustentada por uma promessa. Uma passagem permanece fechada porque uma promessa foi reconhecida por gerações. A estrutura é a porta e sua continuidade social; a relação é a promessa partilhada; a intervenção pode ser investigar o compromisso, persuadir seus guardiões ou tocar a Malha por Canalização; a expressão depende da abordagem; o limite é a força real dessa relação; a consequência pode ser acesso, exposição ou ruptura de confiança; o Resto é o que passa a existir depois que o compromisso foi alterado. A investigação, a conversa e a Canalização não são poderes equivalentes — usam o mesmo modelo de pergunta para encontrar meios diferentes.

## Regra de derivação

Princípio → relação → participação → resolução → resultado → nova possibilidade.

Antes de criar uma mecânica, pergunte qual fenômeno ela modela, qual estrutura já existe, qual relação falta, se essa relação pode ser derivada e o que consumirá seu resultado.

Fundir → hierarquizar → especializar → só então excepcionar.

## Regra de suficiência

Rolar só é necessário quando o resultado pode mudar a situação.

Competência, acesso e tempo suficientes permitem resolução direta. O Motor existe para incerteza relevante, oposição ou risco relevante.

## Sistemas convencionais como derivações

[0116 TABLE]

Sistema convencional | Forma canônica

Combate | Conflito físico dentro de uma Cena

Ataque / manobra | Intervenção

Defesa | limiar estático de deslocamento

Dano | consequência que compromete continuidade física

Cura | transformação de recomposição

Perseguição | Conflito + Posição + Urgência + Pressão quando pertinente

Viagem / exploração | Situação + Posição + Urgência + Preparo quando necessário

Criação / crafting | Ação + Ofício + Preparo + Expressão

Negociação | Intervenção sobre pessoas, relações e expectativas

Investigação | Ação orientada por informação, hipótese e intervenção

Reputação | Permanência social / Reconhecimento

Canalização | Expressão extraordinária através da Urdidura

Selagem | Expressão para fixar uma relação necessária

NPC | presença com o mínimo de estado necessário

Ameaça | presença capaz de sustentar oposição estrutural

Morte / Colapso | transformação crítica da continuidade

## Personalidade estrutural

O TdV não pergunta apenas se você conseguiu. Ele pergunta o que daquilo que você é encontrou o mundo, o que o mundo devolveu e o que ficou preso na Tessitura depois do encontro.

Personalidade não é uma camada estética sobre números. Fios encontram, relações sustentam, resultados deixam marcas e a Tessitura lembra.

## A história que atravessará o livro ~ o Arquivo do Cais

Os exemplos recorrentes se passam num cais de Castelvarco, em Vélia. Trata-se de uma situação demonstrativa criada para este livro, não de uma revelação da campanha Interstício da Convergência nem de um fato histórico que deva ser acrescentado automaticamente ao cânone de Arden.

Uma trabalhadora de registros chamada Iria procura um documento desaparecido sobre uma antiga estação de sinais. Seu companheiro Tomas, acostumado à manutenção de máquinas, descobre que o desaparecimento coincide com falhas numa porta de segurança. Elen, que conhece uma guardiã do arquivo, pode abrir um caminho social. A investigação conduzirá os três a um selo instável no depósito. Nada exige que os personagens combinem combate, Canalização e Selagem: a cena demonstra como diferentes formas de ação podem nascer do mesmo núcleo.

[0123 TABLE]

Participante | O que quer | O que oferece | O que pode perder

Iria | Localizar o registro e compreender a falha | Investigação, memória de arquivo, hipótese | A confiança da instituição

Tomas | Evitar que a estrutura ceda | Engenharia, ferramentas e esforço | Posição, equipamento e Vitalidade

Elen | Conseguir acesso sem transformar a guardiã em inimiga | Vínculo e negociação | Reciprocidade e reputação

O arquivo | Manter sua operação e segurança | Portas, registros, procedimentos, guardiões | Continuidade e controle do depósito

Pergunta para a mesa: qual relação precisa ser modificada para que a intenção se realize? Essa pergunta permanecerá a mesma, embora cada personagem encontre uma resposta diferente.

PARTE I
