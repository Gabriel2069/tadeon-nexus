---
title: "TdV II · Aplicação derivada"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "APLICAÇÃO DERIVADA", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# APLICAÇÃO DERIVADA

INVESTIGAÇÃO

Compreender transforma os caminhos que ainda podem ser percorridos.

Uma especialização do ciclo de Ação orientada por informação e revisão.

## Informação não é um prêmio escondido atrás de dados

Uma investigação bem preparada não exige que o Narrador esconda a única pista indispensável atrás de uma rolagem. O Motor pode decidir tempo, extensão, custo, qualidade da compreensão e novas relações reveladas. Se a continuidade da história depende de saber que existe uma porta na parede, o teste não determina se a parede possui ou não uma porta; determina quais riscos acompanham descobri-la ou atravessá-la.

Exemplo — a assinatura do registro. Iria descobre que uma página foi trocada. Esse fato essencial pode estar acessível por exame adequado, sem teste, se houver tempo e acesso. A rolagem de Investigação pode descobrir quem obteve a folha original, identificar a época provável ou determinar se o grupo chama atenção ao examinar o arquivo. A diferença entre sucesso e falha produz uma nova situação, não o bloqueio total da história.

[1927 TABLE]

Pergunta | Camada de investigação | Resultado orientador

O que aconteceu? | Evidência | Algo observável, direto ou indireto

Que explicação é plausível? | Hipótese | Relações entre pistas e contradições

O que torna isso possível? | Estrutura | Acesso, instituição, técnica, fenômeno

O que posso fazer com o que sei? | Intervenção | Preparação, negociação, Costura ou contenção

O que continua verdadeiro? | Resto | Testemunho, reconhecimento, mudança de posição

A Teia investigativa não é a Malha cosmológica inteira. É a representação operacional de hipóteses, pistas e dependências que o grupo reconheceu. Deve continuar revisável quando novas evidências surgirem.

## SEÇÃO 01INVESTIGAÇÃO

A Investigação é o sistema específico usado quando compreender uma situação é, por si só, parte do Conflito. Ela não transforma conhecimento em uma sequência de testes para descobrir informações que a ficção exige. Pistas Fundamentais existem e podem ser encontradas quando os personagens procuram de maneira coerente. O teste existe para decidir o que a investigação conquista além da descoberta básica: profundidade, contexto, velocidade, interpretação, exposição, preço e consequência.

A Investigação preserva quatro estruturas centrais:

•  Perguntas Centrais ~ o que precisa ser compreendido para que a situação faça sentido;

•  Pistas Fundamentais ~ informações que não podem desaparecer por uma falha de rolagem;

•  Teia ~ relações estabelecidas entre pistas, pessoas, lugares, eventos, objetos e hipóteses;

•  Compasso de Urgência ~ o relógio que registra quando a situação muda enquanto o grupo investiga.

Ela acrescenta duas operações cognitivas explícitas:

•  Hipótese ~ uma interpretação provisória que conecta evidências e permite agir sobre uma explicação;

•  Contradição ~ evidência que não cabe na hipótese atual e força sua revisão.

A investigação, portanto, não mede "quantas pistas faltam". Mede o quanto o grupo consegue transformar informação em compreensão e compreensão em ação.

### Perguntas Centrais

Toda investigação relevante começa com uma ou mais Perguntas Centrais. Elas devem ser perguntas que mudem o que os personagens podem fazer quando respondidas.

Exemplos:

•  Quem está alterando os registros?

•  Por que o fenômeno ocorre somente durante a troca de turno?

•  O que mantém a Dobra naquela forma?

•  Quem se beneficia da permanência do padrão?

•  O que precisa ser alterado para impedir a próxima manifestação?

Uma Pergunta Central pode possuir várias pistas e pode receber respostas parciais. Uma pista pode responder a várias perguntas.

Uma Pergunta Central não precisa ser revelada ao grupo como texto de ficha. Ela pode existir apenas na preparação do Narrador e emergir pela investigação.

### Pistas Fundamentais

Pista Fundamental é qualquer informação cuja ausência impediria a investigação de avançar de maneira justa.

A regra é absoluta:

Se os personagens chegaram a um lugar, pessoa, objeto ou situação de maneira coerente e a informação é necessária para continuar a história, eles recebem a pista fundamental.

Não há teste para determinar se a pista existe.

O teste pode decidir:

•  quão cedo ela é percebida;

•  quanto contexto vem junto;

•  quem percebe algo além dela;

•  qual preço é pago pela descoberta;

•  se a personagem fica exposta;

•  se a evidência é preservada;

•  se uma oportunidade é criada;

•  se uma ameaça percebe que foi investigada.

Uma pista fundamental pode ser entregue diretamente, mas sua interpretação pode continuar disputada.

### Pistas Diretas e Pistas Profundas

Pista Direta é aquilo que a cena oferece pela observação coerente: documento, comportamento, marca material, testemunho, horário, ausência, ruído, padrão ou discrepância.

Pista Profunda é aquilo que exige método, comparação, memória, conhecimento técnico ou leitura de relações para ser percebido.

Não são dois níveis de importância. A diferença é de leitura.

Uma Pista Direta pode revelar que três caixas foram abertas. Uma Pista Profunda pode revelar que as três aberturas obedecem ao mesmo intervalo de tempo usado por uma antiga rotina de manutenção.

### O Teste de Investigação

Quando uma investigação exige resolução, escolha a abordagem e aplique o motor comum:

Matriz → Alinhavo → Fio de Prumo + Fio de Tento → Ascendente/Retorno → Enlace → Desvio → Consonância → consequência.

O Alinhavo representa o método empregado; a Matriz representa como a personagem está realizando a investigação.

Exemplos:

•  Nexo + Investigação para reconstruir relações entre evidências;

•  Nexo + Ciências para interpretar um fenômeno físico;

•  Cadência + Percepção para perceber uma alteração no instante em que ocorre;

•  Lastro + Sociedade para interpretar relações institucionais;

•  Ímpeto + Ofício para desmontar fisicamente um mecanismo sob pressão.

A combinação deve mudar a abordagem na ficção. Não existe "Matriz de investigação" fixa.

### O que o resultado muda

O Narrador escolhe, antes da rolagem, o eixo principal que está em disputa. Um teste de investigação deve responder a pelo menos uma destas perguntas:

1.  Profundidade ~ o que mais é compreendido?

2.  Contexto ~ com o que essa pista se relaciona?

3.  Velocidade ~ quanto tempo foi poupado?

4.  Interpretação ~ qual significado pode ser sustentado com segurança?

5.  Exposição ~ quem percebeu a investigação?

6.  Preservação ~ a evidência permanece utilizável?

7.  Acesso ~ que próximo passo se tornou possível?

8.  Preço ~ o que precisou ser arriscado para descobrir?

Não se deve transformar todos os resultados em "mais uma pista". O resultado deve alterar a posição investigativa.

### Enlace, Desvio e Consonância na investigação

Enlace responde se a abordagem alcançou o objetivo do teste.

Desvio descreve a diferença entre capacidade e método e orienta a forma da consequência:

•  Prumo dominante pode indicar que a personagem compreendeu pelo alcance bruto de sua capacidade, mas deixou lacunas de método, contexto ou controle;

•  Tento dominante pode indicar que o método encontrou uma resposta além do que a capacidade isolada sustentaria, mas a descoberta pode depender de procedimento, instrumento ou circunstância específica;

•  Desvio zero indica equilíbrio entre capacidade e método.

Consonância pode produzir uma leitura excepcional quando há alcance: a relação entre as duas formas de agir se torna particularmente clara e a investigação pode revelar uma conexão que mudaria a direção da Teia, sem transformar a descoberta em um bônus numérico automático.

### Hipótese

Uma Hipótese é uma explicação provisória que conecta pelo menos duas evidências ou uma evidência a uma Pergunta Central.

Uma Hipótese não precisa estar correta para ter valor mecânico.

Quando o grupo formula uma Hipótese plausível, o Narrador pode:

•  confirmar que ela é uma interpretação possível;

•  indicar o que ainda falta para sustentá-la;

•  permitir uma abordagem que antes não existia;

•  transformar a próxima investigação em teste de verificação;

•  expor uma consequência caso a hipótese esteja errada.

O jogador não precisa acertar "a resposta do mestre". A função da Hipótese é permitir intervenção informada.

### Contradição

Contradição surge quando uma nova evidência não pode coexistir confortavelmente com a Hipótese vigente.

A Contradição nunca apaga uma Pista Fundamental anterior. Ela registra que a interpretação atual ficou insuficiente.

Quando uma Contradição surge, o grupo deve escolher entre:

•  abandonar a Hipótese;

•  restringi-la;

•  dividir a explicação em duas relações;

•  procurar uma terceira causa;

•  agir mesmo com incerteza.

Uma Contradição pode ser uma consequência excelente de falha porque cria conhecimento incômodo, e não vazio de informação.

### Teia

A Teia é o registro das relações relevantes descobertas durante a investigação.

Um nó pode ser:

pessoa; lugar; objeto; instituição; evento; documento; fenômeno; Ponto de Costura; Hipótese..

Uma ligação pode representar:

autoria; dependência; coincidência; acesso; sequência; causa presumida; oposição; interesse; pertencimento; contradição..

A Teia não exige uma estrutura gráfica física. Pode existir como anotações, mapa, quadro ou memória da mesa.

O Narrador deve evitar declarar relações que os personagens ainda não têm meios de sustentar. A Teia registra o que o grupo pode defender como leitura, não a verdade absoluta da campanha.

### Recapitular

Recapitular é a ação de reorganizar evidências já obtidas.

Ao Recapitular, o grupo pode:

•  separar fato de interpretação;

•  ligar pistas que ainda estavam isoladas;

•  identificar uma Contradição;

•  transformar uma relação em Hipótese;

•  recuperar uma pergunta esquecida.

Recapitular não cria uma pista que não existia. Ele melhora a leitura das que já existem.

Quando a ação exigir teste, ele deve representar uma dificuldade real de síntese, não uma rolagem obrigatória entre cenas.

### Compartilhar Perspectiva

Compartilhar Perspectiva ocorre quando personagens apresentam leituras diferentes da mesma evidência.

A operação pode:

•  revelar uma interpretação que um único personagem não alcançaria;

•  expor uma Contradição;

•  transformar uma pista em Hipótese;

•  permitir Proveito quando a contribuição do outro personagem muda concretamente a abordagem;

•  reduzir risco de uma decisão baseada em interpretação estreita.

Não é um bônus universal por "trabalhar em equipe". A contribuição precisa alterar a leitura.

### Compasso de Urgência

O Compasso de Urgência possui 3 a 8 espaços, conforme a escala da situação.

•  3 ~ cena curta ou intervenção iminente;

•  4 a 5 ~ investigação comum sob pressão;

•  6 a 8 ~ operação extensa ou múltiplas frentes.

O Compasso avança quando a investigação demora de maneira relevante, uma falha altera a situação, uma oportunidade é perdida, um antagonista reage, uma evidência se degrada ou um gatilho da cena ocorre.

Quando o Compasso se completa, as pistas descobertas permanecem. O que muda é a situação: alguém chega, uma porta fecha, uma testemunha foge, a Dobra pulsa, a evidência é transferida ou outra frente se torna dominante.

O Narrador pode então encerrar, reduzir ou substituir o Compasso conforme a nova situação.

### Falha investigativa

Uma falha não significa "você não encontra nada".

A falha deve produzir uma mudança real, como:

•  descoberta mais lenta;

•  exposição;

•  evidência danificada ou deslocada;

•  interpretação incompleta;

•  acesso mais caro;

•  Pressão crescente;

•  surgimento de Contradição;

•  avanço do Compasso;

•  mudança de Posição;

•  reação de uma pessoa, instituição ou Ameaça.

A única exceção é quando o próprio objeto da investigação está sendo disputado e a perda da informação é coerente com a ficção. Mesmo nesse caso, o Narrador deve evitar apagar retroativamente uma pista fundamental já obtida.

### Investigação e Conflito

Quando uma investigação envolve oposição ativa, ela pode se tornar um Conflito normal.

A investigação então passa a ter:

Objetivo → Posição → Pressão → Ação → Consequência → Permanência.

Exemplo: descobrir a identidade de alguém enquanto essa pessoa tenta destruir os registros. A investigação não recebe um mini-sistema de combate; ela passa a operar como Conflito investigativo.

### Encerramento de uma investigação

Uma investigação não precisa responder todas as Perguntas Centrais para terminar.

Ela pode terminar quando:

•  o grupo possui compreensão suficiente para agir;

•  a Pergunta Central deixa de ser relevante;

•  uma ação muda o problema para outra frente;

•  uma Hipótese é confirmada o bastante para intervenção;

•  a Contradição mostra que a pergunta original estava mal formulada;

•  a situação se transforma em outro tipo de Conflito.

O critério é capacidade de decisão, não porcentagem de pistas coletadas.

### Cadeia investigativa

Pista → Interpretação → Hipótese → Predição → Intervenção → Resultado → Revisão

Investigação não possui teste próprio. Convergência reúne pistas e resultados; Memória da Trama preserva descobertas; Regra da Repetição impede rolagens sem mudança de abordagem.

PARTE VIII
