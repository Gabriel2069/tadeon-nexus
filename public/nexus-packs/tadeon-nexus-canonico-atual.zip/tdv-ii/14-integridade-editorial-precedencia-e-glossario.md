---
title: "TdV II · Integridade editorial, precedência e glossário"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "INTEGRIDADE EDITORIAL, PRECEDÊNCIA E GLOSSÁRIO", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# INTEGRIDADE EDITORIAL, PRECEDÊNCIA E GLOSSÁRIO

Referência de leitura e consulta para a mesa.

## APÊNDICE C.1Precedência entre obras

A Urdidura do Vazio estabelece a cosmologia; Arden, o mundo e suas continuidades históricas; este Livro de Regras v2.0, os procedimentos de mesa; Orbis Ardex, o conhecimento interno das instituições de Veth; Fio~Mestre, o sistema de identidade visual e editoração. Quando um registro in-universe desconhecer algo, isso não contradiz automaticamente a cosmologia.

Dentro deste livro, as regras de procedimento e os casos-limite expressamente consolidados nesta edição prevalecem sobre formulações exemplificativas anteriores do mesmo capítulo. Uma Trama, Lavor, Fragmento ou Selo só especializa uma regra quando declara com precisão o gatilho, a exceção e o preço. O histórico de versões permanece como fonte de investigação, não como legislação paralela.

## APÊNDICE C.2Distinções que não podem ser confundidas

[2667 TABLE]

Conceitos próximos | Distinção canônica

Feição × Constituição | Identidade e continuidade pessoal × capacidades, recursos e proteção

Ofício (Feição) × Ofício (Alinhavo) | História/permissão × competência de execução

Prumo × Tento | Capacidade ampla × método/prática

Enlace × Consonância | Alcance do limiar × encontro dos resultados

Ascendente × Retorno | Melhor expressão da tentativa × componente de sustentação mais vulnerável

Proveito × Forçar | Vantagem situacional sobre um Fio × esforço pago antes da rolagem

Guarda × Evasão × Resistência | Proteção imediata × saída da linha de efeito × sustentação corporal

Lucidez × Firmeza | Coerência cognitiva × sustentação identitária/relacional

Condição × Recurso perdido × Marca | Estado mutável × reserva consumida × transformação duradoura

Pressão × Urgência × Tensão | Escalada de frente × janela temporal/oportunidade × direção do Equilíbrio

Lavor × Trama × Fragmento | Prática incorporada × padrão canalizado × permanência de Dobra com suporte próprio

Canalização × Selagem | Operação extraordinária de tecer relações × fixação especializada de continuidade

Costura × Convergência | Participação funcional conjunta × relação posterior entre resultados

Magnitude × quantidade × Enlace | Escala da presença × número de presenças × alcance da intervenção

Ancorar × Reassentar | Alterar uma consequência por Âncora × tornar a Âncora novamente disponível

Marca × Sutura | Marca é o mecanismo da Feição que registra transformação duradoura; Sutura é o trabalho de estabelecer ou restaurar continuidade entre relações incompatíveis, conforme a Urdidura. Uma campanha pode especializar sua expressão, sem precisar criar sua definição cosmológica.

## APÊNDICE C.3Termos substituídos ou exclusivos do histórico

O vocabulário ordinário utiliza Feição, Matrizes, Alinhavos, Fios, PV/PI/PE/PU, Guarda, Impulso, Resposta, Lavor, Vertente, Malha, Costura, Canalização e Selagem. Os antigos nomes mecânicos Vigor, Cognição e Intrusão não servem de exemplo normativo nesta edição; PA, Rank universal, PS como sanidade e Eco como terceiro dado do teste não são recursos do motor canônico. Cicatriz pode aparecer como termo literário, mas não substitui a Marca mecânica; em cartografia e fenômenos de campanha, preserve a terminologia especializada aprovada no respectivo cenário.

## APÊNDICE C.4Aplicação editorial do Fio~Mestre

•  Prosa de leitura: EB Garamond; aberturas e títulos: EB Garamond; informação técnica e rótulos: Inter; códigos e índices: PT Mono.

•  Evitar adicionar ícones, símbolos, ornamentos, texturas, metáforas ou capítulos que não tenham função editorial ou narrativa.

•  Corpo de regra: primeiro enuncie o que acontece, quando ocorre, como se resolve, o que custa, qual o resultado e o que permanece; depois amplie a intenção conceitual quando necessário.

•  Preferir uma coluna em prosa e páginas de referência, duas apenas para materiais compactos; preservar margens e legibilidade.

•  O livro final não deve reproduzir o histórico experimental como se fossem regras adicionais.

## APÊNDICE C.5Limites explícitos da edição

Esta edição fecha o núcleo procedimental de mesa, suas exceções correntes e sua calibração matemática. Ela não pretende conter todos os Lavores, armas, Tramas, Fragmentos, espécies, reinos ou aventuras possíveis: esses são catálogos e aplicações derivados. Quando não houver regra específica de conteúdo, o Motor, a permissão ficcional e os procedimentos genéricos aqui descritos continuam sendo suficientes; não invente bônus ou punições automáticos.

O equilíbrio de uma campanha inteira ainda depende da disposição de DTs, da escassez de recursos, da composição das Ameaças e de testes reais de mesa. A matemática verificada não equivale a playtest observacional.

APÊNDICE D
