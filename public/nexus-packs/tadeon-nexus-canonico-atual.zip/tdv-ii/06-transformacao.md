---
title: "TdV II · Transformação"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "TRANSFORMAÇÃO", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# TRANSFORMAÇÃO

RESULTADO, CONSEQUÊNCIA, PERMANÊNCIA E DESENVOLVIMENTO

O que aconteceu não precisa desaparecer quando a cena termina.

Como uma ação continua existindo depois de ser resolvida.

## SEÇÃO 01CONSEQUÊNCIAS

Uma consequência não é "penalidade do Narrador". É aquilo que o mundo devolve à tentativa.

Ela pode atingir:

•  Vitalidade;

•  Ponto de Inteireza;

•  Esforço;

•  Posição;

•  Vínculo;

•  Tensão;

•  equipamento;

•  informação;

•  tempo;

•  ameaça/Pressão;

•  Costura ou relação da situação.

A escolha depende da abordagem.

Exemplo: Ímpeto + Atletismo pode arrombar uma porta e danificar o mecanismo; Nexo + Engenharia pode revelar sua trava, mas expor a tentativa; Lastro + Persuasão pode conseguir que uma pessoa a abra, criando uma dívida social.

Isso preserva a regra atual de que falha não deve tornar a cena vazia; ela deve transformar a situação.

## SEÇÃO 02QUANDO O RESULTADO NÃO É SUFICIENTE

Um teste abaixo da DT não deve ser repetido indefinidamente.

A falha gera uma nova condição de continuidade.

A próxima tentativa deve lidar com aquilo que mudou.

Exemplo:

Primeira tentativa: falha em abrir a porta. A pressão do mecanismo desloca-se para o corredor.

Segunda tentativa: não é "tentar de novo"; agora a cena é uma operação diferente, porque o corredor está entrando em risco.

Isso transforma a rolagem em memória.

## SEÇÃO 03CONDIÇÕES E LIMITES

Condições descrevem estados reais da situação. Elas não são uma lista de pequenos modificadores numéricos.

Cada Condição é registrada com quatro elementos:

1.  Nome ~ o estado em linguagem ficcional;

2.  Origem ~ o acontecimento que a produziu;

3.  Efeito ~ o que ela impede, permite ou torna mais difícil;

4.  Saída ~ o que precisa mudar para ela deixar de existir.

### Gramática de uma Condição

Toda Condição precisa alterar pelo menos uma decisão real. Ela pode:

•  impor Desproveito em um Fio específico;

•  impedir ou limitar uma abordagem;

•  alterar Guarda, Posição ou Defesa;

•  modificar o alvo de uma consequência;

•  exigir uma resposta específica;

•  criar uma abertura para outra pessoa.

Uma Condição não deve simplesmente dizer "−2 em tudo".

### Intensidade

A intensidade é indicada pela própria descrição da Condição, não por uma tabela universal de penalidades. Existem três situações de leitura:

Leve: muda escolhas, mas ainda permite funcionamento normal.

Grave: restringe abordagens ou produz Desproveito claro em situações relacionadas.

Crítica: impede determinada ação, ameaça um recurso ou exige intervenção antes que o personagem possa continuar normalmente naquele eixo.

A mesma Condição pode subir ou descer de intensidade conforme a ficção.

### Condição × Recurso × Marca

•  Condição é um estado atual e removível;

•  Recurso perdido representa continuidade consumida;

•  Marca é transformação permanente.

Um ferimento atual, por exemplo, pode ser uma Condição; a Vitalidade perdida representa a continuidade corporal consumida; uma cicatriz narrativa permanente, quando relevante, pode tornar-se parte da Marca.

Os três registros podem nascer do mesmo acontecimento, mas cumprem funções distintas. Não se aplica o mesmo prejuízo duas vezes apenas porque recebeu nomes diferentes.

### Limites

"Limite" continua sendo um dos seis elementos da Feição e não deve ser confundido com uma Condição.

Uma Condição diz "como estou agora". Um Limite diz "o que atravessar isto faz de mim". Uma Marca diz "o que já mudou em mim depois que isso aconteceu".

## SEÇÃO 04MARCAS, MORTE E COLAPSO

O conceito geral de Marca foi estabelecido na seção Feição. Ela é uma transformação permanente da Feição estruturada em:

•  Gatilho;

•  Manifestação;

•  Resíduo.

A Marca comum pode funcionar como obstáculo, consequência, permissão ou nova forma de abordagem. Ela não é um contador e não recebe automaticamente um modificador fixo.

Marca da Morte continua sendo diferente de condição comum.

Marca da Loucura continua sendo uma consequência permanente de Colapso, não uma condição médica.

Cicatriz pode nomear literariamente um vestígio, conforme a Urdidura; não constitui uma nova mecânica de Feição nem substitui Marca. Sutura designa o trabalho relacional de estabelecer ou restaurar continuidade, sem pressupor apagamento do vestígio.

### Colapso e Ponto de Inteireza

A perda do Ponto de Inteireza que levar a Colapso deve gerar uma transformação permanente significativa. Essa transformação pode se materializar como uma nova Marca ou alterar uma Marca já existente, conforme a ficção estabeleça.

O sistema não deve transformar Colapso em mero "fim de pontos". O evento precisa dizer o que mudou na pessoa.

### Marca e Feição

Uma Marca pode:

•  tornar-se a Âncora do personagem

•  pressionar ou alterar Vínculos

•  mudar quais abordagens são possíveis

•  gerar Resíduos que atravessem cenas futuras

•  ser integrada por ações de Reassentamento da Âncora.

Marca da Loucura e Marca da Morte permanecem casos próprios conforme as regras de Morte e Colapso desta edição.

As Marcas especiais obedecem aos protocolos de Morte e Colapso estabelecidos nesta edição.

## Procedimentos definitivos ~ 0 PV, 0 PI, 0 PE e Marcas especiais

As regras abaixo fecham o procedimento, sem criar uma quarta reserva numérica. Preservam o caráter de transformação crítica do TdV: a ficção determina a forma, mas as decisões de risco seguem uma ordem compartilhada.

### Vitalidade zerada e ameaça de morte

Ao alcançar 0 PV, a personagem recebe a Condição Incapacitada: não pode gastar Impulsos em ações físicas exigentes nem manter uma operação que dependa do corpo, embora possa falar, perceber ou expressar um último gesto plausível sem escapar do risco. Uma Resposta de proteção ou Ancorar ainda pode ser possível quando sua Âncora e a ficção realmente sustentem a ação. Não há pontos negativos.

Uma nova consequência física capaz de produzir perda de PV sobre alguém Incapacitado provoca estado À Beira. O Narrador enuncia o perigo concreto (hemorragia, falta de ar, esmagamento, exposição etc.) e oferece uma janela de intervenção até o fim da rodada seguinte, quando a cena comporta esse intervalo. Se ninguém interromper a causa, estabilizar o corpo ou alterar a situação, a personagem morre. Um novo ataque capaz de ferir antes da estabilização pode antecipar a morte quando essa for consequência inevitável da ficção, declarada antes da resolução.

O agravamento da lesão inicial conta como nova consequência física quando sua causa continua ativa: sangramento sem controle, afogamento, fogo ou esmagamento podem levar a À Beira sem novo golpe. Ao aplicar a lesão, o Narrador declara se existe essa deterioração e quando ela atua. O momento não depende de rolagem arbitrária adicional. Se o dano inicial já torna a morte imediata fisicamente inevitável, a mesa declara essa consequência antes da resolução; chegar a 0 PV não cria uma janela de sobrevivência impossível.

Estabilizar exige acesso à pessoa e uma intervenção apropriada (Medicina, Ofício pertinente, Trama ou recurso contextual). Quando há risco ou oposição, resolve-se com o Motor; sem risco e com meios suficientes, a estabilização é direta. A estabilização encerra o estado À Beira, mas não restaura PV automaticamente nem elimina Incapacitada. Um corpo que volta a receber PV e possui condições de funcionamento pode deixar Incapacitada conforme a lesão e as Condições registradas.

Morte: quando a continuidade corporal não pode mais ser sustentada, a morte é definitiva nas circunstâncias ordinárias. Retorno à vida, continuidade anacrônica ou intervenção sobre Alma pertencem a conteúdos extraordinários expressamente autorizados; nenhuma recuperação de PV ressuscita alguém.

Ancorar diante da morte: não cria invulnerabilidade. Se a Âncora pode plausivelmente preservar algum resto de continuidade, ela pode reduzir uma consequência imediatamente terminal a À Beira ou redirecioná-la para uma perda comparável, ficando Abalada; não cancela uma morte consumada nem reverte um ferimento fisicamente irreversível sem manifestação extraordinária.

### Inteireza zerada e Colapso

Ao alcançar 0 PI, a personagem entra em Colapso. A mesa interrompe a intervenção que exigia coerência identitária, registra uma Condição Crítica coerente com a ameaça (desorientação, descontinuidade de memória, desorganização perceptiva, perda de autoria etc.) e define o risco imediato. Ela não realiza ações que dependam daquela continuidade até que haja contenção, assistência, afastamento da fonte ou Ancorar quando possível.

O Colapso deixa uma transformação significativa na Feição: altera uma Marca existente ou origina Marca com Gatilho, Manifestação e Resíduo. Esse registro não é diagnóstico psiquiátrico nem proíbe recuperação funcional. A personagem pode restaurar PI segundo as regras de Recuperação e reintegrar-se à ação; a Marca registra aquilo que não foi simplesmente desfeito. Marca da Loucura, quando empregada pela tradição interna do cenário, nomeia essa transformação ficcional específica, não uma doença real ou punição moral.

### Esforço zerado

A 0 PE, a personagem continua podendo fazer ações ordinárias sem custo, mas não pode iniciar ou sustentar qualquer ação que exija pagamento de PE. Efeitos sustentados que precisem de PE cessam no instante em que o custo devido não é pago. A exceção de Forçar a 0 PE permanece limitada a uma vez por cena e cobra contrapartida expressa. PE não fica negativo.

### Marca da Morte, Marca da Loucura e Marca comum

Uma Marca comum registra transformação persistente da Feição. Marca da Morte é uma forma extraordinária de permanência vinculada a uma morte efetivamente atravessada ou a uma intervenção não ordinária sobre sua irreversibilidade; Marca da Loucura é a denominação interna de uma Marca surgida de Colapso de Inteireza. Ambas preservam os mesmos campos estruturais da Marca, mas não substituem os protocolos de PV e PI.

Controle narrativo: a consequência duradoura precisa ser construída em diálogo com o jogador; nunca se impõem diagnósticos, traços caricaturais ou perda arbitrária de autonomia apenas para criar horror.

### Desenvolvimento

Desenvolvimento é a medida da trajetória já consolidada da personagem. Vai de 0% a 100%, avançando somente em Marcos de 5%.

Cada Marco representa uma mudança que já aconteceu na personagem, e não apenas experiência acumulada. O jogador deve conseguir apontar o que foi incorporado: uma prática, uma compreensão, uma relação, uma transformação ou uma capacidade.

A escala possui 21 posições:

0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95 e 100%.

O valor de Desenvolvimento não concede bônus direto a testes. Ele determina o que a personagem já pode ter incorporado e quais investimentos estão disponíveis.

Desenvolvimento mede quanto mudou. Ponto de Urdume mede o que dessa mudança ainda pode ser investido.

### Marco

Um Marco é alcançado quando a personagem atravessa uma mudança relevante. O Narrador e o jogador devem conseguir responder:

1.  O que aconteceu?

2.  O que a personagem aprendeu, perdeu, assumiu ou transformou?

3.  Que parte da ficha agora expressa essa mudança?

O avanço não precisa ocorrer apenas por vitória. Sobreviver, compreender, reparar uma relação, atravessar um Limite, integrar uma Marca, dominar uma prática ou aceitar uma consequência podem justificar um Marco quando produzem mudança real.

#### Regra de ritmo

O grupo não precisa distribuir um Marco por sessão. Desenvolvimento é deliberadamente mais lento que aquisição de pequenas vantagens dentro de uma cena.

Um Marco pode ser concedido:

•  ao fim de um arco ou conjunto de acontecimentos significativos

•  depois de uma transformação irreversível

•  quando uma prática importante foi realmente incorporada

•  quando uma consequência mudou a personagem de forma duradoura.

Uma personagem não pode receber vários Marcos apenas por repetir a mesma ação sem que exista mudança correspondente.

### Ponto de Urdume

Ponto de Urdume é a moeda de investimento do Desenvolvimento. Ele não é recurso de ação e não pode ser gasto para melhorar uma rolagem no instante em que ela acontece.

#### Aquisição

Ao alcançar cada Marco acima de 0%, a personagem recebe 2 Pontos de Urdume.

Assim, uma trajetória de 0% a 100% fornece 40 Pontos de Urdume ao longo de todo o desenvolvimento.

Pontos não gastos permanecem disponíveis. O personagem não precisa investir imediatamente ao atingir um Marco.

Os PU são deliberadamente escassos. A mesma reserva sustenta Matrizes, Alinhavos, Lavores e ampliações extraordinárias. Cada gasto representa uma escolha de trajetória; a progressão não foi desenhada para permitir comprar tudo.

### O que pode receber Ponto de Urdume

O Ponto de Urdume pode ser investido em quatro tipos de mudança:

#### A. Matriz

Aumentar uma Matriz em uma categoria da escada de dados.

Custo: 3/4/5/6/7 PU por avanço, respectivamente.

A progressão usa os custos consolidados: 3 / 4 / 5 / 6 / 7 PU para d4→d6, d6→d8, d8→d10, d10→d12 e d12→d20.

Aumento de Matriz exige justificativa de incorporação. O personagem não pode simplesmente comprar uma capacidade incompatível com o que viveu.

#### B. Alinhavo

Aumentar um Alinhavo em uma categoria.

Custo: 2 PU por avanço.

O avanço deve corresponder a prática, instrução ou experiência suficiente para justificar a nova categoria.

Alinhavo 0 continua representando prática comum; subir a partir dele representa aprendizado real.

#### C. Lavor

Adquirir um novo Lavor ou desenvolver um Lavor existente.

Custo-base: 4 PU.

Um Lavor excepcionalmente amplo pode custar 6 PU, desde que sua extensão realmente justifique o custo. O custo não deve ser usado para transformar um Lavor em uma categoria de poder arbitrária. Em ambos os casos, o gasto deve ser tratado como uma escolha relevante dentro de uma reserva curta de PU, e não como aquisição rotineira de catálogo.

Desenvolver um Lavor existente pode alterar seu Gatilho, Gesto, Expressão ou limite quando a evolução representar prática real, em vez de simplesmente adicionar bônus.

#### D. Ampliação extraordinária

Algumas transformações não cabem em Matriz, Alinhavo ou Lavor. Um Marco pode permitir uma alteração específica de Feição, equipamento, Trama, Fragmento ou outra estrutura já existente.

Nesse caso, o custo em PU é definido pelo alcance da transformação, normalmente entre 3 e 7 PU, e a alteração precisa ser registrada na própria estrutura afetada. Ampliações dessa natureza são deliberadamente caras porque competem com toda a progressão restante da personagem.

Não existe uma categoria genérica de "poder comprado". O investimento sempre precisa encontrar onde a mudança realmente mora.

### Limites por Desenvolvimento

O Desenvolvimento controla acesso sem criar uma segunda árvore de níveis.

#### Regra-base

•  0 a 20%: consolidação da pessoa e das práticas fundamentais;

•  25 a 45%: práticas especializadas e Lavores mais exigentes;

•  50 a 70%: combinações complexas, especialização profunda e primeiras transformações extraordinárias;

•  75 a 95%: domínio excepcional, Lavores Transcendentes e alterações de grande consequência;

•  100%: integração plena da trajetória; novas aquisições dependem da continuação da campanha ou de uma transformação de escala superior. É um estado extremamente raro, praticamente inalcançável em campanhas normais, e deve representar o fechamento de uma trajetória excepcional, não um patamar de progressão esperado.

Essas faixas são permissões de arquitetura, não pacotes obrigatórios. Uma personagem pode investir seus Pontos de Urdume de forma muito diferente de outra com o mesmo Desenvolvimento.

### Regra de incorporação

Todo investimento responde a uma pergunta simples:

"Onde, na história da personagem, isto passou a existir?"

Sem incorporação plausível, o investimento não é autorizado; os PU permanecem disponíveis até que a ficção justifique a mudança.

Isso vale especialmente para Matriz e Lavores. Um treinamento, mestre, experiência, descoberta, relação, crise ou transformação pode ser a incorporação.

### Ponto de Urdume e Feição

Investimentos podem alterar a Feição quando a mudança é narrativa e permanente.

Exemplos:

•  uma Origem pode ser reinterpretada depois de descobrir uma verdade sobre ela

•  um Ofício pode ganhar nova especialização

•  uma Convicção pode ser aprofundada ou substituída

•  um Limite pode ser atravessado, transformando sua natureza

•  uma Marca pode ser integrada ou evoluir

•  um Vínculo pode tornar-se parte central da trajetória.

Não existe custo universal para "melhorar Feição". O custo, quando houver, deve estar ligado à estrutura que efetivamente mudou.

### Ponto de Urdume não é recurso de emergência

Ponto de Urdume não pode ser gasto durante um teste para:

•  aumentar um dado

•  refazer uma rolagem

•  cancelar uma consequência

•  recuperar recurso

•  alterar retroativamente uma decisão.

Isso preserva a separação entre Desenvolvimento e o motor de cena.

### Cadeia definitiva de persistência

Resultado   ↓Consequência   ↓Resto   ↓Permanência   ├── Memória da Trama   └── Incorporação          ↓   Desenvolvimento

Resultado é leitura do Motor. Consequência é o que a situação recebe. Resto é o que fica disponível ou alterado. Permanência é o que continua verdadeiro. Incorporação é quando uma permanência passa a existir de maneira consolidada na personagem. Desenvolvimento mede a trajetória dessas mudanças.

Uma Condição é uma forma persistente de consequência, não sinônimo de toda consequência. Recurso perdido representa continuidade consumida. Marca é transformação permanente.

Recuperação é transformação de recomposição e depende da continuidade ficcional. Morte e Colapso são transformações críticas, não módulos de combate.

Reconhecimento funciona como permanência social: Desenvolvimento muda a pessoa; Reconhecimento muda o que o mundo espera dela.

### Autorização e ritmo de Desenvolvimento ~ esclarecimento

Há 20 avanços de 5% entre 0% e 100%; cada avanço concede 2 PU, num total de 40 PU. O percentual não é gasto nem convertido em bônus: representa trajetórias incorporadas. Gastos de PU requerem momento ficcional de aprendizado, prática, relação ou transformação; não se compra uma capacidade incompatível com a história apenas porque a reserva permite.

A passagem de Matriz d12 para d20 (7 PU) exige um Marco transcendente e incorporação irreversível explícitos, além do valor em PU. A transição também não pode ser alcançada por Proveito ordinário ou simples Forçar. Alinhavo d12 representa teto ordinário; seu acesso a d20 exige efeito extraordinário específico, não compra automática de uma quinta categoria.

O livro não impõe quantidade fixa de Marcos por sessão: um Marco de Desenvolvimento depende de transformação reconhecida, não de presença, combate ou XP genérico. A soma final permanece limitada a 100% e 40 PU.

## O Resto ~ onde a cena continua respirando

Depois de um encontro decisivo, pergunte: o que mudou? E, apenas quando necessário: o que dessa mudança ainda importa? A primeira resposta descreve a consequência imediata. A segunda determina se houve Resto a registrar. O sistema não premia o preenchimento de fichas; registra continuidades reais. Uma fechadura destruída, uma dívida assumida ou uma testemunha desacreditada podem atravessar várias cenas sem que haja novo dado associado a elas.

[1365 TABLE]

Evento | Resultado | Resto possível | Persistência legítima

Porta forçada | Acesso ao depósito | Fechadura inutilizada | Perseguidores podem atravessar depois

Depoimento obtido | Informação disponível | Testemunha exposta | Um vínculo passa a sofrer cobrança

Selo refeito | Manifestação temporariamente contida | Novo ponto de manutenção | A instituição assume obrigação duradoura

Ancorar um Limite | Consequência redirecionada | Âncora Abalada | Uma escolha posterior deve Reassentá-la

### Memória da Trama e Incorporação não são a mesma coisa

Memória da Trama registra uma transformação que continua verdadeira na rede de acontecimentos: um documento circula, uma comunidade recorda, um Selo muda o acesso a determinado lugar. Incorporação exige que a transformação alcance a pessoa e integre sua Feição, suas práticas ou capacidades por mecanismo permitido. Uma memória pública não é automaticamente um Lavor, e conhecer um efeito não concede acesso a uma Trama.

### Não reduzir dramas a tabelas

A tabela de estados tem função verificável, mas o sistema não determina a intensidade moral de um acontecimento por seu número. Em TdV, uma promessa quebrada pode alterar mais o futuro de uma personagem do que três pontos de dano. A mecânica identifica como a escolha atravessa a situação. A literatura e a interpretação mostram por que essa travessia importa.

PARTE VI
