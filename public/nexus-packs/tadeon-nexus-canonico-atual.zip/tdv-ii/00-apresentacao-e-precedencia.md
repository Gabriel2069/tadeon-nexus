---
title: "TdV II · Apresentação e precedência"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "Apresentação e precedência", "text_extraction": true}
---

> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

TESSITURA DO VAZIO

LIVRO DE REGRAS

Descobertas ~ preços ~ costuras

Trilogia do Anterior ~ Livro II

Gabriel Tadeu2026

“Quando o Vazio temeu, o Medo tomou forma.Quando o Vazio desejou compreender o que havia feito, nasceu o Conhecimento.Entre ambos, o Tempo abriu distância suficiente para que um mundo coubesse.”

## Prólogo ~ A forma do que permanece

Há coisas que continuam porque ninguém as tocou. Outras, porque alguém as sustentou quando teriam se desfeito. Entre ambas, o mundo atravessa seus dias: uma cidade reconhece o caminho dos rios; uma filha identifica a voz da mãe depois de anos; uma porta fechada guarda a ausência de quem partiu. Nada disso é imóvel. Permanecer não é recusar a mudança — é conseguir atravessá-la sem perder inteiramente o sentido.

Em Arden, a realidade tem a forma de uma Tessitura. O que chamamos matéria, lembrança, juramento, corpo e acontecimento nasce de relações suficientemente estáveis para serem reconhecidas. Cada uma dessas relações pode ser pensada como um Fio. Fios se aproximam, se afastam, se cruzam, carregam tensões diferentes e compõem Malhas. Quando alguém intervém, não age sobre um cenário indiferente. Toca uma organização que oferece resistência, memória e possibilidades próprias.

Este livro não transforma essa imagem em um vocabulário vazio. Ela organiza seus procedimentos. A Feição declara que continuidades tornam uma pessoa reconhecível. As Matrizes e os Alinhavos descrevem o que essa pessoa é capaz de fazer. O Motor encontra a intenção com a situação; a Costura faz partes diferentes sustentarem uma operação; a Canalização toca relações profundas; a Selagem fixa uma continuidade; a Transformação registra aquilo que mudou e aquilo que ainda poderá responder.

As personagens não precisam nascer extraordinárias. Podem entrar no mundo com poucas certezas, uma habilidade aprendida com esforço e um vínculo que prefeririam não arriscar. O extraordinário aparece quando as relações que sustentavam essas certezas revelam profundidades que ninguém havia percebido. Nesse instante, a pergunta central não é se a personagem se tornará poderosa. É o que estará disposta a preservar, alterar ou perder.

Você age. A Tessitura responde. Algo permanece.

### Da primeira edição ao TdV II

O primeiro Livro de Regras mostrou TdV como um jogo de descobertas e preços. Essa premissa permanece. A edição II substitui a mecânica antiga por uma arquitetura de Pessoa, Ação, Situação e Transformação, atravessada por Relação. Conceitos anteriores — antigos atributos, perícias, sanidade, Rank universal, poderes não integrados e nomenclaturas em desuso — pertencem à história de desenvolvimento, não a regras concorrentes. Conservamos a intenção literária, a atenção ao humano e a importância das consequências; atualizamos a forma pela qual a mesa compartilha essas decisões.

### Que livro está em suas mãos

Este é o núcleo normativo completo do TdV II v2.0: ensina a criar personagens, decidir ações, administrar cenas, relações e transformações, utilizar a expressão extraordinária e preparar o mundo. Não promete catalogar todo Lavor, Trama, Fragmento, criatura ou lugar de Arden. Esses repertórios expandem o sistema sem substituir seu Motor. As situações que uma regra não nomeia devem ser resolvidas pela gramática comum e pela permissão ficcional, não por bônus improvisados.

### Três maneiras de ler

•  Primeira leitura: acompanhe as notas narrativas e as seções de operação; comece com Pessoa, Motor e Situação.

•  Durante a sessão: consulte os procedimentos destacados e o Apêndice B; não precisa reler a cosmologia para agir.

•  Ao preparar conteúdo: percorra a Matriz de Derivação de Regras, verifique a relação central e identifique o Resto que pode atravessar cenas.

As figuras são esquemas didáticos. Elas não substituem os símbolos oficiais do Fio~Mestre nem representam, isoladamente, um mapa da cosmologia.

## Nota ao leitor ~ compromisso desta edição

A primeira edição apresentou um mundo capaz de responder às escolhas humanas. A segunda procura tornar essa resposta precisa à mesa. A intenção continua nas palavras; o procedimento deve estar ao alcance das mãos.

Este livro preserva a arquitetura e as mecânicas estruturais do Documento Mestre v2.0. A ordem segue as dependências entre conceitos, os cálculos corrigidos são indicados nas referências e os procedimentos antes implícitos aparecem junto das regras a que pertencem. Uma especialização somente altera o procedimento comum quando declara sua exceção.

Regra fundamental: role apenas quando a incerteza e o resultado puderem mudar a situação. Se uma ação é possível e segura dadas competência, acesso e tempo, ela acontece sem teste. Se existe risco relevante, a mesa utiliza os mesmos dois Fios para qualquer tipo de conflito.

Você age. A Tessitura responde. Algo permanece.

## Como consultar esta edição

O corpo principal apresenta a arquitetura e suas aplicações; os Apêndices A a D reúnem probabilidades, consulta rápida, precedência e critérios de autoria. Os números de capítulos das versões anteriores não são remissões válidas nesta edição.

Convenção: quando um procedimento comum se encontra com uma condição específica de Trama, Lavor, Fragmento ou ameaça, a exceção deve estar escrita explicitamente. Exemplos iluminam a regra; não autorizam exceções silenciosas.

## Sumário

PARTE 0
